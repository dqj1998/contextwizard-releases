function getMessage(key) {
  if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
    return chrome.i18n.getMessage(key) || key;
  }
  return key;
}


// Apply i18n to all [data-i18n] and [data-i18n-placeholder] attributes
function applyI18nToDOM() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const message = getMessage(key);
    if (message !== key) {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = message;
      } else {
        el.textContent = message;
      }
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    const message = getMessage(key);
    if (message !== key) {
      el.placeholder = message;
    }
  });
}

function setupVideoCards() {
  document.querySelectorAll('.video-card').forEach(card => {
    card.addEventListener('click', () => {
      const videoUrl = card.getAttribute('data-video-url');
      if (videoUrl) {
        window.open(videoUrl, '_blank', 'noopener,noreferrer');
      }
    });
  });
}

// Initialize page when DOM is ready
function initWelcomePage() {
  // Set locale from extension context
  if (typeof chrome !== 'undefined' && chrome.i18n) {
    document.documentElement.lang = chrome.i18n.getUILanguage();
  }

  // Apply i18n translations
  applyI18nToDOM();

  setupVideoCards();
  initWelcomeNotifications();
}

function initWelcomeNotifications() {
  const statusEl = document.getElementById('welcomeNotificationStatus');
  const testBtn = document.getElementById('welcomeNotificationTestBtn');
  const enableBtn = document.getElementById('welcomeNotificationEnableBtn');
  const helpEl = document.getElementById('welcomeNotificationHelp');

  if (!statusEl) return;

  checkWelcomeNotificationPermission();

  testBtn?.addEventListener('click', () => {
    testBtn.disabled = true;
    testBtn.textContent = getMessage('notificationSending');
    chrome.notifications.create('test-notification-welcome', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'ContextWizard',
      message: 'Notifications are working! You will receive bookmark reminders here.',
      priority: 2
    }, (id) => {
      testBtn.disabled = false;
      testBtn.textContent = getMessage('notificationTestBtn');
      if (chrome.runtime.lastError) {
        statusEl.textContent = getMessage('notificationTestFailed') + chrome.runtime.lastError.message;
        statusEl.className = 'mt-4 rounded-xl px-4 py-3 text-sm font-medium bg-red-50 text-red-700 border border-red-200';
        helpEl?.classList.remove('hidden');
      } else {
        statusEl.textContent = getMessage('notificationTestSuccess');
        statusEl.className = 'mt-4 rounded-xl px-4 py-3 text-sm font-medium bg-green-50 text-green-700 border border-green-200';
      }
    });
  });

  enableBtn?.addEventListener('click', () => {
    enableBtn.disabled = true;
    chrome.permissions.request({ permissions: ['notifications'] }, (granted) => {
      enableBtn.disabled = false;
      if (granted) {
        checkWelcomeNotificationPermission();
      } else {
        helpEl?.classList.remove('hidden');
        statusEl.textContent = getMessage('notificationStatusDenied');
        statusEl.className = 'mt-4 rounded-xl px-4 py-3 text-sm font-medium bg-red-50 text-red-700 border border-red-200';
      }
    });
  });
}

function checkWelcomeNotificationPermission() {
  const statusEl = document.getElementById('welcomeNotificationStatus');
  const enableBtn = document.getElementById('welcomeNotificationEnableBtn');
  const helpEl = document.getElementById('welcomeNotificationHelp');

  if (!statusEl) return;

  chrome.permissions.contains({ permissions: ['notifications'] }, (hasPerm) => {
    if (hasPerm) {
      statusEl.textContent = getMessage('notificationStatusGranted');
      statusEl.className = 'mt-4 rounded-xl px-4 py-3 text-sm font-medium bg-green-50 text-green-700 border border-green-200';
      enableBtn?.classList.add('hidden');
      helpEl?.classList.add('hidden');
    } else {
      statusEl.textContent = getMessage('notificationStatusUnknown');
      statusEl.className = 'mt-4 rounded-xl px-4 py-3 text-sm font-medium bg-amber-50 text-amber-700 border border-amber-200';
      enableBtn?.classList.remove('hidden');
      helpEl?.classList.add('hidden');
    }
  });
}

// Wait for DOM to be fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initWelcomePage);
} else {
  initWelcomePage();
}
