(function () {
  'use strict';

  const SAFETY_MAX_CHARS = 8000;
  const MIN_SEGMENT_CHARS = 500;

  // ── 工具函数 ──

  function charCount(str) {
    return Array.from(str).length;
  }

  function truncate(str, maxChars) {
    if (charCount(str) <= maxChars) return str;
    try {
      const segmenter = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
      const segments = segmenter.segment(str);
      let result = '';
      for (const seg of segments) {
        if (charCount(result) + charCount(seg.segment) > maxChars) break;
        result += seg.segment;
      }
      return result;
    } catch {
      return Array.from(str).slice(0, maxChars).join('');
    }
  }

  function simpleTokenize(text) {
    if (!text) return [];
    const lower = text.toLowerCase();
    const tokens = [];

    if (typeof Intl !== 'undefined' && Intl.Segmenter) {
      const segmenter = new Intl.Segmenter(undefined, { granularity: 'word' });
      for (const seg of segmenter.segment(lower)) {
        if (seg.isWordLike) {
          tokens.push(seg.segment);
        }
      }
    } else {
      for (const word of lower.split(/[^\p{L}\p{N}]+/u)) {
        if (!word) continue;
        if (/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/.test(word)) {
          for (const char of word) {
            tokens.push(char);
          }
        } else {
          if (word.length < 2 && !/[\u4e00-\u9fff]/.test(word)) continue;
          tokens.push(word);
        }
      }
    }
    return tokens;
  }

  // ── Bookmark 与对话匹配 ──

  function normalizeUrl(url) {
    try {
      const u = new URL(url);
      u.hash = '';
      u.search = '';
      return u.href.replace(/\/$/, '');
    } catch {
      return url.replace(/\/$/, '');
    }
  }

  function findConversation(bookmark, conversations) {
    if (!bookmark.url) return null;
    const bmUrl = normalizeUrl(bookmark.url);
    if (!bmUrl) return null;
    // Prefer exact match; fall back to path-prefix match (not arbitrary substring)
    // to avoid false positives like "abc" matching "abcdef".
    let fallback = null;
    for (const c of conversations) {
      if (!c || !c.url) continue;
      const cUrl = normalizeUrl(c.url);
      if (cUrl === bmUrl) return c;
      if (!fallback) {
        // Accept if one URL is a path-prefix of the other (separated at a `/` boundary)
        const longer = cUrl.length > bmUrl.length ? cUrl : bmUrl;
        const shorter = cUrl.length > bmUrl.length ? bmUrl : cUrl;
        if (longer.startsWith(shorter) && (longer[shorter.length] === '/' || longer[shorter.length] === undefined)) {
          fallback = c;
        }
      }
    }
    if (fallback) return fallback;
    // Last resort: content-based matching.  If the bookmark's selected text (or content)
    // appears verbatim in any conversation message, that is strong evidence it belongs
    // to that conversation even when the URL differs (e.g. hash/query changed, page reload).
    const probeText = (bookmark.selectedText || bookmark.content || '').trim();
    if (probeText.length >= 20) {
      for (const c of conversations) {
        if (!c || !c.messages || c.messages.length === 0) continue;
        for (const m of c.messages) {
          if (m.content && m.content.includes(probeText)) {
            return c;
          }
        }
      }
    }
    return null;
  }

  // ── TF-IDF 评分 ──

  function computeTfIdfScores(query, segments) {
    const queryTokens = simpleTokenize(query);
    if (queryTokens.length === 0 || !segments || segments.length === 0) return segments ? segments.map(() => 0) : [];

    const N = segments.length;
    const segTokenLists = segments.map(s => simpleTokenize(s.text || ''));

    const df = {};
    for (const qt of queryTokens) {
      df[qt] = 0;
      for (const tokens of segTokenLists) {
        if (tokens.includes(qt)) df[qt]++;
      }
    }

    return segments.map((seg, i) => {
      const tokens = segTokenLists[i];
      let score = 0;
      for (const qt of queryTokens) {
        const tf = tokens.filter(t => t === qt).length;
        const idf = df[qt] > 0 ? Math.log(N / df[qt]) : 0;
        score += tf * idf;
      }
      return tokens.length > 0 ? score / Math.sqrt(tokens.length) : 0;
    });
  }

  // ── Label 生成 ──

  function getChunkLabel(bm) {
    if (bm?.annotation) return truncate(bm.annotation.replace(/\n/g, ' '), 60);
    if (bm?.content) return truncate(bm.content.replace(/\n/g, ' '), 60);
    if (bm?.selectedText) return bm.selectedText.slice(0, 60);
    if (bm?.url) {
      try { return new URL(bm.url).hostname; } catch { return bm.url.slice(0, 60); }
    }
    return 'Bookmark';
  }

  function buildLabel(bookmarks) {
    const labels = bookmarks.map(b => getChunkLabel(b)).filter(l => l && l !== 'Bookmark');
    const dedup = [...new Set(labels)];
    return dedup.length > 0 ? dedup.join(', ') : null;
  }

  // ── 构建对话文本 ──

  function formatMessages(msgs) {
    const parts = [];
    for (const msg of msgs) {
      const roleLabel = msg.role === 'user' ? 'User' : msg.role === 'assistant' ? 'Assistant' : msg.role || 'Unknown';
      parts.push(`${roleLabel}: ${msg.content || ''}`);
    }
    return parts.join('\n\n');
  }

  // ── 注入块格式化 ──

  function formatContextBlock(segments) {
    if (!segments || segments.length === 0) return '';
    const parts = [];
    for (const s of segments) {
      const label = s.label || `Conversation (${s.bookmarkIds.length} bookmark${s.bookmarkIds.length > 1 ? 's' : ''})`;
      parts.push(`[Bookmark: ${label}]`);
      parts.push(s.text);
      parts.push('---');
    }
    return parts.join('\n');
  }

  // ── 主入口 ──

  function extractForSession(query, bookmarks, conversations, safetyMax) {
    if (!bookmarks || bookmarks.length === 0) {
      return { chunks: [], contextBlock: '', totalChars: 0 };
    }
    if (!query || query.trim().length === 0) {
      return { chunks: [], contextBlock: '', totalChars: 0 };
    }
    safetyMax = safetyMax || SAFETY_MAX_CHARS;

    // 1. 按 conversation URL 分组
    const convMap = new Map(); // url -> { bookmarks[], conv }
    const orphanBookmarks = [];

    for (const bm of bookmarks) {
      const conv = findConversation(bm, conversations);
      if (conv) {
        if (!convMap.has(conv.url)) {
          convMap.set(conv.url, { bookmarks: [], conv });
        }
        convMap.get(conv.url).bookmarks.push(bm);
      } else {
        orphanBookmarks.push(bm);
      }
    }

    // 2. 构建 segments
    const segments = [];
    const processedBookmarkIds = new Set(); // Track bookmarks that produced segments

    // 2a. Conversation segments
    for (const { bookmarks: convBms, conv } of convMap.values()) {
      const allMessages = conv.messages || [];
      const indices = convBms.map(b => b.messageIndex).filter(i => i != null && i < allMessages.length);

      let msgs;
      let minIdx;
      let maxIdx;

      if (indices.length === 0) {
        // No valid messageIndex — use the full conversation (up to first 20 messages as context)
        if (allMessages.length === 0) {
          // Conversation truly has no messages — fall back to individual bookmark text
          for (const bm of convBms) {
            const text = bm.selectedText || bm.content || bm.annotation || '';
            if (!text) continue;
            segments.push({
              convUrl: null,
              bookmarkIds: [bm.id],
              label: getChunkLabel(bm),
              text,
              minIdx: null,
              maxIdx: null,
              totalMessages: 1,
              _conv: null,
            });
            processedBookmarkIds.add(bm.id);
          }
          continue;
        }
        minIdx = 0;
        maxIdx = Math.min(allMessages.length - 1, 19);
        msgs = allMessages.slice(minIdx, maxIdx + 1);
      } else {
        minIdx = Math.min(...indices);
        maxIdx = Math.max(...indices);
        msgs = allMessages.slice(minIdx, maxIdx + 1);

        if (msgs.length === 0) {
          // messageIndex values are out of bounds — use available messages from the start
          if (allMessages.length === 0) {
            for (const bm of convBms) {
              const text = bm.selectedText || bm.content || bm.annotation || '';
              if (!text) continue;
              segments.push({
                convUrl: null,
                bookmarkIds: [bm.id],
                label: getChunkLabel(bm),
                text,
                minIdx: null,
                maxIdx: null,
                totalMessages: 1,
                _conv: null,
              });
              processedBookmarkIds.add(bm.id);
            }
            continue;
          }
          minIdx = 0;
          maxIdx = Math.min(allMessages.length - 1, 19);
          msgs = allMessages.slice(minIdx, maxIdx + 1);
        }
      }

      // Create a single segment with all bookmarks in this conversation
      // Even bookmarks without messageIndex are included (they share the same conv URL)
      segments.push({
        convUrl: conv.url,
        bookmarkIds: convBms.map(b => b.id),
        label: buildLabel(convBms) || undefined,
        text: formatMessages(msgs),
        minIdx,
        maxIdx,
        totalMessages: msgs.length,
        _conv: conv,
      });
      for (const bm of convBms) {
        processedBookmarkIds.add(bm.id);
      }
    }

    // 2b. Orphan bookmarks (no conversation found)
    for (const bm of orphanBookmarks) {
      const text = bm.selectedText || bm.content || bm.annotation || '';
      if (!text) continue;
      segments.push({
        convUrl: null,
        bookmarkIds: [bm.id],
        label: getChunkLabel(bm),
        text,
        minIdx: null,
        maxIdx: null,
        totalMessages: 1,
        _conv: null,
      });
    }

    if (segments.length === 0) {
      return { chunks: [], contextBlock: '', totalChars: 0 };
    }

    // 3. TF-IDF 评分
    const scores = computeTfIdfScores(query, segments);
    for (let i = 0; i < segments.length; i++) {
      segments[i].score = scores[i];
    }

    // 4. 按得分降序
    segments.sort((a, b) => b.score - a.score);

    // 5. 优先扩展高分短 segment
    for (const seg of segments) {
      if (!seg._conv || charCount(seg.text) >= MIN_SEGMENT_CHARS) continue;

      const messages = seg._conv.messages || [];
      let nextIdx = seg.maxIdx + 1;
      const extraMsgs = [];

      while (nextIdx < messages.length && charCount(seg.text) + charCount(formatMessages(extraMsgs)) < MIN_SEGMENT_CHARS) {
        extraMsgs.push(messages[nextIdx]);
        nextIdx++;
      }

      if (extraMsgs.length > 0) {
        const extraText = formatMessages(extraMsgs);
        seg.text += '\n\n' + extraText;
        seg.maxIdx = nextIdx - 1;
        seg.totalMessages += extraMsgs.length;
      }
    }

    // 6. Safety cap
    const selected = [];
    let totalChars = 0;
    for (const seg of segments) {
      const cCount = charCount(seg.text);
      if (totalChars + cCount > safetyMax && selected.length > 0) break;
      if (totalChars === 0 && cCount > safetyMax) {
        seg.text = truncate(seg.text, safetyMax);
      }
      totalChars += charCount(seg.text);
      selected.push({
        bookmarkId: seg.bookmarkIds[0],
        bookmarkIds: seg.bookmarkIds,
        label: seg.label,
        score: seg.score,
        text: seg.text,
        charCount: charCount(seg.text),
      });
    }

    const contextBlock = formatContextBlock(selected);

    return { chunks: selected, contextBlock, totalChars };
  }

  globalThis.extractForSession = extractForSession;
})();
