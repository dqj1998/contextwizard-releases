/**
 * ContextWizard Cloud Sync — Diff Module
 *
 * Generates minimal diff payloads from the change tracker's changelog,
 * and applies incoming diffs with smart merge (Last-Write-Wins).
 *
 * Depends on: CloudSyncTracker
 */

/**
 * @typedef {Object} SyncDiff
 * @property {number} generatedAt - timestamp when diff was created
 * @property {number} sinceTimestamp - changes since this time
 * @property {Object} conversations - { upserted: [], deletedIds: [] }
 * @property {Object} bookmarks - { upserted: [], deletedIds: [] }
 * @property {Object} promptTemplates - { upserted: {}, deletedKeys: [] }
 * @property {Object} searchHistory - { items: [] }  (always full replace for simplicity)
 * @property {Object} settings - { platformSettings?, customPlatforms? } or null
 */

/**
 * Generate a diff payload based on the tracker's changelog.
 * Reads actual data from chrome.storage and filters to only changed items.
 *
 * @returns {Promise<SyncDiff>}
 */
async function generateDiff() {
  const Tracker = globalThis.CloudSyncTracker;
  if (!Tracker) throw new Error('CloudSyncTracker not loaded');

  const lastSyncedAt = await Tracker.getLastSyncedAt();
  const changelog = await Tracker.getChangesSinceLastSync();

  // If no changes, return empty diff
  if (changelog.length === 0) {
    return _emptyDiff(lastSyncedAt);
  }

  // Build sets of changed IDs per type
  const convChanges = await Tracker.getChangedIds('conversation');
  const bmChanges = await Tracker.getChangedIds('bookmark');
  const tmplChanges = await Tracker.getChangedIds('promptTemplate');

  // Check if settings or search history changed
  const hasSettingsChange = changelog.some(c => c.type === 'settings');
  const hasSearchChange = changelog.some(c => c.type === 'searchHistory');

  // Read current data from storage
  const data = await _getStorageData([
    'conversations', 'bookmarks', 'promptEditorTemplates',
    'searchHistory',
  ]);
  const syncData = await _getSyncData(['platformSettings', 'customPlatforms']);

  // Build conversations diff
  const conversations = { upserted: [], deletedIds: [] };
  if (convChanges.upserted.size > 0 || convChanges.deleted.size > 0) {
    const allConvs = data.conversations || [];
    for (const conv of allConvs) {
      const key = `${conv.platform}::${conv.id}`;
      if (convChanges.upserted.has(key)) {
        conversations.upserted.push(conv);
      }
    }
    conversations.deletedIds = Array.from(convChanges.deleted);
  }

  // Build bookmarks diff
  const bookmarks = { upserted: [], deletedIds: [] };
  if (bmChanges.upserted.size > 0 || bmChanges.deleted.size > 0) {
    const allBm = data.bookmarks || [];
    for (const bm of allBm) {
      if (bmChanges.upserted.has(bm.id)) {
        bookmarks.upserted.push(bm);
      }
    }
    bookmarks.deletedIds = Array.from(bmChanges.deleted);
  }

  // Build prompt templates diff
  const promptTemplates = { upserted: {}, deletedKeys: [] };
  if (tmplChanges.upserted.size > 0 || tmplChanges.deleted.size > 0) {
    const allTmpls = data.promptEditorTemplates || {};
    for (const [key, val] of Object.entries(allTmpls)) {
      if (tmplChanges.upserted.has(key)) {
        promptTemplates.upserted[key] = val;
      }
    }
    promptTemplates.deletedKeys = Array.from(tmplChanges.deleted);
  }

  // Search history — send full list if changed (small data, not worth diffing)
  const searchHistory = hasSearchChange
    ? { items: data.searchHistory || [] }
    : null;

  // Settings
  const settings = hasSettingsChange
    ? {
        platformSettings: syncData.platformSettings || {},
        customPlatforms: syncData.customPlatforms || [],
      }
    : null;

  return {
    generatedAt: Date.now(),
    sinceTimestamp: lastSyncedAt,
    conversations,
    bookmarks,
    promptTemplates,
    searchHistory,
    settings,
  };
}

/**
 * Generate a full snapshot of all data (for initial sync or full push).
 * @returns {Promise<Object>}
 */
async function generateFullSnapshot() {
  const data = await _getStorageData([
    'conversations', 'bookmarks', 'promptEditorTemplates',
    'promptEditorReplaceHistory', 'searchHistory',
  ]);
  const syncData = await _getSyncData(['platformSettings', 'customPlatforms']);

  return {
    generatedAt: Date.now(),
    sinceTimestamp: 0,
    conversations: data.conversations || [],
    bookmarks: data.bookmarks || [],
    promptTemplates: data.promptEditorTemplates || {},
    replaceHistory: data.promptEditorReplaceHistory || {},
    searchHistory: data.searchHistory || [],
    platformSettings: syncData.platformSettings || {},
    customPlatforms: syncData.customPlatforms || [],
  };
}

/**
 * Apply a diff payload to local storage (merge, LWW).
 * @param {SyncDiff} diff
 * @returns {Promise<{applied: boolean, stats: Object}>}
 */
async function applyDiff(diff) {
  if (!diff) return { applied: false, stats: {} };

  const stats = {
    conversationsAdded: 0,
    conversationsUpdated: 0,
    conversationsDeleted: 0,
    bookmarksAdded: 0,
    bookmarksUpdated: 0,
    bookmarksDeleted: 0,
    templatesUpdated: 0,
    settingsUpdated: false,
  };

  const data = await _getStorageData([
    'conversations', 'bookmarks', 'promptEditorTemplates', 'searchHistory',
  ]);

  const updateObj = {};

  // ── Conversations ──
  if (diff.conversations) {
    const existing = data.conversations || [];
    const convMap = new Map();

    // Index existing by platform::id
    for (const c of existing) {
      convMap.set(`${c.platform}::${c.id}`, c);
    }

    // Apply upserts (LWW: newer lastUpdated wins)
    for (const incoming of (diff.conversations.upserted || [])) {
      const key = `${incoming.platform}::${incoming.id}`;
      const local = convMap.get(key);
      if (!local) {
        convMap.set(key, incoming);
        stats.conversationsAdded++;
      } else if ((incoming.lastUpdated || 0) >= (local.lastUpdated || 0)) {
        convMap.set(key, incoming);
        stats.conversationsUpdated++;
      }
    }

    // Apply deletes
    for (const deletedKey of (diff.conversations.deletedIds || [])) {
      if (convMap.has(deletedKey)) {
        convMap.delete(deletedKey);
        stats.conversationsDeleted++;
      }
    }

    let merged = Array.from(convMap.values());
    // Cap at 1000
    if (merged.length > 1000) {
      merged.sort((a, b) => (b.lastUpdated || 0) - (a.lastUpdated || 0));
      merged = merged.slice(0, 1000);
    }

    updateObj.conversations = merged;
  }

  // ── Bookmarks ──
  if (diff.bookmarks) {
    const existing = data.bookmarks || [];
    const bmMap = new Map();

    for (const bm of existing) {
      if (bm.id) bmMap.set(bm.id, bm);
    }

    for (const incoming of (diff.bookmarks.upserted || [])) {
      if (!incoming.id) continue;
      const local = bmMap.get(incoming.id);
      if (!local) {
        bmMap.set(incoming.id, incoming);
        stats.bookmarksAdded++;
      } else if ((incoming.updatedAt || incoming.createdAt || 0) >= (local.updatedAt || local.createdAt || 0)) {
        bmMap.set(incoming.id, incoming);
        stats.bookmarksUpdated++;
      }
    }

    for (const deletedId of (diff.bookmarks.deletedIds || [])) {
      if (bmMap.has(deletedId)) {
        bmMap.delete(deletedId);
        stats.bookmarksDeleted++;
      }
    }

    updateObj.bookmarks = Array.from(bmMap.values());
  }

  // ── Prompt Templates ──
  if (diff.promptTemplates) {
    const existing = data.promptEditorTemplates || {};
    const merged = { ...existing };

    for (const [key, val] of Object.entries(diff.promptTemplates.upserted || {})) {
      merged[key] = val;
      stats.templatesUpdated++;
    }

    for (const key of (diff.promptTemplates.deletedKeys || [])) {
      delete merged[key];
    }

    updateObj.promptEditorTemplates = merged;
  }

  // ── Search History ──
  if (diff.searchHistory && diff.searchHistory.items) {
    const existing = data.searchHistory || [];
    const mergedHistory = Array.from(
      new Set([...diff.searchHistory.items, ...existing])
    ).slice(0, 1000);
    updateObj.searchHistory = mergedHistory;
  }

  // Save to local storage
  if (Object.keys(updateObj).length > 0) {
    await _setStorageData(updateObj);
  }

  // ── Settings (sync storage) ──
  if (diff.settings) {
    const syncUpdate = {};
    if (diff.settings.platformSettings) {
      syncUpdate.platformSettings = diff.settings.platformSettings;
    }
    if (diff.settings.customPlatforms) {
      syncUpdate.customPlatforms = diff.settings.customPlatforms;
    }
    if (Object.keys(syncUpdate).length > 0) {
      await _setSyncData(syncUpdate);
      stats.settingsUpdated = true;
    }
  }

  return { applied: true, stats };
}

/**
 * Apply a full snapshot to local storage (used on first pull or full restore).
 * This completely replaces local data.
 * @param {Object} snapshot
 * @returns {Promise<{applied: boolean, stats: Object}>}
 */
async function applyFullSnapshot(snapshot) {
  if (!snapshot) return { applied: false, stats: {} };

  const updateObj = {
    conversations: snapshot.conversations || [],
    bookmarks: snapshot.bookmarks || [],
    promptEditorTemplates: snapshot.promptTemplates || {},
    searchHistory: snapshot.searchHistory || [],
  };

  if (snapshot.replaceHistory) {
    updateObj.promptEditorReplaceHistory = snapshot.replaceHistory;
  }

  await _setStorageData(updateObj);

  // Settings
  const syncUpdate = {};
  if (snapshot.platformSettings) {
    syncUpdate.platformSettings = snapshot.platformSettings;
  }
  if (snapshot.customPlatforms) {
    syncUpdate.customPlatforms = snapshot.customPlatforms;
  }
  if (Object.keys(syncUpdate).length > 0) {
    await _setSyncData(syncUpdate);
  }

  return {
    applied: true,
    stats: {
      conversations: (snapshot.conversations || []).length,
      bookmarks: (snapshot.bookmarks || []).length,
      templates: Object.keys(snapshot.promptTemplates || {}).length,
    },
  };
}

/**
 * Merge a full snapshot from cloud into local data.
 * Unlike applyFullSnapshot (full replace), this preserves local items not in the
 * cloud snapshot (local additions since the snapshot was taken). Used when an
 * existing device pulls a full snapshot, so no local data is lost.
 *
 * Merge rules:
 *   - Conversations / Bookmarks: union by id; cloud entry wins on conflict (newer timestamp)
 *   - Templates: union by key; cloud wins on conflict
 *   - Search history: union (deduplicated)
 *   - Settings (platformSettings, customPlatforms): cloud wins
 */
async function mergeFullSnapshot(snapshot) {
  if (!snapshot) return { applied: false, stats: {} };

  const data = await _getStorageData([
    'conversations', 'bookmarks', 'promptEditorTemplates', 'searchHistory',
  ]);

  const updateObj = {};

  // ── Conversations ──
  {
    const localMap = new Map();
    for (const c of (data.conversations || [])) {
      if (c.id) localMap.set(c.id, c);
    }
    for (const c of (snapshot.conversations || [])) {
      if (!c.id) continue;
      const local = localMap.get(c.id);
      // Cloud wins if it has equal or newer update timestamp
      if (!local ||
          (c.updatedAt || c.timestamp || 0) >= (local.updatedAt || local.timestamp || 0)) {
        localMap.set(c.id, c);
      }
    }
    updateObj.conversations = Array.from(localMap.values());
  }

  // ── Bookmarks ──
  {
    const localMap = new Map();
    for (const b of (data.bookmarks || [])) {
      if (b.id) localMap.set(b.id, b);
    }
    for (const b of (snapshot.bookmarks || [])) {
      if (!b.id) continue;
      const local = localMap.get(b.id);
      if (!local || (b.updatedAt || b.createdAt || 0) >= (local.updatedAt || local.createdAt || 0)) {
        localMap.set(b.id, b);
      }
    }
    updateObj.bookmarks = Array.from(localMap.values());
  }

  // ── Templates ──
  {
    const merged = { ...(data.promptEditorTemplates || {}) };
    for (const [k, v] of Object.entries(snapshot.promptTemplates || {})) {
      merged[k] = v; // cloud wins on conflict
    }
    updateObj.promptEditorTemplates = merged;
  }

  // ── Search history ──
  {
    const existing = data.searchHistory || [];
    const incoming = snapshot.searchHistory || [];
    updateObj.searchHistory = Array.from(new Set([...incoming, ...existing])).slice(0, 1000);
  }

  if (snapshot.replaceHistory) {
    updateObj.promptEditorReplaceHistory = snapshot.replaceHistory;
  }

  await _setStorageData(updateObj);

  // Settings (cloud wins)
  const syncUpdate = {};
  if (snapshot.platformSettings) syncUpdate.platformSettings = snapshot.platformSettings;
  if (snapshot.customPlatforms) syncUpdate.customPlatforms = snapshot.customPlatforms;
  if (Object.keys(syncUpdate).length > 0) await _setSyncData(syncUpdate);

  return {
    applied: true,
    stats: {
      conversations: updateObj.conversations.length,
      bookmarks: updateObj.bookmarks.length,
      templates: Object.keys(updateObj.promptEditorTemplates).length,
    },
  };
}

// ── Internal Storage Helpers ─────────────────────────────────

function _emptyDiff(sinceTimestamp) {
  return {
    generatedAt: Date.now(),
    sinceTimestamp,
    conversations: { upserted: [], deletedIds: [] },
    bookmarks: { upserted: [], deletedIds: [] },
    promptTemplates: { upserted: {}, deletedKeys: [] },
    searchHistory: null,
    settings: null,
  };
}

function _getStorageData(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

function _setStorageData(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

function _getSyncData(keys) {
  return new Promise((resolve) => {
    chrome.storage.sync.get(keys, resolve);
  });
}

function _setSyncData(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.set(data, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}

// Export
if (typeof globalThis !== 'undefined') {
  globalThis.CloudSyncDiff = {
    generateDiff,
    generateFullSnapshot,
    applyDiff,
    applyFullSnapshot,
    mergeFullSnapshot,
  };
}
