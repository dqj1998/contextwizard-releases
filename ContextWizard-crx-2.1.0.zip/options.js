// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Options page script
let platformSettings = {};
let customPlatforms = [];
let pendingPlan = null;
const EXTENSION_VERSION = globalThis.chrome?.runtime?.getManifest?.().version || '1.1.9';

// Key sync status polling
let keyStatusPollingInterval = null;
let keyStatusCheckCount = 0;
const KEY_STATUS_CHECK_INTERVAL = 10000; // Check every 10 seconds
const KEY_STATUS_MAX_CHECKS = 30; // Check for up to 300 seconds (5 minutes, Chrome Sync can be slow)

const getMessage = (key, fallback, substitutions) => {
  if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
    const localized = chrome.i18n.getMessage(key, substitutions);
    if (localized) {
      return formatLegacyPlaceholders(localized, substitutions);
    }
  }
  if (typeof fallback === 'function') {
    return fallback(Array.isArray(substitutions) ? substitutions : []);
  }
  return fallback;
};

function formatLegacyPlaceholders(message, substitutions) {
  if (!message || typeof message !== 'string' || substitutions == null) {
    return message;
  }
  if (!message.includes('{')) {
    return message;
  }

  const values = Array.isArray(substitutions) ? substitutions : [substitutions];
  return message.replaceAll(/\{(\d+)\}/g, (match, index) => {
    const value = values[Number(index)];
    return value === undefined ? match : String(value);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const versionElement = document.getElementById('extensionVersion');
  if (versionElement) {
    versionElement.textContent = EXTENSION_VERSION;
  }
  loadSettings();
  loadDataStats();
  setupEventListeners();
  loadI18n();
  initCloudSyncUI();
  initTermsModal();
  initNotificationSettings();

  if (location.hash) {
    const target = document.querySelector(location.hash);
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
});

// Re-check subscription status when the user returns to this tab (e.g. after Stripe Checkout)
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    _refreshCloudSyncStatus();
  }
});

// Auto-refresh sync status when background auto-sync updates the timestamp
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes['cw_cloud_last_sync_at']) {
    _refreshCloudSyncStatus();
  }
  // Encryption key arrived via Chrome Sync — immediately re-check and trigger sync
  if (area === 'sync' && changes.cw_e2e_key) {

    _checkKeyStatus();
  }
});

// Load platform settings
function loadSettings() {
  chrome.storage.sync.get(['platformSettings', 'customPlatforms'], (result) => {
    platformSettings = result.platformSettings || {};
    customPlatforms = result.customPlatforms || [];
    
    renderPlatformList();
    renderCustomPlatformList();
  });
}

// Load data statistics
function loadDataStats() {
  chrome.storage.local.get(['conversations'], (result) => {
    const conversations = result.conversations || [];
    const totalElement = document.getElementById('totalConversations');
    if (totalElement) {
      totalElement.textContent = conversations.length;
    }
    
    // Calculate storage size
    chrome.storage.local.getBytesInUse(null, (bytes) => {
      const storageElement = document.getElementById('storageUsed');
      if (storageElement) {
        storageElement.textContent = formatStorageSize(bytes);
      }
    });
  });
}

function formatStorageSize(bytes = 0) {
  if (!Number.isFinite(bytes) || bytes <= 0) {
    return '0 KB';
  }
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  let precision = 2;
  if (index === 0) {
    precision = 0;
  } else if (size >= 100) {
    precision = 0;
  } else if (size >= 10) {
    precision = 1;
  }
  return `${size.toFixed(precision)} ${units[index]}`;
}

// Render platform list
function renderPlatformList() {
  const container = document.getElementById('platformList');
  if (!container) {
    return;
  }
  container.innerHTML = '';
  
  for (const [domain, platform] of Object.entries(PLATFORMS)) {
    const isEnabled = platformSettings[domain]?.enabled !== false;
    
    const item = document.createElement('div');
    item.className = 'platform-item';
    item.innerHTML = `
      <div class="platform-info" data-domain="${domain}">
        <div class="platform-color" style="background-color: ${platform.color}"></div>
        <div class="platform-details">
          <div class="platform-name">${platform.name}</div>
          <div class="platform-domain">${domain}</div>
        </div>
      </div>
      <label class="toggle-switch">
        <input type="checkbox" ${isEnabled ? 'checked' : ''} data-domain="${domain}">
        <span class="toggle-slider"></span>
      </label>
    `;
    
    // Add click event to open platform in new tab
    const platformInfo = item.querySelector('.platform-info');
    platformInfo.style.cursor = 'pointer';
    platformInfo.addEventListener('click', () => {
      chrome.tabs.create({ url: `https://${domain}` });
    });
    
    const toggle = item.querySelector('input[type="checkbox"]');
    toggle.addEventListener('change', (e) => {
      togglePlatform(domain, e.target.checked);
    });
    
    container.appendChild(item);
  }
}

// Render custom platform list
function renderCustomPlatformList() {
  const container = document.getElementById('customPlatformList');
  if (!container) {
    return;
  }
  container.innerHTML = '';
  
  if (customPlatforms.length === 0) {
    const emptyMessage = getMessage('customPlatformsEmptyState', 'No custom platforms added yet');
    container.innerHTML = `<p class="empty-message">${escapeHtml(emptyMessage)}</p>`;
    return;
  }
  
  for (const [index, platform] of customPlatforms.entries()) {
    const item = document.createElement('div');
    item.className = 'custom-platform-item';
    item.innerHTML = `
      <div class="platform-info">
        <div class="platform-details">
          <div class="platform-name">${escapeHtml(platform.name)}</div>
          <div class="platform-domain">${escapeHtml(platform.urlPattern)}</div>
        </div>
      </div>
      <button class="btn-delete-custom" data-index="${index}">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
          <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z"/>
          <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
        </svg>
      </button>
    `;

    const platformInfo = item.querySelector('.platform-info');
    platformInfo.style.cursor = 'pointer';
    platformInfo.title = platform.urlPattern;
    platformInfo.addEventListener('click', () => {
      const targetUrl = getPatternBaseUrl(platform.urlPattern);
      if (targetUrl) {
        chrome.tabs.create({ url: targetUrl });
      }
    });
    
    item.querySelector('.btn-delete-custom').addEventListener('click', () => {
      deleteCustomPlatform(index);
    });
    
    container.appendChild(item);
  }
}

// Setup event listeners
function setupEventListeners() {
  // Add custom platform
  const addCustomBtn = document.getElementById('addCustomBtn');
  if (addCustomBtn) {
    addCustomBtn.addEventListener('click', addCustomPlatform);
  }
  
  // Data management
  const exportBtn = document.getElementById('exportBtn');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportData);
  }

  const importBtn = document.getElementById('importBtn');
  const importFile = document.getElementById('importFile');
  if (importBtn && importFile) {
    importBtn.addEventListener('click', () => {
      importFile.click();
    });
    importFile.addEventListener('change', importData);
  }

  const clearBtn = document.getElementById('clearBtn');
  if (clearBtn) {
    clearBtn.addEventListener('click', clearAllData);
  }

  // Cloud Sync buttons
  const cloudSyncLoginBtn = document.getElementById('cloudSyncLoginBtn');
  if (cloudSyncLoginBtn) {
    cloudSyncLoginBtn.addEventListener('click', cloudSyncLogin);
  }
  const cloudSyncLogoutBtn = document.getElementById('cloudSyncLogoutBtn');
  if (cloudSyncLogoutBtn) {
    cloudSyncLogoutBtn.addEventListener('click', cloudSyncLogout);
  }
  const cloudSyncFullBtn = document.getElementById('cloudSyncFullBtn');
  if (cloudSyncFullBtn) {
    cloudSyncFullBtn.addEventListener('click', () => cloudSyncAction('cloudSync_fullSync'));
  }
  const cloudSyncMonthlyBtn = document.getElementById('cloudSyncMonthlyBtn');
  if (cloudSyncMonthlyBtn) {
    cloudSyncMonthlyBtn.addEventListener('click', () => {
      showTermsModal('monthly');
    });
  }
  const cloudSyncYearlyBtn = document.getElementById('cloudSyncYearlyBtn');
  if (cloudSyncYearlyBtn) {
    cloudSyncYearlyBtn.addEventListener('click', () => {
      showTermsModal('yearly');
    });
  }
  const cloudSyncRefreshStatusBtn = document.getElementById('cloudSyncRefreshStatusBtn');
  if (cloudSyncRefreshStatusBtn) {
    cloudSyncRefreshStatusBtn.addEventListener('click', () => {
      cloudSyncRefreshStatusBtn.textContent = getMessage('cloudSyncChecking', 'Checking...');
      cloudSyncRefreshStatusBtn.disabled = true;
      _refreshCloudSyncStatus();
      setTimeout(() => {
        cloudSyncRefreshStatusBtn.textContent = getMessage('cloudSyncRefreshStatus', 'Already paid? Refresh status');
        cloudSyncRefreshStatusBtn.disabled = false;
      }, 3000);
    });
  }
  const cloudSyncManageBtn = document.getElementById('cloudSyncManageBtn');
  if (cloudSyncManageBtn) {
    cloudSyncManageBtn.addEventListener('click', () => {
      cloudSyncManageBtn.disabled = true;
      cloudSyncManageBtn.textContent = getMessage('cloudSyncOpening', 'Opening...');
      chrome.runtime.sendMessage({ action: 'cloudSync_manageSubscription' }, (result) => {
        cloudSyncManageBtn.disabled = false;
        cloudSyncManageBtn.textContent = getMessage('cloudSyncManage', 'Manage Subscription');
        if (!result?.success) showToast(result?.error || getMessage('cloudSyncFailedPortal', 'Failed to open portal'), 'error');
      });
    });
  }
  const cloudSyncAddonBtn = document.getElementById('cloudSyncAddonBtn');
  if (cloudSyncAddonBtn) {
    cloudSyncAddonBtn.addEventListener('click', () => {
      cloudSyncAddonBtn.disabled = true;
      cloudSyncAddonBtn.textContent = getMessage('cloudSyncOpening', 'Opening...');
      chrome.runtime.sendMessage({ action: 'cloudSync_purchaseAddon', addonType: '5gb' }, (result) => {
        cloudSyncAddonBtn.disabled = false;
        cloudSyncAddonBtn.textContent = getMessage('cloudSyncAddon', '+5 GB Storage');
        if (!result?.success) showToast(result?.error || getMessage('cloudSyncFailedCheckout', 'Failed to open checkout'), 'error');
      });
    });
  }

  // Encryption Key Export / Import
  const exportKeyBtn = document.getElementById('cloudSyncExportKeyBtn');
  if (exportKeyBtn) {
    exportKeyBtn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'cloudSync_exportKey' }, (result) => {
        if (result?.success) {
          const display = document.getElementById('cloudSyncKeyDisplay');
          const input = document.getElementById('cloudSyncKeyInput');
          if (display && input) {
            input.value = result.key;
            input.readOnly = true;
            display.style.display = '';
          }
        } else {
          const exportErr = result?.error || '';
          if (exportErr.includes('NO_ENCRYPTION_KEY')) {
            showToast(getMessage('cloudSyncKeyNotFoundYet', 'No encryption key on this device yet. Wait for Chrome Sync to deliver it, or import it manually from another device.'), 'error');
          } else {
            showToast(exportErr || getMessage('cloudSyncExportFailed', 'Failed to export key'), 'error');
          }
        }
      });
    });
  }
  const copyKeyBtn = document.getElementById('cloudSyncKeyCopyBtn');
  if (copyKeyBtn) {
    copyKeyBtn.addEventListener('click', () => {
      const input = document.getElementById('cloudSyncKeyInput');
      if (input?.value) {
        navigator.clipboard.writeText(input.value).then(() => {
          showToast(getMessage('cloudSyncKeyCopied', 'Encryption key copied to clipboard'));
        });
      }
    });
  }
  const importKeyBtn = document.getElementById('cloudSyncImportKeyBtn');
  if (importKeyBtn) {
    importKeyBtn.addEventListener('click', () => {
      const display = document.getElementById('cloudSyncKeyDisplay');
      const input = document.getElementById('cloudSyncKeyInput');
      if (display && input) {
        input.value = '';
        input.readOnly = false;
        input.placeholder = getMessage('cloudSyncKeyPlaceholder', 'Paste encryption key here...');
        display.style.display = '';
        input.focus();

        // Replace copy button with an apply button temporarily
        const copyBtn = document.getElementById('cloudSyncKeyCopyBtn');
        if (copyBtn) {
          const origText = copyBtn.textContent;
          copyBtn.textContent = getMessage('cloudSyncApplyKey', '✓ Apply');
          copyBtn.onclick = () => {
            const keyValue = input.value.trim();
            if (!keyValue) {
              showToast(getMessage('cloudSyncKeyEmpty', 'Please paste a key first'), 'error');
              return;
            }
            chrome.runtime.sendMessage({ action: 'cloudSync_importKey', key: keyValue }, (result) => {
              if (result?.success) {
                showToast(getMessage('cloudSyncKeyImported', 'Encryption key imported! Try syncing again.'));
                display.style.display = 'none';
                input.readOnly = true;
              } else {
                showToast(result?.error || getMessage('cloudSyncInvalidKey', 'Invalid key'), 'error');
              }
              copyBtn.textContent = origText;
              copyBtn.onclick = null; // restore original listener
            });
          };
        }
      }
    });
  }

  // Open Chrome Sync Settings
  const openSyncSettingsBtn = document.getElementById('cloudSyncOpenSyncSettingsBtn');
  if (openSyncSettingsBtn) {
    openSyncSettingsBtn.addEventListener('click', _openChromeSyncSettings);
  }

  // Clear Cloud Data
  const clearCloudBtn = document.getElementById('cloudSyncClearCloudBtn');
  if (clearCloudBtn) {
    clearCloudBtn.addEventListener('click', () => {
      const confirmed = confirm(getMessage('cloudSyncClearConfirm1', 'Are you sure you want to fully reset cloud sync? This cannot be undone.'));
      if (!confirmed) return;
      
      const confirmed2 = confirm(getMessage('cloudSyncClearConfirm2', 'This will delete all cloud sync data, remove the current encryption key from this browser and Chrome Sync, and reset sync state. Your local data will remain. The next sync will generate a new key and upload local data again. Continue?'));
      if (!confirmed2) return;

      clearCloudBtn.disabled = true;
      clearCloudBtn.textContent = '...';
      
      chrome.runtime.sendMessage({ action: 'cloudSync_clearCloudData' }, (result) => {
        clearCloudBtn.disabled = false;
        clearCloudBtn.textContent = getMessage('cloudSyncClearCloud', '🗑️ Full Reset Cloud Sync');
        
        if (result?.success) {
          showToast(getMessage('cloudSyncClearSuccess', 'Cloud sync reset. A new key will be generated on the next sync.'));
          _refreshCloudSyncStatus();
        } else {
          showToast(result?.error || getMessage('cloudSyncResetFailed', 'Failed to reset cloud sync'), 'error');
        }
      });
    });
  }
}

// Toggle platform enabled/disabled
function togglePlatform(domain, enabled) {
  platformSettings[domain] = { enabled };
  
  chrome.storage.sync.set({ platformSettings }, () => {
    const platformName = PLATFORMS[domain].name;
    const message = enabled
      ? getMessage('toastPlatformEnabled', ([name]) => `${name} enabled`, [platformName])
      : getMessage('toastPlatformDisabled', ([name]) => `${name} disabled`, [platformName]);
    showToast(message);
  });
}

// Add custom platform
async function addCustomPlatform() {
  const nameInput = document.getElementById('customName');
  const urlInput = document.getElementById('customUrl');
  if (!nameInput || !urlInput) {
    return;
  }
  
  const name = nameInput.value.trim();
  const urlPattern = urlInput.value.trim();
  
  if (!name || !urlPattern) {
    showToast(getMessage('toastCustomFieldsMissing', 'Please fill in both fields'), 'error');
    return;
  }
  
  // Validate URL pattern
  if (!urlPattern.startsWith('http://') && !urlPattern.startsWith('https://')) {
    showToast(getMessage('toastCustomInvalidPattern', 'URL pattern must start with http:// or https://'), 'error');
    return;
  }
  
  const permissionGranted = await ensureHostPermissionForPattern(urlPattern);
  if (!permissionGranted) {
    return;
  }
  
  customPlatforms.push({
    name,
    urlPattern,
    enabled: true,
    requireDistinctUrl: true,
    selectors: {
      conversationTitle: 'h1',
      messageContainer: '[class*="message"]',
      userMessage: '[class*="user"]',
      assistantMessage: '[class*="assistant"], [class*="bot"]',
      messageText: 'p, div',
      conversationId: () => globalThis.location.pathname
    }
  });
  
  chrome.storage.sync.set({ customPlatforms }, () => {
    renderCustomPlatformList();
    nameInput.value = '';
    urlInput.value = '';
    showToast(getMessage('toastCustomAdded', 'Custom platform added successfully'));
  });
}

// Delete custom platform
function deleteCustomPlatform(index) {
  const confirmMessage = getMessage('toastCustomDeleteConfirm', 'Are you sure you want to delete this custom platform?');
  if (!confirm(confirmMessage)) {
    return;
  }
  
  customPlatforms.splice(index, 1);
  
  chrome.storage.sync.set({ customPlatforms }, () => {
    renderCustomPlatformList();
    showToast(getMessage('toastCustomDeleted', 'Custom platform deleted'));
  });
}

// Export data
function exportData() {
  chrome.storage.local.get(['conversations', 'searchHistory', 'promptEditorReplaceHistory', 'promptEditorTemplates', 'bookmarks'], (result) => {
    const data = {
      version: EXTENSION_VERSION,
      exportDate: new Date().toISOString(),
      conversations: result.conversations || [],
      platformSettings,
      customPlatforms,
      searchHistory: result.searchHistory || [],
      replaceHistory: result.promptEditorReplaceHistory || {},
      promptTemplates: result.promptEditorTemplates || {},
      bookmarks: result.bookmarks || []
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `contextwizard-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    showToast(getMessage('toastExportSuccess', 'Data exported successfully'));
  });
}

// Import data
async function importData(event) {
  const file = event.target.files[0];
  if (!file) return;

  try {
    const fileContents = await file.text();
    const data = JSON.parse(fileContents);
    
    if (!data.version || !data.conversations) {
      throw new Error(getMessage('toastImportInvalidFormat', 'Invalid data format'));
    }
    
    chrome.storage.local.get(['conversations', 'searchHistory', 'promptEditorReplaceHistory', 'promptEditorTemplates', 'bookmarks'], (result) => {
      const existingConversations = result.conversations || [];
      const uniqueConversations = mergeAndDeduplicateConversations(
        existingConversations,
        data.conversations
      );
      
      // Merge search history
      const existingSearchHistory = result.searchHistory || [];
      const importedSearchHistory = data.searchHistory || [];
      const mergedSearchHistory = Array.from(new Set([...importedSearchHistory, ...existingSearchHistory])).slice(0, 1000);
      
      // Merge replace history
      const existingReplaceHistory = result.promptEditorReplaceHistory || {};
      const importedReplaceHistory = data.replaceHistory || {};
      const mergedReplaceHistory = { ...existingReplaceHistory, ...importedReplaceHistory };
      
      // Keep only the latest 100 entries in replace history
      const replaceKeys = Object.keys(mergedReplaceHistory);
      if (replaceKeys.length > 100) {
        replaceKeys.slice(0, replaceKeys.length - 100).forEach(key => {
          delete mergedReplaceHistory[key];
        });
      }
      
      // Merge prompt templates
      const existingTemplates = result.promptEditorTemplates || {};
      const importedTemplates = data.promptTemplates || {};
      const mergedTemplates = { ...existingTemplates, ...importedTemplates };
      
      // Merge bookmarks (deduplicate by id, keep newer ones)
      const existingBookmarks = result.bookmarks || [];
      const importedBookmarks = data.bookmarks || [];
      const bookmarksMap = new Map();
      
      // Add existing bookmarks first
      existingBookmarks.forEach((bookmark) => {
        if (bookmark.id) {
          bookmarksMap.set(bookmark.id, bookmark);
        }
      });
      
      // Add/update with imported bookmarks (newer createdAt wins)
      importedBookmarks.forEach((bookmark) => {
        if (bookmark.id) {
          const existing = bookmarksMap.get(bookmark.id);
          if (!existing || (bookmark.createdAt || 0) > (existing.createdAt || 0)) {
            bookmarksMap.set(bookmark.id, bookmark);
          }
        }
      });
      
      const mergedBookmarks = Array.from(bookmarksMap.values());
      
      const updateObj = {
        conversations: uniqueConversations,
        searchHistory: mergedSearchHistory,
        promptEditorReplaceHistory: mergedReplaceHistory,
        promptEditorTemplates: mergedTemplates,
        bookmarks: mergedBookmarks
      };
      
      chrome.storage.local.set(updateObj, () => {
        // Check for storage quota errors
        if (chrome.runtime.lastError) {
          const error = chrome.runtime.lastError.message;
          if (error.includes('QUOTA_BYTES') || error.includes('quota')) {
            showToast(getMessage('storageQuotaExceeded', 'Storage quota exceeded. Data is too large. Try exporting and clearing old data first.'), 'error');
          } else {
            showToast(getMessage('saveFailedWithReason', ([reason]) => `Failed to save: ${reason}`, [error]), 'error');
          }
          return;
        }
        
        if (data.platformSettings) {
          chrome.storage.sync.set({ platformSettings: data.platformSettings });
        }
        if (data.customPlatforms) {
          chrome.storage.sync.set({ customPlatforms: data.customPlatforms });
        }
        
        loadSettings();
        loadDataStats();
        const importMessage = getMessage('toastImportSuccess', ([count]) => `Imported ${count} conversations`, [data.conversations.length.toString()]);
        showToast(importMessage);
      });
    });
  } catch (error) {
    const errorMessage = getMessage('toastImportFailed', ([message]) => `Failed to import data: ${message}`, [error.message]);
    showToast(errorMessage, 'error');
  }
  
  // Reset file input
  event.target.value = '';
}

// Clear all data
function clearAllData() {
  const confirmMessage = getMessage('toastClearAllConfirm', 'Are you sure you want to delete ALL conversations? This cannot be undone!');
  if (!confirm(confirmMessage)) {
    return;
  }
  
  chrome.storage.local.set({ 
    conversations: [],
    bookmarks: [],
    searchHistory: [],
    promptEditorReplaceHistory: {},
    promptEditorTemplates: {}
  }, () => {
    chrome.runtime.sendMessage({ action: 'updateBadge', conversations: [] }, () => {
      loadDataStats();
      showToast(getMessage('toastClearAllSuccess', 'All data cleared'));
    });
  });
}

// Show toast notification
function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  if (!toast) {
    return;
  }
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.className = 'toast';
  }, 3000);
}

// Escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function getPatternBaseUrl(pattern = '') {
  if (!pattern) {
    return '';
  }
  const trimmed = pattern.trim();
  const wildcardIndex = trimmed.indexOf('*');
  const base = wildcardIndex > -1 ? trimmed.slice(0, wildcardIndex) : trimmed;
  return base || trimmed;
}

// ── Notification Settings ────────────────────────────────────────

function initNotificationSettings() {
  const statusEl = document.getElementById('notificationStatus');
  const testBtn = document.getElementById('notificationTestBtn');
  const enableBtn = document.getElementById('notificationEnableBtn');
  const helpEl = document.getElementById('notificationHelp');

  if (!statusEl) return;

  checkNotificationPermission();

  testBtn?.addEventListener('click', () => {
    testBtn.disabled = true;
    testBtn.textContent = getMessage('notificationSending', 'Sending...');
    chrome.notifications.create('test-notification', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'ContextWizard',
      message: 'Notifications are working! You will receive bookmark reminders here.',
      priority: 2
    }, (id) => {
      testBtn.disabled = false;
      testBtn.textContent = getMessage('notificationTestBtn', 'Test Notification');
      if (chrome.runtime.lastError) {
        statusEl.textContent = getMessage('notificationTestFailed', 'Notification failed: ') + chrome.runtime.lastError.message;
        statusEl.className = 'notification-status denied';
        helpEl?.classList.remove('hidden');
      } else {
        statusEl.textContent = getMessage('notificationTestSuccess', 'Notification sent! Check your system notification area.');
        statusEl.className = 'notification-status granted';
      }
    });
  });

  enableBtn?.addEventListener('click', () => {
    enableBtn.disabled = true;
    chrome.permissions.request({ permissions: ['notifications'] }, (granted) => {
      enableBtn.disabled = false;
      if (granted) {
        checkNotificationPermission();
      } else {
        helpEl?.classList.remove('hidden');
        statusEl.textContent = getMessage('notificationStatusDenied', '✗ Notifications are blocked by the browser');
        statusEl.className = 'notification-status denied';
      }
    });
  });
}

function checkNotificationPermission() {
  const statusEl = document.getElementById('notificationStatus');
  const enableBtn = document.getElementById('notificationEnableBtn');
  const helpEl = document.getElementById('notificationHelp');

  if (!statusEl) return;

  // Check the actual chrome.notifications permission, not just Notification.permission
  chrome.permissions.contains({ permissions: ['notifications'] }, (hasPerm) => {
    if (hasPerm) {
      // Has permission in manifest, but test if it actually works
      statusEl.textContent = getMessage('notificationStatusGranted', '✓ Notifications are enabled');
      statusEl.className = 'notification-status granted';
      enableBtn?.classList.add('hidden');
      helpEl?.classList.add('hidden');
    } else {
      statusEl.textContent = getMessage('notificationStatusUnknown', '? Notification permission not yet granted');
      statusEl.className = 'notification-status unknown';
      enableBtn?.classList.remove('hidden');
      helpEl?.classList.add('hidden');
    }
  });
}

// ── Cloud Sync UI ────────────────────────────────────────────

function initCloudSyncUI() {
  chrome.runtime.sendMessage({ action: 'cloudSync_getUserInfo' }, (user) => {
    if (chrome.runtime.lastError || !user) {
      _showCloudSyncState('loggedOut');
      return;
    }
    _showCloudSyncState('loggedIn');
    _updateCloudSyncUser(user);
    _refreshCloudSyncStatus();

    // Check if user has never synced before
    chrome.runtime.sendMessage({ action: 'cloudSync_getSyncStatus' }, (syncStatus) => {
      if (!chrome.runtime.lastError && syncStatus && syncStatus.lastSyncedAt === 0) {

        // Start key status polling instead of immediate sync
        setTimeout(() => {
          startKeyStatusPolling();
        }, 1500); // Delay to let UI fully load first
      }
    });
  });
}

function cloudSyncLogin() {
  const btn = document.getElementById('cloudSyncLoginBtn');
  if (btn) btn.disabled = true;

  chrome.runtime.sendMessage({ action: 'cloudSync_login' }, (result) => {
    if (btn) btn.disabled = false;
    if (chrome.runtime.lastError) {
      showToast(getMessage('cloudSyncSignInFailedWithReason', ([reason]) => `Sign in failed: ${reason}`, [chrome.runtime.lastError.message]), 'error');
      return;
    }
    if (result?.success) {
      _showCloudSyncState('loggedIn');
      _updateCloudSyncUser(result.user);
      _refreshCloudSyncStatus();
      showToast(getMessage('cloudSyncSignedIn', 'Signed in successfully'));

      // Check if this is a first-time sync
      chrome.runtime.sendMessage({ action: 'cloudSync_getSyncStatus' }, (syncStatus) => {
        if (!chrome.runtime.lastError && syncStatus && syncStatus.lastSyncedAt === 0) {

          // Start key status polling
          setTimeout(() => {
            startKeyStatusPolling();
          }, 1000); // Slight delay to let UI update first
        }
      });
    } else {
      showToast(result?.error || getMessage('cloudSyncSignInFailed', 'Sign in failed'), 'error');
    }
  });
}

function cloudSyncLogout() {
  chrome.runtime.sendMessage({ action: 'cloudSync_logout' }, () => {
    stopKeyStatusPolling();
    _updateKeyStatusIndicator('hidden');
    _showChromeSyncWarning(false);
    _showCloudSyncState('loggedOut');
    showToast(getMessage('cloudSyncSignedOut', 'Signed out'));
  });
}

function cloudSyncAction(action) {
  // Stop key status polling when manual sync starts
  stopKeyStatusPolling();
  _updateKeyStatusIndicator('hidden');

  // Check if encryption key is available before starting sync
  chrome.runtime.sendMessage({ action: 'cloudSync_checkEncryptionKeyAvailability' }, (keyCheck) => {
    if (!chrome.runtime.lastError && keyCheck && !keyCheck.available) {
      // Key not available yet, restart key status polling and keep button disabled
      // Button title will explain why it's disabled
      startKeyStatusPolling();
      _setCloudSyncButtonsEnabled(false);
      return;
    }

    // Key is available or check failed, proceed with sync
    const progressDiv = document.getElementById('cloudSyncProgress');
    const progressBar = document.getElementById('cloudSyncProgressBar');
    const progressText = document.getElementById('cloudSyncProgressText');
    if (progressDiv) progressDiv.style.display = '';

    // Disable sync buttons during operation
    _setCloudSyncButtonsEnabled(false);

    chrome.runtime.sendMessage({ action }, (result) => {
      if (progressDiv) progressDiv.style.display = 'none';
      _setCloudSyncButtonsEnabled(true);

      if (chrome.runtime.lastError) {
        showToast(getMessage('cloudSyncSyncFailedWithReason', ([reason]) => `Sync failed: ${reason}`, [chrome.runtime.lastError.message]), 'error');
        return;
      }
      if (result?.success) {
        showToast(getMessage('cloudSyncSuccess', 'Sync completed'));
        _refreshCloudSyncStatus();
        // Refresh data stats since pull may have added data
        loadDataStats();
      } else {
        showToast(_formatCloudSyncError(result?.error), 'error');
      }
    });
  });
}

function _formatCloudSyncError(error) {
  const msg = String(error || '').trim();
  if (!msg) return 'Sync failed';

  if (msg.includes('ENCRYPTION_KEY_NOT_FOUND')) {
    return 'Encryption key not synced yet. Wait 1-2 minutes and retry. If still failing, check chrome://settings/syncSetup (same Google account + Extensions sync on).';
  }

  if (msg.includes('DECRYPTION_KEY_MISMATCH') || msg.includes('ENCRYPTION_KEY_MISMATCH')) {
    return 'Encryption key mismatch. Verify Chrome Sync settings first; if browsers use different Google accounts, use Export Key on old device and Import Key on this device.';
  }

  // Remove internal error codes for cleaner UX
  return msg.replace(/^[A-Z_]+:\s*/, '');
}

function _refreshCloudSyncStatus() {
  chrome.runtime.sendMessage({ action: 'cloudSync_getStatus' }, (status) => {
    if (chrome.runtime.lastError || !status) return;

    // Token may have expired — getStatus auto-logs out and returns loggedIn:false
    if (status.loggedIn === false) {
      const email = document.getElementById('cloudSyncUserEmail')?.textContent || '';
      _showCloudSyncState('loggedOut', { sessionExpired: true, email });
      return;
    }

    const isPro = status.status === 'active';
    const planSelectEl = document.getElementById('cloudSyncPlanSelect');
    const subscriptionEl = document.getElementById('cloudSyncSubscription');
    const controlsEl = document.getElementById('cloudSyncControls');
    const badgeEl = document.getElementById('cloudSyncPlanBadge');
    const storageInfoEl = document.getElementById('cloudSyncStorageInfo');
    const storageProgressEl = document.getElementById('cloudSyncStorageProgress');
    const keySectionEl = document.getElementById('cloudSyncKeySection');

    if (isPro) {
      if (planSelectEl) planSelectEl.style.display = 'none';
      if (subscriptionEl) subscriptionEl.style.display = '';
      if (controlsEl) controlsEl.style.display = '';
      if (keySectionEl) keySectionEl.style.display = '';
      if (badgeEl) {
        badgeEl.textContent = 'Pro';
        badgeEl.className = 'plan-badge plan-pro';
      }
      // Storage bar
      if (status.storage) {
        const usedMB = (status.storage.used || 0) / (1024 * 1024);
        const totalMB = (status.storage.total || 0) / (1024 * 1024);
        const pct = totalMB > 0 ? Math.min((usedMB / totalMB) * 100, 100) : 0;
        if (storageInfoEl) storageInfoEl.textContent = `${usedMB.toFixed(1)} MB / ${totalMB.toFixed(0)} MB`;
        if (storageProgressEl) storageProgressEl.style.width = `${pct}%`;
      }
    } else {
      // FREE: guide user to pick a plan
      if (planSelectEl) planSelectEl.style.display = '';
      if (subscriptionEl) subscriptionEl.style.display = 'none';
      if (controlsEl) controlsEl.style.display = 'none';
      if (keySectionEl) keySectionEl.style.display = 'none';
    }
  });

  // Update sync status
  chrome.runtime.sendMessage({ action: 'cloudSync_getSyncStatus' }, (syncStatus) => {
    if (chrome.runtime.lastError || !syncStatus) return;

    const lastSyncEl = document.getElementById('cloudSyncLastSync');
    const pendingEl = document.getElementById('cloudSyncPendingBadge');

    if (lastSyncEl) {
      if (syncStatus.lastSyncedAt > 0) {
        const date = new Date(syncStatus.lastSyncedAt);
        lastSyncEl.textContent = getMessage('cloudSyncLastSynced', ([time]) => `Last synced: ${time}`, [date.toLocaleString()]);
      } else {
        lastSyncEl.textContent = getMessage('cloudSyncNeverSynced', 'Never synced');
      }
    }

    if (pendingEl) {
      if (syncStatus.pendingChanges > 0) {
        pendingEl.textContent = getMessage('cloudSyncPending', ([n]) => `${n} pending`, [syncStatus.pendingChanges]);
        pendingEl.style.display = '';
      } else {
        pendingEl.style.display = 'none';
      }
    }

    // Check key status and update sync button state if never synced before
    if (syncStatus.lastSyncedAt === 0) {
      // Restart polling if not already active — fixes the dead state where
      // polling timed out but the key still hasn't arrived
      if (!keyStatusPollingInterval) {
        startKeyStatusPolling();
      } else {
        _checkKeyStatus();
      }
    } else {
      // Already synced before, hide key status and enable button
      _updateKeyStatusIndicator('hidden');
      _setCloudSyncButtonsEnabled(true);
    }
  });
}

function _showCloudSyncState(state, opts = {}) {
  const loggedOut = document.getElementById('cloudSyncLoggedOut');
  const loggedIn = document.getElementById('cloudSyncLoggedIn');
  if (loggedOut) loggedOut.style.display = state === 'loggedOut' ? '' : 'none';
  if (loggedIn) loggedIn.style.display = state === 'loggedIn' ? '' : 'none';

  const noticeEl = document.getElementById('cloudSyncSessionNotice');
  if (!noticeEl) return;
  if (state === 'loggedOut' && opts.sessionExpired) {
    const emailPart = opts.email ? ` (${opts.email})` : '';
    noticeEl.textContent = getMessage(
      'cloudSyncSessionExpired',
      ([e]) => `🔐 For security reasons, your session has expired${e}. Please sign in again.`,
      [emailPart]
    );
    noticeEl.classList.add('visible');
  } else {
    noticeEl.classList.remove('visible');
  }
}

function _updateCloudSyncUser(user) {
  if (!user) return;
  const nameEl = document.getElementById('cloudSyncUserName');
  const emailEl = document.getElementById('cloudSyncUserEmail');
  const avatarEl = document.getElementById('cloudSyncAvatar');
  if (nameEl) nameEl.textContent = user.name || '';
  if (emailEl) emailEl.textContent = user.email || '';
  if (avatarEl && user.avatarUrl) avatarEl.src = user.avatarUrl;
}

function _setCloudSyncButtonsEnabled(enabled) {
  const el = document.getElementById('cloudSyncFullBtn');
  if (el) {
    el.disabled = !enabled;
    if (enabled) {
      // Button is enabled, clear any custom title
      el.title = '';
    } else {
      // Button is disabled, check if it's due to key syncing
      const keyStatusEl = document.getElementById('cloudSyncKeyStatus');
      const isKeyWaiting = keyStatusEl && keyStatusEl.style.display !== 'none' && keyStatusEl.classList.contains('waiting');
      
      if (isKeyWaiting) {
        el.title = getMessage('cloudSyncKeyNotSynced', 'Encryption key syncing via Chrome. Please wait 1-2 minutes and try again.');
      } else {
        el.title = getMessage('cloudSyncSyncing', 'Sync in progress...');
      }
    }

  } else {
    console.warn('[CloudSync] Sync button element not found');
  }
}

function _updateKeyStatusIndicator(status, message) {
  const keyStatusEl = document.getElementById('cloudSyncKeyStatus');
  if (!keyStatusEl) return;

  if (status === 'waiting') {
    keyStatusEl.textContent = getMessage('cloudSyncKeyWaiting', 'Key syncing...') || message || 'Key syncing...';
    keyStatusEl.className = 'key-status waiting';
    keyStatusEl.style.display = '';
  } else if (status === 'available') {
    keyStatusEl.textContent = getMessage('cloudSyncKeyAvailable', 'Key synced') || message || 'Key synced';
    keyStatusEl.className = 'key-status available';
    keyStatusEl.style.display = '';
  } else if (status === 'hidden') {
    keyStatusEl.style.display = 'none';
  }
}

function _checkKeyStatus() {
  chrome.runtime.sendMessage({ action: 'cloudSync_checkEncryptionKeyAvailability' }, (keyCheck) => {
    if (chrome.runtime.lastError || !keyCheck) {
      console.error('[CloudSync] Failed to check encryption key:', chrome.runtime.lastError);
      return;
    }

    if (keyCheck.available) {
      if (keyCheck.willGenerate) {
        // First-time user on device A: key doesn't exist anywhere yet and will
        // be generated automatically during the first pushSync. Nothing to wait
        // for — just enable the button silently.

        _updateKeyStatusIndicator('hidden');
        _setCloudSyncButtonsEnabled(true);
        _showChromeSyncWarning(false);
        stopKeyStatusPolling();

        // Auto-trigger initial sync if Pro subscription is active and never synced.
        // This handles the "returns to options page after first payment" case where
        // visibilitychange fires but no sync has ever run.
        chrome.runtime.sendMessage({ action: 'cloudSync_getStatus' }, (status) => {
          if (!chrome.runtime.lastError && status?.status === 'active') {
            chrome.runtime.sendMessage({ action: 'cloudSync_getSyncStatus' }, (syncStatus) => {
              if (!chrome.runtime.lastError && syncStatus?.lastSyncedAt === 0) {

                setTimeout(() => cloudSyncAction('cloudSync_fullSync'), 500);
              }
            });
          }
        });
        return;
      }

      _updateKeyStatusIndicator('available');
      _setCloudSyncButtonsEnabled(true); // Enable sync button
      _showChromeSyncWarning(false); // Hide Chrome Sync warning
      stopKeyStatusPolling();

      // Trigger auto-sync if never synced before (key just arrived via Chrome Sync)
      chrome.runtime.sendMessage({ action: 'cloudSync_getSyncStatus' }, (syncStatus) => {
        if (!chrome.runtime.lastError && syncStatus && syncStatus.lastSyncedAt === 0) {

          showToast(getMessage('cloudSyncKeySynced', 'Encryption key synced! Starting sync...'), 'success');
          setTimeout(() => {
            cloudSyncAction('cloudSync_pullSync');
          }, 500);
        }
      });
    } else {

      _updateKeyStatusIndicator('waiting');
      _setCloudSyncButtonsEnabled(false); // Disable sync button while key is syncing
    }
  });
}

function startKeyStatusPolling() {
  if (keyStatusPollingInterval) {

    return; // Already polling
  }

  keyStatusCheckCount = 0;

  const overlay = document.getElementById('cloudSyncPollingOverlay');
  if (overlay) overlay.style.display = '';
  _checkKeyStatus(); // Check immediately

  keyStatusPollingInterval = setInterval(() => {
    keyStatusCheckCount++;

    if (keyStatusCheckCount >= KEY_STATUS_MAX_CHECKS) {

      stopKeyStatusPolling();
      // Key never arrived via Chrome Sync — show warning and enable manual options
      _updateKeyStatusIndicator('hidden');
      _setCloudSyncButtonsEnabled(true);
      _showChromeSyncWarning(true);
      showToast(
        getMessage('cloudSyncKeyTimeout',
          'Encryption key sync timed out. Chrome Sync may not be enabled, or this device may use a different Google account. You can enable Chrome Sync or use "Import Key" to transfer the key manually.'),
        'error'
      );
      return;
    }
    _checkKeyStatus();
  }, KEY_STATUS_CHECK_INTERVAL);
}

function stopKeyStatusPolling() {
  if (keyStatusPollingInterval) {
    clearInterval(keyStatusPollingInterval);
    keyStatusPollingInterval = null;

  }
  const overlay = document.getElementById('cloudSyncPollingOverlay');
  if (overlay) overlay.style.display = 'none';
}

function _showChromeSyncWarning(show) {
  const warningEl = document.getElementById('cloudSyncChromeSyncWarning');
  if (warningEl) warningEl.style.display = show ? '' : 'none';
}

function _openChromeSyncSettings() {
  // Try to open the sync setup page directly
  const isEdge = /Edg\//.test(navigator.userAgent);
  const url = isEdge ? 'edge://settings/profiles/sync' : 'chrome://settings/syncSetup';
  chrome.tabs.create({ url });
}

function mergeAndDeduplicateConversations(existing = [], incoming = []) {
  const merged = [...existing];
  const seen = new Set(existing.map(createConversationKey));
  for (const conversation of incoming) {
    const key = createConversationKey(conversation);
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    merged.push(conversation);
  }
  return merged;
}

function createConversationKey(conversation = {}) {
  const platform = conversation.platform || '';
  const id = conversation.id || '';
  return `${platform}::${id}`;
}

async function ensureHostPermissionForPattern(pattern = '') {
  if (!pattern) {
    return false;
  }

  const originPattern = buildOriginPattern(pattern);
  if (!originPattern) {
    showToast(getMessage('toastCustomInvalidPattern', 'Invalid URL pattern'), 'error');
    return false;
  }

  try {
    const hasPermission = await chrome.permissions.contains({ origins: [originPattern] });
    if (hasPermission) {
      return true;
    }
    
    const granted = await chrome.permissions.request({ origins: [originPattern] });
    if (!granted) {
      showToast(getMessage('toastCustomPermissionDenied', 'Permission required for this URL pattern'), 'error');
      return false;
    }

    return true;
  } catch (error) {
    showToast(getMessage('toastCustomPermissionDenied', `Permission request failed: ${error.message}`), 'error');
    return false;
  }
}

function buildOriginPattern(pattern = '') {
  const trimmed = pattern.trim();
  if (!trimmed || !/^https?:\/\//i.test(trimmed)) {
    return '';
  }

  try {
    const cleaned = trimmed.includes('*') ? trimmed.replace(/\*/g, 'x') : trimmed;
    const url = new URL(cleaned);
    return `${url.protocol}//${url.host}/*`;
  } catch (error) {
    return '';
  }
}

// Load internationalization
function loadI18n() {
  const title = globalThis.chrome?.i18n?.getMessage('settingsTitle');
  if (title) {
    document.title = title;
  }

  for (const element of document.querySelectorAll('[data-i18n]')) {
    applyMessage(element, element.dataset.i18n, (target, message) => {
      target.textContent = message;
    });
  }

  for (const element of document.querySelectorAll('[data-i18n-placeholder]')) {
    applyMessage(element, element.dataset.i18nPlaceholder, (target, message) => {
      target.placeholder = message;
    });
  }

  for (const element of document.querySelectorAll('[data-i18n-title]')) {
    applyMessage(element, element.dataset.i18nTitle, (target, message) => {
      target.title = message;
    });
  }

  for (const element of document.querySelectorAll('[data-i18n-aria-label]')) {
    applyMessage(element, element.dataset.i18nAriaLabel, (target, message) => {
      target.setAttribute('aria-label', message);
    });
  }
}

function applyMessage(element, key, applyFn) {
  if (!key || typeof chrome === 'undefined' || !chrome.i18n) {
    return;
  }
  const message = chrome.i18n.getMessage(key);
  if (message) {
    applyFn(element, message);
  }
}

// Expose pure helpers for tests
if (typeof globalThis !== 'undefined') {
  globalThis.ContextWizardOptionsTestHooks = {
    formatStorageSize,
    getPatternBaseUrl,
    mergeAndDeduplicateConversations,
    createConversationKey,
    buildOriginPattern,
    formatLegacyPlaceholders
  };
}

// Terms Modal Functions
function initTermsModal() {
  const termsModal = document.getElementById('termsModal');
  const termsCheckbox = document.getElementById('termsCheckbox');
  const termsConfirmBtn = document.getElementById('termsConfirmBtn');
  const termsCancelBtn = document.getElementById('termsCancelBtn');
  const termsCloseBtn = document.getElementById('termsCloseBtn');

  if (!termsModal || !termsCheckbox || !termsConfirmBtn || !termsCancelBtn || !termsCloseBtn) {
    return;
  }

  termsCheckbox.addEventListener('change', () => {
    termsConfirmBtn.disabled = !termsCheckbox.checked;
  });

  termsConfirmBtn.addEventListener('click', () => {
    if (!pendingPlan) return;
    termsModal.close();
    executeSubscription(pendingPlan);
    pendingPlan = null;
  });

  termsCancelBtn.addEventListener('click', () => {
    termsModal.close();
    pendingPlan = null;
    resetPlanButtons();
  });

  termsCloseBtn.addEventListener('click', () => {
    termsModal.close();
    pendingPlan = null;
    resetPlanButtons();
  });

  termsModal.addEventListener('click', (e) => {
    if (e.target === termsModal) {
      termsModal.close();
      pendingPlan = null;
      resetPlanButtons();
    }
  });

  // Add hidden class when modal closes
  termsModal.addEventListener('close', () => {
    termsModal.classList.add('hidden');
  });
}

function showTermsModal(plan) {
  const termsModal = document.getElementById('termsModal');
  const termsCheckbox = document.getElementById('termsCheckbox');
  const termsConfirmBtn = document.getElementById('termsConfirmBtn');

  if (!termsModal) return;

  pendingPlan = plan;
  termsCheckbox.checked = false;
  termsConfirmBtn.disabled = true;
  termsModal.classList.remove('hidden');
  termsModal.showModal();
}

function executeSubscription(plan) {
  const btnId = plan === 'monthly' ? 'cloudSyncMonthlyBtn' : 'cloudSyncYearlyBtn';
  const btn = document.getElementById(btnId);
  if (btn) btn.disabled = true;

  chrome.runtime.sendMessage({ action: 'cloudSync_subscribe', plan }, (result) => {
    if (btn) btn.disabled = false;
    if (!result?.success) showToast(result?.error || getMessage('cloudSyncFailedCheckout', 'Failed to open checkout'), 'error');
  });
}

function resetPlanButtons() {
  const monthlyBtn = document.getElementById('cloudSyncMonthlyBtn');
  const yearlyBtn = document.getElementById('cloudSyncYearlyBtn');
  if (monthlyBtn) monthlyBtn.disabled = false;
  if (yearlyBtn) yearlyBtn.disabled = false;
}

