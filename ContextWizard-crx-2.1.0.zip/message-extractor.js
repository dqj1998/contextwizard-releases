// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
/**
 * Universal Message Extractor
 * Uses content analysis instead of platform-specific selectors
 */

// Stable ID reused across extractions when the URL has no unique path segment.
// Prevents duplicate conversation entries when a platform stays at a generic URL
// (e.g., Gemini at /app without the conversation sidebar open).
// Reset to null whenever the URL transitions to a unique path.
let _genericUrlSessionId = null;

const ALLOWED_HTML_TAGS = new Set(['strong', 'em', 'b', 'i', 'u', 'code', 'pre', 'p', 'span', 'div', 'ul', 'ol', 'li', 'br', 'blockquote', 'a']);
const ALLOWED_HTML_ATTRS = new Set(['href', 'title']);
const MEDIA_STRIP_SELECTOR = 'img, picture, video, canvas, svg, model-viewer, [role="img"], [aria-hidden="true"][data-testid*="image" i], [data-testid*="media" i]';
const UI_STRIP_SELECTOR = 'button, input, textarea, select, option, [role="button"], [data-testid*="copy" i], [aria-label*="copy" i]';

class MessageExtractor {
  constructor(platform) {
    this.platform = platform;
    this.conversationArea = null;
    this.debugEnabled = Boolean(globalThis.__contextWizardDebug);
  }

  debugLog(...args) {
    if (this.debugEnabled) {

    }
  }

  /**
   * Main extraction method - finds and extracts all messages
   */
  extract() {
    this.debugLog('[MessageExtractor] Starting extraction for', this.platform.name);
    
    // Step 1: Find the conversation area
    this.conversationArea = this.findConversationArea();
    if (!this.conversationArea) {
      this.debugLog('[MessageExtractor] No conversation area found');
      return null;
    }

    // Step 2: Extract all text blocks
    let textBlocks = this.extractTextBlocks(this.conversationArea);
    this.debugLog('[MessageExtractor] Found', textBlocks.length, 'text blocks');
    
    // Step 2.5: If first user message is missing, try to extract from page title/header
    // Only run if we actually have text blocks (ensureFirstUserMessage on empty blocks
    // may pick up welcome/landing page text as a fake user message)
    if (textBlocks.length > 0) {
      textBlocks = this.ensureFirstUserMessage(textBlocks);
    }

    // Step 3: Classify text blocks as user/assistant messages
    const messages = this.classifyMessages(textBlocks);
    this.debugLog('[MessageExtractor] Classified', messages.length, 'messages');

    // Step 4: Generate conversation metadata
    const conversation = this.buildConversation(messages);
    
    return conversation;
  }

  /**
   * Ensure the first user message is present in the extracted blocks.
   * On some platforms like Gemini, the first user query is displayed
   * in a title/header area separate from the main conversation.
   */
  ensureFirstUserMessage(textBlocks) {
    // Check if we already have a user message
    const hasUserMessage = textBlocks.some(block => {
      if (block.structuredRole === 'user') return true;
      const tagName = (block.metadata?.tagName || '').toLowerCase();
      const className = (block.metadata?.className || '').toLowerCase();
      return /(user-query|query-text)/.test(tagName) ||
             /(user|query|prompt)/.test(className);
    });
    
    if (hasUserMessage) {
      return textBlocks;
    }
    
    this.debugLog('[MessageExtractor] No user message found in blocks, searching for title/header');
    
    // Try to find the first user query from title/header elements
    const titleSelectors = [
      // Gemini title selectors
      'h1[class*="conversation" i]',
      '[class*="conversation-title" i]',
      '[class*="chat-title" i]',
      'h1.title',
      // General title selectors (but not in sidebar/nav)
      'main h1',
      '[role="main"] h1',
      '.chat-window h1'
    ];
    
    for (const selector of titleSelectors) {
      const titleElem = document.querySelector(selector);
      if (titleElem) {
        const titleText = (titleElem.textContent || '').trim();
        // Skip if it's just the platform name or too short
        if (titleText.length >= 5 && 
            !this.isPlaceholderText(titleText) &&
            titleText.toLowerCase() !== this.platform.name.toLowerCase()) {
          this.debugLog('[MessageExtractor] Found first user query from title:', titleText.substring(0, 50));
          const userBlock = {
            element: titleElem,
            text: titleText,
            html: titleElem.innerHTML,
            position: 0, // First position
            metadata: this.extractMetadata(titleElem),
            structuredRole: 'user'
          };
          return [userBlock, ...textBlocks];
        }
      }
    }
    
    // Also try the page's document title as last resort (Gemini sets it to the query)
    const docTitle = document.title;
    if (docTitle && docTitle.length >= 5) {
      // Remove common suffixes like " - Gemini" or " | ChatGPT"
      // Keep in sync with all platforms in platforms.js
      const cleanTitle = docTitle.replace(/\s*[-|]\s*(Gemini|ChatGPT|Claude|Copilot|Grok|Perplexity|DeepSeek|Qwen|Kimi|Manus|HuggingFace|Poe).*$/i, '').trim();
      if (cleanTitle.length >= 5 &&
          !this.isPlaceholderText(cleanTitle) &&
          cleanTitle.toLowerCase() !== this.platform.name.toLowerCase()) {
        this.debugLog('[MessageExtractor] Found first user query from document title:', cleanTitle.substring(0, 50));
        const userBlock = {
          element: null,
          text: cleanTitle,
          html: cleanTitle,
          position: 0, // First position
          metadata: { tagName: 'title', className: '', id: '' },
          structuredRole: 'user'
        };
        return [userBlock, ...textBlocks];
      }
    }
    
    return textBlocks;
  }

  /**
   * Find the main conversation area using multiple strategies
   */
  findConversationArea() {
    const geminiArea = this.findGeminiConversationArea();
    if (geminiArea) {
      this.debugLog('[MessageExtractor] Found Gemini area via message elements');
      return geminiArea;
    }

    const explicitRoleArea = this.findExplicitRoleConversationArea();
    if (explicitRoleArea) {
      this.debugLog('[MessageExtractor] Found area via explicit role messages');
      return explicitRoleArea;
    }

    const visualArea = this.findVisualConversationArea();
    if (visualArea) {
      return visualArea;
    }

    // Strategy 1: Use platform hint if available
    if (this.platform.selectors?.conversationArea) {
      const area = document.querySelector(this.platform.selectors.conversationArea);
      if (area) {
        this.debugLog('[MessageExtractor] Found area via platform selector');
        return area;
      }
    }

    // Strategy 2: Find by locating chat input (conversation is above it)
    const chatInput = this.findChatInput();
    if (chatInput) {
      const area = this.findAreaAboveInput(chatInput);
      if (area) {
        this.debugLog('[MessageExtractor] Found area above chat input');
        return area;
      }
    }

    // Strategy 3: Look for scrollable content area
    const scrollableArea = this.findScrollableContentArea();
    if (scrollableArea) {
      this.debugLog('[MessageExtractor] Found scrollable content area');
      return scrollableArea;
    }

    // Strategy 4: Use main content area
    const mainContent = document.querySelector('main, [role="main"], #content, .content');
    if (mainContent) {
      const narrowedArea = mainContent.querySelector(
        '[role="log"], [aria-label*="conversation" i], [aria-label*="chat" i], ' +
        '[aria-label*="message" i], [data-testid*="conversation" i], ' +
        '[class*="conversation-container" i], [class*="chat-container" i]'
      );
      if (narrowedArea) {
        this.debugLog('[MessageExtractor] Using narrowed conversation area within main');
        return narrowedArea;
      }
      this.debugLog('[MessageExtractor] Using main content area');
      return mainContent;
    }

    this.debugLog('[MessageExtractor] Falling back to body');
    return document.body;
  }

  findGeminiConversationArea() {
    if (!this.isGeminiPlatform() || !document.querySelectorAll) {
      return null;
    }

    const messageNodes = Array.from(document.querySelectorAll('user-query, model-response, query-text'))
      .filter((node) => node && !this.shouldSkipElement(node));
    if (!messageNodes.length) {
      return null;
    }

    const candidates = Array.from(document.querySelectorAll('chat-window-content, main, [role="main"]'))
      .filter((candidate) => candidate && !this.shouldSkipElement(candidate))
      .map((candidate) => ({
        element: candidate,
        count: messageNodes.filter((node) => candidate.contains(node)).length,
        priority: candidate.tagName?.toLowerCase() === 'chat-window-content' ? 1 : 0
      }))
      .filter((candidate) => candidate.count > 0)
      .sort((a, b) => {
        if (b.count !== a.count) return b.count - a.count;
        return b.priority - a.priority;
      });

    if (candidates.length) {
      return candidates[0].element;
    }

    let common = messageNodes[0].parentElement || messageNodes[0];
    while (common && common !== document.documentElement) {
      if (messageNodes.every((node) => common.contains(node))) {
        return common;
      }
      common = common.parentElement;
    }

    return null;
  }

  findExplicitRoleConversationArea() {
    if (!document.querySelectorAll) {
      return null;
    }

    const roleNodes = Array.from(document.querySelectorAll('[data-message-author-role], [data-role]'))
      .filter((node) => {
        if (!node || this.shouldSkipElement(node)) return false;
        const role = this.normalizeRoleHint(
          node.dataset?.messageAuthorRole,
          node.dataset?.role,
          node.getAttribute?.('data-message-author-role'),
          node.getAttribute?.('data-role'),
          node.getAttribute?.('aria-label')
        );
        return role === 'user' || role === 'assistant';
      })
      .filter((node, _index, allNodes) => {
        return !allNodes.some((other) => other !== node && node.contains(other));
      });

    if (roleNodes.length < 2) {
      return null;
    }

    let common = roleNodes[0].parentElement || roleNodes[0];
    while (common && common !== document.documentElement) {
      if (roleNodes.every((node) => common.contains(node))) {
        break;
      }
      common = common.parentElement;
    }

    if (!common || common === document.documentElement) {
      return null;
    }

    if (common === document.body) {
      const main = document.querySelector('main, [role="main"]');
      if (main && roleNodes.every((node) => main.contains(node))) {
        return main;
      }
    }

    return common;
  }

  /**
   * Vision-inspired detection: sample along viewport midline to locate chat column
   */
  findVisualConversationArea() {
    try {
      const samples = this.sampleMidlineElements();
      if (!samples.size) {
        return null;
      }

      const candidates = [];
      for (const [element, hits] of samples.entries()) {
        const container = this.elevateToConversationContainer(element);
        if (!container) continue;

        const existing = candidates.find(entry => entry.element === container);
        if (existing) {
          existing.hits += hits;
          continue;
        }

        const stats = this.collectColumnStats(container);
        if (!stats) continue;
        const score = this.scoreConversationCandidate(container, stats);
        if (score <= 0) continue;
        candidates.push({ element: container, score, hits, stats });
      }

      if (!candidates.length) {
        return null;
      }

      candidates.sort((a, b) => {
        // Prioritize score, then hit count, then width coverage
        if (b.score !== a.score) return b.score - a.score;
        if (b.hits !== a.hits) return b.hits - a.hits;
        return b.stats.widthRatio - a.stats.widthRatio;
      });

      if (this.debugEnabled) {
        this.printVisualDebugInfo(candidates);
      }

      const top = candidates[0];
      if (top.score >= 0.55) {
        return top.element;
      }
      return null;
    } catch (error) {
      console.error('[MessageExtractor] Visual detection failed:', error);
      return null;
    }
  }

  sampleMidlineElements(step = 120, offsets = [0.45, 0.5, 0.55]) {
    const map = new Map();
    const width = globalThis.innerWidth || document.documentElement.clientWidth;
    const height = globalThis.innerHeight || document.documentElement.clientHeight;

    if (!width || !height) return map;

    for (let y = 80; y < height - 80; y += step) {
      for (const offset of offsets) {
        const x = Math.min(width - 1, Math.max(1, width * offset));
        const element = document.elementFromPoint(x, y);
        if (!element || element === document.documentElement || element === document.body) continue;

        const style = globalThis.getComputedStyle(element);
        if (!style || style.visibility === 'hidden' || style.pointerEvents === 'none' || Number.parseFloat(style.opacity) === 0) {
          continue;
        }

        const key = element;
        const current = map.get(key) || 0;
        map.set(key, current + 1);
      }
    }

    return map;
  }

  elevateToConversationContainer(element) {
    let current = element;
    let lastValid = null;
    const MAX_DEPTH = 8;
    let depth = 0;

    while (current && current !== document.body && depth < MAX_DEPTH) {
      depth++;
      if (this.isPotentialConversationContainer(current)) {
        lastValid = current;
      }
      current = current.parentElement;
    }
    return lastValid;
  }

  isPotentialConversationContainer(element) {
    const rect = element.getBoundingClientRect();
    if (!rect || rect.width < 280 || rect.height < 200) return false;

    const tag = element.tagName.toLowerCase();
    if (['nav', 'aside', 'header', 'footer'].includes(tag)) return false;

    const className = (element.className || '').toLowerCase();
    if (/(sidebar|(^|[-_\s])nav($|[-_\s])|menu|toolbar)/.test(className)) return false;

    const textLength = (element.innerText || '').trim().length;
    if (textLength < 200) return false;

    const inputDescendant = element.querySelector('textarea, input, [role="textbox"]');
    if (inputDescendant) return false;

    return true;
  }

  collectColumnStats(element) {
    const rect = element.getBoundingClientRect();
    const viewportWidth = globalThis.innerWidth || document.documentElement.clientWidth || rect.width;
    const viewportHeight = globalThis.innerHeight || document.documentElement.clientHeight || rect.height;
    if (!viewportWidth || !viewportHeight) return null;

    const textContent = (element.innerText || '').trim();
    const textLength = textContent.length;
    if (!textLength) return null;

    const linkCount = element.querySelectorAll('a').length;
    const totalNodes = element.querySelectorAll('*').length || 1;

    const childBlocks = Array.from(element.children).filter(child => {
      const childText = (child.innerText || '').trim();
      const childRect = child.getBoundingClientRect();
      return childText.length > 30 && childRect.height > 30;
    });

    const blockPositions = childBlocks.map(block => block.getBoundingClientRect().top).sort((a, b) => a - b);
    let avgGap = 0;
    if (blockPositions.length > 1) {
      const gaps = [];
      for (let i = 1; i < blockPositions.length; i++) {
        gaps.push(blockPositions[i] - blockPositions[i - 1]);
      }
      avgGap = gaps.reduce((sum, gap) => sum + gap, 0) / gaps.length;
    }

    const roleHints = element.querySelectorAll('[data-message-author-role], [data-role], [aria-label]');
    let userCount = 0;
    let assistantCount = 0;
    for (const node of roleHints) {
      const dataRole = node.dataset?.role || node.dataset?.messageAuthorRole;
      const ariaLabel = node.getAttribute('aria-label');
      const value = [dataRole, ariaLabel]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      if (/user|human|you/.test(value)) userCount++;
      if (/assistant|bot|ai|model/.test(value)) assistantCount++;
    }

    return {
      rect,
      viewportWidth,
      viewportHeight,
      textLength,
      childBlockCount: childBlocks.length,
      avgGap,
      linkRatio: linkCount / totalNodes,
      userCount,
      assistantCount,
      widthRatio: rect.width / viewportWidth,
      heightRatio: rect.height / viewportHeight
    };
  }

  scoreConversationCandidate(element, stats) {
    const centerX = stats.rect.left + stats.rect.width / 2;
    const centerDeviation = Math.abs(centerX - stats.viewportWidth / 2) / stats.viewportWidth;
    const centerScore = Math.max(0, 1 - (centerDeviation / 0.25)); // >=25% width away drops to 0

    const widthScore = this.trapezoidScore(stats.widthRatio, 0.3, 0.4, 0.75, 0.85);
    const heightScore = Math.min(1, stats.heightRatio / 0.6);

    const densityScore = Math.min(1, stats.textLength / (stats.rect.width * stats.rect.height / 6));

    const blockScore = Math.min(1, stats.childBlockCount / 6);

    const alternatingScore = (stats.userCount > 0 && stats.assistantCount > 0) ? 1 : 0;

    const linkPenalty = Math.min(1, stats.linkRatio / 0.3);

    const nameScore = this.classNameAffinity(element);

    const total = (centerScore * 0.3) +
                 (widthScore * 0.15) +
                 (heightScore * 0.1) +
                 (densityScore * 0.2) +
                 (blockScore * 0.05) +
                 (alternatingScore * 0.05) +
                 (nameScore * 0.1) -
                 (linkPenalty * 0.1);

    return Math.max(0, Math.min(1, total));
  }

  trapezoidScore(value, minStart, minIdeal, maxIdeal, maxEnd) {
    if (value <= minStart || value >= maxEnd) return 0;
    if (value >= minIdeal && value <= maxIdeal) return 1;
    if (value < minIdeal) {
      return (value - minStart) / (minIdeal - minStart);
    }
    return (maxEnd - value) / (maxEnd - maxIdeal);
  }

  classNameAffinity(element) {
    const className = element.className || '';
    const id = element.id || '';
    
    const ref = className + ' ' + id;
    const value = ref.toLowerCase();
    let score = 0;
    if (/(conversation|content|thread|main)/.test(value)) score += 0.5;
    if (/(chat|messages|reply)/.test(value)) score += 0.5;
    if (/(sidebar|(^|[-_\s])nav($|[-_\s])|menu)/.test(value)) score -= 0.7;
    return Math.max(0, Math.min(1, (score + 0.7) / 1.4));
  }

  printVisualDebugInfo(candidates) {
    if (!this.debugEnabled) return;
    console.groupCollapsed('[MessageExtractor] Visual candidates');
    const topCandidates = candidates.slice(0, 5);
    for (let index = 0; index < topCandidates.length; index++) {
      const item = topCandidates[index];

      this.highlightCandidate(item.element, index);
    }
    console.groupEnd();
  }

  highlightCandidate(element, index) {
    if (!this.debugEnabled) return;
    const colors = ['#4CAF50', '#FF9800', '#03A9F4'];
    const border = document.createElement('div');
    const rect = element.getBoundingClientRect();
    border.style.position = 'fixed';
    border.style.pointerEvents = 'none';
    border.style.border = `2px dashed ${colors[index] || '#9C27B0'}`;
    border.style.borderRadius = '6px';
    border.style.left = `${rect.left}px`;
    border.style.top = `${rect.top}px`;
    border.style.width = `${rect.width}px`;
    border.style.height = `${rect.height}px`;
    border.style.zIndex = 999999;
    border.style.opacity = '0.8';
    document.body.appendChild(border);
    setTimeout(() => border.remove(), 1000);
  }

  /**
   * Find chat input element
   */
  findChatInput() {
    const selectors = [
      'textarea[placeholder*="message" i]',
      'textarea[placeholder*="ask" i]',
      'textarea[placeholder*="chat" i]',
      'textarea[placeholder*="type" i]',
      'div[contenteditable="true"][role="textbox"]',
      'textarea:not([style*="display: none"])'
    ];

    for (const selector of selectors) {
      const inputs = document.querySelectorAll(selector);
      for (const input of inputs) {
        const rect = input.getBoundingClientRect();
        if (rect.height > 20 && rect.width > 100) {
          return input;
        }
      }
    }
    return null;
  }

  /**
   * Find the scrollable area above chat input
   */
  findAreaAboveInput(chatInput) {
    const inputRect = chatInput.getBoundingClientRect();
    let container = chatInput.parentElement;
    let level = 0;

    while (container && container !== document.body && level < 10) {
      level++;
      const siblings = Array.from(container.parentElement?.children || []);

      for (const sibling of siblings) {
        if (sibling === container) continue;

        const rect = sibling.getBoundingClientRect();
        const isAboveInput = rect.top < inputRect.top;
        const isLargeEnough = rect.width > 300 && rect.height > 200;

        if (isAboveInput && isLargeEnough) {
          return sibling;
        }
      }
      container = container.parentElement;
    }
    return null;
  }

  /**
   * Find scrollable content area
   */
  findScrollableContentArea() {
    // Try specific selectors first
    const candidates = document.querySelectorAll('[class*="scroll"], [class*="content"], [class*="chat"], [class*="conversation"]');
    
    for (const elem of candidates) {
      const style = globalThis.getComputedStyle(elem);
      const rect = elem.getBoundingClientRect();
      
      const isScrollable = style.overflowY === 'auto' || 
                          style.overflowY === 'scroll' || 
                          elem.scrollHeight > elem.clientHeight;
      const isLargeEnough = rect.width > 300 && rect.height > 200;
      
      if (isScrollable && isLargeEnough) {
        return elem;
      }
    }
    
    // Try finding flex column containers with many children (common pattern)
    const flexContainers = document.querySelectorAll('[class*="flex"][class*="col"]');
    for (const elem of flexContainers) {
      const rect = elem.getBoundingClientRect();
      const hasEnoughChildren = elem.children.length >= 5;
      const isLargeEnough = rect.width > 300 && rect.height > 200;
      
      if (hasEnoughChildren && isLargeEnough) {
        // Check if children have text content
        const childrenWithText = Array.from(elem.children).filter(child => {
          const text = (child.textContent || '').trim();
          return text.length > 20;
        });
        
        if (childrenWithText.length >= 3) {
          return elem;
        }
      }
    }
    
    return null;
  }

  /**
   * Log structured blocks for debugging
   */
  logStructuredBlocks(blocks) {
    for (let i = 0; i < blocks.length; i++) {
      const block = blocks[i];
      this.debugLog(`[MessageExtractor] Block ${i}: role=${block.structuredRole}, text=${block.text.substring(0, 50)}...`);
    }
  }

  /**
   * Merge blocks that are siblings within the same parent container.
   * Prevents fragmentation when selectors or the TreeWalker find individual
   * child elements (p, pre, div) inside a message container as separate blocks.
   */
  getDepth(el) {
    if (!el || !el.parentElement) return 0;
    let depth = 0;
    let current = el;
    while (current.parentElement) {
      depth++;
      current = current.parentElement;
    }
    return depth;
  }

  compareBlocksByDocumentOrder(a, b) {
    const aPos = Number.isFinite(a.position) ? a.position : Number.MAX_SAFE_INTEGER;
    const bPos = Number.isFinite(b.position) ? b.position : Number.MAX_SAFE_INTEGER;
    if (aPos !== bPos) return aPos - bPos;

    const aElement = a.element;
    const bElement = b.element;
    if (aElement && bElement && aElement !== bElement && typeof aElement.compareDocumentPosition === 'function') {
      const relation = aElement.compareDocumentPosition(bElement);
      if (relation & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
      if (relation & Node.DOCUMENT_POSITION_PRECEDING) return 1;
    }
    return 0;
  }

  normalizeForComparison(text) {
    return (text || '').toLowerCase().replaceAll(/\s+/g, ' ').trim();
  }

  mergeAdjacentBlocks(blocks) {
    if (blocks.length <= 1) return blocks;

    // Sort by DOM depth (ancestors first) so role propagation in the reduce
    // below reliably finds ancestor blocks already in the accumulator.
    blocks = [...blocks].sort((a, b) => this.getDepth(a.element) - this.getDepth(b.element));

    // First pass: remove descendant blocks and propagate structuredRole from removed
    // descendants to their ancestor (handles cases like ChatGPT turn section containing
    // the actual [data-message-author-role] div — we keep the section but inherit its role)
    const topLevel = blocks.reduce((acc, block, i) => {
      const parent = blocks.find((other, j) => {
        if (i === j) return false;
        return other.element?.contains?.(block.element);
      });

      if (!parent) {
        acc.push({ ...block });
      } else if (block.structuredRole && block.structuredRole !== 'unknown') {
        const accParent = acc.find(b => b.element === parent.element);
        if (accParent && (!accParent.structuredRole || accParent.structuredRole === 'unknown')) {
          accParent.structuredRole = block.structuredRole;
          accParent.metadata = { ...accParent.metadata, ...block.metadata };
        }
      }
      return acc;
    }, []);

    if (topLevel.length <= 1) return topLevel;

    // Second pass: merge only fragments that are inside the same explicit
    // message boundary. Unknown sibling blocks are separate turns until proven
    // otherwise; merging them destroys message boundaries on generic/custom chats.
    const merged = [];
    let group = [topLevel[0]];

    for (let i = 1; i < topLevel.length; i++) {
      const curr = topLevel[i];
      const prev = topLevel[i - 1];
      if (this.shouldMergeSiblingBlocks(prev, curr)) {
        group.push(curr);
      } else {
        merged.push(this.mergeBlockGroup(group));
        group = [curr];
      }
    }
    if (group.length) merged.push(this.mergeBlockGroup(group));

    return merged;
  }

  shouldMergeSiblingBlocks(prev, curr) {
    if (prev.element?.parentElement !== curr.element?.parentElement) {
      return false;
    }

    const prevBoundary = this.getMessageBoundaryElement(prev.element);
    const currBoundary = this.getMessageBoundaryElement(curr.element);
    if (!prevBoundary || prevBoundary !== currBoundary) {
      return false;
    }

    const prevKnown = prev.structuredRole && prev.structuredRole !== 'unknown';
    const currKnown = curr.structuredRole && curr.structuredRole !== 'unknown';
    return !prevKnown || !currKnown || prev.structuredRole === curr.structuredRole;
  }

  getMessageBoundaryElement(element) {
    let current = element;
    let depth = 0;
    while (current && current !== document.body && depth < 10) {
      depth += 1;
      const dataRole = this.normalizeRoleHint(
        current.dataset?.role,
        current.dataset?.messageAuthorRole,
        current.getAttribute?.('data-message-author-role'),
        current.getAttribute?.('aria-label')
      );
      const testId = (current.getAttribute?.('data-testid') || '').toLowerCase();
      if (dataRole !== 'unknown' || /(turn|conversation)/.test(testId)) {
        return current;
      }
      current = current.parentElement;
    }

    current = element;
    depth = 0;
    while (current && current !== document.body && depth < 10) {
      depth += 1;
      const tagName = (current.tagName || '').toLowerCase();
      const className = (current.className || '').toLowerCase();
      const testId = (current.getAttribute?.('data-testid') || '').toLowerCase();
      if (/(user-query|model-response|assistant-message|user-message)/.test(tagName) ||
          /(message|turn|response|query|font-user-message|font-claude-response|standard-markdown)/.test(className) ||
          /(message)/.test(testId)) {
        return current;
      }
      current = current.parentElement;
    }
    return null;
  }

  /** Merge a consecutive group of same-parent blocks into one */
  mergeBlockGroup(group) {
    if (group.length === 1) return group[0];

    const texts = group.map(b => (b.text || '').trim()).filter(Boolean);
    const first = group[0];
    const knownRole = group.find(b => b.structuredRole && b.structuredRole !== 'unknown');
    const knownMeta = group.find(b => b.metadata?.dataRole || b.metadata?.dataAuthor);

    return {
      element: first.element,
      text: texts.join('\n'),
      html: group.map(b => b.html || '').filter(Boolean).join('\n'),
      position: first.position,
      metadata: knownMeta?.metadata || first.metadata,
      structuredRole: knownRole?.structuredRole || first.structuredRole || 'unknown'
    };
  }

  /**
   * Extract meaningful text blocks from the conversation area
   */
  extractTextBlocks(container) {
    const explicitRoleBlocks = this.extractExplicitRoleBlocks(container);
    if (explicitRoleBlocks.length) {
      this.debugLog('[MessageExtractor] Using explicit role extraction, found', explicitRoleBlocks.length, 'blocks');
      return explicitRoleBlocks;
    }

    const claudeBlocks = this.extractClaudeBlocks(container);
    if (this.hasReliableStructuredBlocks(claudeBlocks)) {
      this.debugLog('[MessageExtractor] Using Claude structured extraction, found', claudeBlocks.length, 'blocks');
      return claudeBlocks;
    }

    const grokBlocks = this.extractGrokBlocks(container);
    if (this.hasReliableStructuredBlocks(grokBlocks)) {
      this.debugLog('[MessageExtractor] Using Grok structured extraction, found', grokBlocks.length, 'blocks');
      return grokBlocks;
    }

    // Grok-specific guard: if Grok extraction found nothing, don't fall through to
    // visual/TreeWalker heuristics which may pick up UI text as fake messages
    if (this.isGrokPlatform()) {
      this.debugLog('[MessageExtractor] Grok platform with no structured messages, returning empty');
      return [];
    }

    // Claude-specific guard: new chat page (/new) has sidebar content that visual walker
    // incorrectly picks up as conversation messages
    if (this.isClaudePlatform()) {
      this.debugLog('[MessageExtractor] Claude platform with no structured messages, returning empty');
      return [];
    }

// Gemini-specific extraction: try custom elements (user-query, model-response, query-text)
    // before the guard, so actual conversation messages are not blocked.
    const geminiBlocks = this.extractGeminiBlocks(container);
    if (this.hasReliableStructuredBlocks(geminiBlocks)) {
      this.debugLog('[MessageExtractor] Using Gemini structured extraction, found', geminiBlocks.length, 'blocks');
      return geminiBlocks;
    }

    // Gemini-specific guard: landing page (/app) shows welcome text that gets misclassified
    if (this.isGeminiPlatform()) {
      if (geminiBlocks.length > 0) {
        this.debugLog('[MessageExtractor] Using Gemini partial extraction, found', geminiBlocks.length, 'blocks');
        return geminiBlocks;
      }
      this.debugLog('[MessageExtractor] Gemini platform with no structured messages, returning empty');
      return [];
    }

    let structuredBlocks = this.extractStructuredBlocks(container);
    if (this.hasReliableStructuredBlocks(structuredBlocks)) {
      this.debugLog('[MessageExtractor] Using reliable structured extraction, found', structuredBlocks.length, 'blocks');
      if (this.debugEnabled) {
        this.logStructuredBlocks(structuredBlocks);
      }
      structuredBlocks = this.mergeAdjacentBlocks(structuredBlocks);
      this.debugLog('[MessageExtractor] After merging siblings:', structuredBlocks.length, 'blocks');
      return structuredBlocks;
    }

    const visualBlocks = this.extractVisualReadingBlocks(container);
    if (visualBlocks.length >= 2) {
      this.debugLog('[MessageExtractor] Using visual reading extraction, found', visualBlocks.length, 'blocks');
      return visualBlocks;
    }

    if (structuredBlocks.length) {
      this.debugLog('[MessageExtractor] Using structured extraction, found', structuredBlocks.length, 'blocks');
      if (this.debugEnabled) {
        this.logStructuredBlocks(structuredBlocks);
      }
      structuredBlocks = this.mergeAdjacentBlocks(structuredBlocks);
      this.debugLog('[MessageExtractor] After merging siblings:', structuredBlocks.length, 'blocks');
      return structuredBlocks;
    }

    this.debugLog('[MessageExtractor] Structured extraction found nothing, falling back to tree walker');
    const blocks = [];
    const processed = new Set();
    let candidatesChecked = 0;
    let candidatesAccepted = 0;

    // Use TreeWalker to traverse all text nodes
    const walker = document.createTreeWalker(
      container,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: (node) => {
          // Skip if already processed
          if (processed.has(node)) return NodeFilter.FILTER_REJECT;
          
          // Skip if any ancestor is already processed (descendant of an accepted block)
          // This prevents extracting individual child elements within a message container
          // as separate blocks, which would lose role signals and cause misclassification.
          let ancestorCheck = node.parentElement;
          while (ancestorCheck && ancestorCheck !== container) {
            if (processed.has(ancestorCheck)) return NodeFilter.FILTER_REJECT;
            ancestorCheck = ancestorCheck.parentElement;
          }
          
          // Skip certain elements
          if (this.shouldSkipElement(node)) return NodeFilter.FILTER_REJECT;
          
          // Accept elements that likely contain message text
          candidatesChecked++;
          if (this.isMessageCandidate(node)) {
            candidatesAccepted++;
            return NodeFilter.FILTER_ACCEPT;
          }
          
          return NodeFilter.FILTER_SKIP;
        }
      }
    );

    let node;
    while (node = walker.nextNode()) {
      if (processed.has(node)) continue;

      const text = this.extractCleanText(node);
      if (!text || text.length < 3) continue;

      // Check if this is valid content
      if (this.isPlaceholderText(text)) continue;

      const formatted = this.extractFormattedHtml(node);

      const block = {
        element: node,
        text: text,
        html: formatted,
        position: this.getElementPosition(node),
        metadata: this.extractMetadata(node)
      };

      blocks.push(block);
      
      // Mark this element and its ancestors as processed to avoid duplicates
      let current = node;
      while (current && current !== container) {
        processed.add(current);
        current = current.parentElement;
      }
    }
    
    this.debugLog('[MessageExtractor] TreeWalker: checked', candidatesChecked, 'candidates, accepted', candidatesAccepted, ', found', blocks.length, 'valid blocks');

    // Sort by position in document
    blocks.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));

    // DO NOT call mergeAdjacentBlocks here: TreeWalker blocks lack
    // structuredRole, so the sibling-merge pass would blindly merge
    // distinct messages (different turns but same parentElement) into
    // one block — destroying message boundaries and role classification.
    // The TreeWalker's acceptNode already prevents descendant-overlap via
    // the processed-ancestor check.
    return blocks;
  }

  hasReliableStructuredBlocks(blocks) {
    if (!Array.isArray(blocks) || blocks.length < 2) {
      return false;
    }

    const roles = new Set(blocks
      .map(block => block.structuredRole)
      .filter(role => role === 'user' || role === 'assistant'));

    return roles.has('user') && roles.has('assistant');
  }

  extractExplicitRoleBlocks(container) {
    if (!container?.querySelectorAll) {
      return [];
    }

    // Data-attribute based role detection (works for most platforms)
    const roleNodes = Array.from(container.querySelectorAll('[data-message-author-role], [data-role]'))
      .filter((node) => {
        if (!node || this.shouldSkipElement(node)) return false;
        const role = this.normalizeRoleHint(
          node.dataset?.messageAuthorRole,
          node.dataset?.role,
          node.getAttribute?.('data-message-author-role'),
          node.getAttribute?.('data-role'),
          node.getAttribute?.('aria-label')
        );
        return role === 'user' || role === 'assistant';
      })
      .filter((node, _index, allNodes) => {
        return !allNodes.some((other) => other !== node && node.contains(other));
      });

    // Class-based assistant detection (ChatGPT uses .agent-turn, HuggingFace uses pattern classes)
    const assistantClassNodes = Array.from(container.querySelectorAll(
      '.agent-turn, [class*="agent-turn"]'
    ))
      .filter((node) => {
        if (!node || this.shouldSkipElement(node)) return false;
        return !roleNodes.some((other) => other === node || other.contains(node));
      })
      .filter((node, _index, allNodes) => {
        return !allNodes.some((other) => other !== node && node.contains(other));
      });

    const combinedNodes = [...roleNodes];
    for (const node of assistantClassNodes) {
      if (!combinedNodes.some(other => other === node || node.contains(other) || other.contains(node))) {
        combinedNodes.push(node);
      }
    }

    const blocks = [];
    for (const node of combinedNodes) {
      let role = 'unknown';

      // Check data attributes first
      role = this.normalizeRoleHint(
        node.dataset?.messageAuthorRole,
        node.dataset?.role,
        node.getAttribute?.('data-message-author-role'),
        node.getAttribute?.('data-role'),
        node.getAttribute?.('aria-label')
      );

      // If no role from data attributes, check class-based patterns
      if (role === 'unknown') {
        if (this.hasExactClassToken(node, 'agent-turn') ||
            this.hasClassPattern(node, /agent-turn/)) {
          role = 'assistant';
        }
      }

      const text = this.cleanMessageText(this.extractCleanText(node), role);
      if (!text) continue;

      const sanitizedNode = this.cloneNodeWithoutMedia(this.getPrimaryContentNode(node));
      const html = this.extractFormattedHtmlFromClone(sanitizedNode);
      blocks.push({
        element: node,
        text,
        html,
        position: this.getElementPosition(node),
        metadata: this.extractMetadata(node),
        structuredRole: role
      });
    }

    blocks.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));
    return blocks;
  }

  extractVisualReadingBlocks(container) {
    if (!container?.querySelectorAll || typeof globalThis.getComputedStyle !== 'function') {
      return [];
    }

    const containerRect = container.getBoundingClientRect?.();
    if (!this.hasUsableRect(containerRect)) {
      return [];
    }

    const rawCandidates = Array.from(container.querySelectorAll(
      'article, section, div, p, li, pre, blockquote, [role="article"], [role="listitem"]'
    ))
      .filter((element) => this.isVisualTextCandidate(element, containerRect))
      .map((element) => ({
        element,
        rect: element.getBoundingClientRect(),
        text: this.extractCleanText(element),
        metadata: this.extractMetadata(element)
      }))
      .filter((candidate) => candidate.text && candidate.text.length >= 2);

    if (rawCandidates.length < 2) {
      return [];
    }

    const candidates = this.reduceVisualCandidates(rawCandidates);
    if (candidates.length < 2) {
      return [];
    }

    candidates.sort((a, b) => {
      const topDiff = a.rect.top - b.rect.top;
      if (Math.abs(topDiff) > 4) return topDiff;
      return a.rect.left - b.rect.left;
    });

    const blocks = candidates.map((candidate, index) => {
      const role = this.inferRoleFromVisualAlignment(candidate.rect, containerRect, index);
      return {
        element: candidate.element,
        text: this.cleanMessageText(candidate.text, role),
        html: this.extractFormattedHtml(candidate.element),
        position: this.getElementPosition(candidate.element),
        metadata: candidate.metadata,
        structuredRole: role
      };
    }).filter(block => block.text);

    return this.mergeVisualBlocks(blocks, containerRect);
  }

  hasUsableRect(rect) {
    return rect &&
      Number.isFinite(rect.top) &&
      Number.isFinite(rect.left) &&
      rect.width >= 240 &&
      rect.height >= 80;
  }

  isVisualTextCandidate(element, containerRect) {
    if (!element || this.shouldSkipElement(element)) return false;
    const rect = element.getBoundingClientRect?.();
    if (!rect || rect.width < 24 || rect.height < 8) return false;
    if (!Number.isFinite(rect.top) || !Number.isFinite(rect.left)) return false;
    if (rect.bottom < containerRect.top - 200 || rect.top > containerRect.bottom + 200) return false;

    const style = globalThis.getComputedStyle(element);
    if (!style || style.display === 'none' || style.visibility === 'hidden' || Number.parseFloat(style.opacity || '1') === 0) {
      return false;
    }

    const text = this.extractCleanText(element);
    if (!text || text.length < 2) return false;
    if (this.isPlaceholderText(text) && text.length < 20) return false;

    const tagName = (element.tagName || '').toLowerCase();
    const className = (element.className || '').toLowerCase();
    const isLikelyTextBlock = /message|bubble|prose|markdown|response|query|whitespace|text-message|content/.test(className) ||
      ['p', 'li', 'pre', 'blockquote', 'article', 'section'].includes(tagName) ||
      element.getAttribute?.('role') === 'article';
    if (isLikelyTextBlock) return true;

    const containerWidth = containerRect.width || 1;
    return text.length >= 12 && rect.width <= containerWidth * 0.92;
  }

  reduceVisualCandidates(candidates) {
    const selected = [];
    const sorted = [...candidates].sort((a, b) => {
      const aPriority = this.getVisualCandidatePriority(a.element, a.text);
      const bPriority = this.getVisualCandidatePriority(b.element, b.text);
      if (aPriority !== bPriority) return bPriority - aPriority;
      return this.getDepth(b.element) - this.getDepth(a.element);
    });

    for (const candidate of sorted) {
      const duplicate = selected.some((existing) => {
        if (existing.element === candidate.element) return true;
        const sameText = this.normalizeForComparison(existing.text) === this.normalizeForComparison(candidate.text);
        return sameText && (existing.element.contains(candidate.element) || candidate.element.contains(existing.element));
      });
      if (!duplicate) {
        selected.push(candidate);
      }
    }

    return selected.filter((candidate) => {
      const coveredByBetterAncestor = selected.some((other) => {
        if (other === candidate) return false;
        if (!other.element.contains(candidate.element)) return false;
        const otherText = this.normalizeForComparison(other.text);
        const text = this.normalizeForComparison(candidate.text);
        return otherText.includes(text) && this.getVisualCandidatePriority(other.element, other.text) >= this.getVisualCandidatePriority(candidate.element, candidate.text);
      });
      return !coveredByBetterAncestor;
    });
  }

  getVisualCandidatePriority(element, text) {
    const className = (element.className || '').toLowerCase();
    const tagName = (element.tagName || '').toLowerCase();
    let priority = 0;
    if (/message|bubble|text-message|user-message|assistant-message/.test(className)) priority += 5;
    if (/prose|markdown|response|query|whitespace/.test(className)) priority += 3;
    if (['p', 'li', 'pre', 'blockquote'].includes(tagName)) priority += 1;
    if ((text || '').length > 80) priority += 1;
    return priority;
  }

  inferRoleFromVisualAlignment(rect, containerRect, index) {
    const leftGap = Math.max(0, rect.left - containerRect.left);
    const rightGap = Math.max(0, containerRect.right - rect.right);
    const width = containerRect.width || 1;
    const center = rect.left + rect.width / 2;
    const containerCenter = containerRect.left + width / 2;

    if (rightGap + width * 0.04 < leftGap && center > containerCenter + width * 0.08) {
      return 'user';
    }

    if (leftGap + width * 0.04 < rightGap && center < containerCenter + width * 0.08) {
      return 'assistant';
    }

    return index % 2 === 0 ? 'user' : 'assistant';
  }

  mergeVisualBlocks(blocks, containerRect) {
    const merged = [];
    for (const block of blocks) {
      const previous = merged.at(-1);
      if (previous && previous.structuredRole === block.structuredRole && this.shouldMergeVisualBlocks(previous, block, containerRect)) {
        const combined = this.mergeBlockGroup([previous, block]);
        merged[merged.length - 1] = combined;
      } else {
        merged.push(block);
      }
    }
    return merged;
  }

  shouldMergeVisualBlocks(prev, curr, containerRect) {
    const prevRect = prev.element?.getBoundingClientRect?.();
    const currRect = curr.element?.getBoundingClientRect?.();
    if (!prevRect || !currRect) return false;
    const verticalGap = currRect.top - prevRect.bottom;
    if (verticalGap < -4 || verticalGap > 72) return false;

    const width = containerRect.width || 1;
    const leftDelta = Math.abs(prevRect.left - currRect.left);
    const rightDelta = Math.abs(prevRect.right - currRect.right);
    return leftDelta < width * 0.12 || rightDelta < width * 0.12;
  }

  isClaudePlatform() {
    const platformName = (this.platform?.name || '').toLowerCase();
    return platformName.includes('claude') ||
      document.documentElement?.dataset?.theme === 'claude';
  }

  hasExactClassToken(element, classToken) {
    return Array.from(element?.classList || []).some(token => token === classToken || token === `!${classToken}`);
  }

  hasClassPattern(element, pattern) {
    if (!element || !pattern) return false;
    const className = (element.className || '');
    return pattern.test(className);
  }

  isInsideNonConversationControl(element) {
    let current = element;
    let depth = 0;
    while (current && current !== document.body && depth < 8) {
      depth += 1;
      const tagName = (current.tagName || '').toLowerCase();
      const role = (current.getAttribute?.('role') || '').toLowerCase();
      if (role === 'status' || tagName === 'form' || tagName === 'fieldset') {
        return true;
      }
      current = current.parentElement;
    }
    return false;
  }

  extractClaudeBlocks(container) {
    if (!this.isClaudePlatform() || !container?.querySelectorAll) {
      return [];
    }

    const nodes = Array.from(container.querySelectorAll(
      '[data-testid="user-message"], [class*="font-user-message" i], [class*="font-claude-response" i]'
    ));

    const blocks = [];
    for (const node of nodes) {
      if (!node || this.shouldSkipElement(node) || this.isInsideNonConversationControl(node)) {
        continue;
      }

      let role = 'unknown';
      if (node.getAttribute?.('data-testid') === 'user-message' || this.hasExactClassToken(node, 'font-user-message')) {
        role = 'user';
      } else if (this.hasExactClassToken(node, 'font-claude-response')) {
        role = 'assistant';
      }

      if (role === 'unknown') {
        continue;
      }

      const contentNode = this.getPrimaryContentNode(node);
      const sanitizedNode = this.cloneNodeWithoutMedia(contentNode);
      if (!sanitizedNode) {
        continue;
      }

      const text = this.cleanMessageText(this.extractCleanText(node), role);
      if (!text || this.isPlaceholderText(text)) {
        continue;
      }

      blocks.push({
        element: node,
        text,
        html: this.extractFormattedHtmlFromClone(sanitizedNode),
        position: this.getElementPosition(node),
        metadata: this.extractMetadata(node),
        structuredRole: role
      });
    }

    blocks.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));
    return blocks;
  }

  isGrokPlatform() {
    const platformName = (this.platform?.name || '').toLowerCase();
    return platformName.includes('grok') ||
      /(^|\.)grok\.com$/i.test(globalThis.location?.hostname || '') ||
      /\s-\sGrok$/i.test(document.title || '');
  }

  isGeminiPlatform() {
    const platformName = (this.platform?.name || '').toLowerCase();
    return platformName.includes('gemini') ||
      /(^|\.)gemini\.google\.com$/i.test(globalThis.location?.hostname || '');
  }

  extractGrokBlocks(container) {
    if (!this.isGrokPlatform() || !container?.querySelectorAll) {
      return [];
    }

    const nodes = Array.from(container.querySelectorAll('[data-testid="user-message"], [data-testid="assistant-message"], [data-testid="UserMessage"], [data-testid="AssistantMessage"]'));
    const blocks = [];

    for (const node of nodes) {
      if (!node || this.shouldSkipElement(node) || this.isInsideNonConversationControl(node)) {
        continue;
      }

      const testId = node.getAttribute?.('data-testid') || '';
      const role = /user/i.test(testId) ? 'user' : 'assistant';
      const contentNode = this.getPrimaryContentNode(node);
      const sanitizedNode = this.cloneNodeWithoutMedia(contentNode);
      if (!sanitizedNode) {
        continue;
      }

      const text = this.cleanMessageText(this.extractCleanText(node), role);
      if (!text || this.isPlaceholderText(text)) {
        continue;
      }

      blocks.push({
        element: node,
        text,
        html: this.extractFormattedHtmlFromClone(sanitizedNode),
        position: this.getElementPosition(node),
        metadata: this.extractMetadata(node),
        structuredRole: role
      });
    }

    blocks.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));
    return blocks;
  }

  /**
   * Extract Gemini-specific message blocks.
   * Gemini uses custom elements (user-query, model-response, query-text)
   * instead of data-role attributes. This runs before the Gemini guard
   * so actual conversation messages are not blocked.
   */
  extractGeminiBlocks(container) {
    if (!this.isGeminiPlatform() || !container?.querySelectorAll) {
      return [];
    }

const GEMINI_SELECTORS = [
      'user-query',
      'model-response',
      'query-text'
    ];

    const nodes = GEMINI_SELECTORS.flatMap((selector) =>
      Array.from(container.querySelectorAll(selector))
    );

    if (!nodes.length) {
      this.debugLog('[MessageExtractor] extractGeminiBlocks: no Gemini elements found');
      return [];
    }

    // Deduplicate: prefer deepest nodes (avoid matching ancestor turns)
    const filtered = [];
    for (const node of nodes) {
      if (!node || this.shouldSkipElement(node)) continue;
      const hasDescendant = nodes.some((other) => other !== node && node.contains(other));
      if (!hasDescendant) {
        filtered.push(node);
      }
    }

    if (!filtered.length) {
      return [];
    }

    const seen = new Set();
    const blocks = [];

    for (const node of filtered) {
      if (seen.has(node)) continue;
      seen.add(node);

      const tagName = (node.tagName || '').toLowerCase();
      const className = (node.className || '').toLowerCase();

      // Assign role based on element tag name
      let role = 'unknown';
      if (tagName === 'user-query' || tagName === 'query-text' ||
          /(query-text|user-message-text)/.test(className)) {
        role = 'user';
      } else if (tagName === 'model-response') {
        role = 'assistant';
      }

      const contentNode = this.getPrimaryContentNode(node);
      const sanitizedNode = this.cloneNodeWithoutMedia(contentNode);
      if (!sanitizedNode) continue;

      let text = this.cleanMessageText(this.extractCleanText(node), role);
      if (!text || this.isPlaceholderText(text)) continue;

      const html = this.extractFormattedHtmlFromClone(sanitizedNode);
      blocks.push({
        element: node,
        text,
        html,
        position: this.getElementPosition(node),
        metadata: this.extractMetadata(node),
        structuredRole: role
      });
    }

    blocks.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));
    this.debugLog('[MessageExtractor] extractGeminiBlocks found', blocks.length, 'blocks');
    return blocks;
  }

  extractStructuredBlocks(container) {
    if (!container?.querySelectorAll) {
      return [];
    }

    const SELECTORS = [
      '[data-message-author-role]',
      '[data-role]',
      '[aria-label*="message" i]',
      '[aria-label*="answer" i]',
      '[data-testid*="message" i]',
      '[data-testid*="turn" i]',
      '[data-is-streaming]',
      'conversation-turn',
      'message-content',
      '[class*="font-user-message" i]',
      '[class*="font-claude-response" i]',
      '[class*="user-message" i]',
      '[class*="assistant-message" i]',
      '[class*="standard-markdown" i]',
      // ChatGPT class-based assistant patterns (new UI uses .agent-turn instead of data attributes)
      '.agent-turn',
      '[class*="agent-turn"]',
      // Gemini custom elements and selectors
      'user-query',
      'model-response',
      'query-text',
      '.query-text',
      '.user-message-text',
      // Gemini conversation title that contains the first query
      '[class*="conversation-title" i]',
      '[class*="chat-title" i]',
      // Manus.im selectors (uses divs with whitespace-pre-wrap for text blocks)
      'div[class*="whitespace-pre-wrap"]',
      'div[class*="max-w-none"][class*="text-[16px]"]',
      // HuggingFace selectors (flexible patterns for flex containers and styled divs)
      'div[class*="rounded"][class*="bg-"][class*="p-"]',
      'div[class*="prose"][class*="max-w"]'
    ];

    const nodes = SELECTORS.flatMap((selector) => Array.from(container.querySelectorAll(selector)));
    this.debugLog('[MessageExtractor] extractStructuredBlocks found', nodes.length, 'nodes from selectors');
    if (!nodes.length) {
      return [];
    }

    // Deduplicate: when multiple selectors match ancestor + descendant (e.g., SECTION turn + inner DIV),
    // prefer the deepest node (which has the most specific role information like [data-message-author-role]).
    // A node is kept only if no other matched node is its descendant.
    const filtered = [];
    const depthCache = new Map();
    function getDepth(el) {
      let d = depthCache.get(el);
      if (d !== undefined) return d;
      d = 0;
      let cur = el;
      while ((cur = cur.parentElement)) d++;
      depthCache.set(el, d);
      return d;
    }
    for (const node of nodes) {
      if (!node || this.shouldSkipElement(node)) continue;
      const hasDescendant = nodes.some(other => other !== node && node.contains(other));
      if (!hasDescendant) {
        filtered.push(node);
      }
    }
    // Sort deepest first so inner (role-rich) nodes get processed first, and their ancestors are
    // already in the seen set when we encounter them later (from fallback selectors).
    // But we already filtered ancestors above, so this sort is for safety.
    filtered.sort((a, b) => getDepth(b) - getDepth(a));

    this.debugLog('[MessageExtractor] After ancestor dedup:', filtered.length, 'nodes');

    const seen = new Set();
    const blocks = [];
    for (const node of filtered) {
      if (seen.has(node) || this.shouldSkipElement(node)) {
        continue;
      }

      seen.add(node);
      
      const metadata = this.extractMetadata(node);

      // First try data attributes
      let role = this.normalizeRoleHint(
        node.dataset?.messageAuthorRole,
        node.dataset?.role,
        node.getAttribute?.('data-message-author-role'),
        node.getAttribute?.('aria-label')
      );
      
      // If no role from attributes, check tag name (for custom elements like user-query, model-response)
      if (role === 'unknown') {
        const tagName = (node.tagName || '').toLowerCase();
        const className = (node.className || '').toLowerCase();
        if (/(user-query|query-container|user-message)/.test(tagName) ||
            /(user-query|query-text|query-container|user-message)/.test(tagName) ||
            /(query-text|user-message-text|conversation-title|chat-title)/.test(className)) {
          role = 'user';
        } else if (/(model-response|assistant-message)/.test(tagName)) {
          role = 'assistant';
        }
      }

      if (role === 'unknown') {
        role = this.getRoleFromAncestors(node);
      }

      if (role === 'unknown') {
        role = this.getRoleFromClassNames(metadata);
      }

      const contentNode = this.getPrimaryContentNode(node);
      const sanitizedNode = this.cloneNodeWithoutMedia(contentNode);
      if (!sanitizedNode) {
        continue;
      }

      let text = this.cleanMessageText(this.extractCleanText(node), role);
      if (!text) {
        continue;
      }

      if (text.length < 3 && role === 'unknown') {
        continue;
      }

      if (this.isPlaceholderText(text) && role === 'unknown') {
        continue;
      }

      const html = this.extractFormattedHtmlFromClone(sanitizedNode);
      blocks.push({
        element: node,
        text,
        html,
        position: this.getElementPosition(node),
        metadata,
        structuredRole: role
      });
    }

    blocks.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));
    return blocks;
  }

  /**
   * Check if element should be skipped
   */
  isInsideNavContainer(element) {
    if (!element) return false;
    if (this._isNavElement(element)) return true;
    let current = element.parentElement;
    let depth = 0;
    const MAX_NAV_DEPTH = 8;
    while (current && depth < MAX_NAV_DEPTH) {
      depth++;
      if (this._isNavElement(current)) return true;
      current = current.parentElement;
    }
    return false;
  }

  /** Check a single element for nav/sidebar characteristics */
  _isNavElement(el) {
    const tag = el.tagName.toLowerCase();
    if (tag === 'nav' || tag === 'aside') return true;
    const role = el.getAttribute('role') || '';
    if (role === 'navigation') return true;
    const className = (el.className || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    const combined = [className, id].filter(Boolean).join(' ');
    // Only match explicit nav/sidebar patterns. Avoid overly broad
    // substrings like "history" (matches "chat-history") or "menu"
    // (matches "documentation-menu") which cause legitimate conversation
    // containers to be classified as navigation and their content skipped.
    if (/(^sidebar$|sidebar-|sidebar_|nav-|-nav)/i.test(combined)) {
      return true;
    }
    return false;
  }

  shouldSkipElement(element) {
    const tag = element.tagName.toLowerCase();
    
    // Skip these elements
    if (['script', 'style', 'link', 'meta', 'svg', 'path', 'button', 'input', 'textarea'].includes(tag)) {
      return true;
    }

    // Skip hidden elements
    const style = globalThis.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') {
      return true;
    }

    const className = element.className || '';
    const id = element.id || '';
    const combined = (className + ' ' + id).toLowerCase();
    
    // FIRST check for navigation/sidebar elements - these should always be skipped
    // Avoid overly broad terms like "panel" (matches "panel-content", "chat-panel"),
    // "dialog" (matches "<dialog>" conversation containers), or "modal"
    // (matches modal-hosted conversations). The isInsideNavContainer check below
    // already catches truly nested nav elements via tag/role/class heuristics.
    if (/(^nav$|sidebar|^header$|^footer$|menu|toolbar|toast|notification)/i.test(combined)) {
      return true;
    }

    // THEN check if this is a message-related element - but verify it's not inside a nav sidebar container
    if (/(message|query|response|chat|conversation|turn|content)/i.test(combined)) {
      // Even if class names suggest a message, skip if inside a nav/sidebar/header container
      if (this.isInsideNavContainer(element)) {
        return true;
      }
      return false;
    }

    // For any other element, also check if it's inside a navigation container
    if (this.isInsideNavContainer(element)) {
      return true;
    }

    return false;
  }

  /**
   * Check if element is likely a message container
   */
  isMessageCandidate(element) {
    const tagName = element.tagName.toLowerCase();
    const className = element.className || '';
    const text = this.extractCleanText(element);
    
    // Must have substantial text
    if (!text || text.length < 10) return false;

    if (this.isInsideNavContainer(element)) return false;
    
    // High-priority: divs used for message content in modern chat apps (like Manus, HuggingFace)
    // These are typically styled divs that contain plain text or formatted content
    if (tagName === 'div') {
      // Whitespace-preserving divs used for message content (Manus, HuggingFace styles)
      // Support flexible matching: exact classes OR containing variations
      if ((className.includes('whitespace-pre-wrap') || className.match(/whitespace|preserve/i)) && text.length > 15) {
        return true;
      }
      
      // Content wrapper divs in rich editors (supports max-w-none, max-w, content-box patterns)
      if ((className.includes('max-w') || className.match(/max-width|content.*wrap/i)) && text.length > 50) {
        return true;
      }
      
      // Message-specific divs (supports message-text, message-content, chat-bubble, etc.)
      if (className.match(/message|chat|bubble|response|user|query/i) && text.length > 15) {
        return true;
      }
    }
    
    // Simple paragraph elements are high-priority message blocks (e.g., some Manus pages)
    if (tagName === 'p' && text.length > 20) {
      const children = Array.from(element.children);
      // Only accept if it's a leaf node or has minimal formatting children
      if (children.length === 0 || (children.length <= 3 && children.every(c => ['span', 'strong', 'em', 'b', 'i', 'code'].includes(c.tagName.toLowerCase())))) {
        return true;
      }
    }

    // Check if children also have substantial text (nested structure)
    const children = Array.from(element.children);
    const childrenWithText = children.filter(child => {
      const childText = this.extractCleanText(child);
      return childText && childText.length > 10;
    });

    // If many children have text, this is probably a container, not a message
    // Increased from 5 to 15 to handle platforms with multiple sub-blocks (like Manus)
    if (childrenWithText.length > 15) return false;

    // Good signs: markdown, message-related class names
    const hasMessageClass = /(message|chat|turn|query|response|content)/i.test(className);
    
    // Custom elements (like Gemini's user-query, model-response)
    const isCustomElement = tagName.includes('-');
    
    // List elements can be part of messages
    if ((tagName === 'ul' || tagName === 'ol') && text.length > 30) {
      return true;
    }
    
    return hasMessageClass || isCustomElement || text.length > 50;
  }

  /**
   * Extract clean text from element
   */
  extractCleanText(element) {
    const contentNode = this.getPrimaryContentNode(element);
    const sanitized = this.cloneNodeWithoutMedia(contentNode);

    // First try the sanitized clone (strips media but also buttons/UI)
    let text = this.extractTextFromClone(sanitized);

    // If sanitized text is empty but the original element has meaningful text,
    // fall back to the original element's text content. This handles cases
    // like ChatGPT's stopped/thinking responses where text lives inside
    // <button> elements that get stripped by cloneNodeWithoutMedia.
    if (!text || text.length < 3) {
      const originalText = this.extractTextFromElement(element);
      if (originalText && originalText.length >= 3) {
        text = originalText;
      }
    }

    return text;
  }

  extractTextFromClone(sanitized) {
    if (!sanitized) {
      return '';
    }

    let text;
    const childCount = sanitized.childNodes.length;
    if (childCount <= 1) {
      text = sanitized.textContent || '';
    } else {
      const parts = [];
      for (const child of sanitized.childNodes) {
        const childText = (child.textContent || '').trim();
        if (childText) parts.push(childText);
      }
      text = parts.join(' ');
    }
    text = text.replaceAll(/\s+/g, ' ').trim();
    return text;
  }

  extractTextFromElement(element) {
    if (!element) return '';
    const text = (element.textContent || '').replaceAll(/\s+/g, ' ').trim();
    return text;
  }

  cleanMessageText(text, role = 'unknown') {
    let cleaned = (text || '').replaceAll(/\s+/g, ' ').trim();
    if (!cleaned) {
      return '';
    }

    const userLabel = '(?:you said|your prompt|あなたのプロンプト|ユーザー(?:の)?(?:プロンプト|入力)?)';
    const assistantLabel = '(?:assistant|chatgpt said|gemini の回答|gemini response|model response)';

    if (role === 'user') {
      cleaned = cleaned.replace(new RegExp(`^${userLabel}\\s*[:：]?\\s*`, 'i'), '').trim();
    } else if (role === 'assistant') {
      cleaned = cleaned.replace(new RegExp(`^${assistantLabel}\\s*[:：]?\\s*`, 'i'), '').trim();
    } else {
      cleaned = cleaned
        .replace(new RegExp(`^${userLabel}\\s*[:：]?\\s*`, 'i'), '')
        .replace(new RegExp(`^${assistantLabel}\\s*[:：]?\\s*`, 'i'), '')
        .trim();
    }

    return cleaned;
  }

  extractFormattedHtml(element) {
    if (!element) {
      return '';
    }

    const htmlSource = this.getPrimaryContentNode(element);
    const sanitizedSource = this.cloneNodeWithoutMedia(htmlSource);
    return this.extractFormattedHtmlFromClone(sanitizedSource);
  }

  extractFormattedHtmlFromClone(cloneNode) {
    if (!cloneNode) {
      return '';
    }

    const sanitized = this.cloneAllowedNode(cloneNode);
    if (!sanitized) {
      return '';
    }

    const wrapper = document.createElement('div');
    wrapper.appendChild(sanitized);
    const html = wrapper.innerHTML.trim();
    if (html.length > 4000) {
      return html.substring(0, 4000);
    }
    return html;
  }

  cloneAllowedNode(node) {
    if (!node) {
      return null;
    }

    if (node.nodeType === Node.TEXT_NODE) {
      return document.createTextNode(node.textContent || '');
    }

    if (node.nodeType !== Node.ELEMENT_NODE) {
      return null;
    }

    return this.cloneAllowedElement(node);
  }

  cloneAllowedElement(element) {
    const tagName = element.tagName?.toLowerCase() || '';
    const isAllowed = ALLOWED_HTML_TAGS.has(tagName);
    const container = isAllowed ? document.createElement(tagName) : document.createDocumentFragment();

    if (isAllowed && element.attributes) {
      this.copyAllowedAttributes(container, element);
    }

    for (const child of Array.from(element.childNodes)) {
      const cloned = this.cloneAllowedNode(child);
      if (cloned) {
        container.appendChild(cloned);
      }
    }

    return container;
  }

  getPrimaryContentNode(element) {
    if (!element) {
      return null;
    }
    const rootText = this.getNormalizedElementText(element);
    const selectors = [
      '[class*="content" i]',
      'message-content',
      '[class*="markdown" i]',
      '.markdown',
      '.text-base',
      '[class*="response" i]',
      '[class*="standard-markdown" i]',
      '[data-testid*="message" i]',
      '[data-testid*="content" i]',
      // Target role-attributed divs inside agent-turn wrappers
      '[data-message-author-role]',
      // Gemini-specific selectors
      '.query-text',
      '.user-message-text',
      'query-text'
    ];

    let bestMatch = null;
    let bestLength = 0;
    for (const selector of selectors) {
      const matches = Array.from(element.querySelectorAll?.(selector) || []);
      for (const match of matches) {
        const textLength = this.getNormalizedElementText(match).length;
        if (textLength > bestLength) {
          bestMatch = match;
          bestLength = textLength;
        }
      }
    }

    if (bestMatch) {
      const rootLength = rootText.length;
      if (!rootLength || bestLength >= Math.min(rootLength, Math.max(80, rootLength * 0.65))) {
        return bestMatch;
      }
    }

    return element;
  }

  getNormalizedElementText(element) {
    if (!element) return '';
    const clone = this.cloneNodeWithoutMedia(element);
    return (clone?.textContent || '').replaceAll(/\s+/g, ' ').trim();
  }

  cloneNodeWithoutMedia(element) {
    if (!element || typeof element.cloneNode !== 'function') {
      return null;
    }
    const clone = element.cloneNode(true);
    this.stripMediaElements(clone);
    return clone;
  }

  stripMediaElements(root) {
    if (!root) {
      return;
    }
    const scope = typeof root.querySelectorAll === 'function' ? root : null;
    if (!scope) {
      return;
    }

    for (const mediaNode of scope.querySelectorAll(MEDIA_STRIP_SELECTOR)) {
      mediaNode.remove();
    }

    for (const uiNode of scope.querySelectorAll(UI_STRIP_SELECTOR)) {
      uiNode.remove();
    }

    for (const figure of scope.querySelectorAll('figure')) {
      const caption = figure.querySelector('figcaption');
      const hasCaptionText = caption?.textContent?.trim().length;
      if (caption && hasCaptionText) {
        const replacement = document.createElement('div');
        replacement.appendChild(caption.cloneNode(true));
        figure.replaceWith(replacement);
        return;
      }

      const remainingText = (figure.textContent || '').trim();
      if (!remainingText) {
        figure.remove();
      }
    }
  }

  copyAllowedAttributes(targetElement, sourceElement) {
    for (const attr of Array.from(sourceElement.attributes)) {
      const attrName = attr.name?.toLowerCase();
      if (!ALLOWED_HTML_ATTRS.has(attrName)) {
        continue;
      }
      if (attrName === 'href' && /^javascript:/i.test(attr.value || '')) {
        continue;
      }
      targetElement.setAttribute(attr.name, attr.value);
    }
  }

  /**
   * Get element position in document
   */
  getElementPosition(element) {
    if (!element || typeof element.getBoundingClientRect !== 'function') {
      return Number.MAX_SAFE_INTEGER;
    }

    const rect = element.getBoundingClientRect();
    const scrollY = Number(globalThis.scrollY) || 0;
    const scrollX = Number(globalThis.scrollX) || 0;
    const top = rect.top + scrollY;
    const left = rect.left + scrollX;

    if (!Number.isFinite(top) || !Number.isFinite(left)) {
      return Number.MAX_SAFE_INTEGER;
    }

    // Combine top and left so overlapping nodes still get deterministic ordering
    return Math.round(top * 10000 + left);
  }

  /**
   * Extract metadata from element
   */
  extractMetadata(element) {
    return {
      tagName: element.tagName.toLowerCase(),
      className: element.className || '',
      id: element.id || '',
      dataRole: element.dataset?.role || '',
      dataAuthor: element.dataset?.messageAuthorRole || '',
      ariaLabel: element.getAttribute('aria-label') || ''
    };
  }

  /**
   * Check if text is a placeholder
   */
  isPlaceholderText(text) {
    const trimmed = text.trim().toLowerCase();
    
    if (trimmed.length > 100) return false;

    const placeholderPatterns = [
      /^(type|enter|write|ask).*(message|question|here)/i,
      /^(start|begin).*(typing|conversation)/i,
      /^placeholder$/i,
      /^untitled/i,
      /^\.\.\./,
      /^loading/i,
      /^thinking/i,
      /^generating/i,
      /^copy$/i,
      /^code$/i,
      /^\d+$/,  // Just numbers
      /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,  // Dates
    ];

    for (const pattern of placeholderPatterns) {
      if (pattern.test(trimmed)) return true;
    }

    // Repetitive characters
    const uniqueChars = new Set(trimmed.replaceAll(/\s/g, ''));
    if (uniqueChars.size <= 2 && trimmed.length > 3) return true;

    return false;
  }

  /**
   * Classify text blocks as user or assistant messages
   */
  classifyMessages(textBlocks) {
    const messages = [];
    
    for (let i = 0; i < textBlocks.length; i++) {
      const block = textBlocks[i];
      const rawRole = this.determineRole(block, i, textBlocks);
      const role = rawRole === 'assistant' || rawRole === 'user' ? rawRole : 'unknown';

      messages.push({
        role: role,
        content: block.text,
        html: block.html,
        timestamp: Date.now(),
        element: block.element,
        position: block.position
      });
    }

    // Deduplicate
    return this.deduplicateMessages(messages);
  }

  /**
   * Determine if a text block is from user or assistant
   */
  determineRole(block, index, allBlocks) {
    if (block.structuredRole === 'user' || block.structuredRole === 'assistant') {
      return block.structuredRole;
    }

    // Check explicit attributes first
    const roleFromAttributes = this.getRoleFromAttributes(block.metadata);
    if (roleFromAttributes !== 'unknown') return roleFromAttributes;

    const roleFromAncestors = this.getRoleFromAncestors(block.element);
    if (roleFromAncestors !== 'unknown') return roleFromAncestors;

    // Check class and tag names
    const roleFromClassNames = this.getRoleFromClassNames(block.metadata);
    if (roleFromClassNames !== 'unknown') return roleFromClassNames;

    // Use heuristics
    return this.getRoleFromHeuristics(index, allBlocks);
  }

  getRoleFromAttributes(meta) {
    return this.normalizeRoleHint(
      meta.dataRole,
      meta.dataAuthor,
      meta.ariaLabel
    );
  }

  getRoleFromAncestors(element) {
    let current = element?.parentElement;
    let depth = 0;
    const MAX_DEPTH = 15;

    while (current && depth < MAX_DEPTH) {
      depth += 1;
      const role = this.normalizeRoleHint(
        current.dataset?.role,
        current.dataset?.messageAuthorRole,
        current.getAttribute?.('data-message-author-role'),
        current.getAttribute?.('aria-label')
      );
      if (role !== 'unknown') {
        return role;
      }

      const className = (current.className || '').toLowerCase();
      const tagName = (current.tagName || '').toLowerCase();
      
      // Check tag name for custom elements
      if (/(user-query|query-text)/.test(tagName)) {
        return 'user';
      }
      if (/(model-response)/.test(tagName)) {
        return 'assistant';
      }
      
      // Check class name
      if (/(user|prompt|query|question|human|sender|asker)/.test(className)) {
        return 'user';
      }
      if (/(assistant|bot|model|ai|copilot|agent)/.test(className)) {
        return 'assistant';
      }

      current = current.parentElement;
    }

    return 'unknown';
  }

  getRoleFromClassNames(meta) {
    const className = (meta.className || '').toLowerCase();
    const tagName = (meta.tagName || '').toLowerCase();
    
    if (/(user|query|human|prompt|question|sender)/.test(className) ||
        /(user-query|query-container|user-message|query-text)/.test(tagName) ||
        /(font-user-message|claude-user|query-text|user-message-text|conversation-title|chat-title)/.test(className)) {
      return 'user';
    }
    
    if (/(assistant|bot|model|ai|copilot|agent)/.test(className) ||
        /(assistant-message|model-response)/.test(tagName) ||
        /(claude-response|font-claude-response|standard-markdown|agent-turn)/.test(className)) {
      return 'assistant';
    }

    return 'unknown';
  }

  normalizeRoleHint(...candidates) {
    for (const candidate of candidates) {
      if (!candidate) {
        continue;
      }
      const value = String(candidate).toLowerCase();
      if (/(user|human|you|sender|asker)/.test(value)) {
        return 'user';
      }
      if (/(assistant|bot|model|ai|copilot)/.test(value)) {
        return 'assistant';
      }
    }
    return 'unknown';
  }

  getRoleFromHeuristics(index, allBlocks) {
    // First message is usually from user
    if (index === 0) return 'user';
    
    // Check previous non-unknown message
    for (let j = index - 1; j >= 0; j--) {
      const prevRole = this.determineRole(allBlocks[j], j, allBlocks);
      if (prevRole !== 'unknown') {
        return prevRole === 'user' ? 'assistant' : 'user';
      }
    }
    
    // Default to alternating
    return index % 2 === 0 ? 'user' : 'assistant';
  }

  /**
   * Remove duplicate messages
   */
  deduplicateMessages(messages) {
    const normalize = (text) => text.toLowerCase().replaceAll(/\s+/g, ' ').trim();
    const unique = [];

    for (const msg of messages) {
      const normalized = normalize(msg.content);
      const match = this.findMatchingMessage(unique, msg.role, normalized, normalize);

      if (!match) {
        msg.__normalized = normalized;
        unique.push(msg);
        continue;
      }

      const { message: existing, relation } = match;

      if (relation === 'newContainsExisting') {
        existing.content = msg.content;
        existing.timestamp = msg.timestamp;
        existing.__normalized = normalized;
        this.updateMessageHtml(existing, msg, true);
        continue;
      }

      // relation is 'exact' or 'existingContainsNew'
      existing.timestamp = Math.max(existing.timestamp, msg.timestamp);
      this.updateMessageHtml(existing, msg);
    }

    for (const item of unique) {
      delete item.__normalized;
    }

    unique.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));

    return this.removeSequentialDuplicates(unique, normalize);
  }

  removeSequentialDuplicates(messages, normalizeFn) {
    const compacted = [];

    for (const current of messages) {
      const normalized = normalizeFn(current.content);
      if (!normalized) continue;

      const previous = compacted.at(-1);
      if (previous) {
        const prevNormalized = previous.__normalized ?? normalizeFn(previous.content);
        previous.__normalized = prevNormalized;

        const sameRole = previous.role === current.role;
        if (sameRole &&
            (normalized === prevNormalized ||
           this.isSubstantiveContainmentDuplicate(normalized, prevNormalized) ||
           this.isSubstantiveContainmentDuplicate(prevNormalized, normalized))) {
          // Prefer the richer content and the more likely role when duplicates appear back-to-back
          if (normalized.length > prevNormalized.length) {
            previous.content = current.content;
            previous.__normalized = normalized;
            this.updateMessageHtml(previous, current, true);
          }
          previous.timestamp = Math.max(previous.timestamp, current.timestamp);
          previous.role = this.preferRole(previous.role, current.role);
          this.updateMessageHtml(previous, current);
          continue;
        }
      }

      current.__normalized = normalized;
      compacted.push(current);
    }

    for (const item of compacted) {
      delete item.__normalized;
    }

    return compacted;
  }

  updateMessageHtml(target, source, overwrite = false) {
    if (!target || !source) {
      return;
    }
    if (overwrite) {
      if (source.html) {
        target.html = source.html;
      }
      return;
    }
    if (!target.html && source.html) {
      target.html = source.html;
    }
  }
  preferRole(existingRole, incomingRole) {
    if (!incomingRole) return existingRole || 'assistant';
    if (!existingRole) return incomingRole;
    if (incomingRole === existingRole) return existingRole;

    const priority = ['assistant', 'user', 'system', 'unknown'];
    const existingIndex = priority.indexOf(existingRole);
    const incomingIndex = priority.indexOf(incomingRole);
    if (incomingIndex === -1 && existingIndex === -1) {
      return incomingRole;
    }
    if (incomingIndex === -1) {
      return existingRole;
    }
    if (existingIndex === -1) {
      return incomingRole;
    }
    return incomingIndex <= existingIndex ? incomingRole : existingRole;
  }

  findMatchingMessage(candidates, role, normalizedText, normalizeFn) {
    for (const candidate of candidates) {
      if (candidate.role !== role) continue;

      const candidateNormalized = candidate.__normalized ?? normalizeFn(candidate.content);
      candidate.__normalized = candidateNormalized;

      if (normalizedText === candidateNormalized) {
        return { message: candidate, relation: 'exact' };
      }

      if (candidateNormalized.includes(normalizedText)) {
        if (this.isSubstantiveContainmentDuplicate(candidateNormalized, normalizedText)) {
          return { message: candidate, relation: 'existingContainsNew' };
        }
      }

      if (normalizedText.includes(candidateNormalized)) {
        if (this.isSubstantiveContainmentDuplicate(normalizedText, candidateNormalized)) {
          return { message: candidate, relation: 'newContainsExisting' };
        }
      }
    }
    return null;
  }

  isSubstantiveContainmentDuplicate(longerText, shorterText) {
    if (!longerText || !shorterText || !longerText.includes(shorterText)) {
      return false;
    }

    if (shorterText.length < 20) {
      return false;
    }

    return shorterText.length / longerText.length >= 0.55;
  }

  /**
   * Build final conversation object
   */
  buildConversation(messages) {
    messages.sort((a, b) => this.compareBlocksByDocumentOrder(a, b));

    if (!messages.length) {
      this.debugLog('[MessageExtractor] No messages extracted');
      return null;
    }

    // Generate title from first user message
    const title = this.generateTitle(messages);
    
    // Generate conversation ID
    const conversationId = this.generateConversationId();

    return {
      id: conversationId,
      platform: this.platform.name,
      title: title,
      url: globalThis.location.href,
      messages: messages.map(m => ({
        role: m.role,
        content: m.content,
        ...(m.html ? { html: m.html } : {}),
        ...(Number.isFinite(m.position) ? { position: m.position } : {}),
        timestamp: m.timestamp
      })).map((message, index) => ({ ...message, order: index })),
      lastUpdated: Date.now(),
      summary: this.generateSummary(messages)
    };
  }

  /**
   * Generate conversation title
   */
  generateTitle(messages) {
    const firstCandidate = messages.find(m => m.role === 'user') || messages[0];
    
    if (firstCandidate) {
      const content = firstCandidate.content.trim();
      const firstSentence = content.split(/[.!?。！？\n]/)[0].trim();
      
      if (firstSentence.length >= 10 && firstSentence.length <= 100) {
        return firstSentence;
      } else if (firstSentence.length > 100) {
        return firstSentence.substring(0, 80) + '...';
      } else if (content.length > 10) {
        return content.substring(0, 50) + (content.length > 50 ? '...' : '');
      }
    }

    // Try platform selector
    if (this.platform.selectors?.conversationTitle) {
      const titleElem = document.querySelector(this.platform.selectors.conversationTitle);
      const pageTitle = titleElem?.textContent?.trim();
      if (pageTitle && pageTitle.length >= 10 && !this.isPlaceholderText(pageTitle)) {
        return pageTitle.substring(0, 100);
      }
    }

    // Generate from timestamp
    const timestamp = new Date().toLocaleString();
    return `${this.platform.name} Conversation - ${timestamp}`;
  }

  /**
   * Generate conversation ID
   * Uses URL path segment as stable ID when available (enables dedup
   * in background.js across multiple extraction runs of the same page).
    * Falls back to a page-session ID for platforms that allow generic URLs;
    * platforms requiring distinct URLs still wait until the URL gains a stable identifier.
   */
  generateConversationId() {
    const path = globalThis.location.pathname;
    const parts = path.split('/').filter(Boolean);

    // If path has a meaningful ID (e.g., /chat/abc123)
    if (parts.length > 0) {
      const lastPart = parts.at(-1);
      if (lastPart.length > 5 && lastPart !== 'chat' && lastPart !== 'conversation') {
        // URL now has a unique segment — reset the generic-URL session ID so that
        // if the user later returns to a generic URL it gets a fresh entry.
        _genericUrlSessionId = null;
        return lastPart;
      }
    }

    // Generic URL (e.g., Gemini at /app without sidebar): reuse the same ID for the
    // entire page session so repeated extractions update one conversation entry rather
    // than creating duplicates.
    if (!_genericUrlSessionId) {
      _genericUrlSessionId = `${this.platform.name}-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
    }
    return _genericUrlSessionId;
  }

  /**
   * Generate summary for search
   */
  generateSummary(messages) {
    const firstFew = messages.slice(0, 3);
    return firstFew.map(m => m.content).join(' ').substring(0, 500);
  }
}

// Export for use in content script
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MessageExtractor;
} else {
  globalThis.MessageExtractor = MessageExtractor;
}
