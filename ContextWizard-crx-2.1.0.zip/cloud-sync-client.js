/**
 * ContextWizard Cloud Sync — Client SDK (Simplified v2)
 *
 * Key changes from v1:
 * - No deviceId: all devices share the same cloud storage
 * - Object-level sync: each conversation/bookmark synced individually
 * - Soft delete: deletions are marked and synced
 * - Server stores encrypted blob, client handles all merge logic
 */

const CLOUD_SYNC_API_BASE = 'https://api.contextwizard.app';
const CW_AUTH_TOKEN_KEY = 'cw_sync_auth_token';
const CW_USER_INFO_KEY = 'cw_sync_user_info';
const CW_LAST_SYNC_KEY = 'cw_cloud_last_sync_at';
const CW_SYNC_LOCK_KEY = 'cw_sync_in_progress';

let _syncInProgress = false;

async function _getToken() {
  const result = await new Promise((resolve) => {
    chrome.storage.local.get(CW_AUTH_TOKEN_KEY, resolve);
  });
  return result[CW_AUTH_TOKEN_KEY] || null;
}

async function _getLastSyncAt() {
  const result = await new Promise((resolve) => {
    chrome.storage.local.get(CW_LAST_SYNC_KEY, resolve);
  });
  return result[CW_LAST_SYNC_KEY] || 0;
}

async function _setLastSyncAt(timestamp) {
  await new Promise((resolve) => {
    chrome.storage.local.set({ [CW_LAST_SYNC_KEY]: timestamp }, resolve);
  });
}

async function _acquireSyncLock() {
  const result = await new Promise((resolve) => {
    chrome.storage.local.get(CW_SYNC_LOCK_KEY, resolve);
  });
  
  if (result[CW_SYNC_LOCK_KEY]) {
    const lockTime = result[CW_SYNC_LOCK_KEY];
    if (Date.now() - lockTime < 5 * 60 * 1000) {
      return false;
    }
    console.warn('[CloudSync] Stale sync lock detected, clearing');
  }
  
  await new Promise((resolve) => {
    chrome.storage.local.set({ [CW_SYNC_LOCK_KEY]: Date.now() }, resolve);
  });
  return true;
}

async function _releaseSyncLock() {
  await new Promise((resolve) => {
    chrome.storage.local.remove(CW_SYNC_LOCK_KEY, resolve);
  });
}

async function checkCloudKeyStatus() {
  const token = await _getToken();
  if (!token) return { hasKey: false, networkError: false };

  try {
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/sync/key-status`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    if (resp.ok) {
      return await resp.json();
    }
    // Server error (4xx/5xx) — treat as unknown, not as "no key"
    console.warn('[CloudSync] Key status check returned', resp.status);
    return { hasKey: false, networkError: true };
  } catch (e) {
    // Network error — cannot determine key status; do NOT treat as first device
    console.warn('[CloudSync] Failed to check key status (network error):', e);
    return { hasKey: false, networkError: true };
  }
}

async function setCloudKeyStatus(hasKey) {
  const token = await _getToken();
  if (!token) throw new Error('Not logged in — cannot set cloud key status');
  
  const maxRetries = 3;
  let lastError;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const resp = await fetch(`${CLOUD_SYNC_API_BASE}/sync/key-status`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ hasKey }),
      });
      
      if (resp.ok) return;
      
      lastError = new Error(`Server returned ${resp.status}`);
      console.warn(`[CloudSync] setCloudKeyStatus attempt ${attempt}/${maxRetries} failed:`, resp.status);
    } catch (e) {
      lastError = e;
      console.warn(`[CloudSync] setCloudKeyStatus attempt ${attempt}/${maxRetries} failed:`, e.message);
    }
    
    if (attempt < maxRetries) {
      await new Promise(r => setTimeout(r, 500 * Math.pow(2, attempt - 1)));
    }
  }
  
  throw new Error(
    `SET_KEY_STATUS_FAILED: Could not confirm key status with server after ${maxRetries} attempts. ` +
    `This is critical — without server confirmation, other devices may generate a different key. ` +
    `Please check your connection and retry. Last error: ${lastError?.message}`
  );
}

async function ensureEncryptionKey(isFirstDevice) {
  const Crypto = globalThis.CloudSyncCrypto;
  if (!Crypto) throw new Error('Crypto module not loaded');
  
  // Check if we already have a key
  const hasLocalKey = await Crypto.isEncryptionKeyAvailable();
  if (isFirstDevice) {
    // Server says no key exists for this account, so start fresh even if this
    // device still has stale key material from a previous sync generation.
    if (hasLocalKey && Crypto.clearAllStoredKeys) {

      await Crypto.clearAllStoredKeys();
    }

    // First device: generate new key

    const key = await Crypto.getMasterKey({ allowGenerate: true });
    await setCloudKeyStatus(true);
    return key;
  }

  if (hasLocalKey) {
    return await Crypto.getMasterKey();
  } else {
    // Subsequent device: wait for Chrome Sync to propagate key.
    // Chrome Sync can take up to 2+ minutes; use 120 s to match UI polling window.

    const key = await Crypto.waitForEncryptionKey(120000, 3000);
    if (key) return key;

    throw new Error('KEY_SYNC_TIMEOUT: Encryption key not received from Chrome Sync. Please check: 1) Same Google account on all devices, 2) Chrome Sync enabled, 3) Extensions sync turned on. Or manually export/import key from Settings.');
  }
}

async function login() {
  try {
    const authStartUrl = `${CLOUD_SYNC_API_BASE}/auth/google/start`;

    const responseUrl = await new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow(
        { url: authStartUrl, interactive: true },
        (callbackUrl) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(callbackUrl);
          }
        }
      );
    });

    const url = new URL(responseUrl);
    const error = url.searchParams.get('error');
    if (error) {
      return { success: false, error: `OAuth error: ${error}` };
    }

    const token = url.searchParams.get('token');
    const userB64 = url.searchParams.get('user');

    if (!token || !userB64) {
      return { success: false, error: 'Missing token in OAuth response' };
    }

    let user;
    try {
      user = JSON.parse(atob(userB64));
    } catch (e) {
      return { success: false, error: 'Invalid user data in OAuth response' };
    }

    await new Promise((resolve) => {
      chrome.storage.local.set({
        [CW_AUTH_TOKEN_KEY]: token,
        [CW_USER_INFO_KEY]: user,
      }, resolve);
    });

    return { success: true, user };
  } catch (error) {
    console.error('[CloudSync] Login error:', error);
    return { success: false, error: error.message };
  }
}

async function logout() {
  await new Promise((resolve) => {
    chrome.storage.local.remove([CW_AUTH_TOKEN_KEY, CW_USER_INFO_KEY], resolve);
  });
}

async function getUserInfo() {
  const result = await new Promise((resolve) => {
    chrome.storage.local.get(CW_USER_INFO_KEY, resolve);
  });
  return result[CW_USER_INFO_KEY] || null;
}

async function isLoggedIn() {
  const token = await _getToken();
  return !!token;
}

async function getAllLocalObjects() {
  const data = await new Promise((resolve) => {
    chrome.storage.local.get([
      'conversations',
      'bookmarks',
      'promptEditorTemplates',
      'searchHistory',
      'promptEditorReplaceHistory'
    ], resolve);
  });

  const syncData = await new Promise((resolve) => {
    chrome.storage.sync.get(['platformSettings', 'customPlatforms'], resolve);
  });

  const objects = {};

  // Conversations: key = "conversation_{platform}::{id}"
  for (const conv of (data.conversations || [])) {
    const key = `conversation_${conv.platform}::${conv.id}`;
    objects[key] = {
      type: 'conversation',
      id: conv.id,
      data: conv,
      updatedAt: conv.lastUpdated || conv.timestamp || Date.now(),
      deleted: false
    };
  }

  // Bookmarks: key = "bookmark_{id}"
  for (const bm of (data.bookmarks || [])) {
    const key = `bookmark_${bm.id}`;
    objects[key] = {
      type: 'bookmark',
      id: bm.id,
      data: bm,
      updatedAt: bm.updatedAt || bm.createdAt || Date.now(),
      deleted: false
    };
  }

  // Prompt Templates
  const templates = data.promptEditorTemplates || {};
  for (const [tmplKey, tmplValue] of Object.entries(templates)) {
    const key = `promptTemplate_${tmplKey}`;
    objects[key] = {
      type: 'promptTemplate',
      id: tmplKey,
      data: tmplValue,
      updatedAt: tmplValue.createdAt || Date.now(),
      deleted: false
    };
  }

  // Search History (full object)
  if ((data.searchHistory || []).length > 0) {
    const key = 'searchHistory_main';
    objects[key] = {
      type: 'searchHistory',
      id: 'main',
      data: { items: data.searchHistory },
      updatedAt: Date.now(),
      deleted: false
    };
  }

  // Replace History
  const replaceHistory = data.promptEditorReplaceHistory || {};
  if (Object.keys(replaceHistory).length > 0) {
    const key = 'replaceHistory_main';
    objects[key] = {
      type: 'replaceHistory',
      id: 'main',
      data: replaceHistory,
      updatedAt: Date.now(),
      deleted: false
    };
  }

  // Settings from sync storage
  if (syncData.platformSettings) {
    const key = 'settings_platformSettings';
    objects[key] = {
      type: 'settings',
      id: 'platformSettings',
      data: syncData.platformSettings,
      updatedAt: Date.now(),
      deleted: false
    };
  }

  if (syncData.customPlatforms) {
    const key = 'settings_customPlatforms';
    objects[key] = {
      type: 'settings',
      id: 'customPlatforms',
      data: syncData.customPlatforms,
      updatedAt: Date.now(),
      deleted: false
    };
  }

  return objects;
}

function applyMergedObjects(objects) {
  const localData = {};
  const syncData = {};

  return new Promise((resolve) => {
    chrome.storage.local.get([
      'conversations',
      'bookmarks',
      'promptEditorTemplates',
      'searchHistory',
      'promptEditorReplaceHistory'
    ], (data) => {
      const convMap = new Map();
      const bmMap = new Map();
      const tmplMap = { ...(data.promptEditorTemplates || {}) };
      let searchHistory = data.searchHistory || [];
      let replaceHistory = data.promptEditorReplaceHistory || {};
      let platformSettings = null;
      let customPlatforms = null;

      // Initialize maps with existing local data
      for (const conv of (data.conversations || [])) {
        convMap.set(`${conv.platform}::${conv.id}`, conv);
      }
      for (const bm of (data.bookmarks || [])) {
        bmMap.set(bm.id, bm);
      }

      // Apply incoming objects
      for (const [, obj] of Object.entries(objects)) {
        if (obj.deleted) {
          if (obj.type === 'conversation') {
            const convKey = obj.data?.platform && obj.data?.id ? `${obj.data.platform}::${obj.data.id}` : obj.id;
            convMap.delete(convKey);
          } else if (obj.type === 'bookmark') {
            bmMap.delete(obj.id);
          } else if (obj.type === 'promptTemplate') {
            delete tmplMap[obj.id];
          }
          continue;
        }

        if (obj.type === 'conversation') {
          const convKey = `${obj.data.platform}::${obj.data.id}`;
          const existing = convMap.get(convKey);
          if (!existing || obj.updatedAt >= (existing.lastUpdated || 0)) {
            convMap.set(convKey, obj.data);
          }
        } else if (obj.type === 'bookmark') {
          const existing = bmMap.get(obj.id);
          if (!existing || obj.updatedAt >= (existing.updatedAt || existing.createdAt || 0)) {
            bmMap.set(obj.id, obj.data);
          }
        } else if (obj.type === 'promptTemplate') {
          tmplMap[obj.id] = obj.data;
        } else if (obj.type === 'searchHistory') {
          searchHistory = [...new Set([...searchHistory, ...(obj.data.items || [])])].slice(0, 1000);
        } else if (obj.type === 'replaceHistory') {
          replaceHistory = { ...replaceHistory, ...obj.data };
        } else if (obj.type === 'settings') {
          if (obj.id === 'platformSettings') {
            platformSettings = obj.data;
          } else if (obj.id === 'customPlatforms') {
            customPlatforms = obj.data;
          }
        }
      }

      // Build update objects
      localData.conversations = Array.from(convMap.values());
      localData.bookmarks = Array.from(bmMap.values());
      localData.promptEditorTemplates = tmplMap;
      localData.searchHistory = searchHistory;
      localData.promptEditorReplaceHistory = replaceHistory;

      if (platformSettings) {
        syncData.platformSettings = platformSettings;
      }
      if (customPlatforms) {
        syncData.customPlatforms = customPlatforms;
      }

      resolve({ localData, syncData });
    });
  });
}

async function mergeObjects(localObjects, remoteObjects) {
  const merged = { ...localObjects };

  for (const [key, remote] of Object.entries(remoteObjects)) {
    if (remote.deleted) {
      // Mark as deleted - will be filtered out on next sync
      merged[key] = { ...remote };
      continue;
    }

    const local = localObjects[key];
    if (!local) {
      merged[key] = remote;
    } else if (remote.updatedAt >= local.updatedAt) {
      // Remote is newer or equal - use remote
      merged[key] = remote;
    }
    // Otherwise keep local (local is newer)
  }

  return merged;
}

async function pushSync({ onProgress } = {}) {
  if (_syncInProgress) {
    return { success: false, error: 'Sync already in progress' };
  }
  
  const lockAcquired = await _acquireSyncLock();
  if (!lockAcquired) {
    return { success: false, error: 'Sync already in progress (detected via storage lock)' };
  }
  _syncInProgress = true;

  try {
    const token = await _getToken();
    if (!token) return { success: false, error: 'Not logged in' };

    const Crypto = globalThis.CloudSyncCrypto;
    if (!Crypto) throw new Error('Crypto module not loaded');

    if (onProgress) onProgress(10);

    // Check if this is first device or subsequent
    const cloudKeyStatus = await checkCloudKeyStatus();

    // If network error: we cannot safely determine whether a key exists on the
    // server. Never treat this as "first device" — doing so would generate a new
    // key and destroy the ability to decrypt existing cloud data.
    if (cloudKeyStatus.networkError) {
      return { success: false, error: 'Cannot verify key status: network error. Please check your connection and try again.' };
    }

    const isFirstDevice = !cloudKeyStatus.hasKey;

    // Ensure we have encryption key
    // For first device: generate new key
    // For subsequent devices: wait for Chrome Sync or fail
    if (onProgress) onProgress(15);
    await ensureEncryptionKey(isFirstDevice);

    // Get all local objects
    const localObjects = await getAllLocalObjects();
    const objectCount = Object.keys(localObjects).length;

    if (objectCount === 0) {
      if (onProgress) onProgress(100);
      return { success: true, syncType: 'none', message: 'Nothing to sync' };
    }

    if (onProgress) onProgress(30);

    // Encrypt
    const payload = {
      version: 1,
      objects: localObjects
    };

    // Measure raw (pre-encryption) size for accurate quota accounting
    const rawBytes = new TextEncoder().encode(JSON.stringify(payload)).length;

    const encrypted = await Crypto.encryptSyncData(payload);

    if (onProgress) onProgress(60);

    // Upload
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/sync/push`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/octet-stream',
        'X-Raw-Size': String(rawBytes),
      },
      body: encrypted,
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      const errorMsg = err.error || `Push failed (${resp.status})`;
      if (resp.status === 413) {
        return { success: false, error: errorMsg, quotaExceeded: true, used: err.used, limit: err.limit };
      }
      throw new Error(errorMsg);
    }

    if (onProgress) onProgress(90);

    await _setLastSyncAt(Date.now());

    if (onProgress) onProgress(100);

    return { success: true, syncType: 'push', objectCount };
  } catch (error) {
    console.error('[CloudSync] Push error:', error);
    return { success: false, error: error.message };
  } finally {
    _syncInProgress = false;
    await _releaseSyncLock();
  }
}

async function pullSync({ onProgress } = {}) {
  if (_syncInProgress) {
    return { success: false, error: 'Sync already in progress' };
  }
  
  const lockAcquired = await _acquireSyncLock();
  if (!lockAcquired) {
    return { success: false, error: 'Sync already in progress (detected via storage lock)' };
  }
  _syncInProgress = true;

  try {
    const token = await _getToken();
    if (!token) return { success: false, error: 'Not logged in' };

    const Crypto = globalThis.CloudSyncCrypto;
    if (!Crypto) throw new Error('Crypto module not loaded');

    if (onProgress) onProgress(10);

    // Check if cloud has data
    const cloudKeyStatus = await checkCloudKeyStatus();

    if (onProgress) onProgress(15);

    // Ensure we have encryption key before attempting decrypt
    // For subsequent devices: must wait for key from Chrome Sync
    // Note: if network error, we still try to pull — the pull request itself will
    // fail or return empty if the server is unreachable.
    const hasCloudData = cloudKeyStatus.hasKey && !cloudKeyStatus.networkError;
    if (hasCloudData) {
      try {
        await ensureEncryptionKey(false);
      } catch (e) {
        if (e.message.includes('KEY_SYNC_TIMEOUT') || e.message.includes('NO_ENCRYPTION_KEY')) {
          return { success: false, error: e.message };
        }
        throw e;
      }
    }

    if (onProgress) onProgress(20);

    // Download encrypted blob
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/sync/pull`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });

    if (!resp.ok) {
      throw new Error(`Pull failed (${resp.status})`);
    }

    if (onProgress) onProgress(30);

    const encryptedBuffer = await resp.arrayBuffer();

    // Check if there's data
    if (encryptedBuffer.byteLength === 0) {
      if (onProgress) onProgress(100);
      await _setLastSyncAt(Date.now());
      return { success: true, syncType: 'none', message: 'No cloud data' };
    }

    if (onProgress) onProgress(50);

    // Decrypt
    let remoteData;
    try {
      remoteData = await Crypto.decryptSyncData(encryptedBuffer);
    } catch (e) {
      console.warn('[CloudSync] Decrypt failed:', e.message);
      // Check if we have a key - if not, this might be first sync
      const hasKey = await Crypto.isEncryptionKeyAvailable();
      if (!hasKey) {
        return { success: false, error: 'NO_ENCRYPTION_KEY: Please wait for key sync from another device, or export/import key manually.' };
      }
      return { success: false, error: `Decryption failed: ${e.message}` };
    }

    if (onProgress) onProgress(70);

    const remoteObjects = remoteData.objects || {};

    // Get local objects
    const localObjects = await getAllLocalObjects();

    // Merge: LWW by updatedAt
    const mergedObjects = await mergeObjects(localObjects, remoteObjects);

    if (onProgress) onProgress(80);

    // Apply to local storage
    const { localData, syncData } = await applyMergedObjects(mergedObjects);

    await new Promise((resolve) => {
      chrome.storage.local.set(localData, resolve);
    });

    if (Object.keys(syncData).length > 0) {
      await new Promise((resolve) => {
        chrome.storage.sync.set(syncData, resolve);
      });
    }

    if (onProgress) onProgress(90);

    await _setLastSyncAt(Date.now());

    if (onProgress) onProgress(100);

    return { success: true, syncType: 'pull', objectCount: Object.keys(mergedObjects).length };
  } catch (error) {
    console.error('[CloudSync] Pull error:', error);
    return { success: false, error: error.message };
  } finally {
    _syncInProgress = false;
    await _releaseSyncLock();
  }
}

async function fullSync({ onProgress } = {}) {
  if (_syncInProgress) {
    return { success: false, error: 'Sync already in progress' };
  }

  // First pull to get remote changes, then push to upload local
  const pullResult = await pullSync({
    onProgress: onProgress ? (p) => onProgress(Math.round(p * 0.4)) : undefined,
  });

  // If pull failed due to a key issue, skip push entirely.
  // Pushing would either (a) time out waiting for the same missing key, or
  // (b) incorrectly treat a network error as "first device" and generate a
  // new key — destroying the ability to decrypt existing cloud data.
  const pullKeyError = !pullResult.success && pullResult.error && (
    pullResult.error.includes('KEY_SYNC_TIMEOUT') ||
    pullResult.error.includes('NO_ENCRYPTION_KEY') ||
    pullResult.error.includes('SET_KEY_STATUS_FAILED') ||
    pullResult.error.includes('DECRYPTION_KEY_MISMATCH') ||
    pullResult.error.includes('ENCRYPTION_KEY_NOT_FOUND') ||
    pullResult.error.includes('key status')
  );
  if (pullKeyError) {
    if (onProgress) onProgress(100);
    return {
      success: false,
      quotaExceeded: false,
      pullResult,
      pushResult: { success: false, error: 'Skipped: encryption key not available' },
    };
  }

  const pushResult = await pushSync({
    onProgress: onProgress ? (p) => onProgress(40 + Math.round(p * 0.6)) : undefined,
  });

  return {
    success: pullResult.success && pushResult.success,
    quotaExceeded: pushResult.quotaExceeded || false,
    pullResult,
    pushResult,
  };
}

function isSyncing() {
  return _syncInProgress;
}

async function getSyncStatus() {
  const lastSyncedAt = await _getLastSyncAt();
  const loggedIn = await isLoggedIn();

  return {
    loggedIn,
    lastSyncedAt,
    isSyncing: _syncInProgress,
  };
}

async function setupPeriodicSync() {
  const [existing, lastSyncAt] = await Promise.all([
    new Promise(resolve => chrome.alarms.get('cw-cloud-sync', resolve)),
    _getLastSyncAt(),
  ]);

  const thirtyMin = 30 * 60 * 1000;
  const syncOverdue = lastSyncAt === 0 || (Date.now() - lastSyncAt > thirtyMin);

  if (existing && !syncOverdue) {

    return;
  }

  if (existing) {
    await new Promise(resolve => chrome.alarms.clear('cw-cloud-sync', resolve));
  }

  chrome.alarms.create('cw-cloud-sync', {
    delayInMinutes: syncOverdue ? 1 : 30,
    periodInMinutes: 30,
  });

}

async function handleAlarm(alarm) {
  if (alarm.name !== 'cw-cloud-sync') return;

  try {
    const loggedIn = await isLoggedIn();
    if (!loggedIn) {

      return;
    }

    const token = await _getToken();
    const statusResp = await fetch(`${CLOUD_SYNC_API_BASE}/subscription/status`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });

    if (!statusResp.ok) {
      console.warn('[CloudSync] Auto-sync skipped: status check failed', statusResp.status);
      return;
    }

    const status = await statusResp.json();

    if (status.status !== 'active') {

      return;
    }

    const result = await fullSync();
    if (result.success) {

    } else if (result.quotaExceeded) {
      console.warn('[CloudSync] Auto-sync stopped: storage quota exceeded. Used:', result.pushResult?.used, '/ Limit:', result.pushResult?.limit);
    } else {
      console.warn('[CloudSync] Auto-sync failed:', result.pullResult?.error || result.pushResult?.error);
    }
  } catch (e) {
    console.error('[CloudSync] Auto-sync error:', e);
  }
}

async function checkEncryptionKeyAvailability() {
  const Crypto = globalThis.CloudSyncCrypto;
  if (!Crypto) {
    return { available: false, error: 'Crypto module not available' };
  }

  const localAvailable = await Crypto.isEncryptionKeyAvailable();
  if (localAvailable) return { available: true };

  // No local key — ask the server whether a key has ever been set up.
  // If the server says hasKey=false this is the first device; the key will be
  // generated automatically during the first pushSync, so we treat it as
  // "available" and let the user proceed instead of waiting forever.
  const cloudStatus = await checkCloudKeyStatus();

  // Network error: we can't tell — don't block the user but flag uncertainty.
  if (cloudStatus.networkError) {
    return { available: false, networkError: true };
  }

  if (!cloudStatus.hasKey) {
    // First device — key will be generated on first push.
    return { available: true, willGenerate: true };
  }

  // Server has a key but it hasn't arrived locally yet — wait for Chrome Sync.
  return { available: false };
}

async function clearCloudDataAndResetSync() {
  const token = await _getToken();
  if (!token) return { success: false, error: 'Not logged in' };

  const Crypto = globalThis.CloudSyncCrypto;
  if (!Crypto) throw new Error('Crypto module not loaded');

  try {
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/sync/clear-cloud-data`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
    });

    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      return { success: false, error: err.error || 'Failed to reset cloud sync' };
    }

    await Promise.all([
      Crypto.clearAllStoredKeys ? Crypto.clearAllStoredKeys() : Promise.resolve(),
      _setLastSyncAt(0),
    ]);

    // Explicitly reset server-side key status so next install treats this as first
    // device and generates a fresh key instead of waiting forever for a deleted key.
    await setCloudKeyStatus(false).catch((e) => {
      console.warn('[CloudSync] Failed to reset cloud key status:', e);
    });

    await setupPeriodicSync();

    return { success: true };
  } catch (error) {
    console.error('[CloudSync] Reset error:', error);
    return { success: false, error: error.message };
  }
}

async function getStatus() {
  const token = await _getToken();
  if (!token) return { loggedIn: false };

  try {
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/subscription/status`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });

    if (resp.status === 401) {
      // Token expired — clear auth
      await logout();
      return { loggedIn: false, error: 'Session expired' };
    }

    if (!resp.ok) throw new Error(`Status check failed (${resp.status})`);

    const data = await resp.json();
    return { loggedIn: true, ...data };
  } catch (error) {
    console.error('[CloudSync] Status error:', error);
    return { loggedIn: true, error: error.message };
  }
}

async function subscribe(plan = 'monthly') {
  const token = await _getToken();
  if (!token) return { success: false, error: 'Not logged in' };

  try {
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/subscription/checkout`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ plan }),
    });

    if (!resp.ok) throw new Error(`Checkout failed (${resp.status})`);

    const data = await resp.json();
    // Open Stripe Checkout in a new tab
    if (data.checkoutUrl) {
      chrome.tabs.create({ url: data.checkoutUrl });
    }
    return { success: true, url: data.checkoutUrl };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function purchaseAddon(addonType) {
  const token = await _getToken();
  if (!token) return { success: false, error: 'Not logged in' };

  try {
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/subscription/addon`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ addon_type: addonType }),
    });

    if (!resp.ok) throw new Error(`Addon checkout failed (${resp.status})`);

    const data = await resp.json();
    if (data.checkoutUrl) {
      chrome.tabs.create({ url: data.checkoutUrl });
    }
    return { success: true, url: data.checkoutUrl };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function manageSubscription() {
  const token = await _getToken();
  if (!token) return { success: false, error: 'Not logged in' };

  try {
    const resp = await fetch(`${CLOUD_SYNC_API_BASE}/subscription/portal`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
    });

    if (!resp.ok) throw new Error(`Portal failed (${resp.status})`);

    const data = await resp.json();
    if (data.url) {
      chrome.tabs.create({ url: data.url });
    }
    return { success: true, url: data.url };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

if (typeof globalThis !== 'undefined') {
  globalThis.CloudSyncClient = {
    login,
    logout,
    isLoggedIn,
    getUserInfo,
    pushSync,
    pullSync,
    fullSync,
    isSyncing,
    getSyncStatus,
    getStatus,
    subscribe,
    purchaseAddon,
    manageSubscription,
    checkEncryptionKeyAvailability,
    clearCloudDataAndResetSync,
    setupPeriodicSync,
    handleAlarm,
    CLOUD_SYNC_API_BASE,
  };
}
