// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Popup script for managing conversation list (with self-promotion banner)

// Import core popup logic
// eslint-disable-next-line no-undef
// The base implementation lives in popup.js; this file only adds banner behavior.
// Uses chromeApi and getMessage from popup.js (loaded first in popup.ad.html)

const UNLOCK_STORAGE_KEY = 'cwAdsUnlockState';
// eslint-disable-next-line no-undef
const popupAdChromeApi = globalThis.chrome;

document.addEventListener('DOMContentLoaded', () => {
  detectWindowType();
  const amazonAdLink = document.getElementById('amazonAdLink');
  const bannerElement = document.getElementById('selfAdBanner');
  const unlockElements = {
    button: document.getElementById('unlockAdBtn'),
    modal: document.getElementById('unlockModal'),
    form: document.getElementById('unlockForm'),
    input: document.getElementById('unlockCodeInput'),
    message: document.getElementById('unlockMessage'),
    closeBtn: document.getElementById('unlockCloseBtn'),
    cancelBtn: document.getElementById('unlockCancelBtn'),
    submitBtn: document.getElementById('unlockSubmitBtn')
  };

  initAmazonBanner(amazonAdLink);
  initUnlockWorkflow(bannerElement, unlockElements);
  
  // Initialize chat platforms button (defined in popup.js)
  if (typeof initChatPlatformsButton === 'function') {
    initChatPlatformsButton();
  }
});

// Detect if running in popup or standalone window
function detectWindowType() {
  popupAdChromeApi.windows.getCurrent((currentWindow) => {
    // If it's a popup type window (opened via chrome.windows.create)
    if (currentWindow.type === 'popup') {
      document.body.classList.add('resizable');
    }
  });
}

function initAmazonBanner(amazonAdLink) {
  if (!amazonAdLink) {
    return;
  }

  const DEFAULT_TAG = 'contextwizard-20';
  const JP_TAG = 'contextwiza-zip-22';
  const REGION_CONFIG = {
    'ja': { domain: 'amazon.co.jp', tag: JP_TAG },
    'en-GB': { domain: 'amazon.co.uk', tag: DEFAULT_TAG },
    'de': { domain: 'amazon.de', tag: DEFAULT_TAG },
    'fr': { domain: 'amazon.fr', tag: DEFAULT_TAG },
    'it': { domain: 'amazon.it', tag: DEFAULT_TAG },
    'es': { domain: 'amazon.es', tag: DEFAULT_TAG },
    'en-CA': { domain: 'amazon.ca', tag: DEFAULT_TAG },
    'fr-CA': { domain: 'amazon.ca', tag: DEFAULT_TAG },
    'en-AU': { domain: 'amazon.com.au', tag: DEFAULT_TAG },
    'default': { domain: 'amazon.com', tag: DEFAULT_TAG }
  };

  const uiLocale = (popupAdChromeApi?.i18n?.getMessage('@@ui_locale'))
    || navigator.language
    || 'en-US';
  const lang = uiLocale.replace('_', '-');
  const shortLang = lang.split('-')[0];
  const targetConfig = REGION_CONFIG[lang] || REGION_CONFIG[shortLang] || REGION_CONFIG.default;
  amazonAdLink.href = `https://www.${targetConfig.domain}/?tag=${targetConfig.tag}`;

  const titleEl = amazonAdLink.querySelector('.self-ad-title');
  const ctaEl = amazonAdLink.querySelector('.self-ad-cta');
  if (titleEl && ctaEl && typeof getMessage === 'function') {
    titleEl.textContent = getMessage('adAmazonTitle', titleEl.textContent);
    ctaEl.textContent = getMessage('adAmazonCta', ctaEl.textContent);
  }

  if (popupAdChromeApi?.tabs) {
    amazonAdLink.addEventListener('click', (event) => {
      event.preventDefault();
      popupAdChromeApi.tabs.create({ url: amazonAdLink.href });
    });
  }
}

function initUnlockWorkflow(bannerElement, elements) {
  if (!bannerElement || !elements?.button || !elements?.modal || !elements?.form || !elements?.input) {
    return;
  }

  elements.button.addEventListener('click', () => openUnlockModal(elements));
  elements.closeBtn?.addEventListener('click', () => closeUnlockModal(elements));
  elements.cancelBtn?.addEventListener('click', () => closeUnlockModal(elements));
  elements.modal.addEventListener('click', (event) => {
    if (event.target === elements.modal) {
      closeUnlockModal(elements);
    }
  });

  elements.form.addEventListener('submit', (event) => {
    event.preventDefault();
    void handleUnlockSubmission(bannerElement, elements);
  });

  const storage = popupAdChromeApi?.storage?.local;
  if (storage) {
    storage.get([UNLOCK_STORAGE_KEY], (stored) => {
      if (stored?.[UNLOCK_STORAGE_KEY]?.unlocked) {
        hideAdBanner(bannerElement, elements.button);
      }
    });
  }
}

function openUnlockModal(elements) {
  elements.modal.classList.remove('hidden');
  elements.modal.setAttribute('open', '');
  setUnlockMessage(elements.message, '', '');
  elements.input.value = '';
  elements.input.focus();
}

function closeUnlockModal(elements) {
  elements.modal.classList.add('hidden');
  elements.modal.removeAttribute('open');
}

async function handleUnlockSubmission(bannerElement, elements) {
  const code = elements.input.value.trim();
  if (!code) {
    setUnlockMessage(elements.message, getMessage('adUnlockEmpty', 'Please enter the unlock code.'), 'error');
    elements.input.focus();
    return;
  }

  if (!Array.isArray(globalThis.UNLOCK_HASHES) || !globalThis.UNLOCK_HASHES.length) {
    setUnlockMessage(elements.message, getMessage('adUnlockMissingHashes', 'Unlock data missing in this build.'), 'error');
    return;
  }

  setSubmittingState(elements, true);
  try {
    const hashedInput = await hashCode(code);
    const matched = globalThis.UNLOCK_HASHES.includes(hashedInput);
    if (!matched) {
      setUnlockMessage(elements.message, getMessage('adUnlockInvalid', 'Code not recognized. Please try again.'), 'error');
      return;
    }

    await persistUnlockState();
    hideAdBanner(bannerElement, elements.button);
    setUnlockMessage(elements.message, getMessage('adUnlockSuccess', 'Success! Ads are now disabled.'), 'success');
    setTimeout(() => closeUnlockModal(elements), 800);
  } catch (error) {
    setUnlockMessage(elements.message, getMessage('adUnlockError', 'Something went wrong. Please try again.'), 'error');
  } finally {
    setSubmittingState(elements, false);
  }
}

function hashCode(code) {
  if (!globalThis.crypto?.subtle) {
    return Promise.reject(new Error('SubtleCrypto is unavailable'));
  }
  const encoder = new TextEncoder();
  const data = encoder.encode(code);
  return crypto.subtle.digest('SHA-256', data).then((buffer) => {
    const hashArray = Array.from(new Uint8Array(buffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  });
}

function persistUnlockState() {
  return new Promise((resolve, reject) => {
    const storage = popupAdChromeApi?.storage?.local;
    if (!storage) {
      resolve();
      return;
    }
    storage.set({ [UNLOCK_STORAGE_KEY]: { unlocked: true, updatedAt: Date.now() } }, () => {
      const error = popupAdChromeApi?.runtime?.lastError;
      if (error) {
        reject(error);
        return;
      }
      resolve();
    });
  });
}

function hideAdBanner(bannerElement, unlockButton) {
  if (bannerElement) {
    bannerElement.style.display = 'none';
    bannerElement.setAttribute('aria-hidden', 'true');
  }
  if (unlockButton) {
    unlockButton.disabled = true;
    unlockButton.style.display = 'none';
  }
}

function setUnlockMessage(target, text, variant) {
  if (!target) {
    return;
  }
  target.textContent = text || '';
  target.classList.remove('success', 'error');
  if (variant) {
    target.classList.add(variant);
  }
}

function setSubmittingState(elements, isSubmitting) {
  if (elements.submitBtn) {
    elements.submitBtn.disabled = isSubmitting;
  }
  if (elements.input) {
    elements.input.disabled = isSubmitting;
  }
}

// getMessage is imported from popup.js (loaded first in popup.ad.html)
