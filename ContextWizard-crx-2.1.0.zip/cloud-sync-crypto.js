/**
 * ContextWizard Cloud Sync — E2E Encryption Module
 * 
 * Uses a random AES-256-GCM key stored in chrome.storage.sync.
 * The key is automatically synced across devices by Chrome.
 * Our cloud-sync server never sees the plaintext data or the key.
 * 
 * Data flow: JSON → gzip compress → AES-256-GCM encrypt → [IV][ciphertext+tag]
 */

const CW_SYNC_KEY_STORAGE = 'cw_e2e_key';
const CW_KEY_LOCAL_BACKUP = 'cw_e2e_key_local'; // local-only backup, survives sync issues
const CW_ENCRYPTION_VERSION = 1;
const AES_GCM_IV_LENGTH = 12; // 96 bits, standard for AES-GCM

let _cachedMasterKey = null;

/**
 * Get or create the AES-256-GCM master key.
 * This is for ENCRYPTION only (pushSync).
 * For first device: generates a new key.
 * For subsequent devices: reads from sync storage or waits for it.
 * @param {Object} options
 * @param {boolean} options.allowGenerate - whether to generate new key if none exists (default false)
 * @returns {Promise<CryptoKey>}
 */
async function getMasterKey({ allowGenerate = false } = {}) {
  if (_cachedMasterKey) return _cachedMasterKey;

  const stored = await new Promise((resolve) => {
    chrome.storage.sync.get(CW_SYNC_KEY_STORAGE, resolve);
  });

  if (stored[CW_SYNC_KEY_STORAGE]) {
    // Import existing key from sync storage
    const keyBytes = new Uint8Array(stored[CW_SYNC_KEY_STORAGE]);
    _cachedMasterKey = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    // Backup to local storage (survives sync conflicts)
    await new Promise((resolve) => {
      chrome.storage.local.set({ [CW_KEY_LOCAL_BACKUP]: stored[CW_SYNC_KEY_STORAGE] }, resolve);
    });
    return _cachedMasterKey;
  }

  // Sync storage empty — try restoring from local backup first.
  const localStored = await new Promise((resolve) => {
    chrome.storage.local.get(CW_KEY_LOCAL_BACKUP, resolve);
  });

  if (localStored[CW_KEY_LOCAL_BACKUP]) {

    const keyBytes = new Uint8Array(localStored[CW_KEY_LOCAL_BACKUP]);
    _cachedMasterKey = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    // Re-save to sync storage
    await new Promise((resolve) => {
      chrome.storage.sync.set({
        [CW_SYNC_KEY_STORAGE]: Array.from(keyBytes)
      }, resolve);
    });
    return _cachedMasterKey;
  }

  // No backup either
  if (allowGenerate) {

    _cachedMasterKey = await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    const exported = await crypto.subtle.exportKey('raw', _cachedMasterKey);
    const keyArray = Array.from(new Uint8Array(exported));
    await new Promise((resolve) => {
      chrome.storage.sync.set({
        [CW_SYNC_KEY_STORAGE]: keyArray
      }, resolve);
    });
    // Backup to local
    await new Promise((resolve) => {
      chrome.storage.local.set({ [CW_KEY_LOCAL_BACKUP]: keyArray }, resolve);
    });
    return _cachedMasterKey;
  }

  // No key exists and not allowed to generate
  throw new Error('NO_ENCRYPTION_KEY: No encryption key found. This may be a new device. Please wait for Chrome Sync to propagate the key from another device, or manually import a key.');
}

/**
 * Get the master key IF it already exists — never auto-generate.
 * Use this for decryption, where creating a new key would be wrong
 * (the real key should come via chrome.storage.sync from the original device).
 * Falls back to local backup so that a Chrome Sync propagation delay (or a
 * same-device reinstall where local storage survived) does not block decryption.
 * @returns {Promise<CryptoKey|null>}
 */
async function getMasterKeyIfExists() {
  if (_cachedMasterKey) return _cachedMasterKey;

  // Check sync storage first (authoritative copy, synced across devices)
  const stored = await new Promise((resolve) => {
    chrome.storage.sync.get(CW_SYNC_KEY_STORAGE, resolve);
  });

  if (stored[CW_SYNC_KEY_STORAGE]) {
    const keyBytes = new Uint8Array(stored[CW_SYNC_KEY_STORAGE]);
    _cachedMasterKey = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    // Keep local backup in sync
    await new Promise((resolve) => {
      chrome.storage.local.set({ [CW_KEY_LOCAL_BACKUP]: stored[CW_SYNC_KEY_STORAGE] }, resolve);
    });
    return _cachedMasterKey;
  }

  // Sync storage empty — fall back to local backup.
  // This handles: (a) Chrome Sync propagation delay, (b) same-device reinstall
  // where chrome.storage.local survived, (c) Chrome Sync temporarily unavailable.
  const localStored = await new Promise((resolve) => {
    chrome.storage.local.get(CW_KEY_LOCAL_BACKUP, resolve);
  });

  if (localStored[CW_KEY_LOCAL_BACKUP]) {

    const keyBytes = new Uint8Array(localStored[CW_KEY_LOCAL_BACKUP]);
    _cachedMasterKey = await crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
    // Re-save to sync storage so Chrome Sync picks it up
    await new Promise((resolve) => {
      chrome.storage.sync.set({ [CW_SYNC_KEY_STORAGE]: localStored[CW_KEY_LOCAL_BACKUP] }, resolve);
    });
    return _cachedMasterKey;
  }

  return null;
}

/**
 * Check if an encryption key exists in sync storage or local backup.
 * Falls back to local backup so that a Chrome Sync propagation delay
 * does not permanently block the user — getMasterKey() uses the same
 * fallback order, so if we report "available" here, crypto ops will work.
 * @returns {Promise<boolean>}
 */
async function isEncryptionKeyAvailable() {
  const stored = await new Promise((resolve) => {
    chrome.storage.sync.get(CW_SYNC_KEY_STORAGE, resolve);
  });
  if (stored[CW_SYNC_KEY_STORAGE]) return true;

  // Chrome Sync may not have propagated yet — check the local backup.
  const local = await new Promise((resolve) => {
    chrome.storage.local.get(CW_KEY_LOCAL_BACKUP, resolve);
  });
  return !!local[CW_KEY_LOCAL_BACKUP];
}

/**
 * Wait for the encryption key to appear in chrome.storage.sync.
 * Chrome sync may take up to 2+ minutes to propagate storage from another device.
 * @param {number} maxWaitMs — total wait time (default 120 seconds)
 * @param {number} intervalMs — poll interval (default 3 seconds)
 * @returns {Promise<CryptoKey|null>} key if found, null if timed out
 */
async function waitForEncryptionKey(maxWaitMs = 120000, intervalMs = 3000) {
  const startTime = Date.now();

  while (Date.now() - startTime < maxWaitMs) {
    _cachedMasterKey = null; // Force fresh read from chrome.storage.sync
    const key = await getMasterKeyIfExists();
    if (key) {

      return key;
    }
    const elapsed = Math.round((Date.now() - startTime) / 1000);

    await new Promise(r => setTimeout(r, intervalMs));
  }

  return null;
}

/**
 * Clear the cached key (e.g., on logout). Does NOT delete from storage.
 */
function clearCachedKey() {
  _cachedMasterKey = null;
}

/**
 * Remove the encryption key from chrome.storage.sync (but NOT local backup).
 * Used on a fresh device when we detect the local key is wrong (auto-generated
 * garbage). After clearing, we wait for Chrome sync to deliver the correct key
 * from the original device.
 * @returns {Promise<void>}
 */
async function clearSyncKey() {
  _cachedMasterKey = null;
  await new Promise((resolve) => {
    chrome.storage.sync.remove(CW_SYNC_KEY_STORAGE, resolve);
  });
}

/**
 * Remove all persisted key material from both sync and local storage.
 * Used for an explicit user-requested cloud sync reset.
 * @returns {Promise<void>}
 */
async function clearAllStoredKeys() {
  _cachedMasterKey = null;
  await Promise.all([
    new Promise((resolve) => {
      chrome.storage.sync.remove(CW_SYNC_KEY_STORAGE, resolve);
    }),
    new Promise((resolve) => {
      chrome.storage.local.remove(CW_KEY_LOCAL_BACKUP, resolve);
    }),
  ]);
}

/**
 * Export the encryption key as a base64 string for manual transfer to another browser.
 * @returns {Promise<string>} base64-encoded key
 */
async function exportKeyAsBase64() {
  const key = await getMasterKey();
  const raw = await crypto.subtle.exportKey('raw', key);
  return btoa(String.fromCharCode(...new Uint8Array(raw)));
}

/**
 * Import an encryption key from a base64 string (from another browser).
 * Overwrites the current key in chrome.storage.sync.
 * @param {string} base64Key
 * @returns {Promise<void>}
 */
async function importKeyFromBase64(base64Key) {
  _cachedMasterKey = null; // Clear any stale cached key before import
  
  const binary = atob(base64Key.trim());
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

  if (bytes.length !== 32) {
    throw new Error('Invalid key: expected 32 bytes (AES-256)');
  }

  const imported = await crypto.subtle.importKey(
    'raw', bytes, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']
  );

  await new Promise((resolve) => {
    chrome.storage.sync.set({
      [CW_SYNC_KEY_STORAGE]: Array.from(bytes)
    }, resolve);
  });
  // Also update local backup
  await new Promise((resolve) => {
    chrome.storage.local.set({ [CW_KEY_LOCAL_BACKUP]: Array.from(bytes) }, resolve);
  });

  _cachedMasterKey = imported;
}

/**
 * Encrypt data for cloud sync.
 * @param {object} data — JSON-serializable data
 * @returns {Promise<ArrayBuffer>} — [12 bytes IV][ciphertext with GCM auth tag]
 */
async function encryptSyncData(data) {
  const key = await getMasterKey();
  const json = JSON.stringify(data);

  // Gzip compress
  const compressed = await _gzipCompress(json);

  // AES-256-GCM encrypt with random IV
  const iv = crypto.getRandomValues(new Uint8Array(AES_GCM_IV_LENGTH));
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    compressed
  );

  // Pack: [IV (12 bytes)][ciphertext + GCM auth tag (16 bytes)]
  const result = new Uint8Array(iv.length + ciphertext.byteLength);
  result.set(iv, 0);
  result.set(new Uint8Array(ciphertext), iv.length);
  return result.buffer;
}

/**
 * Decrypt data from cloud sync.
 * @param {ArrayBuffer} encryptedBuffer — [12 bytes IV][ciphertext with GCM auth tag]
 * @returns {Promise<object>} — parsed JSON data
 */
async function decryptSyncData(encryptedBuffer) {
  // Use getMasterKeyIfExists — NEVER auto-generate a key for decryption.
  // If no key exists, chrome.storage.sync hasn't propagated it yet from the
  // original device, and creating a new key would make things worse.
  const key = await getMasterKeyIfExists();
  if (!key) {
    throw new Error(
      'ENCRYPTION_KEY_NOT_FOUND: No encryption key found on this device. ' +
      'The key syncs automatically via Chrome. Please ensure: ' +
      '(1) You are signed into Chrome with the same Google account on both devices, ' +
      '(2) Chrome sync is enabled (chrome://settings/syncSetup), ' +
      '(3) "Extensions" sync is turned on. ' +
      'Then wait a moment and try Sync again.'
    );
  }

  const data = new Uint8Array(encryptedBuffer);
  const iv = data.slice(0, AES_GCM_IV_LENGTH);
  const ciphertext = data.slice(AES_GCM_IV_LENGTH);

  let compressed;
  try {
    // AES-GCM decrypt (also verifies integrity via auth tag)
    compressed = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      ciphertext
    );
  } catch (e) {
    // OperationError = key exists but doesn't match (or corrupted data)
    throw new Error(
      'DECRYPTION_KEY_MISMATCH: The encryption key on this device does not match ' +
      'the one used to encrypt the cloud data. If you use different Google accounts, ' +
      'export the key from your original device (Settings → Cloud Sync → Export Key) ' +
      'and import it here.'
    );
  }

  // Gzip decompress
  const json = await _gzipDecompress(compressed);
  return JSON.parse(json);
}

/**
 * Gzip compress a string to ArrayBuffer.
 * @param {string} text
 * @returns {Promise<ArrayBuffer>}
 */
async function _gzipCompress(text) {
  const blob = new Blob([text]);
  const stream = blob.stream().pipeThrough(new CompressionStream('gzip'));
  return new Response(stream).arrayBuffer();
}

/**
 * Gzip decompress an ArrayBuffer to string.
 * @param {ArrayBuffer} buffer
 * @returns {Promise<string>}
 */
async function _gzipDecompress(buffer) {
  const blob = new Blob([buffer]);
  const stream = blob.stream().pipeThrough(new DecompressionStream('gzip'));
  return new Response(stream).text();
}

// Export for use in background.js (ES module) and tests
if (typeof globalThis !== 'undefined') {
  globalThis.CloudSyncCrypto = {
    getMasterKey,
    getMasterKeyIfExists,
    waitForEncryptionKey,
    isEncryptionKeyAvailable,
    clearCachedKey,
    clearSyncKey,
    clearAllStoredKeys,
    exportKeyAsBase64,
    importKeyFromBase64,
    encryptSyncData,
    decryptSyncData,
    CW_ENCRYPTION_VERSION,
    // Exposed for testing only
    _gzipCompress,
    _gzipDecompress,
  };
}
