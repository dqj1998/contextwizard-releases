// SendDetector — 平台独立的 AI 聊天发送检测模块
// 通过三种信号检测用户消息发送: Enter+清空(首选) / DOM消息数变化(辅助) / URL变化(仅参考)
// 加载方式: content script (CONTENT_SCRIPT_FILES), 通过 globalThis 共享

(function () {
  'use strict';

  class SendDetector {
    constructor(platformConfig, platformName) {
      this.config = platformConfig;
      this.platformName = platformName;
      this.inputEl = null;
      this.messageListEl = null;
      this.prevMessageCount = 0;
      this.messageObserver = null;
      this.urlObserver = null;
      this.isRunning = false;
      this.dedupWindow = platformConfig.eventDedupWindowMs || 800;
      this.lastEventFingerprint = null;
      this.lastEventTime = 0;
      this.lastMessageCount = 0;
      this.stabilityTimer = null;
    }

    start(onMessageSent) {
      if (this.isRunning) return;
      this.isRunning = true;
      this.callback = onMessageSent;

      this.queryElements();

      this.attachEnterKeyListener();
      this.attachMessageCountObserver();
      this.attachUrlObserver();
    }

    stop() {
      this.isRunning = false;
      if (this.messageObserver) {
        this.messageObserver.disconnect();
        this.messageObserver = null;
      }
      if (this.urlObserver) {
        this.urlObserver.disconnect();
        this.urlObserver = null;
      }
      if (this.stabilityTimer) {
        clearTimeout(this.stabilityTimer);
        this.stabilityTimer = null;
      }
      this.callback = null;
    }

    queryElements() {
      const selectors = this.config.inputSelector;
      const selectorList = Array.isArray(selectors) ? selectors : [selectors];
      for (const sel of selectorList) {
        const el = document.querySelector(sel);
        if (el) {
          this.inputEl = el;
          break;
        }
      }

      if (this.config.messageListSelector) {
        const listSel = this.config.messageListSelector;
        const listSelectorList = Array.isArray(listSel) ? listSel : [listSel];
        for (const sel of listSelectorList) {
          const el = document.querySelector(sel);
          if (el) {
            this.messageListEl = el.parentElement || el;
            break;
          }
        }
      }
    }

    isInputCleared() {
      if (!this.inputEl) return false;
      const text = this.inputEl.innerText || this.inputEl.textContent || '';
      return text.trim().length === 0;
    }

    getFingerprint() {
      const inputText = this.inputEl ? (this.inputEl.innerText || this.inputEl.textContent || '') : '';
      const hash = simpleHash(inputText);
      return `${this.platformName}:${window.location.href.split('?')[0]}:${hash}`;
    }

    isDuplicate(fingerprint) {
      const now = Date.now();
      if (fingerprint === this.lastEventFingerprint && (now - this.lastEventTime) < this.dedupWindow) {
        return true;
      }
      return false;
    }

    markSent(fingerprint) {
      this.lastEventFingerprint = fingerprint;
      this.lastEventTime = Date.now();
    }

    emitIfNotDuplicate(payload) {
      const fp = this.getFingerprint();
      if (this.isDuplicate(fp)) return;
      this.markSent(fp);
      if (this.callback) this.callback(payload);
    }

    // 信号1: Enter 键 + 输入框清空 = 消息已发送（首选）
    attachEnterKeyListener() {
      this._enterHandler = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          this.queryElements();
          setTimeout(() => {
            if (!this.inputEl) {
              this.queryElements();
            }
            if (this.isRunning && this.isInputCleared()) {
              this.emitIfNotDuplicate({ signal: 'enter', time: Date.now() });
            }
          }, 100);
        }
      };
      document.addEventListener('keydown', this._enterHandler);
    }

    // 信号2: DOM 消息列表数量变化（辅助，延迟 500ms 确认防流式误报）
    attachMessageCountObserver() {
      const target = this.messageListEl || document.body;
      this.messageObserver = new MutationObserver(() => {
        if (!this.isRunning) return;
        if (this.stabilityTimer) clearTimeout(this.stabilityTimer);
        this.stabilityTimer = setTimeout(() => {
          if (!this.isRunning) return;
          const currentCount = this.getMessageCount();
          if (currentCount > this.lastMessageCount) {
            this.lastMessageCount = currentCount;
            this.emitIfNotDuplicate({ signal: 'dom', time: Date.now() });
          }
        }, 500);
      });

      this.messageObserver.observe(target, {
        childList: true,
        subtree: true,
      });
      this.lastMessageCount = this.getMessageCount();
    }

    getMessageCount() {
      if (this.messageListEl) {
        return this.messageListEl.children ? this.messageListEl.children.length : 0;
      }
      if (this.config.messageListSelector) {
        const sels = Array.isArray(this.config.messageListSelector)
          ? this.config.messageListSelector
          : [this.config.messageListSelector];
        for (const sel of sels) {
          const nodes = document.querySelectorAll(sel);
          if (nodes.length > 0) return nodes.length;
        }
      }
      return 0;
    }

    // 信号3: URL 变化（仅辅助，不独立触发发送事件）
    attachUrlObserver() {
      let lastUrl = window.location.href;
      this.urlObserver = new MutationObserver(() => {
        const currentUrl = window.location.href;
        if (currentUrl !== lastUrl) {
          lastUrl = currentUrl;
          this.queryElements();
          this.lastMessageCount = this.getMessageCount();
        }
      });
      this.urlObserver.observe(document.querySelector('title') || document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
      });

      window.addEventListener('popstate', () => {
        this.queryElements();
        this.lastMessageCount = this.getMessageCount();
      });
    }
  }

  function simpleHash(str) {
    let hash = 0;
    const s = str.slice(0, 50);
    for (let i = 0; i < s.length; i++) {
      const char = s.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(36);
  }

  globalThis.SendDetector = SendDetector;
})();
