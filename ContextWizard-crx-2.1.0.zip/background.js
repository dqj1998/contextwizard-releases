// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Background service worker for managing conversations and storage
// Core algorithms powered by WebAssembly for performance and protection.

// Cloud Sync modules (plain script, attach to globalThis)
import './cloud-sync-crypto.js';
import './cloud-sync-transfer.js';
import './cloud-sync-tracker.js';
import './cloud-sync-diff.js';
import './cloud-sync-client.js';

// Seed data for first-install default prompts and replacements
import './seed-data.js';

const CORE_SCRIPT_ID = 'contextwizard-core';
const CUSTOM_SCRIPT_PREFIX = 'contextwizard-custom-';
const CONTENT_SCRIPT_FILES = {
  js: ['shared-utils.js', 'platforms.js', 'message-extractor.js', 'content.js',
       'platform-config.js', 'send-detector.js', 'bookmark-context-extractor.js',
       'relevance-scorer.js', 'context-session.js', 'context-panel.js', 'content-injector.js'],
  css: ['content.css', 'context-panel.css']
};
const CORE_MATCH_PATTERNS = [
  'https://chatgpt.com/*',
  'https://claude.ai/*',
  'https://gemini.google.com/*',
  'https://copilot.microsoft.com/*',
  'https://www.perplexity.ai/*',
  'https://huggingface.co/chat/*',
  'https://poe.com/*',
  'https://grok.com/*',
  'https://chat.deepseek.com/*',
  'https://chat.qwen.ai/*',
  'https://www.kimi.com/*',
  'https://manus.im/*'
];
const ACTION_POPUP_PATH = chrome.runtime.getManifest()?.action?.default_popup || 'popup.html';

// Track source tab info for popup windows opened from the floating indicator
// Maps popupWindowId → { sourceTabId, sourceTabUrl, sourceWindowId, popupTabId }
const popupSourceTabMap = new Map();

function initializeContentScripts() {
  registerCoreContentScript().catch(() => {});
  syncCustomContentScripts().catch(() => {});
}

async function registerCoreContentScript() {
  await unregisterContentScriptSafe(CORE_SCRIPT_ID);
  await chrome.scripting.registerContentScripts([
    {
      id: CORE_SCRIPT_ID,
      matches: CORE_MATCH_PATTERNS,
      runAt: 'document_idle',
      persistAcrossSessions: true,
      ...CONTENT_SCRIPT_FILES
    }
  ]);
}

async function syncCustomContentScripts() {
  const { customPlatforms = [] } = await chrome.storage.sync.get(['customPlatforms']);
  const desiredScripts = buildCustomScriptDefinitions(customPlatforms);
  const registered = await chrome.scripting.getRegisteredContentScripts();
  const registeredCustom = registered.filter((script) => script.id?.startsWith(CUSTOM_SCRIPT_PREFIX));

  const desiredIds = new Set(desiredScripts.map((script) => script.id));
  const idsToRemove = registeredCustom
    .filter((script) => !desiredIds.has(script.id))
    .map((script) => script.id);

  if (idsToRemove.length) {
    await unregisterContentScriptSafe(idsToRemove);
  }

  const existingIds = new Set(
    registeredCustom.map((script) => script.id)
  );
  const scriptsToRegister = desiredScripts.filter((script) => !existingIds.has(script.id));

  if (scriptsToRegister.length) {
    await chrome.scripting.registerContentScripts(scriptsToRegister);
  }
}

function buildCustomScriptDefinitions(platforms = []) {
  const scripts = [];
  const seenMatches = new Set();

  for (const platform of platforms) {
    const matchPattern = normalizeToMatchPattern(platform?.urlPattern);
    if (!matchPattern || seenMatches.has(matchPattern)) {
      continue;
    }
    seenMatches.add(matchPattern);
    scripts.push({
      id: buildCustomScriptId(matchPattern),
      matches: [matchPattern],
      runAt: 'document_idle',
      persistAcrossSessions: true,
      ...CONTENT_SCRIPT_FILES
    });
  }

  return scripts;
}

function normalizeToMatchPattern(pattern = '') {
  const trimmed = pattern.trim();
  if (!trimmed || !/^https?:\/\//i.test(trimmed)) {
    return '';
  }

  if (trimmed.includes('*')) {
    return trimmed;
  }

  if (trimmed.endsWith('/')) {
    return `${trimmed}*`;
  }
  return `${trimmed}/*`;
}

function buildCustomScriptId(matchPattern) {
  return `${CUSTOM_SCRIPT_PREFIX}${hashString(matchPattern)}`;
}

function hashString(value) {
  let hash = 0;
  for (const char of value) {
    const code = char.codePointAt(0) ?? 0;
    hash = Math.trunc((hash << 5) - hash + code);
  }
  return Math.abs(hash).toString(36);
}

async function unregisterContentScriptSafe(ids) {
  const idList = Array.isArray(ids) ? ids : [ids];
  if (!idList.length) {
    return;
  }
  try {
    await chrome.scripting.unregisterContentScripts({ ids: idList });
  } catch (error) {
    if (!error?.message?.includes('No such content script')) {
      console.warn('[ContextWizard Background] Failed to unregister scripts', error);
    }
  }
}

function seedFirstInstallDefaults() {
  const locale = (chrome.i18n && typeof chrome.i18n.getMessage === 'function'
    ? chrome.i18n.getMessage('@@ui_locale')
    : '') || navigator.language || 'en';

  const seedData = globalThis.SeedData;
  if (!seedData) {
    console.warn('[ContextWizard] SeedData not available');
    return;
  }

  const updates = {};

  chrome.storage.local.get(['promptEditorTemplates', 'promptEditorReplaceHistory'], (result) => {
    if (!result.promptEditorTemplates || Object.keys(result.promptEditorTemplates).length === 0) {
      updates.promptEditorTemplates = seedData.getSeedTemplates(locale);
    }
    if (!result.promptEditorReplaceHistory || Object.keys(result.promptEditorReplaceHistory).length === 0) {
      updates.promptEditorReplaceHistory = seedData.getSeedReplacements(locale);
    }

    if (Object.keys(updates).length > 0) {
      chrome.storage.local.set(updates, () => {

      });
    }
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync') {
    // Encryption key arrived via Chrome Sync — clear cached key so next crypto call picks it up
    if (changes.cw_e2e_key) {

      if (globalThis.CloudSyncCrypto?.clearCachedKey) {
        globalThis.CloudSyncCrypto.clearCachedKey();
      }
    }
    
    if (changes.customPlatforms) {
      syncCustomContentScripts().catch((error) => {
        console.error('[ContextWizard Background] Failed to resync custom scripts', error);
      });
    }
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  // Schema migration — run on every install/update to ensure data compatibility
  migrateBookmarkSchema();

  if (details.reason === 'install') {
    chrome.tabs.create({
      url: chrome.runtime.getURL('welcome.html')
    });

    chrome.storage.sync.get(['platformSettings'], (result) => {
      if (!result.platformSettings) {
        const defaultSettings = {};
        chrome.storage.sync.set({ platformSettings: defaultSettings });
      }
    });

    chrome.storage.local.get(['conversations'], (result) => {
      if (!result.conversations) {
        chrome.storage.local.set({ conversations: [] });
      }
    });

    seedFirstInstallDefaults();

    chrome.storage.local.set({
      rating_install_date: Date.now(),
      rating_chat_count: 0,
      rating_has_rated: false,
      rating_dismissed_count: 0,
      rating_last_dismissed_time: 0,
      rating_banner_gray_sent: false
    });
  } else if (details.reason === 'update') {
    chrome.storage.local.get(['rating_install_date'], (result) => {
      if (!result.rating_install_date) {
        chrome.storage.local.set({
          rating_install_date: Date.now(),
          rating_chat_count: 0,
          rating_has_rated: false,
          rating_dismissed_count: 0,
          rating_last_dismissed_time: 0,
          rating_banner_gray_sent: false
        });
      }
    });
  }

  initializeContentScripts();

  // Set up periodic cloud sync alarm on extension install/update
  if (globalThis.CloudSyncClient) {

    globalThis.CloudSyncClient.setupPeriodicSync();
  }
});

if (chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(() => {
initializeContentScripts();

// Reminder alarm is initialized below, after function definitions
    // Set up periodic cloud sync alarm on browser start
    if (globalThis.CloudSyncClient) {

      globalThis.CloudSyncClient.setupPeriodicSync();
    }
  });
}

// Handle cloud sync alarms
chrome.alarms.onAlarm.addListener((alarm) => {

  if (alarm.name === REMINDER_CHECK_ALARM) {
    handleReminderAlarm();
    return;
  }
  if (globalThis.CloudSyncClient) {
    globalThis.CloudSyncClient.handleAlarm(alarm);
  } else {

  }
});

initializeContentScripts();

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'saveConversation') {
    saveConversation(request.conversation, sender.tab);
    sendResponse({ success: true });
  } else if (request.action === 'getConversations') {
    getConversations(request.filter, sendResponse);
    return true; // Async response
  } else if (request.action === 'deleteConversation') {
    deleteConversation(request.conversationId, sendResponse);
    return true; // Async response
  } else if (request.action === 'searchConversations') {
    searchConversations(request.query, sendResponse);
    return true; // Async response
  } else if (request.action === 'updateBadge') {
    updateBadge(request.conversations);
    sendResponse({ success: true });
  } else if (request.action === 'openPopupWindow') {
    openPopupWindow(sender, sendResponse);
    return true;
  } else if (request.action === 'getSourceTabInfo') {
    getSourceTabInfo(sendResponse);
    return true;
  } else if (request.action === 'openTabWithNavContext') {
    openTabWithNavContext(request.url, request.navContext, sendResponse);
    return true;
  } else if (request.action === 'openPromptEditor') {
    openPromptEditor(request.tab, sendResponse);
    return true;
  } else if (request.action === 'passSearchNavContext') {
    // Pass search navigation context to content script on the target tab
    if (sender.tab?.id) {
      chrome.tabs.sendMessage(sender.tab.id, {
        action: 'receiveSearchNavContext',
        navContext: request.navContext
      }).catch(() => {
        // Silently ignore if content script not ready
      });
    }
    sendResponse({ success: true });
  } else if (request.action === 'saveBookmark') {
    saveBookmark(request.bookmark, sendResponse);
    return true; // Async response
  } else if (request.action === 'deleteBookmark') {
    deleteBookmark(request.bookmarkId, sendResponse);
    return true; // Async response
  } else if (request.action === 'getBookmarks') {
    getBookmarks(request.filter, sendResponse);
    return true; // Async response
  } else if (request.action === 'getBookmarksByConversation') {
    getBookmarksByConversation(request.url, sendResponse);
    return true; // Async response
  } else if (request.action === 'renameBookmark') {
    renameBookmark(request.bookmarkId, request.newName, sendResponse);
    return true; // Async response
  } else if (request.action === 'renameBookmarkGroup') {
    renameBookmarkGroup(request.oldName, request.newName, sendResponse);
    return true; // Async response
  } else if (request.action === 'saveReminder') {
    saveReminder(request.bookmarkId, request.reminder, sendResponse);
    return true; // Async response
  } else if (request.action === 'deleteReminder') {
    deleteReminder(request.bookmarkId, sendResponse);
    return true; // Async response
  } else if (request.action === 'getReminder') {
    getReminder(request.bookmarkId, sendResponse);
    return true; // Async response
  } else if (request.action === 'getReminderHistory') {
    getReminderHistory(sendResponse);
    return true; // Async response
  } else if (request.action === 'getUnreadReminderCount') {
    getUnreadReminderCount(sendResponse);
    return true; // Async response
  } else if (request.action === 'markReminderRead') {
    markReminderRead(request.reminderId, sendResponse);
    return true; // Async response
  } else if (request.action === 'markAllRemindersRead') {
    markAllRemindersRead(sendResponse);
    return true; // Async response
  } else if (request.action === 'cleanupOldReminderHistory') {
    cleanupOldReminderHistory(sendResponse);
    return true; // Async response
  } else if (request.action === 'requestHostPermission') {
    requestHostPermission(request.pattern, sendResponse);
    return true; // Async response
  } else if (request.action === 'openBookmarkManager') {
    openBookmarkManager(request.bookmarkId, sendResponse);
    return true; // Async response
  }
  // ── Page Copy Actions ──
  else if (request.action === 'copyPage_executeOnTab') {
    copyPageExecuteOnTab(request.tabId, sendResponse);
    return true;
  }
  // ── Cloud Sync Actions ──
  else if (request.action === 'cloudSync_login') {
    globalThis.CloudSyncClient?.login().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_logout') {
    globalThis.CloudSyncClient?.logout().then(() => sendResponse({ success: true }));
    return true;
  } else if (request.action === 'cloudSync_getStatus') {
    globalThis.CloudSyncClient?.getStatus().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_getSyncStatus') {
    globalThis.CloudSyncClient?.getSyncStatus().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_pushSync') {
    globalThis.CloudSyncClient?.pushSync().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_pullSync') {
    globalThis.CloudSyncClient?.pullSync().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_fullSync') {
    globalThis.CloudSyncClient?.fullSync().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_subscribe') {
    globalThis.CloudSyncClient?.subscribe(request.plan).then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_purchaseAddon') {
    globalThis.CloudSyncClient?.purchaseAddon(request.addonType).then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_manageSubscription') {
    globalThis.CloudSyncClient?.manageSubscription().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_getUserInfo') {
    globalThis.CloudSyncClient?.getUserInfo().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_exportKey') {
    globalThis.CloudSyncCrypto?.exportKeyAsBase64().then(
      (key) => sendResponse({ success: true, key }),
      (err) => sendResponse({ success: false, error: err.message })
    );
    return true;
  } else if (request.action === 'cloudSync_importKey') {
    globalThis.CloudSyncCrypto?.importKeyFromBase64(request.key).then(
      () => sendResponse({ success: true }),
      (err) => sendResponse({ success: false, error: err.message })
    );
    return true;
  } else if (request.action === 'cloudSync_checkEncryptionKeyAvailability') {
    globalThis.CloudSyncClient?.checkEncryptionKeyAvailability().then(sendResponse);
    return true;
  } else if (request.action === 'cloudSync_clearCloudData') {
    globalThis.CloudSyncClient?.clearCloudDataAndResetSync().then(sendResponse);
    return true;
  }
  // ── Bookmark Group Actions ──
  else if (request.action === 'saveBookmarkGroup') {
    saveBookmarkGroup(request.group, sendResponse);
    return true;
  } else if (request.action === 'deleteBookmarkGroup') {
    deleteBookmarkGroup(request.groupId, sendResponse);
    return true;
  } else if (request.action === 'getBookmarkGroups') {
    getBookmarkGroups(sendResponse);
    return true;
  }
  // ── Context Session Actions ──
  else if (request.action === 'CONTEXT_SESSION_START') {
    handleContextSessionStart(request, sender, sendResponse);
    return true;
  } else if (request.action === 'GET_BOOKMARK_CONTEXT_DATA') {
    handleGetBookmarkContextData(request, sender, sendResponse);
    return true;
  }
  // ── Scroll to Bookmark ──
  else if (request.action === 'scrollToBookmark') {
    const { bookmarkId, targetUrl } = request;
    const sendScroll = (tabId) => {
      chrome.tabs.sendMessage(tabId, {
        action: 'scrollToBookmark',
        bookmarkId
      }).catch(() => {});
    };
    if (targetUrl) {
      chrome.tabs.query({ url: targetUrl }, (tabs) => {
        if (tabs && tabs.length > 0) {
          sendScroll(tabs[0].id);
        }
      });
    } else if (sender.tab?.id) {
      sendScroll(sender.tab.id);
    }
    sendResponse({ success: true });
  }
});

function openTabWithNavContext(url, navContext, callback) {
  const targetUrl = typeof url === 'string' ? url.trim() : '';
  if (!targetUrl) {
    callback?.({ success: false, error: 'Missing url' });
    return;
  }

  chrome.tabs.create({ url: targetUrl }).then((tab) => {
    const tabId = tab?.id;
    if (!tabId || !navContext) {
      callback?.({ success: true });
      return;
    }

    // Wait for the tab to finish loading before sending the nav context.
    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId) {
        return;
      }
      if (changeInfo.status !== 'complete') {
        return;
      }

      chrome.tabs.sendMessage(tabId, {
        action: 'receiveSearchNavContext',
        navContext
      }).catch(() => {
        // Content script may not be ready yet; ignore.
      });

      chrome.tabs.onUpdated.removeListener(onUpdated);
    };

    chrome.tabs.onUpdated.addListener(onUpdated);

    // Safety cleanup in case the tab never reaches 'complete'.
    setTimeout(() => {
      try {
        chrome.tabs.onUpdated.removeListener(onUpdated);
      } catch {
        // ignore
      }
    }, 15000);

    callback?.({ success: true, tabId });
  }).catch((error) => {
    console.warn('[ContextWizard Background] Failed to open tab with nav context', error);
    callback?.({ success: false, error: error?.message });
  });
}

/**
 * Focus an existing window whose tab URL starts with the given URL,
 * or create a new window if no matching window exists.
 * @param {string} url - The extension URL to match
 * @param {chrome.windows.CreateData} createOptions - Window creation options
 * @param {function} [callback] - Optional callback
 */
function focusOrCreateWindow(url, createOptions, callback) {
  chrome.windows.getAll({ populate: true }, (windows) => {
    const existingWindow = windows.find((w) =>
      w.tabs?.some((tab) => tab.url && tab.url.startsWith(url))
    );
    if (existingWindow) {
      chrome.windows.update(existingWindow.id, { focused: true }, () => {
        callback?.({ success: true, reused: true });
      });
    } else {
      chrome.windows.create(createOptions, (win) => {
        callback?.({ success: true, window: win });
      });
    }
  });
}

function openPopupWindow(sender, callback) {
  const popupUrl = chrome.runtime.getURL(ACTION_POPUP_PATH);
  const sourceTabId = sender?.tab?.id;
  const sourceTabUrl = sender?.tab?.url;
  const sourceWindowId = sender?.tab?.windowId;

  focusOrCreateWindow(popupUrl, {
    url: popupUrl,
    type: 'popup',
    width: 420,
    height: 640,
    focused: true
  }, (result) => {
    if (result.reused) {
      chrome.windows.getAll({ populate: true }, (windows) => {
        const existing = windows.find(w =>
          w.tabs?.some(t => t.url && t.url.startsWith(popupUrl))
        );
        if (existing) {
          popupSourceTabMap.set(existing.id, {
            sourceTabId,
            sourceTabUrl,
            sourceWindowId,
            popupTabId: existing.tabs?.[0]?.id
          });
          notifyPopupSourceTabChanged(existing.tabs?.[0]?.id, sourceTabId, sourceTabUrl);
        }
      });
    } else if (result.window) {
      const popupWindowId = result.window.id;
      const popupTabId = result.window.tabs?.[0]?.id;
      popupSourceTabMap.set(popupWindowId, {
        sourceTabId,
        sourceTabUrl,
        sourceWindowId,
        popupTabId
      });
    }
    callback?.(result);
  });
}

function getSourceTabInfo(callback) {
  chrome.windows.getCurrent({ populate: true }, (win) => {
    if (!win) {
      callback?.({});
      return;
    }
    const info = popupSourceTabMap.get(win.id);
    if (info) {
      callback?.({ tabId: info.sourceTabId, url: info.sourceTabUrl });
    } else {
      callback?.({});
    }
  });
}

function openPromptEditor(tab, callback) {
  const editorUrl = chrome.runtime.getURL('prompt_editor.html' + (tab === 'templates' ? '?tab=templates' : ''));
  focusOrCreateWindow(editorUrl, {
    url: editorUrl,
    type: 'popup',
    width: 600,
    height: 700,
    focused: true
  }, callback);
}

function openBookmarkManager(bookmarkId, callback) {
  const baseUrl = chrome.runtime.getURL('bookmark_editor.html');
  const urlWithHash = bookmarkId ? `${baseUrl}#bookmarkId=${bookmarkId}` : baseUrl;

  focusOrCreateWindow(baseUrl, {
    url: urlWithHash,
    type: 'popup',
    width: 500,
    height: 700,
    focused: true
  }, (result) => {
    if (result?.reused && bookmarkId) {
      chrome.windows.getAll({ populate: true }, (windows) => {
        const existing = windows.find(w =>
          w.tabs?.some(t => t.url && t.url.startsWith(baseUrl))
        );
        if (existing) {
          const tab = existing.tabs?.find(t => t.url && t.url.startsWith(baseUrl));
          if (tab?.id) {
            chrome.tabs.sendMessage(tab.id, {
              action: 'scrollToBookmarkId',
              bookmarkId
            }).catch(() => {});
          }
        }
      });
    }
    callback?.(result);
  });
}

// Save or update a conversation
function saveConversation(conversation, tab) {
  chrome.storage.local.get(['conversations', 'bookmarks'], (result) => {
    let conversations = result.conversations || [];
    const newFingerprint = getFingerprint(conversation);
    
    // Check if conversation already exists by ID
    let existingIndex = conversations.findIndex(c => 
      c.id === conversation.id && c.platform === conversation.platform
    );
    
    // If not found by ID, check by content similarity (same platform and same title)
    if (existingIndex === -1) {
      existingIndex = conversations.findIndex(c => 
        c.platform === conversation.platform &&
        getFingerprint(c) === newFingerprint
      );

      if (existingIndex > -1) {

        // Update the ID to the new one (in case URL changed)
        conversation.id = conversations[existingIndex].id;
      }
    }
    
    // Additional check: prevent saving if exact same content was just saved
    const isDuplicate = conversations.some((c, idx) => {
      if (idx === existingIndex) return false; // Skip the one we're updating
      
      return c.platform === conversation.platform &&
             getFingerprint(c) === newFingerprint &&
             // Check if saved within last 5 minutes
             (Date.now() - c.lastUpdated) < 300000;
    });
    
    if (isDuplicate) {

      return;
    }
    
    if (existingIndex > -1) {
      // Update existing conversation only if content actually changed
      const existing = conversations[existingIndex];
      const existingFingerprint = getFingerprint(existing);
      const messagesChanged = existingFingerprint !== newFingerprint;
      
      if (!messagesChanged) {

        return;
      }

      const mergedMessages = mergeConversationMessages(existing.messages, conversation.messages);
      const mergedSummary = summarizeMessages(mergedMessages);
      const mergedConversation = {
        ...existing,
        ...conversation,
        messages: mergedMessages,
        summary: mergedSummary,
        lastUpdated: Date.now()
      };
      delete mergedConversation.fingerprint;
      mergedConversation.fingerprint = getFingerprint(mergedConversation);
      conversations[existingIndex] = mergedConversation;
    } else {
      // Add new conversation

      conversations.push({
        ...conversation,
        fingerprint: newFingerprint,
        createdAt: Date.now(),
        lastUpdated: Date.now()
      });
    }
    
    // Keep only the most recent 1000 conversations, but always protect ones with bookmarks
    if (conversations.length > 1000) {
      const bookmarkedUrls = new Set(
        (result.bookmarks || []).map(b => b.url).filter(Boolean)
      );
      conversations.sort((a, b) => b.lastUpdated - a.lastUpdated);
      const pinned = conversations.filter(c => c.url && bookmarkedUrls.has(c.url));
      const unpinned = conversations.filter(c => !c.url || !bookmarkedUrls.has(c.url));
      const keepCount = Math.max(0, 1000 - pinned.length);
      conversations = [...pinned, ...unpinned.slice(0, keepCount)];
    }
    
    chrome.storage.local.set({ conversations }, () => {
      // Update badge to show recent count only
      updateBadge(conversations);
    });
  });
}

// Get all conversations with optional filtering
function getConversations(filter, callback) {
  chrome.storage.local.get(['conversations'], (result) => {
    let conversations = result.conversations || [];
    
    if (filter) {
      if (filter.platform) {
        conversations = conversations.filter(c => c.platform === filter.platform);
      }
      if (filter.startDate) {
        conversations = conversations.filter(c => c.lastUpdated >= filter.startDate);
      }
      if (filter.endDate) {
        conversations = conversations.filter(c => c.lastUpdated <= filter.endDate);
      }
    }
    
    // Sort by last updated, most recent first
    conversations.sort((a, b) => b.lastUpdated - a.lastUpdated);
    
    callback({ conversations });
  });
}

// Delete a conversation
function deleteConversation(conversationId, callback) {
  chrome.storage.local.get(['conversations'], (result) => {
    let conversations = result.conversations || [];
    conversations = conversations.filter(c => c.id !== conversationId);
    
    chrome.storage.local.set({ conversations }, () => {
      updateBadge(conversations);
      callback({ success: true });
    });
  });
}

// Search conversations (enhanced version with phrase matching, prefix matching, and context snippets)
function searchConversations(query, callback) {
  chrome.storage.local.get(['conversations'], (result) => {
    const conversations = result.conversations || [];
    
    const tokens = getSearchTokens(query);

    if (!tokens.length) {
      callback({ conversations: [] });
      return;
    }

    const matches = conversations.filter((conversation) =>
      conversationMatchesAllTokens(conversation, tokens)
    );

    matches.sort((a, b) => {
      const aTitleScore = countTokensInText(a.title, tokens);
      const bTitleScore = countTokensInText(b.title, tokens);

      if (aTitleScore !== bTitleScore) {
        return bTitleScore - aTitleScore;
      }

      return (b.lastUpdated || 0) - (a.lastUpdated || 0);
    });

    callback({ conversations: matches });
  });
}

function getSearchTokens(query) {
  return String(query || '')
    .toLowerCase()
    .split(/\s+/)
    .map((token) => token.trim())
    .filter(Boolean);
}

function conversationMatchesAllTokens(conversation, tokens) {
  if (!conversation || !tokens.length) {
    return false;
  }

  const combinedText = buildConversationSearchText(conversation);
  if (!combinedText) {
    return false;
  }

  return tokens.every((token) => combinedText.includes(token));
}

function buildConversationSearchText(conversation) {
  const parts = [];

  if (conversation.title) {
    parts.push(conversation.title);
  }

  if (conversation.summary) {
    parts.push(conversation.summary);
  }

  if (Array.isArray(conversation.messages)) {
    for (const message of conversation.messages) {
      if (message?.content) {
        parts.push(message.content);
      }
    }
  }

  if (!parts.length) {
    return '';
  }

  return parts.join('\n').toLowerCase();
}

function countTokensInText(text, tokens) {
  if (!text || !tokens.length) {
    return 0;
  }
  const lowerText = text.toLowerCase();
  return tokens.reduce((count, token) => count + (lowerText.includes(token) ? 1 : 0), 0);
}

// Update extension badge
function updateBadge(conversations) {
  const eightHoursAgo = Date.now() - 8 * 60 * 60 * 1000;
  const recentCount = (conversations || []).filter((conversation) => {
    const updatedAt = Math.max(conversation.lastUpdated || 0, conversation.createdAt || 0);
    // Only count histories created or modified within the last eight hours
    return updatedAt >= eightHoursAgo;
  }).length;

  if (recentCount > 0) {
    chrome.action.setBadgeText({ text: recentCount > 99 ? '99+' : recentCount.toString() });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Initialize badge on startup
chrome.storage.local.get(['conversations'], (result) => {
  const conversations = result.conversations || [];
  updateBadge(conversations);
});

// Check for pending conversations from localStorage when tabs are updated
// This helps recover conversations saved during extension reload
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Ask content script to check for pending conversations
    chrome.tabs.sendMessage(tabId, { action: 'checkPending' }).catch(() => {
      // Content script might not be loaded yet, ignore
    });
  }
});

// Notify popup windows when the source tab changes (tab switch or URL change)
// so the "Copy Page Content" button can show/hide dynamically.
chrome.tabs.onActivated.addListener((activeInfo) => {
  for (const [, info] of popupSourceTabMap) {
    if (info.sourceWindowId === activeInfo.windowId) {
      chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (tab?.url) {
          info.sourceTabId = activeInfo.tabId;
          info.sourceTabUrl = tab.url;
          notifyPopupSourceTabChanged(info.popupTabId, tab.id, tab.url);
        }
      });
    }
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url) return;
  for (const [, info] of popupSourceTabMap) {
    if (info.sourceTabId === tabId) {
      info.sourceTabUrl = changeInfo.url;
      notifyPopupSourceTabChanged(info.popupTabId, tabId, changeInfo.url);
    }
  }
});

chrome.windows.onRemoved.addListener((windowId) => {
  popupSourceTabMap.delete(windowId);
});

function notifyPopupSourceTabChanged(popupTabId, sourceTabId, url) {
  if (!popupTabId) return;
  chrome.tabs.sendMessage(popupTabId, {
    action: 'sourceTabChanged',
    tabId: sourceTabId,
    url
  }).catch(() => {});
}

function normalizeMessageText(text) {
  return (text || '').replaceAll(/\s+/g, ' ').trim();
}

function getFingerprint(conversation) {
  if (!conversation) {
    return '';
  }

  if (conversation.fingerprint) {
    return conversation.fingerprint;
  }

  if (!Array.isArray(conversation.messages) || !conversation.messages.length) {
    return '';
  }

  const normalized = conversation.messages.map((message) => ({
    role: message.role,
    content: normalizeMessageText(message.content)
  }));

  const fingerprint = JSON.stringify(normalized);
  conversation.fingerprint = fingerprint;
  return fingerprint;
}

function summarizeMessages(messages) {
  if (!Array.isArray(messages) || !messages.length) {
    return '';
  }

  const summaryText = messages
    .slice(0, 3)
    .map((message) => (message?.content || '').trim())
    .filter(Boolean)
    .join(' ');

  return summaryText.substring(0, 500);
}

function mergeConversationMessages(existingMessages, incomingMessages) {
  const existing = Array.isArray(existingMessages) ? existingMessages.map((msg, index) => ({ ...msg, __mergeIndex: index })) : [];
  const incoming = Array.isArray(incomingMessages) ? incomingMessages.map((msg, index) => ({ ...msg, __mergeIndex: index })) : [];

  if (!existing.length) {
    return sortMergedMessages(incoming.map((msg) => ({ ...msg })));
  }

  if (!incoming.length) {
    return sortMergedMessages(existing);
  }

  const incomingIsCompleteSnapshot = isLikelyCompleteSnapshot(incoming, existing);

  if (incomingIsCompleteSnapshot) {
    return sortMergedMessages(incoming.map((msg) => ({ ...msg })));
  }

  if (containsMessageSequence(existing, incoming)) {
    return sortMergedMessages(existing);
  }

  const normalizeKey = (message = {}) => {
    const role = message.role || 'unknown';
    const normalizedContent = normalizeMessageText(message.content);
    return `${role}:${normalizedContent}`;
  };

  const indexMap = new Map();
  for (let index = 0; index < existing.length; index += 1) {
    indexMap.set(normalizeKey(existing[index]), index);
  }

  const existingCounts = countMessagesByKey(existing, normalizeKey);
  const incomingSeen = new Map();
  const additions = [];

  for (const message of incoming) {
    const key = normalizeKey(message);
    const seenCount = (incomingSeen.get(key) || 0) + 1;
    incomingSeen.set(key, seenCount);

    if (indexMap.has(key)) {
      const storedMessage = existing[indexMap.get(key)];
      if (!storedMessage.timestamp && message?.timestamp) {
        storedMessage.timestamp = message.timestamp;
      }
      if (!storedMessage.html && message?.html) {
        storedMessage.html = message.html;
      }
      if (seenCount <= (existingCounts.get(key) || 0)) {
        continue;
      }
    }

    const incomingContent = normalizeMessageText(message.content);
    const incomingRole = message.role || 'unknown';
    let replacedExisting = false;

    for (let idx = 0; idx < existing.length; idx += 1) {
      const stored = existing[idx];
      if ((stored.role || 'unknown') !== incomingRole) continue;
      const storedContent = normalizeMessageText(stored.content);
      if (!storedContent || !incomingContent) continue;

      if (incomingContent.startsWith(storedContent)) {
        existing[idx] = {
          ...stored,
          content: message.content,
          html: message.html || stored.html,
          timestamp: message.timestamp || stored.timestamp
        };
        indexMap.set(normalizeKey(existing[idx]), idx);
        replacedExisting = true;
        break;
      }
      if (storedContent.startsWith(incomingContent)) {
        replacedExisting = true;
        break;
      }
    }

    if (!replacedExisting) {
      additions.push({
        role: message.role,
        content: message.content,
        timestamp: message.timestamp,
        html: message.html,
        __mergeIndex: message.__mergeIndex
      });
    }
  }

  const orderedAdditions = orderPartialSnapshotAdditions(additions, existing);
  for (const message of orderedAdditions) {
    const cleanedMessage = {
      role: message.role,
      content: message.content,
      timestamp: message.timestamp,
      html: message.html,
      order: existing.length,
      __mergeIndex: existing.length
    };

    existing.push(cleanedMessage);
    indexMap.set(normalizeKey(cleanedMessage), existing.length - 1);
  }

  return sortMergedMessages(existing);
}

function isLikelyCompleteSnapshot(incomingMessages, existingMessages) {
  if (!Array.isArray(incomingMessages) || !incomingMessages.length) return false;
  if (!Array.isArray(existingMessages) || !existingMessages.length) return true;
  if (incomingMessages.length < existingMessages.length) return false;

  const hasContiguousOrder = incomingMessages.every((message, index) => message.order === index);
  if (!hasContiguousOrder) return false;

  const hasUser = incomingMessages.some((message) => message.role === 'user');
  const hasAssistant = incomingMessages.some((message) => message.role === 'assistant');
  if (!hasUser || !hasAssistant) return false;

  if (existingMessages[0]?.role === 'user' && incomingMessages[0]?.role === 'assistant') {
    return false;
  }

  return containsMessageMultiset(incomingMessages, existingMessages);
}

function containsMessageMultiset(candidateMessages, referenceMessages) {
  const candidateCounts = countMessagesByKey(candidateMessages, messageSequenceKey);
  const referenceCounts = countMessagesByKey(referenceMessages, messageSequenceKey);

  for (const [key, requiredCount] of referenceCounts) {
    if ((candidateCounts.get(key) || 0) < requiredCount) {
      return false;
    }
  }

  return true;
}

function orderPartialSnapshotAdditions(additions, existingMessages = []) {
  if (!Array.isArray(additions) || additions.length <= 1) {
    return additions || [];
  }

  const ordered = additions.map((message, index) => ({ ...message, __partialIndex: index }));
  const lastExistingRole = [...existingMessages].reverse().find((message) => message?.role)?.role;

  if (lastExistingRole !== 'user' && ordered[0]?.role === 'assistant') {
    const firstUserIndex = ordered.findIndex((message) => message.role === 'user');
    if (firstUserIndex > 0) {
      const leadingAssistants = ordered.slice(0, firstUserIndex);
      const rest = ordered.slice(firstUserIndex);
      let userRunLength = 0;
      while (userRunLength < rest.length && rest[userRunLength].role === 'user') {
        userRunLength += 1;
      }
      return [
        ...rest.slice(0, userRunLength),
        ...leadingAssistants,
        ...rest.slice(userRunLength)
      ].map(({ __partialIndex, ...message }) => message);
    }
  }

  return ordered.map(({ __partialIndex, ...message }) => message);
}

function messageSequenceKey(message = {}) {
  const role = message.role || 'unknown';
  return `${role}:${normalizeMessageText(message.content)}`;
}

function containsMessageSequence(candidateMessages, sequenceMessages) {
  if (!Array.isArray(sequenceMessages) || !sequenceMessages.length) {
    return true;
  }
  let sequenceIndex = 0;
  for (const candidate of candidateMessages || []) {
    if (messageSequenceKey(candidate) === messageSequenceKey(sequenceMessages[sequenceIndex])) {
      sequenceIndex += 1;
      if (sequenceIndex === sequenceMessages.length) {
        return true;
      }
    }
  }
  return false;
}

function countMessagesByKey(messages, getKey) {
  const counts = new Map();
  for (const message of messages) {
    const key = getKey(message);
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return counts;
}

function sortMergedMessages(messages) {
  const sorted = messages.map((message, index) => ({ ...message, __mergeIndex: message.__mergeIndex ?? index }));
  sorted.sort((a, b) => {
    const aOrder = Number.isFinite(a.order) ? a.order : Number.MAX_SAFE_INTEGER;
    const bOrder = Number.isFinite(b.order) ? b.order : Number.MAX_SAFE_INTEGER;
    if (aOrder !== bOrder) return aOrder - bOrder;

    const aPosition = Number.isFinite(a.position) ? a.position : Number.MAX_SAFE_INTEGER;
    const bPosition = Number.isFinite(b.position) ? b.position : Number.MAX_SAFE_INTEGER;
    if (aPosition !== bPosition) return aPosition - bPosition;

    const aTimestamp = Number.isFinite(a.timestamp) ? a.timestamp : Number.MAX_SAFE_INTEGER;
    const bTimestamp = Number.isFinite(b.timestamp) ? b.timestamp : Number.MAX_SAFE_INTEGER;
    if (aTimestamp !== bTimestamp) return aTimestamp - bTimestamp;

    return a.__mergeIndex - b.__mergeIndex;
  });

  return sorted.map(({ __mergeIndex, ...message }) => message);
}

// ========== Bookmark Storage Functions ==========

// Generate unique ID for bookmark
// ========== Schema Migration ==========
const CURRENT_SCHEMA_VERSION = 2; // v1 → v2: annotation + groupId 引入 (2026-06-24)

async function migrateBookmarkSchema() {
  try {
    const result = await chrome.storage.local.get(['schemaVersion']);
    if (result.schemaVersion >= CURRENT_SCHEMA_VERSION) return;

    // migration v1 → v2: 为所有已有 bookmark 补充 annotation/groupId 字段
    const { bookmarks = [] } = await chrome.storage.local.get('bookmarks');
    let changed = false;
    const updatedBookmarks = bookmarks.map(b => {
      if (b.annotation === undefined || b.groupId === undefined) {
        changed = true;
        return {
          ...b,
          annotation: b.annotation ?? '',
          groupId: b.groupId ?? '',
          updatedAt: b.updatedAt ?? Date.now()
        };
      }
      return b;
    });
    if (changed) {
      await chrome.storage.local.set({
        bookmarks: updatedBookmarks,
        schemaVersion: CURRENT_SCHEMA_VERSION
      });

    } else {
      await chrome.storage.local.set({ schemaVersion: CURRENT_SCHEMA_VERSION });
    }
  } catch (e) {
    console.warn('[ContextWizard] Schema migration failed (non-blocking):', e);
  }
}

function generateBookmarkId() {
  return `bookmark_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}



// Save a new bookmark
function saveBookmark(bookmark, callback) {
  if (!bookmark || !bookmark.selectedText) {
    callback?.({ success: false, error: 'Invalid bookmark data' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    const bookmarks = result.bookmarks || [];

    // Add new bookmark with generated ID
    const ts = Date.now();
    const newBookmark = {
      id: generateBookmarkId(),
      content: bookmark.content || bookmark.selectedText || '',
      selectedText: bookmark.selectedText || '',
      htmlOffset: bookmark.htmlOffset || 0,
      url: bookmark.url || '',
      createdAt: ts,
      updatedAt: ts,
      platform: bookmark.platform || '',
      messageIndex: bookmark.messageIndex || 0
    };

    if (bookmark.reminder && bookmark.reminder.enabled) {
      newBookmark.reminder = bookmark.reminder;
    }

    bookmarks.push(newBookmark);

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        callback?.({ success: false, error: chrome.runtime.lastError.message });
      } else {
        callback?.({ success: true, bookmark: newBookmark });
      }
    });
  });
}

// Delete a bookmark by ID
function deleteBookmark(bookmarkId, callback) {
  if (!bookmarkId) {
    callback?.({ success: false, error: 'Missing bookmark ID' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    let bookmarks = result.bookmarks || [];
    const originalLength = bookmarks.length;
    
    bookmarks = bookmarks.filter((bookmark) => bookmark.id !== bookmarkId);
    
    if (bookmarks.length === originalLength) {
      callback?.({ success: false, error: 'Bookmark not found' });
      return;
    }

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        callback?.({ success: false, error: chrome.runtime.lastError.message });
      } else {
        callback?.({ success: true });
      }
    });
  });
}

// Rename a bookmark
function renameBookmark(bookmarkId, newName, callback) {
  if (!bookmarkId || !newName) {
    callback?.({ success: false, error: 'Missing bookmark ID or new name' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    let bookmarks = result.bookmarks || [];
    const bookmark = bookmarks.find(b => b.id === bookmarkId);
    if (!bookmark) {
      callback?.({ success: false, error: 'Bookmark not found' });
      return;
    }

    bookmark.content = newName;
    bookmark.updatedAt = Date.now();

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        callback?.({ success: false, error: chrome.runtime.lastError.message });
      } else {
        callback?.({ success: true, bookmark });
      }
    });
  });
}

// Rename all bookmarks in a group (same content value)
function renameBookmarkGroup(oldName, newName, callback) {
  if (!oldName || !newName) {
    callback?.({ success: false, error: 'Missing old or new name' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    let bookmarks = result.bookmarks || [];
    let updatedCount = 0;

    bookmarks.forEach(b => {
      if (b.content === oldName) {
        b.content = newName;
        b.updatedAt = Date.now();
        updatedCount++;
      }
    });

    if (updatedCount === 0) {
      callback?.({ success: false, error: 'No bookmarks found in group' });
      return;
    }

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        callback?.({ success: false, error: chrome.runtime.lastError.message });
      } else {
        callback?.({ success: true, updatedCount });
      }
    });
  });
}

// Get all bookmarks with optional filtering
function getBookmarks(filter, callback) {
  chrome.storage.local.get(['bookmarks'], (result) => {
    let bookmarks = result.bookmarks || [];
    
    if (filter) {
      if (filter.platform) {
        bookmarks = bookmarks.filter((b) => b.platform === filter.platform);
      }
      if (filter.url) {
        bookmarks = bookmarks.filter((b) => {
          if (!b.url) return false;
          
          // Extract conversation ID for ChatGPT URLs
          const extractConversationId = (url) => {
            const match = url.match(/\/c\/([a-f0-9-]+)/);
            return match ? match[1] : null;
          };
          
          const bookmarkId = extractConversationId(b.url);
          const filterId = extractConversationId(filter.url);
          
          // If both have conversation IDs, match those
          if (bookmarkId && filterId) {
            return bookmarkId === filterId;
          }
          
          // Otherwise, do flexible URL matching
          const bookmarkBase = b.url.split('?')[0];
          const filterBase = filter.url.split('?')[0];
          return bookmarkBase === filterBase || b.url === filter.url;
        });
      }
      if (filter.searchQuery) {
        const query = filter.searchQuery.toLowerCase();
        bookmarks = bookmarks.filter((b) => 
          (b.content || '').toLowerCase().includes(query) ||
          (b.selectedText || '').toLowerCase().includes(query)
        );
      }
    }

    // Sort by creation time (newest first)
    bookmarks.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    
    callback?.({ success: true, bookmarks });
  });
}

// Get bookmarks for a specific URL
function getBookmarksByConversation(url, callback) {
  if (!url) {
    callback?.({ success: false, error: 'Missing URL' });
    return;
  }

  getBookmarks({ url }, callback);
}


// ========== Bookmark Group CRUD ==========

function generateGroupId() {
  return `group_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

function saveBookmarkGroup(group, callback) {
  if (!group || !group.name) {
    callback?.({ success: false, error: 'Group name is required' });
    return;
  }

  chrome.storage.local.get(['bookmarkGroups'], (result) => {
    const groups = result.bookmarkGroups || [];
    const ts = Date.now();

    if (group.id) {
      const idx = groups.findIndex(g => g.id === group.id);
      if (idx >= 0) {
        groups[idx] = { ...groups[idx], ...group, updatedAt: ts };
        chrome.storage.local.set({ bookmarkGroups: groups }, () => {
          callback?.({ success: true, group: groups[idx] });
        });
        return;
      }
    }

    const newGroup = {
      id: generateGroupId(),
      name: group.name,
      bookmarkIds: group.bookmarkIds || [],
      platform: group.platform || null,
      createdAt: ts,
      updatedAt: ts,
    };
    groups.push(newGroup);
    chrome.storage.local.set({ bookmarkGroups: groups }, () => {
      callback?.({ success: true, group: newGroup });
    });
  });
}

function deleteBookmarkGroup(groupId, callback) {
  if (!groupId) {
    callback?.({ success: false, error: 'Missing group ID' });
    return;
  }

  chrome.storage.local.get(['bookmarkGroups'], (result) => {
    const groups = result.bookmarkGroups || [];
    const filtered = groups.filter(g => g.id !== groupId);
    if (filtered.length === groups.length) {
      callback?.({ success: false, error: 'Group not found' });
      return;
    }
    chrome.storage.local.set({ bookmarkGroups: filtered }, () => {
      callback?.({ success: true });
    });
  });
}

function getBookmarkGroups(callback) {
  chrome.storage.local.get(['bookmarkGroups'], (result) => {
    const groups = result.bookmarkGroups || [];
    groups.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    callback?.({ success: true, groups });
  });
}

// ========== Context Session Handlers ==========

function handleContextSessionStart(request, sender, sendResponse) {
  const { bookmarkGroupId, bookmarkUrl, bookmarkIds, targetPlatform, openInNewTab } = request;
  if ((!bookmarkGroupId && !bookmarkUrl && (!bookmarkIds || bookmarkIds.length === 0)) || !targetPlatform) {
    sendResponse({ success: false, error: 'Missing bookmarkGroupId/bookmarkUrl/bookmarkIds or targetPlatform' });
    return;
  }

  chrome.storage.local.get(['bookmarkGroups', 'bookmarks', 'conversations'], (result) => {
    var group;
    if (bookmarkGroupId) {
      var groups = result.bookmarkGroups || [];
      group = groups.find(g => g.id === bookmarkGroupId);
      if (!group) {
        sendResponse({ success: false, error: 'Bookmark group not found' });
        return;
      }
    }

    const allBookmarks = result.bookmarks || [];
    var groupBookmarks;
    if (bookmarkIds && bookmarkIds.length > 0) {
      groupBookmarks = allBookmarks.filter(function(b) { return bookmarkIds.includes(b.id); });
      if (groupBookmarks.length === 0) {
        sendResponse({ success: false, error: 'No bookmarks found for provided IDs' });
        return;
      }
      group = {
        id: 'group_ids_' + bookmarkIds[0],
        name: groupBookmarks[0].content || groupBookmarks[0].selectedText || 'Bookmarks',
        bookmarkIds: groupBookmarks.map(function(b) { return b.id; }),
      };
    } else if (bookmarkUrl) {
      groupBookmarks = allBookmarks.filter(function(b) { return b.url === bookmarkUrl; });
      if (groupBookmarks.length === 0) {
        sendResponse({ success: false, error: 'No bookmarks found for this URL' });
        return;
      }
      group = {
        id: 'virtual_' + bookmarkUrl.replace(/[^a-zA-Z0-9]/g, '_'),
        name: groupBookmarks[0].selectedText || 'Bookmark',
        bookmarkIds: groupBookmarks.map(function(b) { return b.id; }),
      };
    } else {
      groupBookmarks = allBookmarks.filter(b => group.bookmarkIds.includes(b.id));
    }

    const allConversations = result.conversations || [];
    // Filter to only relevant conversations to reduce payload size.
    // Fall back to sending all conversations if no bookmark URLs are available,
    // to avoid accidentally orphaning bookmarks with URL edge-cases.
    const bookmarkUrls = new Set(groupBookmarks.map(b => b.url).filter(Boolean));
    let conversations;
    if (bookmarkUrls.size === 0) {
      conversations = allConversations;
    } else {
      conversations = allConversations.filter(c => {
        if (!c || !c.url) return false;
        const cUrl = c.url.replace(/[?#].*$/, '').replace(/\/$/, '');
        return Array.from(bookmarkUrls).some(bmUrl => {
          const bUrl = bmUrl.replace(/[?#].*$/, '').replace(/\/$/, '');
          if (!bUrl) return false;
          if (cUrl === bUrl) return true;
          const longer = cUrl.length > bUrl.length ? cUrl : bUrl;
          const shorter = cUrl.length > bUrl.length ? bUrl : cUrl;
          return longer.startsWith(shorter) && (longer[shorter.length] === '/' || longer[shorter.length] === undefined);
        });
      });
      // If filter was too aggressive and matched nothing but bookmarks had URLs,
      // fall back to all conversations so extractForSession can still try to match.
      if (conversations.length === 0 && allConversations.length > 0) {
        conversations = allConversations;
      }
    }

    const payload = {
      action: 'CONTEXT_SESSION_START',
      bookmarks: groupBookmarks,
      conversations: conversations,
      bookmarkGroup: group
    };

    // Inject scripts into tabId then send payload; if tab still loading, fall back to onUpdated.
    const injectAndSend = (tabId) => {
      chrome.scripting.executeScript({ target: { tabId }, files: CONTENT_SCRIPT_FILES.js })
        .then(() => chrome.scripting.insertCSS({ target: { tabId }, files: CONTENT_SCRIPT_FILES.css }))
        .then(() => chrome.tabs.sendMessage(tabId, payload))
        .catch(() => {
          // Tab still loading — inject scripts then send when complete
          const onReady = (updatedTabId, changeInfo) => {
            if (updatedTabId !== tabId || changeInfo.status !== 'complete') return;
            chrome.tabs.onUpdated.removeListener(onReady);
            chrome.scripting.executeScript({ target: { tabId }, files: CONTENT_SCRIPT_FILES.js })
              .then(() => chrome.scripting.insertCSS({ target: { tabId }, files: CONTENT_SCRIPT_FILES.css }))
              .then(() => chrome.tabs.sendMessage(tabId, payload))
              .catch(() => {});
          };
          chrome.tabs.onUpdated.addListener(onReady);
          setTimeout(() => chrome.tabs.onUpdated.removeListener(onReady), 15000);
        });
    };

    const openTab = (tabId) => {
      chrome.tabs.sendMessage(tabId, payload)
        .then(response => {
          if (!response?.success) {
            // content.js running but ContextSession scripts not yet injected
            const supplementary = ['platform-config.js', 'send-detector.js',
              'bookmark-context-extractor.js', 'relevance-scorer.js',
              'context-session.js', 'context-panel.js', 'content-injector.js'];
            chrome.scripting.executeScript({ target: { tabId }, files: supplementary })
              .then(() => chrome.scripting.insertCSS({ target: { tabId }, files: CONTENT_SCRIPT_FILES.css }))
              .then(() => chrome.tabs.sendMessage(tabId, payload))
              .catch(() => {});
          }
        })
        .catch(() => {
          // Content script not running — inject everything and retry
          injectAndSend(tabId);
        });
      sendResponse({ success: true, tabId });
    };

    const platformUrl = request.targetUrl || `https://${targetPlatform}`;

    // Always open a new tab so each ContextChat starts a fresh conversation
    chrome.tabs.create({ url: platformUrl }).then(tab => {
      if (tab?.id) openTab(tab.id);
    }).catch(err => {
      sendResponse({ success: false, error: 'Failed to open tab: ' + err.message });
    });
  });
}

function handleGetBookmarkContextData(request, sender, sendResponse) {
  const { bookmarkIds } = request;
  if (!bookmarkIds || !Array.isArray(bookmarkIds)) {
    sendResponse({ success: false, error: 'Missing bookmarkIds array' });
    return;
  }

  chrome.storage.local.get(['bookmarks', 'conversations'], (result) => {
    const allBookmarks = result.bookmarks || [];
    const bookmarks = allBookmarks.filter(b => bookmarkIds.includes(b.id));

    const conversations = result.conversations || [];
    const bookmarkConversations = [];
    for (const bm of bookmarks) {
      if (bm.url) {
        const conv = conversations.find(c => c.url === bm.url);
        if (conv) bookmarkConversations.push(conv);
      }
    }

    sendResponse({ success: true, bookmarks, conversations: bookmarkConversations });
  });
}

// ========== Bookmark Reminder Functions ==========

const REMINDER_CHECK_ALARM = 'reminder-check';

function ensureReminderCheckAlarm() {
  chrome.alarms.get(REMINDER_CHECK_ALARM, (existing) => {

    if (!existing) {
      chrome.alarms.create(REMINDER_CHECK_ALARM, {
        periodInMinutes: 1
      });

    }
  });
}

// Initialize reminder alarm on every service worker start
ensureReminderCheckAlarm();

function handleReminderAlarm() {
  chrome.storage.session.get(['reminderProcessing'], (sessionResult) => {
    if (sessionResult.reminderProcessing) {

      return;
    }
    chrome.storage.session.set({ reminderProcessing: true }, () => {
      const now = Math.floor(Date.now() / 1000);

      chrome.storage.local.get(['bookmarks'], (result) => {
        const bookmarks = result.bookmarks || [];
        let changed = false;

        for (const bookmark of bookmarks) {
          if (!bookmark.reminder || !bookmark.reminder.enabled) continue;
          const reminder = bookmark.reminder;

          if (!reminder.time || reminder.time > now) continue;

          showReminderNotification(bookmark);

          bookmark.updatedAt = Date.now();
          if (reminder.recurrence && reminder.recurrence !== 'none') {
            bookmark.reminder.time = calculateNextReminderTime(reminder);
          } else {
            bookmark.reminder.enabled = false;
            bookmark.reminder.time = null;
          }
          changed = true;
        }

        const releaseLock = () => {
          chrome.storage.session.set({ reminderProcessing: false });
        };

        if (changed) {
          chrome.storage.local.set({ bookmarks }, releaseLock);
        } else {
          releaseLock();
        }
      });
    });
  });
}

function showReminderNotification(bookmark) {
  const title = 'ContextWizard Reminder';
  const content = bookmark.content || bookmark.selectedText || 'Bookmark reminder';
  const notificationId = `reminder_${bookmark.id}`;

  chrome.notifications.create(notificationId, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message: content,
    priority: 2,
    requireInteraction: true
  });

  // Add to reminder history
  addReminderHistoryItem(bookmark);
}

chrome.notifications.onClicked.addListener((notificationId) => {
  if (!notificationId.startsWith('reminder_')) return;
  const bookmarkId = notificationId.replace('reminder_', '');

  chrome.notifications.clear(notificationId);

  // Mark reminder history as read when notification is clicked
  markReminderHistoryAsRead(bookmarkId);

  chrome.storage.local.get(['bookmarks'], (result) => {
    const bookmarks = result.bookmarks || [];
    const bookmark = bookmarks.find(b => b.id === bookmarkId);
    if (bookmark?.url) {
      chrome.tabs.create({ url: bookmark.url, active: true }, (tab) => {
        if (tab && tab.id) {
          const onUpdated = (tabId, changeInfo) => {
            if (tabId !== tab.id || changeInfo.status !== 'complete') return;
            chrome.tabs.onUpdated.removeListener(onUpdated);
            setTimeout(() => {
              chrome.tabs.sendMessage(tab.id, {
                action: 'scrollToBookmark',
                bookmarkId: bookmarkId
              }).catch(() => {});
            }, 2000);
          };
          chrome.tabs.onUpdated.addListener(onUpdated);
          setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdated); }, 15000);
        }
      });
    }
  });
});

function markReminderHistoryAsRead(bookmarkId) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    const history = result[REMINDER_HISTORY_KEY] || [];
    let changed = false;
    
    // Find and mark all unread items for this bookmark
    history.forEach(item => {
      if (item.bookmarkId === bookmarkId && !item.read) {
        item.read = true;
        changed = true;
      }
    });
    
    if (changed) {
      chrome.storage.local.set({ [REMINDER_HISTORY_KEY]: history }, () => {
        updateReminderBadge(history);
      });
    }
  });
}

function calculateNextReminderTime(reminder) {
  const now = new Date();
  const recurrence = reminder.recurrence;
  const [hour, minute] = (reminder.timeOfDay || '09:00').split(':').map(Number);

  if (recurrence === 'none') {
    return reminder.time;
  }

  if (recurrence === 'daily') {
    const next = new Date(now);
    next.setHours(hour, minute, 0, 0);
    if (next.getTime() <= Date.now()) {
      next.setDate(next.getDate() + 1);
    }
    return Math.floor(next.getTime() / 1000);
  }

  if (recurrence === 'weekdays') {
    let next = new Date(now);
    if (next.getDay() === 0 || next.getDay() === 6) {
      next.setDate(next.getDate() + ((1 - next.getDay() + 7) % 7 || 7));
      next.setHours(hour, minute, 0, 0);
    } else {
      next.setHours(hour, minute, 0, 0);
      if (next.getTime() <= Date.now()) {
        next.setDate(next.getDate() + 1);
        if (next.getDay() === 0) next.setDate(next.getDate() + 1);
        if (next.getDay() === 6) next.setDate(next.getDate() + 2);
      }
    }
    return Math.floor(next.getTime() / 1000);
  }

  if (recurrence === 'weekly' && reminder.weekdays && reminder.weekdays.length > 0) {
    for (let i = 0; i < 7; i++) {
      const dow = (now.getDay() + i) % 7;
      if (reminder.weekdays.includes(dow)) {
        const next = new Date(now);
        next.setDate(now.getDate() + i);
        next.setHours(hour, minute, 0, 0);
        if (i === 0 && next.getTime() <= Date.now()) {
          continue;
        }
        return Math.floor(next.getTime() / 1000);
      }
    }
    const fallback = new Date(now);
    fallback.setDate(fallback.getDate() + 7);
    fallback.setHours(hour, minute, 0, 0);
    return Math.floor(fallback.getTime() / 1000);
  }

  if (recurrence === 'monthly' && reminder.monthlyDay) {
    const next = new Date(now);
    next.setMonth(next.getMonth() + 1, reminder.monthlyDay);
    next.setHours(hour, minute, 0, 0);
    if (next.getDate() !== reminder.monthlyDay) {
      next.setDate(0);
    }
    return Math.floor(next.getTime() / 1000);
  }

  if (recurrence === 'monthlyNth' && reminder.monthlyNthWeekday != null && reminder.monthlyWeekday != null) {
    const next = getNextNthWeekdayOfMonth(
      now.getFullYear(), now.getMonth() + 1,
      reminder.monthlyNthWeekday, reminder.monthlyWeekday, hour, minute
    );
    if (next.getTime() / 1000 <= reminder.time) {
      return getNextNthWeekdayOfMonth(
        now.getFullYear(), now.getMonth() + 2,
        reminder.monthlyNthWeekday, reminder.monthlyWeekday, hour, minute
      ).getTime() / 1000;
    }
    return Math.floor(next.getTime() / 1000);
  }

  return reminder.time + 86400;
}

function getNextNthWeekdayOfMonth(year, month, nth, weekday, hour, minute) {
  const lastDayOfMonth = new Date(year, month, 0).getDate();

  if (nth === -1) {
    for (let d = lastDayOfMonth; d >= 1; d--) {
      const dt = new Date(year, month - 1, d);
      if (dt.getDay() === weekday) {
        dt.setHours(hour, minute, 0, 0);
        return dt;
      }
    }
  }

  const firstDay = new Date(year, month - 1, 1);
  const dayOfWeek = firstDay.getDay();
  const daysUntilWeekday = (weekday - dayOfWeek + 7) % 7;
  let targetDate = 1 + daysUntilWeekday + (nth - 1) * 7;
  if (targetDate > lastDayOfMonth) {
    targetDate -= 7;
  }
  const result = new Date(year, month - 1, targetDate);
  result.setHours(hour, minute, 0, 0);
  return result;
}

function saveReminder(bookmarkId, reminder, callback) {
  if (!bookmarkId) {
    callback?.({ success: false, error: 'Missing bookmark ID' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    const bookmarks = result.bookmarks || [];
    const bookmark = bookmarks.find(b => b.id === bookmarkId);
    if (!bookmark) {
      callback?.({ success: false, error: 'Bookmark not found' });
      return;
    }

    bookmark.reminder = {
      enabled: reminder.enabled !== false,
      time: reminder.time || null,
      timeOfDay: reminder.timeOfDay || '09:00',
      recurrence: reminder.recurrence || 'none',
      weekdays: reminder.weekdays || [],
      monthlyDay: reminder.monthlyDay || 1,
      monthlyNthWeekday: reminder.monthlyNthWeekday != null ? reminder.monthlyNthWeekday : null,
      monthlyWeekday: reminder.monthlyWeekday != null ? reminder.monthlyWeekday : null
    };
    bookmark.updatedAt = Date.now();

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        callback?.({ success: false, error: chrome.runtime.lastError.message });
      } else {
        callback?.({ success: true, reminder: bookmark.reminder });
      }
    });
  });
}

function deleteReminder(bookmarkId, callback) {
  if (!bookmarkId) {
    callback?.({ success: false, error: 'Missing bookmark ID' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    const bookmarks = result.bookmarks || [];
    const bookmark = bookmarks.find(b => b.id === bookmarkId);
    if (!bookmark) {
      callback?.({ success: false, error: 'Bookmark not found' });
      return;
    }

    bookmark.reminder = { enabled: false };
    bookmark.updatedAt = Date.now();

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        callback?.({ success: false, error: chrome.runtime.lastError.message });
      } else {
        callback?.({ success: true });
      }
    });
  });
}

function getReminder(bookmarkId, callback) {
  if (!bookmarkId) {
    callback?.({ success: false, error: 'Missing bookmark ID' });
    return;
  }

  chrome.storage.local.get(['bookmarks'], (result) => {
    const bookmarks = result.bookmarks || [];
    const bookmark = bookmarks.find(b => b.id === bookmarkId);
    callback?.({
      success: true,
      reminder: bookmark?.reminder || { enabled: false }
    });
  });
}


// ========== Reminder History Functions ==========

const REMINDER_HISTORY_KEY = 'reminderHistory';
const REMINDER_HISTORY_CLEANUP_DAYS = 30;

function generateReminderHistoryId() {
  return `rh_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function addReminderHistoryItem(bookmark) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    const history = result[REMINDER_HISTORY_KEY] || [];
    const newItem = {
      id: generateReminderHistoryId(),
      bookmarkId: bookmark.id,
      triggeredAt: Date.now(),
      read: false,
      content: (bookmark.content || bookmark.selectedText || '').substring(0, 100),
      platform: bookmark.platform || 'unknown',
      url: bookmark.url || ''
    };
    history.unshift(newItem);
    
    // Cleanup old read items
    const cutoffTime = Date.now() - REMINDER_HISTORY_CLEANUP_DAYS * 24 * 60 * 60 * 1000;
    const cleanedHistory = history.filter(item => 
      !item.read || item.triggeredAt > cutoffTime
    );
    
    chrome.storage.local.set({ [REMINDER_HISTORY_KEY]: cleanedHistory });
    
    // Update badge
    updateReminderBadge(cleanedHistory);
  });
}

function getReminderHistory(callback) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    callback?.(result[REMINDER_HISTORY_KEY] || []);
  });
}

function getUnreadReminderCount(callback) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    const history = result[REMINDER_HISTORY_KEY] || [];
    const unreadCount = history.filter(item => !item.read).length;
    callback?.(unreadCount);
  });
}

function markReminderRead(reminderId, callback) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    const history = result[REMINDER_HISTORY_KEY] || [];
    const item = history.find(h => h.id === reminderId);
    if (item) {
      item.read = true;
      chrome.storage.local.set({ [REMINDER_HISTORY_KEY]: history }, () => {
        updateReminderBadge(history);
        callback?.({ success: true });
      });
    } else {
      callback?.({ success: false, error: 'Reminder not found' });
    }
  });
}

function markAllRemindersRead(callback) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    const history = result[REMINDER_HISTORY_KEY] || [];
    history.forEach(item => { item.read = true; });
    chrome.storage.local.set({ [REMINDER_HISTORY_KEY]: history }, () => {
      updateReminderBadge(history);
      callback?.({ success: true });
    });
  });
}

function updateReminderBadge(history) {
  const unreadCount = history.filter(item => !item.read).length;
  if (unreadCount > 0) {
    chrome.action.setBadgeText({ text: unreadCount > 99 ? '99+' : String(unreadCount) });
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

function cleanupOldReminderHistory(callback) {
  chrome.storage.local.get([REMINDER_HISTORY_KEY], (result) => {
    const history = result[REMINDER_HISTORY_KEY] || [];
    const cutoffTime = Date.now() - REMINDER_HISTORY_CLEANUP_DAYS * 24 * 60 * 60 * 1000;
    const cleanedHistory = history.filter(item => 
      !item.read || item.triggeredAt > cutoffTime
    );
    chrome.storage.local.set({ [REMINDER_HISTORY_KEY]: cleanedHistory }, () => {
      updateReminderBadge(cleanedHistory);
      callback?.(cleanedHistory);
    });
  });
}


async function requestHostPermission(pattern, callback) {
  if (!pattern) {
    callback?.({ success: false, error: 'Missing pattern' });
    return;
  }

  const originPattern = buildOriginPattern(pattern);
  if (!originPattern) {
    callback?.({ success: false, error: 'Invalid pattern' });
    return;
  }

  try {
    const hasPermission = await chrome.permissions.contains({ origins: [originPattern] });

    if (hasPermission) {
      callback?.({ success: true, granted: true });
      return;
    }

    const granted = await chrome.permissions.request({ origins: [originPattern] });

    callback?.({ success: true, granted });
  } catch (error) {
    console.error('[ContextWizard Background] Permission request failed:', error);
    callback?.({ success: false, error: error?.message });
  }
}

function buildOriginPattern(pattern = '') {
  const trimmed = pattern.trim();
  if (!trimmed || !/^https?:\/\//i.test(trimmed)) {
    return '';
  }

  if (trimmed.includes('*')) {
    const slashIndex = trimmed.indexOf('/', trimmed.indexOf('//') + 2);
    if (slashIndex === -1) {
      return trimmed.endsWith('*') ? trimmed : `${trimmed}*`;
    }
    const base = trimmed.slice(0, slashIndex);
    return `${base}/*`;
  }

  try {
    const url = new URL(trimmed);
    return `${url.protocol}//${url.host}/*`;
  } catch (error) {
    return '';
  }
}

// ── Page Copy helpers ──────────────────────────────────────────────

async function copyPageExecuteOnTab(tabId, callback) {
  if (!tabId) {
    callback?.({ success: false, error: 'Missing tabId' });
    return;
  }

  try {
    // Use activeTab to inject a text-extraction function and return the result
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: extractPageTextInTab
    });

    const text = results?.[0]?.result || '';
    callback?.({ success: true, text });
  } catch (error) {
    console.error('[ContextWizard Background] copyPageExecuteOnTab failed:', error);
    callback?.({ success: false, error: error?.message });
  }
}

// Injected into the page via chrome.scripting.executeScript — must be self-contained
function extractPageTextInTab() {
  const BLOCK_TAGS = new Set([
    'ADDRESS','ARTICLE','ASIDE','BLOCKQUOTE','DD','DETAILS','DIALOG',
    'DIV','DL','DT','FIELDSET','FIGCAPTION','FIGURE','FOOTER','FORM',
    'H1','H2','H3','H4','H5','H6','HEADER','HGROUP','HR','LI','MAIN',
    'NAV','OL','P','PRE','SECTION','TABLE','TBODY','TD','TFOOT','TH',
    'THEAD','TR','UL',
  ]);

  // Tags that typically contain navigation / chrome, not content
  const NOISE_TAGS = new Set(['NAV','FOOTER','HEADER','ASIDE']);

  // class/id substrings that signal non-content regions
  const NOISE_PATTERNS = /sidebar|widget|recommend|related|footer|nav-|navbar|navigation|cookie|banner|advert|sponsor|promo|language-selector|lang-select|scaffold-layout__aside|scaffold-layout__sidebar|msg-overlay|global-footer|share-box|social-action|feed-sort|artdeco-dropdown|artdeco-modal/i;

  // role values that signal non-content
  const NOISE_ROLES = new Set(['navigation','banner','contentinfo','complementary']);

  function isNoiseElement(el) {
    if (NOISE_TAGS.has(el.tagName)) return true;
    const role = el.getAttribute('role') || '';
    if (NOISE_ROLES.has(role)) return true;
    const cls = el.className || '';
    const id = el.id || '';
    const str = typeof cls === 'string' ? cls : '';
    if (NOISE_PATTERNS.test(str) || NOISE_PATTERNS.test(id)) return true;
    return false;
  }

  function walk(node, lines) {
    if (node.nodeType === Node.TEXT_NODE) {
      const t = node.textContent.replace(/[ \t]+/g, ' ').trim();
      if (t) lines.push(t);
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;

    const tag = node.tagName;

    // Skip noise subtrees entirely
    if (isNoiseElement(node)) return;

    const isBlock = BLOCK_TAGS.has(tag);
    if (isBlock) lines.push('');

    if (tag === 'LI') {
      const parent = node.parentElement;
      if (parent && parent.tagName === 'OL') {
        lines.push(`${Array.from(parent.children).indexOf(node) + 1}. `);
      } else {
        lines.push('- ');
      }
    }
    if (tag === 'TD' || tag === 'TH') lines.push('\t');

    for (const child of node.childNodes) walk(child, lines);

    if (tag === 'BR') lines.push('');
    if (isBlock) lines.push('');
  }

  // ── 1. Try to find main content area first ──
  const body = document.body;
  if (!body) return '';

  const mainEl = document.querySelector(
    'main, [role="main"], article, .main-content, #main-content, ' +
    '.scaffold-layout__main, .core-rail'
  );
  const root = mainEl || body;
  const clone = root.cloneNode(true);

  // Remove obviously unwanted elements
  const unwanted = clone.querySelectorAll(
    'script,style,noscript,svg,canvas,iframe,video,audio,' +
    '[aria-hidden="true"],.visually-hidden,.sr-only,' +
    'button,input,select,textarea,form,' +
    '.ad-banner,.premium-upsell,.artdeco-card__actions'
  );
  for (const el of unwanted) el.remove();

  // ── 2. Walk and collect text ──
  const lines = [];
  walk(clone, lines);
  let text = lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();

  // ── 3. Post-processing: deduplicate repeated lines ──
  const seen = new Set();
  const deduped = [];
  for (const line of text.split('\n')) {
    const trimmed = line.trim();
    // Skip empty lines between content but keep structure
    if (!trimmed) {
      // Allow at most one blank line
      if (deduped.length > 0 && deduped[deduped.length - 1] !== '') {
        deduped.push('');
      }
      continue;
    }
    // Skip very short UI-label-like lines (1-3 chars) that repeat
    if (trimmed.length <= 3 && seen.has(trimmed)) continue;
    // Skip exact duplicate lines (e.g. repeated profile titles)
    if (trimmed.length > 10 && seen.has(trimmed)) continue;
    seen.add(trimmed);
    deduped.push(line);
  }

  return deduped.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

// Expose selected helpers for unit tests
if (typeof globalThis !== 'undefined') {
  globalThis.ContextWizardBackgroundTestHooks = {
    normalizeToMatchPattern,
    hashString,
    buildCustomScriptId,
    normalizeMessageText,
    getFingerprint,
    summarizeMessages,
    mergeConversationMessages,
    getSearchTokens,
    conversationMatchesAllTokens,
    buildConversationSearchText,
    countTokensInText,
    updateBadge,
    calculateNextReminderTime,
    getNextNthWeekdayOfMonth,
    handleReminderAlarm
  };
}
