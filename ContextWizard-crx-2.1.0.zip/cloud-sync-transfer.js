/**
 * ContextWizard Cloud Sync — Chunked Transfer Module
 * 
 * Handles splitting large encrypted payloads into 2MB chunks for upload,
 * and reassembling chunks on download. Supports:
 * - Progress callbacks
 * - Retry on failure (3 attempts per chunk)
 * - Resume from last uploaded chunk
 * - Yielding between chunks to keep UI responsive
 */

const CHUNK_SIZE = 2 * 1024 * 1024; // 2MB per chunk
const MAX_RETRIES = 3;
const YIELD_MS = 50;                // ms to yield between chunks
const DOWNLOAD_CONCURRENCY = 3;     // parallel chunk downloads

/**
 * @typedef {Object} TransferProgress
 * @property {'uploading'|'downloading'|'merging'} phase
 * @property {number} current - current chunk index (0-based)
 * @property {number} total - total chunk count
 * @property {number} percent - 0-100
 */

/**
 * Upload an encrypted buffer in chunks.
 * @param {string} apiBase - API base URL
 * @param {string} token - JWT auth token
 * @param {ArrayBuffer} encryptedBuffer - full encrypted data
 * @param {string} deviceId - unique device identifier
 * @param {function} [onProgress] - progress callback
 * @returns {Promise<{syncId: string, size: number}>}
 */
async function chunkedUpload(apiBase, token, encryptedBuffer, deviceId, rawSize, onProgress) {
  const totalSize = encryptedBuffer.byteLength;
  const totalChunks = Math.ceil(totalSize / CHUNK_SIZE);
  const dataHash = await _sha256hex(encryptedBuffer);
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
  };

  // 1. Init upload — send rawSize so server accounts original (pre-gzip) bytes
  const initRes = await fetch(`${apiBase}/sync/init`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ totalChunks, totalSize, rawSize: rawSize || totalSize, dataHash, deviceId }),
  });

  if (!initRes.ok) {
    const err = await initRes.json();
    throw new Error(err.error || 'Failed to init upload');
  }

  const { syncId } = await initRes.json();

  // 2. Check for resumable chunks
  let uploadedSet = new Set();
  try {
    const statusRes = await fetch(
      `${apiBase}/sync/upload-status?syncId=${syncId}`,
      { headers: { 'Authorization': `Bearer ${token}` } }
    );
    if (statusRes.ok) {
      const statusData = await statusRes.json();
      uploadedSet = new Set(statusData.uploaded || []);
    }
  } catch { /* fresh start */ }

  // 3. Upload chunks with retry
  const data = new Uint8Array(encryptedBuffer);

  for (let i = 0; i < totalChunks; i++) {
    if (uploadedSet.has(i)) {
      if (onProgress) {
        onProgress({ phase: 'uploading', current: i + 1, total: totalChunks, percent: Math.round(((i + 1) / totalChunks) * 100) });
      }
      continue; // Already uploaded (resume)
    }

    const start = i * CHUNK_SIZE;
    const end = Math.min(start + CHUNK_SIZE, totalSize);
    const chunk = data.slice(start, end);

    let success = false;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        const chunkRes = await fetch(
          `${apiBase}/sync/chunk?syncId=${syncId}&index=${i}`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/octet-stream',
            },
            body: chunk.buffer,
          }
        );

        if (chunkRes.ok) {
          success = true;
          break;
        }

        // If 413 (quota exceeded) or 404 (record gone), don't retry
        if (chunkRes.status === 413 || chunkRes.status === 404) {
          const err = await chunkRes.json();
          throw new Error(err.error || `Upload failed with status ${chunkRes.status}`);
        }
      } catch (e) {
        if (attempt === MAX_RETRIES - 1) throw e;
        await _delay(1000 * (attempt + 1)); // Exponential-ish backoff
      }
    }

    if (!success) {
      throw new Error(`Failed to upload chunk ${i} after ${MAX_RETRIES} attempts`);
    }

    if (onProgress) {
      onProgress({
        phase: 'uploading',
        current: i + 1,
        total: totalChunks,
        percent: Math.round(((i + 1) / totalChunks) * 100),
      });
    }

    // Yield to keep UI responsive
    if (i < totalChunks - 1) {
      await _delay(YIELD_MS);
    }
  }

  // 4. Complete upload
  const completeRes = await fetch(
    `${apiBase}/sync/complete?syncId=${syncId}`,
    { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } }
  );

  if (!completeRes.ok) {
    const err = await completeRes.json();
    throw new Error(err.error || 'Failed to complete upload');
  }

  return { syncId, size: totalSize };
}

/**
 * Download the latest snapshot in chunks and reassemble.
 * @param {string} apiBase - API base URL
 * @param {string} token - JWT auth token
 * @param {function} [onProgress] - progress callback
 * @returns {Promise<{buffer: ArrayBuffer, syncId: string, dataHash: string} | null>}
 */
async function chunkedDownload(apiBase, token, onProgress) {
  const headers = { 'Authorization': `Bearer ${token}` };

  // 1. Get pull info
  const infoRes = await fetch(`${apiBase}/sync/pull-info`, { headers });
  if (!infoRes.ok) {
    let errBody = '';
    try { errBody = await infoRes.text(); } catch { /* ignore */ }
    throw new Error(`Failed to get pull info (${infoRes.status}): ${errBody}`);
  }

  const { snapshot } = await infoRes.json();
  if (!snapshot) return null; // No snapshot exists

  const { syncId, dataHash, dataSize, downloadChunks, chunkSize, createdAt } = snapshot;

  // 2. Download chunks with concurrency
  const chunks = new Array(downloadChunks);
  let completedCount = 0;

  const downloadChunk = async (index) => {
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        const res = await fetch(
          `${apiBase}/sync/pull-chunk?syncId=${syncId}&index=${index}`,
          { headers }
        );

        if (!res.ok) {
          if (attempt === MAX_RETRIES - 1) {
            throw new Error(`Failed to download chunk ${index}`);
          }
          await _delay(1000 * (attempt + 1));
          continue;
        }

        chunks[index] = new Uint8Array(await res.arrayBuffer());
        completedCount++;

        if (onProgress) {
          onProgress({
            phase: 'downloading',
            current: completedCount,
            total: downloadChunks,
            percent: Math.round((completedCount / downloadChunks) * 100),
          });
        }
        return;
      } catch (e) {
        if (attempt === MAX_RETRIES - 1) throw e;
        await _delay(1000 * (attempt + 1));
      }
    }
  };

  // Run downloads with bounded concurrency
  const queue = Array.from({ length: downloadChunks }, (_, i) => i);
  const workers = [];
  for (let w = 0; w < Math.min(DOWNLOAD_CONCURRENCY, downloadChunks); w++) {
    workers.push((async () => {
      while (queue.length > 0) {
        const idx = queue.shift();
        if (idx !== undefined) await downloadChunk(idx);
      }
    })());
  }
  await Promise.all(workers);

  // 3. Merge chunks
  if (onProgress) {
    onProgress({ phase: 'merging', current: 0, total: 1, percent: 0 });
  }

  let totalLength = 0;
  for (const chunk of chunks) {
    totalLength += chunk.byteLength;
  }

  const merged = new Uint8Array(totalLength);
  let offset = 0;
  for (const chunk of chunks) {
    merged.set(chunk, offset);
    offset += chunk.byteLength;
  }

  if (onProgress) {
    onProgress({ phase: 'merging', current: 1, total: 1, percent: 100 });
  }

  return { buffer: merged.buffer, syncId, dataHash, createdAt };
}

// ── Helpers ──────────────────────────────────────────────────

async function _sha256hex(buffer) {
  const hash = await crypto.subtle.digest('SHA-256', buffer);
  return Array.from(new Uint8Array(hash))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function _delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Export
if (typeof globalThis !== 'undefined') {
  globalThis.CloudSyncTransfer = {
    chunkedUpload,
    chunkedDownload,
    CHUNK_SIZE,
  };
}
