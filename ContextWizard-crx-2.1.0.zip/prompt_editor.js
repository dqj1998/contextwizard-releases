// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Prompt Editor script for creating and editing prompts

const getMessage = (key, fallback, substitutions) => {
  if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
    const localized = chrome.i18n.getMessage(key, substitutions);
    if (localized) {
      return localized;
    }
  }
  if (typeof fallback === 'function') {
    return fallback(Array.isArray(substitutions) ? substitutions : []);
  }
  return fallback;
};

// Storage keys
const REPLACE_HISTORY_KEY = 'promptEditorReplaceHistory';
const PROMPT_TEMPLATES_KEY = 'promptEditorTemplates';
const MAX_REPLACE_HISTORY = 100;

let replaceHistory = {};
let promptTemplates = {};
let selectedText = '';
let selectedTextStart = -1;
let selectedTextEnd = -1;
let replaceDialog = null;
let autoReplaceResultsDialog = null;
let replacementSettingsDialog = null;
let promptTemplatesPopup = null;
let promptTemplatesBackdrop = null;
let promptTemplatesList = null;
let textarea = null;
let statusElement = null;

// Auto Replace state
let autoReplaceResults = []; // Stores {original, replacement, count, reverted}
let contentBeforeAutoReplace = '';

// Undo/Redo state
const UNDO_MAX_STACK = 200;
const INPUT_SNAPSHOT_DEBOUNCE_MS = 350;
let undoStack = [];
let redoStack = [];
let inputSnapshotTimer = null;

function captureState() {
  return {
    value: textarea ? textarea.value : '',
    selectionStart: textarea ? textarea.selectionStart : 0,
    selectionEnd: textarea ? textarea.selectionEnd : 0
  };
}

function applyState(state) {
  if (!state || !textarea) return;
  textarea.value = state.value;
  try {
    textarea.selectionStart = state.selectionStart;
    textarea.selectionEnd = state.selectionEnd;
  } catch {}
  textarea.focus();
}

function pushHistory(state) {
  if (!state) return;
  // Avoid pushing duplicate consecutive states
  const last = undoStack.length ? undoStack[undoStack.length - 1] : null;
  if (last && last.value === state.value && last.selectionStart === state.selectionStart && last.selectionEnd === state.selectionEnd) {
    return;
  }
  undoStack.push(state);
  if (undoStack.length > UNDO_MAX_STACK) {
    undoStack.shift();
  }
  // New changes invalidate redo history
  redoStack = [];
}

function scheduleInputSnapshot() {
  if (inputSnapshotTimer) {
    clearTimeout(inputSnapshotTimer);
  }
  inputSnapshotTimer = setTimeout(() => {
    inputSnapshotTimer = null;
    pushHistory(captureState());
  }, INPUT_SNAPSHOT_DEBOUNCE_MS);
}

function undo() {
  if (undoStack.length <= 1) return;
  const current = undoStack.pop();
  redoStack.push(current);
  const previous = undoStack[undoStack.length - 1];
  applyState(previous);
}

function redo() {
  if (!redoStack.length) return;
  const next = redoStack.pop();
  undoStack.push(next);
  applyState(next);
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', initializeEditor);

function initializeEditor() {
  textarea = document.getElementById('promptEditorTextarea');
  replaceDialog = document.getElementById('replaceDialog');
  autoReplaceResultsDialog = document.getElementById('autoReplaceResultsDialog');
  replacementSettingsDialog = document.getElementById('replacementSettingsDialog');
  statusElement = document.getElementById('editorStatus');

  // Load i18n strings
  updatePageTitle();
  
  // Load replace history from storage and migrate if needed
  chrome.storage.local.get([REPLACE_HISTORY_KEY], (result) => {
    if (result[REPLACE_HISTORY_KEY]) {
      const loadedHistory = result[REPLACE_HISTORY_KEY];
      // Migrate old format (string values) to new format (object with replacement and ignoreCase)
      let needsMigration = false;
      for (const [key, value] of Object.entries(loadedHistory)) {
        if (typeof value === 'string') {
          // Old format: {original: replacement}
          // New format: {original: {replacement: string, ignoreCase: boolean}}
          loadedHistory[key] = { replacement: value, ignoreCase: true };
          needsMigration = true;
        }
      }
      replaceHistory = loadedHistory;
      if (needsMigration) {
        // Save migrated data
        const updateObj = {};
        updateObj[REPLACE_HISTORY_KEY] = replaceHistory;
        chrome.storage.local.set(updateObj);
      }
    }
  });

  // Load prompt templates from storage
  chrome.storage.local.get([PROMPT_TEMPLATES_KEY], (result) => {
    if (result[PROMPT_TEMPLATES_KEY]) {
      promptTemplates = result[PROMPT_TEMPLATES_KEY];
    } else {
      promptTemplates = {};
      savePromptTemplates();
    }
  });

  // Get prompt templates popup elements
  promptTemplatesPopup = document.getElementById('promptTemplatesPopup');
  promptTemplatesBackdrop = document.getElementById('promptTemplatesBackdrop');
  promptTemplatesList = document.getElementById('promptTemplatesList');

  // Set up button handlers
  document.getElementById('editorCloseBtn').addEventListener('click', closeEditor);
  document.getElementById('promptEditorAutoReplaceBtn').addEventListener('click', performAutoReplace);
  document.getElementById('promptEditorManageReplacementsBtn').addEventListener('click', showReplacementSettings);
  document.getElementById('promptEditorTemplatesBtn').addEventListener('click', showPromptTemplatesPopup);
  document.getElementById('promptEditorClearBtn').addEventListener('click', clearText);
  document.getElementById('promptEditorSaveBtn').addEventListener('click', saveToClipboard);
  document.getElementById('replaceDialogCancelBtn').addEventListener('click', cancelReplace);
  document.getElementById('replaceDialogConfirmBtn').addEventListener('click', confirmReplace);
  document.getElementById('autoReplaceResultsCloseBtn').addEventListener('click', closeAutoReplaceResults);
  document.getElementById('autoReplaceResultsDoneBtn').addEventListener('click', closeAutoReplaceResults);
  document.getElementById('replacementSettingsCloseBtn').addEventListener('click', closeReplacementSettings);
  document.getElementById('replacementSettingsDoneBtn').addEventListener('click', closeReplacementSettings);
  document.getElementById('promptTemplatesCloseBtn').addEventListener('click', hidePromptTemplatesPopup);
  document.getElementById('promptTemplatesAddBtn').addEventListener('click', addNewTemplate);
  document.getElementById('promptTemplatesAddInput').addEventListener('input', handleTemplateInputChange);
  document.getElementById('promptTemplatesAddInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addNewTemplate();
  });
  if (promptTemplatesBackdrop) {
    promptTemplatesBackdrop.addEventListener('click', hidePromptTemplatesPopup);
  }

  // Set up textarea event listeners
  textarea.addEventListener('mouseup', handleTextSelection);
  textarea.addEventListener('keyup', handleTextSelection);
  textarea.addEventListener('select', handleTextSelection);
  textarea.addEventListener('input', scheduleInputSnapshot);

  // Initialize replace dialog close handler
  replaceDialog.addEventListener('click', (e) => {
    if (e.target === replaceDialog) {
      cancelReplace();
    }
  });

  // Initialize auto replace results dialog close handler
  autoReplaceResultsDialog.addEventListener('click', (e) => {
    if (e.target === autoReplaceResultsDialog) {
      closeAutoReplaceResults();
    }
  });

  // Initialize replacement settings dialog close handler
  replacementSettingsDialog.addEventListener('click', (e) => {
    if (e.target === replacementSettingsDialog) {
      closeReplacementSettings();
    }
  });

  // Load initial clipboard content
  loadClipboardContent();

  // Initialize first history state
  pushHistory(captureState());

  // Translate UI elements
  translateUI();
  
  // Handle URL parameters for specific tabs
  handleUrlParameters();
}

/**
 * Handle URL parameters for specific functionality
 */
function handleUrlParameters() {
  const urlParams = new URLSearchParams(window.location.search);
  const tab = urlParams.get('tab');
  
  if (tab === 'templates') {
    // Auto-open templates popup after initialization
    setTimeout(() => {
      showPromptTemplatesPopup();
    }, 500);
  }
}

/**
 * Update page title with i18n
 */
function updatePageTitle() {
  const title = getMessage('promptEditorTitle', 'Prompt Editor');
  document.title = title;
}

/**
 * Translate all i18n elements on page
 */
function translateUI() {
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    const text = getMessage(key, key);
    el.textContent = text;
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.getAttribute('data-i18n-placeholder');
    const text = getMessage(key, key);
    el.placeholder = text;
  });

  document.querySelectorAll('[data-i18n-title]').forEach((el) => {
    const key = el.getAttribute('data-i18n-title');
    const text = getMessage(key, key);
    el.title = text;
  });

  document.querySelectorAll('[data-i18n-aria-label]').forEach((el) => {
    const key = el.getAttribute('data-i18n-aria-label');
    const text = getMessage(key, key);
    el.setAttribute('aria-label', text);
  });
}

/**
 * Load clipboard content on editor open with a light retry mechanism
 */
async function loadClipboardContent(retries = 1) {
  try {
    const text = await navigator.clipboard.readText();
    if (text && text.trim()) {
      textarea.value = text;
      textarea.focus();
      // Record state after loading clipboard content
      pushHistory(captureState());
      return true;
    }
  } catch (err) {
    // If permission prompt just appeared or focus isn't ready, retry once
    if (retries > 0) {
      setTimeout(() => loadClipboardContent(retries - 1), 500);
      return false;
    }
    // Clipboard read not available
  }
  return false;
}

/**
 * Show status message
 */
function showStatus(message, type = 'success', duration = 2500) {
  statusElement.textContent = message;
  statusElement.className = `editor-status visible ${type}`;

  if (duration > 0) {
    setTimeout(() => {
      statusElement.classList.remove('visible');
    }, duration);
  }
}

/**
 * Clear textarea content
 */
function clearText() {
  const confirmed = confirm(getMessage('promptEditorClearConfirm', 'Are you sure you want to clear all text? This cannot be undone.'));
  if (confirmed) {
    textarea.value = '';
    textarea.selectionStart = 0;
    textarea.selectionEnd = 0;
    textarea.focus();
    pushHistory(captureState());
    showStatus(getMessage('promptEditorCleared', 'Text cleared'));
  }
}

/**
 * Copy textarea content to clipboard and close editor
 */
async function saveToClipboard() {
  const text = textarea.value;
  
  if (!text.trim()) {
    showStatus(getMessage('promptEditorEmptyError', 'Nothing to save. The textarea is empty.'), 'error', 3000);
    return;
  }

  try {
    await copyTextToClipboard(text);
    showStatus(getMessage('promptEditorSaveSuccess', 'Saved to clipboard!'), 'success', 1500);
    
    // Close editor after brief delay
    setTimeout(() => {
      closeEditor();
    }, 1500);
  } catch (err) {
    console.error('Failed to copy to clipboard:', err);
    showStatus(getMessage('promptEditorSaveError', 'Failed to save to clipboard'), 'error', 3000);
  }
}

/**
 * Copy text to clipboard (with fallback for older browsers)
 */
async function copyTextToClipboard(text) {
  // Try modern Clipboard API first
  if (navigator.clipboard && navigator.clipboard.writeText) {
    return navigator.clipboard.writeText(text);
  }

  // Fallback for older browsers
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.style.position = 'fixed';
  textarea.style.left = '-9999px';
  textarea.style.top = '-9999px';
  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();
  
  try {
    document.execCommand('copy');
  } finally {
    document.body.removeChild(textarea);
  }
}

/**
 * Handle text selection in textarea
 */
function handleTextSelection() {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  
  selectedTextStart = start;
  selectedTextEnd = end;
  selectedText = textarea.value.substring(start, end);

  // Show/hide replace button based on selection
  if (selectedText.length > 0) {
    showReplaceButton();
  } else {
    hideReplaceButton();
  }
}

/**
 * Show replace button near cursor
 */
function showReplaceButton() {
  // Remove existing button if any
  hideReplaceButton();

  if (selectedTextStart < 0 || selectedTextEnd < 0) {
    return;
  }

  // Create container for replace button
  const container = document.createElement('div');
  container.className = 'replace-button-container';
  container.id = 'replaceButtonContainer';

  const button = document.createElement('button');
  button.className = 'replace-action-btn';
  button.textContent = getMessage('promptEditorReplaceWithButton', 'Replace with');
  button.addEventListener('click', openReplaceDialog);

  container.appendChild(button);
  document.body.appendChild(container);

  // Position button near the selected text
  // Get the textarea's position and the selection position
  const textareaRect = textarea.getBoundingClientRect();
  
  // Get the position of the selected text within the textarea
  // We'll position the button at the end of the selection
  const before = textarea.value.substring(0, selectedTextEnd);
  const lines = before.split('\n');
  const currentLine = lines.length - 1;
  const lineStartPos = lines.slice(0, -1).reduce((sum, line) => sum + line.length + 1, 0);
  const charInLine = selectedTextEnd - lineStartPos;
  
  // Estimate position (this is approximate)
  // Each character is roughly 8px wide in monospace font
  const charWidth = 8;
  const lineHeight = 22; // Based on the textarea line-height
  
  const offsetLeft = charWidth * charInLine;
  const offsetTop = lineHeight * currentLine;
  
  // Position relative to textarea
  const left = textareaRect.left + offsetLeft;
  const top = textareaRect.top + offsetTop + lineHeight + 5;
  
  container.style.position = 'fixed';
  container.style.left = left + 'px';
  container.style.top = top + 'px';
  container.style.zIndex = '1999';
}

/**
 * Hide replace button
 */
function hideReplaceButton() {
  const container = document.getElementById('replaceButtonContainer');
  if (container) {
    container.remove();
  }
}

/**
 * Open replace dialog
 */
function openReplaceDialog() {
  if (!selectedText) {
    return;
  }

  const replaceWithInput = document.getElementById('replaceWithInput');
  const ignoreCaseCheckbox = document.getElementById('ignoreCaseCheckbox');
  replaceWithInput.value = '';
  replaceWithInput.focus();

  // Check if we have previous replacement for this text
  if (replaceHistory[selectedText]) {
    const entry = replaceHistory[selectedText];
    // Support both old format (string) and new format (object)
    if (typeof entry === 'string') {
      replaceWithInput.value = entry;
      ignoreCaseCheckbox.checked = true;
    } else {
      replaceWithInput.value = entry.replacement;
      ignoreCaseCheckbox.checked = entry.ignoreCase !== false;
    }
    // Select all text for convenience
    replaceWithInput.select();
  } else {
    // Default to ignore case checked for new entries
    ignoreCaseCheckbox.checked = true;
  }

  // Show dialog - remove hidden class and show it
  replaceDialog.classList.remove('hidden');
  
  // Focus on input after a brief delay to ensure it's visible
  setTimeout(() => {
    replaceWithInput.focus();
  }, 50);
}

/**
 * Cancel replace operation
 */
function cancelReplace() {
  // Always hide with the hidden class
  replaceDialog.classList.add('hidden');
  document.getElementById('replaceWithInput').value = '';
  textarea.focus();
}

/**
 * Confirm and perform replace operation
 */
function confirmReplace() {
  const replacementText = document.getElementById('replaceWithInput').value;
  const ignoreCase = document.getElementById('ignoreCaseCheckbox').checked;
  
  if (!selectedText) {
    cancelReplace();
    return;
  }

  // Store in replace history with ignoreCase setting
  saveReplaceHistory(selectedText, replacementText, ignoreCase);

  // Count occurrences before replacement (with or without case insensitive)
  const pattern = new RegExp(escapeRegex(selectedText), ignoreCase ? 'gi' : 'g');
  const beforeCount = (textarea.value.match(pattern) || []).length;

  let finalContent;
  if (ignoreCase) {
    finalContent = textarea.value.replace(pattern, (match) => {
      let newText = replacementText;
      if (match === match.toUpperCase()) {
        newText = replacementText.toUpperCase();
      } else if (match[0] === match[0].toUpperCase()) {
        newText = replacementText.charAt(0).toUpperCase() + replacementText.slice(1);
      }
      return newText;
    });
  } else {
    const beforeSelection = textarea.value.substring(0, selectedTextStart);
    const afterSelection = textarea.value.substring(selectedTextEnd);
    const newContent = beforeSelection + replacementText + afterSelection;
    finalContent = newContent.split(selectedText).join(replacementText);
  }
  
  textarea.value = finalContent;
  
  // Close replace dialog
  cancelReplace();

  // Hide the floating "Replace with" button after replacement
  hideReplaceButton();

  // Show success message
  const message = `${getMessage('promptEditorReplaceSuccess', 'Replaced text')} (${beforeCount})`;
  // Extend visibility duration for better feedback
  showStatus(message, 'success', 4500);

  // Restore focus and selection
  textarea.focus();

  // Record history after replacement change
  pushHistory(captureState());
}

/**
 * Save replacement to history
 */
function saveReplaceHistory(original, replacement, ignoreCase = true) {
  replaceHistory[original] = {
    replacement: replacement,
    ignoreCase: ignoreCase
  };

  // Keep only last MAX_REPLACE_HISTORY entries
  const keys = Object.keys(replaceHistory);
  if (keys.length > MAX_REPLACE_HISTORY) {
    delete replaceHistory[keys[0]];
  }

  // Save to storage
  const updateObj = {};
  updateObj[REPLACE_HISTORY_KEY] = replaceHistory;
  chrome.storage.local.set(updateObj);
}

/**
 * Escape special regex characters
 */
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Perform auto replace using replace history
 */
function performAutoReplace() {
  if (!textarea.value.trim()) {
    showStatus(getMessage('promptEditorEmptyError', 'The textarea is empty.'), 'error', 3000);
    return;
  }

  // Save state before auto replace
  contentBeforeAutoReplace = textarea.value;
  autoReplaceResults = [];

  let currentContent = textarea.value;
  
  // Find all matches from replace history in current content
  for (const [original, entry] of Object.entries(replaceHistory)) {
    // Support both old format (string) and new format (object)
    const replacement = typeof entry === 'string' ? entry : entry.replacement;
    const ignoreCase = typeof entry === 'string' ? true : entry.ignoreCase !== false;
    
    if (!original || original === replacement) continue;
    
    const flags = ignoreCase ? 'gi' : 'g';
    const pattern = new RegExp(escapeRegex(original), flags);
    
    // Track actual matched texts with their original case
    const matchedWithCases = [];
    const replacedContent = currentContent.replace(pattern, (match) => {
      matchedWithCases.push(match);
      let newText = replacement;
      // Only apply case preservation if ignoreCase is true
      if (ignoreCase) {
        if (match === match.toUpperCase()) {
          newText = replacement.toUpperCase();
        } else if (match[0] === match[0].toUpperCase()) {
          newText = replacement.charAt(0).toUpperCase() + replacement.slice(1);
        }
      }
      return newText;
    });
    
    if (matchedWithCases.length > 0) {
      currentContent = replacedContent;
      
      autoReplaceResults.push({
        original: original,
        replacement: replacement,
        count: matchedWithCases.length,
        reverted: false,
        matchedWithCases: matchedWithCases
      });
    }
  }

  if (autoReplaceResults.length === 0) {
    showStatus(getMessage('promptEditorNoAutoReplaceMatches', 'No matches found in replace history.'), 'error', 3000);
    return;
  }

  // Apply all replacements
  textarea.value = currentContent;
  pushHistory(captureState());

  // Show results dialog
  showAutoReplaceResults();
}

/**
 * Show auto replace results dialog
 */
function showAutoReplaceResults() {
  const resultsList = document.getElementById('autoReplaceResultsList');
  resultsList.innerHTML = '';

  if (autoReplaceResults.length === 0) {
    const noResults = document.createElement('div');
    noResults.className = 'auto-replace-no-results';
    noResults.textContent = getMessage('promptEditorNoAutoReplaceResults', 'No replacements were made.');
    resultsList.appendChild(noResults);
  } else {
    autoReplaceResults.forEach((result, index) => {
      const item = document.createElement('div');
      item.className = 'auto-replace-result-item';
      if (result.reverted) {
        item.classList.add('reverted');
      }

      const info = document.createElement('div');
      info.className = 'auto-replace-result-info';

      const text = document.createElement('div');
      text.className = 'auto-replace-result-text';
      
      const originalSpan = document.createElement('span');
      originalSpan.textContent = result.original;
      
      const arrow = document.createElement('span');
      arrow.className = 'auto-replace-result-arrow';
      arrow.textContent = '→';
      
      const replacementSpan = document.createElement('span');
      replacementSpan.textContent = result.replacement;
      
      text.appendChild(originalSpan);
      text.appendChild(arrow);
      text.appendChild(replacementSpan);

      const count = document.createElement('div');
      count.className = 'auto-replace-result-count';
      count.textContent = getMessage('promptEditorReplacementCount', `${result.count} replacement(s)`, [result.count.toString()]);

      info.appendChild(text);
      info.appendChild(count);

      const undoBtn = document.createElement('button');
      undoBtn.className = 'auto-replace-undo-btn';
      undoBtn.textContent = result.reverted 
        ? getMessage('promptEditorReverted', 'Reverted')
        : getMessage('promptEditorUndoButton', 'Undo');
      undoBtn.disabled = result.reverted;
      undoBtn.addEventListener('click', () => revertAutoReplace(index));

      item.appendChild(info);
      item.appendChild(undoBtn);
      resultsList.appendChild(item);
    });
  }

  autoReplaceResultsDialog.classList.remove('hidden');
}

/**
 * Revert a specific auto replace operation
 */
function revertAutoReplace(index) {
  if (index < 0 || index >= autoReplaceResults.length) return;
  
  const result = autoReplaceResults[index];
  if (result.reverted) return;

  // Revert this specific replacement in textarea
  // Use the recorded matched texts to preserve original case
  const currentContent = textarea.value;
  let revertedContent = currentContent;
  
  if (result.matchedWithCases && result.matchedWithCases.length > 0) {
    const pattern = new RegExp(escapeRegex(result.replacement), 'gi');
    let matchIndex = 0;
    revertedContent = currentContent.replace(pattern, (match) => {
      const originalCase = result.matchedWithCases[matchIndex];
      matchIndex++;
      return originalCase;
    });
  } else {
    // Fallback for old format
    revertedContent = currentContent.split(result.replacement).join(result.original);
  }
  
  textarea.value = revertedContent;

  // Mark as reverted
  result.reverted = true;
  
  // Update history
  pushHistory(captureState());

  // Refresh results display
  showAutoReplaceResults();
  
  showStatus(getMessage('promptEditorReplacementReverted', 'Replacement reverted'), 'success', 2000);
}

/**
 * Close auto replace results dialog
 */
function closeAutoReplaceResults() {
  autoReplaceResultsDialog.classList.add('hidden');
  autoReplaceResults = [];
  contentBeforeAutoReplace = '';
  textarea.focus();
}

/**
 * Close the editor
 */
function closeEditor() {
  // Check if this is a popup window or a tab
  if (window.opener) {
    // This is a window opened by another window
    window.close();
  } else if (chrome.tabs && chrome.tabs.getCurrent) {
    // This is a tab, close it
    chrome.tabs.getCurrent((tab) => {
      if (tab) {
        chrome.tabs.remove(tab.id);
      } else {
        window.close();
      }
    });
  } else {
    // Fallback
    window.close();
  }
}

/**
 * Show replacement settings modal
 */
function showReplacementSettings() {
  renderReplacementSettingsList();
  replacementSettingsDialog.classList.remove('hidden');
}

/**
 * Close replacement settings modal
 */
function closeReplacementSettings() {
  replacementSettingsDialog.classList.add('hidden');
  textarea.focus();
}

/**
 * Render the replacement settings list
 */
function renderReplacementSettingsList() {
  const list = document.getElementById('replacementSettingsList');
  list.innerHTML = '';

  const entries = Object.entries(replaceHistory);
  
  if (entries.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'replacement-settings-empty';
    empty.textContent = getMessage('promptEditorNoReplacementSettings', 'No saved replacement settings.');
    list.appendChild(empty);
    return;
  }

  entries.forEach(([original, entry]) => {
    // Support both old format (string) and new format (object)
    const replacement = typeof entry === 'string' ? entry : entry.replacement;
    const ignoreCase = typeof entry === 'string' ? true : entry.ignoreCase !== false;
    
    const item = document.createElement('div');
    item.className = 'replacement-settings-item';
    item.dataset.original = original;

    // Text info
    const info = document.createElement('div');
    info.className = 'replacement-settings-info';

    const text = document.createElement('div');
    text.className = 'replacement-settings-text';
    
    const originalSpan = document.createElement('span');
    originalSpan.className = 'replacement-settings-original';
    originalSpan.textContent = original;
    
    const arrow = document.createElement('span');
    arrow.className = 'replacement-settings-arrow';
    arrow.textContent = '→';
    
    const replacementSpan = document.createElement('span');
    replacementSpan.className = 'replacement-settings-replacement';
    replacementSpan.textContent = replacement;
    
    text.appendChild(originalSpan);
    text.appendChild(arrow);
    text.appendChild(replacementSpan);
    info.appendChild(text);

    // Ignore case checkbox
    const checkboxContainer = document.createElement('div');
    checkboxContainer.className = 'replacement-settings-checkbox';
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `ignoreCase-${encodeURIComponent(original)}`;
    checkbox.checked = ignoreCase;
    checkbox.addEventListener('change', () => toggleIgnoreCase(original, checkbox.checked));
    
    const checkboxLabel = document.createElement('label');
    checkboxLabel.htmlFor = checkbox.id;
    checkboxLabel.textContent = getMessage('promptEditorIgnoreCaseShort', 'Ignore case');
    
    checkboxContainer.appendChild(checkbox);
    checkboxContainer.appendChild(checkboxLabel);

    // Delete button (initially visible)
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'replacement-settings-delete-btn';
    deleteBtn.innerHTML = `<svg viewBox="0 0 16 16" fill="currentColor">
      <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z"/>
      <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
    </svg>`;
    deleteBtn.title = getMessage('promptEditorDeleteReplacement', 'Delete');
    deleteBtn.addEventListener('click', () => showDeleteConfirmation(item, original));

    item.appendChild(info);
    item.appendChild(checkboxContainer);
    item.appendChild(deleteBtn);
    list.appendChild(item);
  });
}

/**
 * Toggle ignore case setting for a replacement entry
 */
function toggleIgnoreCase(original, newValue) {
  if (!replaceHistory[original]) return;
  
  const entry = replaceHistory[original];
  // Support both old format (string) and new format (object)
  const replacement = typeof entry === 'string' ? entry : entry.replacement;
  
  replaceHistory[original] = {
    replacement: replacement,
    ignoreCase: newValue
  };

  // Save to storage
  const updateObj = {};
  updateObj[REPLACE_HISTORY_KEY] = replaceHistory;
  chrome.storage.local.set(updateObj);
}

/**
 * Show delete confirmation buttons
 */
function showDeleteConfirmation(item, original) {
  // Find and hide the delete button
  const deleteBtn = item.querySelector('.replacement-settings-delete-btn');
  if (deleteBtn) {
    deleteBtn.style.display = 'none';
  }

  // Check if confirmation buttons already exist
  let confirmBtns = item.querySelector('.replacement-settings-confirm-btns');
  if (confirmBtns) {
    confirmBtns.style.display = 'flex';
    return;
  }

  // Create confirmation buttons
  confirmBtns = document.createElement('div');
  confirmBtns.className = 'replacement-settings-confirm-btns';

  const confirmBtn = document.createElement('button');
  confirmBtn.className = 'replacement-settings-confirm-btn';
  confirmBtn.textContent = getMessage('promptEditorConfirmDelete', 'Delete');
  confirmBtn.addEventListener('click', () => deleteReplacement(original));

  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'replacement-settings-cancel-btn';
  cancelBtn.textContent = getMessage('promptEditorCancelDelete', 'Cancel');
  cancelBtn.addEventListener('click', () => hideDeleteConfirmation(item));

  confirmBtns.appendChild(confirmBtn);
  confirmBtns.appendChild(cancelBtn);
  item.appendChild(confirmBtns);
}

/**
 * Hide delete confirmation buttons
 */
function hideDeleteConfirmation(item) {
  const confirmBtns = item.querySelector('.replacement-settings-confirm-btns');
  if (confirmBtns) {
    confirmBtns.style.display = 'none';
  }

  const deleteBtn = item.querySelector('.replacement-settings-delete-btn');
  if (deleteBtn) {
    deleteBtn.style.display = 'flex';
  }
}

/**
 * Delete a replacement entry
 */
function deleteReplacement(original) {
  delete replaceHistory[original];

  // Save to storage
  const updateObj = {};
  updateObj[REPLACE_HISTORY_KEY] = replaceHistory;
  chrome.storage.local.set(updateObj, () => {
    renderReplacementSettingsList();
    showStatus(getMessage('promptEditorReplacementDeleted', 'Replacement deleted'), 'success', 2000);
  });
}

/**
 * Save prompt templates to storage
 */
function savePromptTemplates() {
  const updateObj = {};
  updateObj[PROMPT_TEMPLATES_KEY] = promptTemplates;
  chrome.storage.local.set(updateObj);
}

/**
 * Handle template input change - enable/disable Add button
 */
function handleTemplateInputChange() {
  const input = document.getElementById('promptTemplatesAddInput');
  const addBtn = document.getElementById('promptTemplatesAddBtn');
  addBtn.disabled = !input.value.trim();
}

/**
 * Show prompt templates popup
 */
function showPromptTemplatesPopup() {
  renderPromptTemplatesList();
  promptTemplatesPopup.classList.remove('hidden');
  if (promptTemplatesBackdrop) {
    promptTemplatesBackdrop.classList.remove('hidden');
  }
  const input = document.getElementById('promptTemplatesAddInput');
  const addBtn = document.getElementById('promptTemplatesAddBtn');
  input.value = '';
  addBtn.disabled = true;
  input.focus();
}

/**
 * Hide prompt templates popup
 */
function hidePromptTemplatesPopup() {
  promptTemplatesPopup.classList.add('hidden');
  if (promptTemplatesBackdrop) {
    promptTemplatesBackdrop.classList.add('hidden');
  }
  textarea.focus();
}

/**
 * Render prompt templates list (sorted by usage frequency)
 */
function renderPromptTemplatesList() {
  promptTemplatesList.innerHTML = '';

  const templates = Object.entries(promptTemplates);

  if (templates.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'templates-empty';
    empty.textContent = getMessage('promptEditorNoTemplates', 'No prompts saved.');
    promptTemplatesList.appendChild(empty);
    return;
  }

  // Sort by usage count descending, then by creation time ascending
  templates.sort((a, b) => {
    const aCount = a[1].usageCount || 0;
    const bCount = b[1].usageCount || 0;
    if (bCount !== aCount) {
      return bCount - aCount;
    }
    return (a[1].createdAt || 0) - (b[1].createdAt || 0);
  });

  templates.forEach(([templateText, data]) => {
    const item = document.createElement('div');
    item.className = 'template-item';

    const text = document.createElement('div');
    text.className = 'template-text';
    text.textContent = templateText;
    text.title = templateText;
    item.appendChild(text);

    if (data.usageCount > 0) {
      const badge = document.createElement('span');
      badge.className = 'template-usage-badge';
      badge.textContent = data.usageCount;
      item.appendChild(badge);
    }

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'template-delete-btn';
    deleteBtn.textContent = getMessage('promptEditorDeleteTemplate', 'Delete');
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      showDeleteTemplateConfirmation(item, templateText, confirmBtn, cancelBtn, deleteBtn);
    });
    item.appendChild(deleteBtn);

    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'template-delete-confirm-btn';
    confirmBtn.textContent = getMessage('promptEditorConfirmDelete', 'Delete');
    confirmBtn.style.display = 'none';
    confirmBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteTemplate(templateText);
    });
    item.appendChild(confirmBtn);

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'template-delete-cancel-btn';
    cancelBtn.textContent = getMessage('promptEditorCancelDelete', 'Cancel');
    cancelBtn.style.display = 'none';
    cancelBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      hideDeleteTemplateConfirmation(item, templateText, confirmBtn, cancelBtn, deleteBtn);
    });
    item.appendChild(cancelBtn);

    item.addEventListener('click', () => {
      insertTemplate(templateText);
    });

    promptTemplatesList.appendChild(item);
  });
}

/**
 * Insert template at cursor position
 */
function insertTemplate(templateText) {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;

  const before = textarea.value.substring(0, start);
  const after = textarea.value.substring(end);
  textarea.value = before + templateText + after;

  const newCursorPos = start + templateText.length;
  textarea.selectionStart = newCursorPos;
  textarea.selectionEnd = newCursorPos;

  if (promptTemplates[templateText]) {
    promptTemplates[templateText].usageCount = (promptTemplates[templateText].usageCount || 0) + 1;
    savePromptTemplates();
  }

  textarea.focus();
  pushHistory(captureState());

  hidePromptTemplatesPopup();

  showStatus(getMessage('promptEditorTemplateInserted', 'Prompt inserted'), 'success', 1500);
}

/**
 * Add new template
 */
function addNewTemplate() {
  const input = document.getElementById('promptTemplatesAddInput');
  const text = input.value.trim();

  if (!text) {
    showStatus(getMessage('promptEditorTemplateEmptyError', 'Please enter a prompt.'), 'error', 2000);
    return;
  }

  if (promptTemplates[text]) {
    showStatus(getMessage('promptEditorTemplateExistsError', 'This prompt already exists.'), 'error', 2000);
    return;
  }

  promptTemplates[text] = {
    usageCount: 0,
    createdAt: Date.now()
  };

  savePromptTemplates();

  input.value = '';
  renderPromptTemplatesList();

  showStatus(getMessage('promptEditorTemplateAdded', 'Prompt added'), 'success', 1500);
}

/**
 * Delete template
 */
function deleteTemplate(templateText) {
  if (!promptTemplates[templateText]) return;

  delete promptTemplates[templateText];
  savePromptTemplates();
  renderPromptTemplatesList();

  showStatus(getMessage('promptEditorTemplateDeleted', 'Prompt deleted'), 'success', 1500);
}

/**
 * Show delete confirmation for template
 */
function showDeleteTemplateConfirmation(item, templateText, confirmBtn, cancelBtn, deleteBtn) {
  deleteBtn.style.display = 'none';
  confirmBtn.style.display = 'block';
  cancelBtn.style.display = 'block';
}

/**
 * Hide delete confirmation for template
 */
function hideDeleteTemplateConfirmation(item, templateText, confirmBtn, cancelBtn, deleteBtn) {
  confirmBtn.style.display = 'none';
  cancelBtn.style.display = 'none';
  deleteBtn.style.display = 'flex';
}

// Handle Escape key to close the editor or cancel replace dialog
document.addEventListener('keydown', (e) => {
  // Undo/Redo shortcuts: support Ctrl/Cmd+Z and Ctrl/Cmd+Shift+Z
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
    if (e.shiftKey) {
      redo();
    } else {
      undo();
    }
    e.preventDefault();
    return;
  }

  if (e.key === 'Escape') {
    if (!replaceDialog.classList.contains('hidden')) {
      cancelReplace();
      e.preventDefault();
    } else if (!autoReplaceResultsDialog.classList.contains('hidden')) {
      closeAutoReplaceResults();
      e.preventDefault();
    } else if (!replacementSettingsDialog.classList.contains('hidden')) {
      closeReplacementSettings();
      e.preventDefault();
    } else if (promptTemplatesPopup && !promptTemplatesPopup.classList.contains('hidden')) {
      hidePromptTemplatesPopup();
      e.preventDefault();
    } else {
      closeEditor();
    }
  }
});
