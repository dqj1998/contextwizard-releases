// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Popup script for managing conversation list
const PAGE_SIZE = 30;
const TOP_PLATFORM_LIMIT = 3;
const SCROLL_TRIGGER_OFFSET = 80;
const SEARCH_DEBOUNCE_MS = 200;
const HISTORY_SAVE_DEBOUNCE_MS = 1000;
const SEARCH_HISTORY_MAX = 1000;
const SEARCH_SUGGESTIONS_DISPLAY = 8;
const GLOBAL_STATUS_CLEAR_MS = 2500;
let clearHistoryConfirmVisible = false;
let suggestionsPointerDown = false;
const UI_LOCALE = (globalThis.chrome?.i18n?.getMessage('@@ui_locale'))
  || (globalThis.navigator?.language)
  || 'en';
const NORMALIZED_LOCALE = UI_LOCALE.replace('_', '-');
const TIME_THRESHOLDS = [
  { limit: 60, unit: 'second', divisor: 1, immediate: true },
  { limit: 3600, unit: 'minute', divisor: 60 },
  { limit: 86400, unit: 'hour', divisor: 3600 },
  { limit: 604800, unit: 'day', divisor: 86400 }
];
const REGEX_SPECIAL_CHARS = /[.*+?^${}()|[\]\\]/g;
let relativeTimeFormatter = null;
if (typeof Intl !== 'undefined' && typeof Intl.RelativeTimeFormat === 'function') {
  try {
    relativeTimeFormatter = new Intl.RelativeTimeFormat(NORMALIZED_LOCALE, { numeric: 'auto' });
  } catch (error) {
    console.warn('[ContextWizard Popup] RelativeTimeFormat unavailable for locale', UI_LOCALE, error);
  }
}

let allConversations = [];
let visibleConversations = [];
let currentFilter = 'all';
let searchQuery = '';
let detailModal = null;
let detailElements = {};
let topPlatformStats = [];
let filteredConversationsCache = [];
let renderedCount = 0;
let isLoadingMore = false;
let searchHistory = [];
let searchDebounceTimer = null;
let globalStatusClearTimer = null;
let detailStatusClearTimer = null;
let detailConversation = null;

// Search result navigation state
let currentDetailIndex = -1;  // Index in filteredConversationsCache
let searchResultsNavContext = null;  // { searchQuery, resultsList, currentIndex }

// Detail match navigation state (within a single conversation)
let detailMatchElements = [];
let currentMatchCursor = -1;

const getMessage = (key, fallback, substitutions) => {
  if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
    const localized = chrome.i18n.getMessage(key, substitutions);
    if (localized) {
      return localized;
    }
  }
  if (typeof fallback === 'function') {
    return fallback(Array.isArray(substitutions) ? substitutions : []);
  }
  return fallback;
};

// Open a tab in the last focused normal window (avoids spawning inside this popup)
function openTabInLastFocusedWindow(createProps, onCreated) {
  const props = { ...createProps };
  chrome.windows.getLastFocused({ windowTypes: ['normal'] }, (win) => {
    if (!chrome.runtime.lastError && win && win.id) {
      props.windowId = win.id;
    }

    chrome.tabs.create(props, (tab) => {
      if (chrome.runtime.lastError) {
        onCreated?.(null);
        return;
      }

      onCreated?.(tab);
    });
  });
}

function getGlobalStatusElement() {
  return document.getElementById('globalStatus');
}

function setGlobalStatusText(text) {
  const statusEl = getGlobalStatusElement();
  if (!statusEl) {
    return;
  }

  const value = (text || '').trim();
  statusEl.textContent = value;
  if (value) {
    statusEl.classList.add('visible');
  } else {
    statusEl.classList.remove('visible');
  }

  if (globalStatusClearTimer) {
    clearTimeout(globalStatusClearTimer);
    globalStatusClearTimer = null;
  }

  if (value) {
    globalStatusClearTimer = setTimeout(() => {
      globalStatusClearTimer = null;
      setGlobalStatusText('');
    }, GLOBAL_STATUS_CLEAR_MS);
  }
}

function setGlobalStatusMessage(messageKey, fallback) {
  setGlobalStatusText(getMessage(messageKey, fallback));
}

// Shared utility functions are loaded from shared-utils.js
// - htmlToPlainText
// - extractMessageText
// - formatConversationAsContextText
// - copyTextToClipboard

// ============================================
// Debounce Utility
// ============================================

/**
 * Create a debounced version of a function
 * @param {Function} fn - Function to debounce
 * @param {number} delay - Delay in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(fn, delay) {
  let timeoutId = null;
  return function(...args) {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    timeoutId = setTimeout(() => {
      fn.apply(this, args);
      timeoutId = null;
    }, delay);
  };
}

// ============================================
// Search History Functions
// ============================================

/**
 * Load search history from storage
 */
function loadSearchHistory() {
  chrome.storage.local.get(['searchHistory'], (result) => {
    searchHistory = result.searchHistory || [];
  });
}

/**
 * Save a search query to history (with deduplication)
 * @param {string} query - Search query to save
 */
function saveSearchHistory(query) {
  const trimmed = query?.trim();
  if (!trimmed) return;
  
  // Remove existing occurrence (for deduplication)
  const existingIndex = searchHistory.indexOf(trimmed);
  if (existingIndex !== -1) {
    searchHistory.splice(existingIndex, 1);
  }
  
  // Add to front (most recent first)
  searchHistory.unshift(trimmed);
  
  // Limit to max entries
  if (searchHistory.length > SEARCH_HISTORY_MAX) {
    searchHistory = searchHistory.slice(0, SEARCH_HISTORY_MAX);
  }
  
  // Persist to storage
  chrome.storage.local.set({ searchHistory });
}

/**
 * Clear all search history
 */
function clearSearchHistory(options = {}) {
  const { keepOpen = false } = options;
  searchHistory = [];
  chrome.storage.local.set({ searchHistory: [] });
  if (!keepOpen) {
    hideSearchSuggestions();
  }
}

function showClearHistoryInlineConfirm() {
  if (clearHistoryConfirmVisible) {
    return;
  }
  const header = document.querySelector('.suggestions-header');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  if (!header || !clearHistoryBtn) {
    return;
  }

  clearHistoryConfirmVisible = true;
  clearHistoryBtn.style.display = 'none';

  const confirmLabel = getMessage('clearHistoryConfirmAction', 'Confirm');
  const cancelLabel = getMessage('clearHistoryCancelAction', 'Cancel');
  const promptLabel = getMessage('clearHistoryConfirm', 'Clear all search history?');

  let confirmWrap = document.getElementById('clearHistoryConfirmWrap');
  if (!confirmWrap) {
    confirmWrap = document.createElement('div');
    confirmWrap.id = 'clearHistoryConfirmWrap';
    confirmWrap.className = 'clear-history-confirm';
  }

  confirmWrap.innerHTML = '';

  const prompt = document.createElement('span');
  prompt.className = 'clear-history-prompt';
  prompt.textContent = promptLabel;

  const confirmBtn = document.createElement('button');
  confirmBtn.type = 'button';
  confirmBtn.className = 'clear-history-action confirm';
  confirmBtn.textContent = confirmLabel;
  confirmBtn.addEventListener('click', () => {
    suggestionsPointerDown = true;
    clearSearchHistory({ keepOpen: true });
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      updateSearchSuggestions(searchInput.value);
    }
    hideClearHistoryInlineConfirm();
    setTimeout(() => { suggestionsPointerDown = false; }, 300);
  });

  const cancelBtn = document.createElement('button');
  cancelBtn.type = 'button';
  cancelBtn.className = 'clear-history-action cancel';
  cancelBtn.textContent = cancelLabel;
  cancelBtn.addEventListener('click', () => {
    suggestionsPointerDown = true;
    hideClearHistoryInlineConfirm();
    setTimeout(() => { suggestionsPointerDown = false; }, 300);
  });

  confirmWrap.appendChild(prompt);
  confirmWrap.appendChild(confirmBtn);
  confirmWrap.appendChild(cancelBtn);

  header.appendChild(confirmWrap);
}

function hideClearHistoryInlineConfirm() {
  clearHistoryConfirmVisible = false;
  const confirmWrap = document.getElementById('clearHistoryConfirmWrap');
  confirmWrap?.remove();
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  if (clearHistoryBtn) {
    clearHistoryBtn.style.display = '';
  }
}

/**
 * Remove a single search history entry
 * @param {string} query - Search query to remove
 */
function removeSearchHistoryEntry(query) {
  if (!query) return;
  const index = searchHistory.indexOf(query);
  if (index === -1) return;
  searchHistory.splice(index, 1);
  chrome.storage.local.set({ searchHistory });
}

/**
 * Get search suggestions based on input
 * @param {string} input - Current input text
 * @returns {string[]} Matching suggestions
 */
function getSearchSuggestions(input) {
  const trimmed = input?.trim().toLowerCase() || '';
  
  if (!trimmed) {
    // Return most recent searches
    return searchHistory.slice(0, SEARCH_SUGGESTIONS_DISPLAY);
  }
  
  // Filter history by prefix match
  const matches = searchHistory.filter((item) => 
    item.toLowerCase().startsWith(trimmed) || item.toLowerCase().includes(trimmed)
  );
  
  return matches.slice(0, SEARCH_SUGGESTIONS_DISPLAY);
}

// ============================================
// Search Suggestions UI
// ============================================

/**
 * Update search suggestions dropdown
 * @param {string} inputValue - Current input value
 */
function updateSearchSuggestions(inputValue) {
  const searchSuggestions = document.getElementById('searchSuggestions');
  const suggestionsList = document.getElementById('suggestionsList');
  
  if (!searchSuggestions || !suggestionsList) return;
  
  const suggestions = getSearchSuggestions(inputValue);
  const deleteLabel = getMessage('deleteHistoryItemLabel', 'Remove from history');
  
  if (suggestions.length === 0) {
    hideSearchSuggestions();
    return;
  }
  
  suggestionsList.innerHTML = '';
  
  for (const suggestion of suggestions) {
    const item = document.createElement('div');
    item.className = 'suggestion-item';
    item.tabIndex = 0;
    
    // Highlight matching part
    const inputLower = (inputValue || '').toLowerCase();
    const suggestionLower = suggestion.toLowerCase();
    const matchIndex = suggestionLower.indexOf(inputLower);
    
    const text = document.createElement('div');
    text.className = 'suggestion-text';
    if (inputLower && matchIndex !== -1) {
      const before = suggestion.substring(0, matchIndex);
      const match = suggestion.substring(matchIndex, matchIndex + inputLower.length);
      const after = suggestion.substring(matchIndex + inputLower.length);
      text.innerHTML = `${escapeHtml(before)}<strong>${escapeHtml(match)}</strong>${escapeHtml(after)}`;
    } else {
      text.textContent = suggestion;
    }

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'suggestion-delete-btn';
    deleteBtn.type = 'button';
    deleteBtn.title = deleteLabel;
    deleteBtn.setAttribute('aria-label', deleteLabel);
    deleteBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
        <path d="M8 1a7 7 0 110 14A7 7 0 018 1zm0 1.2a5.8 5.8 0 100 11.6A5.8 5.8 0 008 2.2z"/>
        <path d="M4.5 7.25a.75.75 0 000 1.5h7a.75.75 0 000-1.5h-7z"/>
      </svg>
    `;

    deleteBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      suggestionsPointerDown = true;
      removeSearchHistoryEntry(suggestion);
      updateSearchSuggestions(inputValue);
      setTimeout(() => { suggestionsPointerDown = false; }, 300);
    });

    item.addEventListener('click', () => {
      selectSuggestion(suggestion);
    });
    
    item.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        selectSuggestion(suggestion);
      }
    });

    item.appendChild(text);
    item.appendChild(deleteBtn);
    suggestionsList.appendChild(item);
  }
  
  searchSuggestions.style.display = 'block';
}

/**
 * Hide search suggestions dropdown
 */
function hideSearchSuggestions() {
  const searchSuggestions = document.getElementById('searchSuggestions');
  if (searchSuggestions) {
    searchSuggestions.style.display = 'none';
  }
  hideClearHistoryInlineConfirm();
  suggestionsPointerDown = false;
}

/**
 * Select a suggestion and perform search
 * @param {string} suggestion - Selected suggestion text
 */
function selectSuggestion(suggestion) {
  const searchInput = document.getElementById('searchInput');
  const clearSearch = document.getElementById('clearSearch');
  
  if (searchInput) {
    searchInput.value = suggestion;
    searchQuery = suggestion;
    if (clearSearch) {
      clearSearch.style.display = 'block';
    }
    hideSearchSuggestions();
    saveSearchHistory(suggestion);
    performSearch();
  }
}

/**
 * Navigate through suggestions with keyboard
 * @param {number} direction - 1 for down, -1 for up
 */
function focusNextSuggestion(direction) {
  const suggestionsList = document.getElementById('suggestionsList');
  if (!suggestionsList) return;
  
  const items = suggestionsList.querySelectorAll('.suggestion-item');
  if (items.length === 0) return;
  
  const currentFocus = document.activeElement;
  let currentIndex = -1;
  
  items.forEach((item, index) => {
    if (item === currentFocus) {
      currentIndex = index;
    }
  });
  
  let nextIndex = currentIndex + direction;
  if (nextIndex < 0) {
    nextIndex = items.length - 1;
  } else if (nextIndex >= items.length) {
    nextIndex = 0;
  }
  
  items[nextIndex].focus();
}

// ============================================
// Bookmark Panel (inside popup)
// ============================================

let bookmarkInitialized = false;

// ============================================
// Bookmark Panel (inside popup)
// ============================================

const BM_BOOKMARKS_KEY = 'bookmarks';
const BM_MAX_UNDO_LEVELS = 20;

let bmAllBookmarks = [];
let bmAllBookmarkGroups = [];
let bmFilteredBookmarks = [];
let bmUndoStack = [];
let bmDraggedBookmarkId = null;
let bmStatusClearTimer = null;

function initBookmarkPanel() {
  loadBmBookmarks();
  setupBmEventListeners();
}

function setupBmEventListeners() {
  const searchInput = document.getElementById('bmSearchInput');
  const searchClearBtn = document.getElementById('bmSearchClearBtn');
  const platformFilter = document.getElementById('bmPlatformFilter');
  const sortFilter = document.getElementById('bmSortFilter');
  const refreshBtn = document.getElementById('bmRefreshBtn');
  const undoBtn = document.getElementById('bmUndoBtn');
  const reminderHistoryBtn = document.getElementById('bmReminderHistoryBtn');

  if (searchInput) {
    searchInput.addEventListener('input', handleBmSearch);
  }
  if (searchClearBtn) {
    searchClearBtn.addEventListener('click', clearBmSearch);
  }
  if (platformFilter) {
    platformFilter.addEventListener('change', applyBmFilters);
  }
  if (sortFilter) {
    sortFilter.addEventListener('change', applyBmFilters);
  }
  if (refreshBtn) {
    refreshBtn.addEventListener('click', refreshBmBookmarks);
  }
  if (undoBtn) {
    undoBtn.addEventListener('click', undoBmLastAction);
  }
  if (reminderHistoryBtn) {
    reminderHistoryBtn.addEventListener('click', showBmReminderHistoryPanel);
  }

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
      if (currentTopTab === 'bookmarks') {
        e.preventDefault();
        undoBmLastAction();
      }
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes[BM_BOOKMARKS_KEY] && currentTopTab === 'bookmarks') {
      loadBmBookmarks();
    }
  });
}

function loadBmBookmarks() {
  const listContainer = document.getElementById('bmBookmarksList');
  if (!listContainer) return;

  listContainer.innerHTML = '<div class="loading-state">' + escapeHtml(getMessage('bookmarkLoading', 'Loading bookmarks...')) + '</div>';

  chrome.storage.local.get([BM_BOOKMARKS_KEY, 'bookmarkGroups'], (result) => {
    if (chrome.runtime.lastError) {
      listContainer.innerHTML = '<div class="error-state"><p>' + escapeHtml(getMessage('bookmarkLoadError', 'Failed to load bookmarks')) + '</p></div>';
      return;
    }

    bmAllBookmarks = result[BM_BOOKMARKS_KEY] || [];
    bmAllBookmarks.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    bmAllBookmarkGroups = result.bookmarkGroups || [];
    bmAllBookmarkGroups.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

    populateBmPlatformFilter();
    applyBmFilters();
  });
}

function refreshBmBookmarks() {
  loadBmBookmarks();
  showBmStatus(getMessage('bookmarkRefreshed', 'Bookmark list refreshed'), 'success');
}

function populateBmPlatformFilter() {
  const platformFilter = document.getElementById('bmPlatformFilter');
  if (!platformFilter) return;

  const platforms = [...new Set(bmAllBookmarks.map(b => b.platform).filter(Boolean))];
  const defaultOption = platformFilter.querySelector('option[value=""]');
  platformFilter.innerHTML = '';
  platformFilter.appendChild(defaultOption);

  platforms.forEach(platform => {
    const option = document.createElement('option');
    option.value = platform;
    option.textContent = platform;
    platformFilter.appendChild(option);
  });
}

function handleBmSearch() {
  const searchInput = document.getElementById('bmSearchInput');
  const searchClearBtn = document.getElementById('bmSearchClearBtn');
  const query = searchInput?.value.trim() || '';
  if (searchClearBtn) {
    searchClearBtn.classList.toggle('hidden', !query);
  }
  applyBmFilters();
}

function clearBmSearch() {
  const searchInput = document.getElementById('bmSearchInput');
  const searchClearBtn = document.getElementById('bmSearchClearBtn');
  if (searchInput) searchInput.value = '';
  if (searchClearBtn) searchClearBtn.classList.add('hidden');
  applyBmFilters();
}

function applyBmFilters() {
  const searchInput = document.getElementById('bmSearchInput');
  const platformFilter = document.getElementById('bmPlatformFilter');
  const sortFilter = document.getElementById('bmSortFilter');

  const searchQuery = (searchInput?.value || '').toLowerCase().trim();
  const platform = platformFilter?.value || '';
  const sort = sortFilter?.value || 'newest';

  bmFilteredBookmarks = [...bmAllBookmarks];

  if (searchQuery) {
    bmFilteredBookmarks = bmFilteredBookmarks.filter(bookmark =>
      (bookmark.content || '').toLowerCase().includes(searchQuery) ||
      (bookmark.selectedText || '').toLowerCase().includes(searchQuery)
    );
  }

  if (platform) {
    bmFilteredBookmarks = bmFilteredBookmarks.filter(bookmark => bookmark.platform === platform);
  }

  switch (sort) {
    case 'oldest':
      bmFilteredBookmarks.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      break;
    case 'content':
      bmFilteredBookmarks.sort((a, b) => (a.content || '').localeCompare(b.content || ''));
      break;
    case 'newest':
    default:
      bmFilteredBookmarks.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      break;
  }

  renderBmBookmarks();
}

function renderBmBookmarks() {
  const listContainer = document.getElementById('bmBookmarksList');
  const emptyState = document.getElementById('bmBookmarksEmpty');

  if (!listContainer || !emptyState) return;

  if (bmFilteredBookmarks.length === 0) {
    listContainer.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');

  const groupedBookmarks = bmGroupByContent(bmFilteredBookmarks);
  let html = '';

  for (const [content, bookmarks] of Object.entries(groupedBookmarks)) {
    const duplicateCount = bookmarks.length - 1;
    const title = escapeHtml(content.length > 100 ? content.substring(0, 100) + '...' : content);

    html += `
      <div class="bookmarks-group" data-group-content="${escapeHtml(content).replace(/"/g, '&quot;')}">
        <div class="bookmarks-group-title">
          <span class="bookmarks-group-title-text">${title}</span>
          <input class="bookmark-group-name-input" type="text" value="${escapeHtml(content).replace(/"/g, '&quot;')}" style="display:none">
          <button class="bookmark-group-rename-btn" title="${escapeHtml(getMessage('bookmarkRenameButton', 'Rename'))}">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
              <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
            </svg>
          </button>
          ${duplicateCount > 0 ? `<span class="duplicate-count">(+${duplicateCount} more)</span>` : ''}
          <button class="bookmark-group-chat-btn" title="${escapeHtml(getMessage('bookmarkChatTitle', 'Chat with context'))}">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
              <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.8 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.297-.365a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.78 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.97 9.97 0 0 1-2.812-.472l-.382-.232z"/>
            </svg>
          </button>
        </div>
    `;

    bookmarks.forEach(bookmark => {
      html += bmRenderBookmarkItem(bookmark);
    });

    html += '</div>';
  }

  listContainer.innerHTML = html;

  listContainer.querySelectorAll('.bookmark-item').forEach(item => {
    item.addEventListener('click', (e) => {
      const deleteBtn = e.target.closest('.bookmark-delete-btn');
      if (deleteBtn) {
        e.stopPropagation();
        bmToggleDeleteMode(deleteBtn);
        return;
      }
      const reminderBtn = e.target.closest('.bookmark-reminder-btn');
      if (reminderBtn) {
        e.stopPropagation();
        bmOpenReminderModal(reminderBtn.getAttribute('data-bookmark-id'));
        return;
      }
      if (e.target.closest('.confirm-delete-btn') || e.target.closest('.cancel-delete-btn')) {
        return;
      }
      const bookmarkId = item.getAttribute('data-bookmark-id');
      const url = item.getAttribute('data-url');
      bmJumpToBookmark(bookmarkId, url);
    });
  });

  // Group rename button handlers (popup)
  listContainer.querySelectorAll('.bookmark-group-rename-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      bmStartRenameGroup(btn);
    });
  });

  // Group rename input handlers (popup)
  listContainer.querySelectorAll('.bookmark-group-name-input').forEach(input => {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.stopPropagation();
        bmCommitRenameGroup(input);
      } else if (e.key === 'Escape') {
        e.stopPropagation();
        bmCancelRenameGroup(input);
      }
    });
    input.addEventListener('blur', () => {
      bmCommitRenameGroup(input);
    });
  });

  listContainer.querySelectorAll('.bookmark-group-chat-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const group = btn.closest('.bookmarks-group');
      if (!group) return;
      const bookmarkItems = group.querySelectorAll('.bookmark-item');
      const bookmarkIds = [];
      bookmarkItems.forEach(item => {
        const id = item.getAttribute('data-bookmark-id');
        if (id) bookmarkIds.push(id);
      });
      if (bookmarkIds.length > 0) {
        bmOpenPlatformPopup(btn, bookmarkIds);
      }
    });
  });

  bmSetupDragAndDrop();
}

function bmGroupByContent(bookmarks) {
  const groups = {};
  bookmarks.forEach(bookmark => {
    const content = bookmark.content || getMessage('bookmarkUntitled', 'Untitled');
    if (!groups[content]) groups[content] = [];
    groups[content].push(bookmark);
  });
  return groups;
}

function bmRenderBookmarkItem(bookmark) {
  const date = bookmark.createdAt ? new Date(bookmark.createdAt).toLocaleDateString() : '';
  const platform = escapeHtml(bookmark.platform || getMessage('unknownPlatform', 'Unknown'));
  const url = escapeHtml(bookmark.url || '');
  const deleteTitle = escapeHtml(getMessage('bookmarkDeleteButton', 'Delete'));
  const reminderTitle = escapeHtml(getMessage('bookmarkReminderButton', 'Set reminder'));
  const hasReminder = bookmark.reminder && bookmark.reminder.enabled;
  const reminderActiveClass = hasReminder ? ' active' : '';
  const reminderIndicator = bmRenderReminderIndicator(bookmark);

  return `
    <div class="bookmark-item" draggable="true" data-bookmark-id="${bookmark.id}" data-url="${url}">
      <div class="bookmark-header">
        <span class="bookmark-content">${escapeHtml(bookmark.selectedText || '')}</span>
        <button class="bookmark-reminder-btn${reminderActiveClass}" data-bookmark-id="${bookmark.id}" title="${reminderTitle}">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.995-14.901a1 1 0 1 0-1.99 0A5.002 5.002 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7 0-2.42-1.72-4.44-4.005-4.901z"/>
          </svg>
        </button>
        <button class="bookmark-delete-btn" data-bookmark-id="${bookmark.id}" title="${deleteTitle}">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0V6a.5.5 0 001 0V6z"/>
            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4 4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
          </svg>
        </button>
      </div>
      <div class="bookmark-meta">
        <span class="bookmark-platform">${platform}</span>
        <span class="bookmark-date">${date}</span>
        ${reminderIndicator}
      </div>
    </div>
  `;
}

function bmRenderReminderIndicator(bookmark) {
  const r = bookmark.reminder;
  if (!r || !r.enabled) return '';
  const label = bmGetReminderCronLabel(r);
  return `<span class="bookmark-reminder-next" title="${escapeHtml(label)}">⏰ ${escapeHtml(label)}</span>`;
}

function bmGetReminderCronLabel(r) {
  if (!r || !r.enabled) return '';
  const timeStr = r.timeOfDay || '09:00';
  const [h, m] = timeStr.split(':');
  const timeDisplay = `${h.padStart(2, '0')}:${m.padStart(2, '0')}`;

  switch (r.recurrence) {
    case 'daily':
      return `Daily at ${timeDisplay}`;
    case 'weekdays':
      return `Weekdays at ${timeDisplay}`;
    case 'weekly': {
      if (!r.weekdays || r.weekdays.length === 0) return `Weekly at ${timeDisplay}`;
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const days = r.weekdays.sort().map(d => dayNames[d]).join(', ');
      return `${days} at ${timeDisplay}`;
    }
    case 'monthly':
    case 'monthlyNth': {
      if (r.monthlyNthWeekday != null && r.monthlyWeekday != null) {
        const nthLabels = ['', '1st', '2nd', '3rd', '4th', 'Last'];
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const nth = r.monthlyNthWeekday === -1 ? 'Last' : nthLabels[r.monthlyNthWeekday];
        return `${nth} ${dayNames[r.monthlyWeekday]} of month at ${timeDisplay}`;
      }
      const day = r.monthlyDay || 1;
      return `Day ${day} of month at ${timeDisplay}`;
    }
    case 'none':
    default: {
      if (r.time) {
        const d = new Date(r.time * 1000);
        return `Once: ${d.toLocaleDateString()} ${timeDisplay}`;
      }
      return '';
    }
  }
}

function bmJumpToBookmark(bookmarkId, url) {
  if (!url) {
    showBmStatus(getMessage('bookmarkJumpError', 'Unable to jump to bookmark location'), 'error');
    return;
  }

  const sendScrollMessage = (tabId) => {
    const maxRetries = 10;
    const checkDelay = 500;
    let retryCount = 0;

    const checkAndScroll = () => {
      chrome.tabs.sendMessage(tabId, { action: 'checkBookmarkReady' }, (readyResponse) => {
        if (chrome.runtime.lastError) {
          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(checkAndScroll, checkDelay);
          }
          return;
        }
        if (readyResponse && readyResponse.ready) {
          chrome.tabs.sendMessage(tabId, { action: 'scrollToBookmark', bookmarkId });
        } else {
          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(checkAndScroll, checkDelay);
          }
        }
      });
    };
    setTimeout(checkAndScroll, 1500);
  };

  const createTab = (windowId) => {
    const createProps = { url, active: true };
    if (windowId) createProps.windowId = windowId;

    chrome.tabs.create(createProps, (tab) => {
      if (chrome.runtime.lastError) {
        showBmStatus(getMessage('bookmarkJumpError', 'Failed to open URL'), 'error');
        return;
      }
      if (tab && tab.id) sendScrollMessage(tab.id);
    });
  };

  chrome.windows.getLastFocused({ windowTypes: ['normal'] }, (win) => {
    if (!chrome.runtime.lastError && win && win.id) {
      createTab(win.id);
    } else {
      createTab();
    }
  });

  showBmStatus(getMessage('bookmarkJumpSuccess', 'Navigated to bookmark location'), 'success');
}

function bmToggleDeleteMode(deleteBtn) {
  const bookmarkItem = deleteBtn.closest('.bookmark-item');
  const bookmarkId = deleteBtn.getAttribute('data-bookmark-id');

  if (deleteBtn.classList.contains('in-delete-mode')) {
    deleteBtn.classList.remove('in-delete-mode');
    deleteBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
      <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0V6a.5.5 0 001 0V6z"/>
      <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4 4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
    </svg>`;
    const deleteActions = bookmarkItem.querySelector('.delete-actions');
    if (deleteActions) deleteActions.remove();
  } else {
    document.querySelectorAll('.bookmark-delete-btn.in-delete-mode').forEach(btn => {
      btn.classList.remove('in-delete-mode');
      btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0V6a.5.5 0 001 0V6z"/>
        <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4 4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
      </svg>`;
      const existingActions = btn.closest('.bookmark-item')?.querySelector('.delete-actions');
      if (existingActions) existingActions.remove();
    });

    deleteBtn.classList.add('in-delete-mode');
    deleteBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
      <path d="M8 15A7 7 0 118 1a7 7 0 010 14zm0 1A8 8 0 118 0a8 8 0 010 16z"/>
      <path d="M10 10.5a.5.5 0 01-1 0V9a.5.5 0 011 0v1.5z"/>
    </svg>`;

    const deleteActions = document.createElement('div');
    deleteActions.className = 'delete-actions';
    deleteActions.innerHTML = `
      <button class="confirm-delete-btn" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('bookmarkDeleteButton', 'Delete'))}</button>
      <button class="cancel-delete-btn" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('bookmarkCancelButton', 'Cancel'))}</button>
    `;
    bookmarkItem.appendChild(deleteActions);

    bookmarkItem.querySelector('.confirm-delete-btn')?.addEventListener('click', (e) => {
      e.stopPropagation();
      bmDeleteBookmark(bookmarkId);
    });
    bookmarkItem.querySelector('.cancel-delete-btn')?.addEventListener('click', (e) => {
      e.stopPropagation();
      bmToggleDeleteMode(deleteBtn);
    });
  }
}

function bmDeleteBookmark(bookmarkId) {
  bmPushUndoState();
  chrome.runtime.sendMessage(
    { action: 'deleteBookmark', bookmarkId },
    (response) => {
      if (response?.success) {
        bmAllBookmarks = bmAllBookmarks.filter(b => b.id !== bookmarkId);
        applyBmFilters();
      } else {
        bmUndoStack.pop();
        bmUpdateUndoButton();
        showBmStatus(getMessage('bookmarkDeleteError', 'Failed to delete bookmark'), 'error');
      }
    }
  );
}

function bmPushUndoState() {
  bmUndoStack.push(JSON.parse(JSON.stringify(bmAllBookmarks)));
  if (bmUndoStack.length > BM_MAX_UNDO_LEVELS) bmUndoStack.shift();
  bmUpdateUndoButton();
}

function bmUpdateUndoButton() {
  const undoBtn = document.getElementById('bmUndoBtn');
  if (!undoBtn) return;
  undoBtn.disabled = bmUndoStack.length === 0;
  const label = getMessage('bookmarkUndo', 'Undo');
  undoBtn.title = bmUndoStack.length > 0 ? `${label} (${bmUndoStack.length})` : label;
  undoBtn.setAttribute('aria-label', undoBtn.title);
}

function undoBmLastAction() {
  if (bmUndoStack.length === 0) return;
  bmAllBookmarks = bmUndoStack.pop();
  chrome.storage.local.set({ [BM_BOOKMARKS_KEY]: bmAllBookmarks }, () => {
    if (chrome.runtime.lastError) {
      showBmStatus(getMessage('bookmarkUndoError', 'Failed to undo'), 'error');
      return;
    }
    applyBmFilters();
    bmUpdateUndoButton();
    showBmStatus(getMessage('bookmarkUndoSuccess', 'Undo successful'), 'success');
  });
}

function bmSetupDragAndDrop() {
  const listContainer = document.getElementById('bmBookmarksList');
  if (!listContainer) return;

  listContainer.querySelectorAll('.bookmark-item').forEach(item => {
    item.addEventListener('dragstart', (e) => {
      bmDraggedBookmarkId = item.getAttribute('data-bookmark-id');
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', bmDraggedBookmarkId);
    });
    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      bmDraggedBookmarkId = null;
    });
  });

  listContainer.querySelectorAll('.bookmarks-group').forEach(groupEl => {
    let enterCount = 0;
    const groupContent = groupEl.getAttribute('data-group-content');

    groupEl.addEventListener('dragenter', (e) => {
      if (!bmDraggedBookmarkId) return;
      const dragged = bmAllBookmarks.find(b => b.id === bmDraggedBookmarkId);
      if (!dragged || dragged.content === groupContent) return;
      e.preventDefault();
      enterCount++;
      groupEl.classList.add('drag-over');
    });

    groupEl.addEventListener('dragleave', () => {
      enterCount--;
      if (enterCount <= 0) {
        enterCount = 0;
        groupEl.classList.remove('drag-over');
      }
    });

    groupEl.addEventListener('dragover', (e) => {
      if (!bmDraggedBookmarkId) return;
      const dragged = bmAllBookmarks.find(b => b.id === bmDraggedBookmarkId);
      if (!dragged || dragged.content === groupContent) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
    });

    groupEl.addEventListener('drop', (e) => {
      e.preventDefault();
      enterCount = 0;
      groupEl.classList.remove('drag-over');
      if (!bmDraggedBookmarkId) return;

      const dragged = bmAllBookmarks.find(b => b.id === bmDraggedBookmarkId);
      if (!dragged || dragged.content === groupContent) return;

      bmPushUndoState();
      dragged.content = groupContent;

      chrome.storage.local.set({ [BM_BOOKMARKS_KEY]: bmAllBookmarks }, () => {
        if (chrome.runtime.lastError) {
          bmUndoStack.pop();
          bmUpdateUndoButton();
          showBmStatus(getMessage('bookmarkMoveError', 'Failed to move bookmark'), 'error');
          return;
        }
        applyBmFilters();
        showBmStatus(getMessage('bookmarkMoved', 'Bookmark moved to group'), 'success');
      });
    });
  });
}

function showBmStatus(message, type) {
  const statusEl = document.getElementById('bmEditorStatus');
  if (!statusEl) return;

  statusEl.textContent = message;
  statusEl.className = 'editor-status visible ' + type;

  if (bmStatusClearTimer) clearTimeout(bmStatusClearTimer);
  bmStatusClearTimer = setTimeout(() => {
    statusEl.classList.remove('visible');
    bmStatusClearTimer = null;
  }, 3000);
}

// ========== Group Rename Functions (popup) ==========

function bmStartRenameGroup(renameBtn) {
  const groupEl = renameBtn.closest('.bookmarks-group');
  if (!groupEl) return;

  const nameText = groupEl.querySelector('.bookmarks-group-title-text');
  const nameInput = groupEl.querySelector('.bookmark-group-name-input');
  if (!nameText || !nameInput) return;

  nameText.style.display = 'none';
  nameInput.style.display = 'block';
  nameInput.focus();
  nameInput.select();
}

function bmCommitRenameGroup(input) {
  const groupEl = input.closest('.bookmarks-group');
  if (!groupEl) return;

  const nameText = groupEl.querySelector('.bookmarks-group-title-text');
  const oldName = groupEl.getAttribute('data-group-content');
  const newName = input.value.trim();

  if (!newName || newName === oldName) {
    bmCancelRenameGroup(input);
    return;
  }

  chrome.runtime.sendMessage(
    { action: 'renameBookmarkGroup', oldName, newName },
    (response) => {
      if (response?.success) {
        nameText.textContent = newName;
        groupEl.setAttribute('data-group-content', newName);
        nameText.style.display = '';
        input.style.display = 'none';
        showBmStatus(getMessage('bookmarkRenameSuccess', 'Bookmark renamed'), 'success');
        applyBmFilters();
      } else {
        showBmStatus(getMessage('bookmarkRenameError', 'Failed to rename bookmark'), 'error');
        bmCancelRenameGroup(input);
      }
    }
  );
}

function bmCancelRenameGroup(input) {
  const groupEl = input.closest('.bookmarks-group');
  if (!groupEl) return;

  const nameText = groupEl.querySelector('.bookmarks-group-title-text');
  if (nameText) {
    nameText.style.display = '';
  }
  input.style.display = 'none';
  input.value = groupEl.getAttribute('data-group-content') || '';
}

// ========== Bookmark Reminder Modal (reused from bookmark_editor.js) ==========

let bmReminderModal = null;
let bmReminderBookmarkId = null;
let bmSelectedReminderType = 'once';
let bmSelectedWeekdays = [];
let bmSelectedMonthlyMode = 'day';

function bmOpenReminderModal(bookmarkId) {
  bmReminderBookmarkId = bookmarkId;
  const bookmark = bmAllBookmarks.find(b => b.id === bookmarkId);
  if (!bookmark) return;

  const label = document.getElementById('reminderBookmarkLabel');
  if (label) label.textContent = bookmark.content || bookmark.selectedText || 'Untitled';

  const r = bookmark.reminder || {};
  if (r.enabled && r.time) {
    const dt = new Date(r.time * 1000);
    const dateStr = dt.toISOString().split('T')[0];
    const timeStr = r.timeOfDay || `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;

    const recurrence = r.recurrence || 'none';
    if (recurrence === 'none') bmSelectedReminderType = 'once';
    else if (recurrence === 'daily') bmSelectedReminderType = 'daily';
    else if (recurrence === 'weekdays' || recurrence === 'weekly') bmSelectedReminderType = 'weekly';
    else if (recurrence === 'monthly' || recurrence === 'monthlyNth') bmSelectedReminderType = 'monthly';
    else bmSelectedReminderType = 'once';

    document.getElementById('reminderDate').value = dateStr;
    document.getElementById('reminderTime').value = timeStr;
    document.getElementById('reminderDailyTime').value = timeStr;
    document.getElementById('reminderWeeklyTime').value = timeStr;
    document.getElementById('reminderMonthlyTime').value = timeStr;

    if (recurrence === 'weekdays') {
      bmSelectedWeekdays = [1, 2, 3, 4, 5];
    } else {
      bmSelectedWeekdays = r.weekdays ? [...r.weekdays] : [];
    }

    if (recurrence === 'monthlyNth' || (recurrence === 'monthly' && r.monthlyNthWeekday != null)) {
      bmSelectedMonthlyMode = 'nth';
      document.getElementById('reminderMonthlyNth').value = r.monthlyNthWeekday ?? 1;
      document.getElementById('reminderMonthlyWeekday').value = r.monthlyWeekday ?? 1;
    } else {
      bmSelectedMonthlyMode = 'day';
      document.getElementById('reminderMonthlyDay').value = r.monthlyDay || 1;
    }
  } else {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes() + 5).padStart(2, '0')}`;

    bmSelectedReminderType = 'once';
    bmSelectedWeekdays = [];
    bmSelectedMonthlyMode = 'day';

    document.getElementById('reminderDate').value = dateStr;
    document.getElementById('reminderTime').value = timeStr;
    document.getElementById('reminderDailyTime').value = '09:00';
    document.getElementById('reminderWeeklyTime').value = '09:00';
    document.getElementById('reminderMonthlyTime').value = '09:00';
    document.getElementById('reminderMonthlyDay').value = '1';
    document.getElementById('reminderMonthlyNth').value = '1';
    document.getElementById('reminderMonthlyWeekday').value = '1';
  }

  document.querySelectorAll('.reminder-type-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-type') === bmSelectedReminderType);
  });
  document.querySelectorAll('.weekday-btn').forEach(btn => {
    const day = parseInt(btn.getAttribute('data-day'));
    btn.classList.toggle('active', bmSelectedWeekdays.includes(day));
  });
  document.querySelectorAll('.monthly-mode-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-mode') === bmSelectedMonthlyMode);
  });

  bmUpdateReminderOptionsVisibility();
  bmUpdateReminderSummary();

  const hasReminder = r.enabled && r.time;
  document.getElementById('reminderDeleteBtn')?.classList.toggle('hidden', !hasReminder);

  // Initialize modal if not already done
  if (!bmReminderModal) {
    bmReminderModal = document.getElementById('reminderModal');
    if (bmReminderModal) {
      document.getElementById('reminderModalCloseBtn')?.addEventListener('click', bmCloseReminderModal);
      document.getElementById('reminderCancelBtn')?.addEventListener('click', bmCloseReminderModal);
      document.getElementById('reminderSaveBtn')?.addEventListener('click', bmSaveReminderFromModal);
      document.getElementById('reminderDeleteBtn')?.addEventListener('click', bmDeleteReminderFromModal);

      bmReminderModal.addEventListener('click', (e) => {
        if (e.target === bmReminderModal) bmCloseReminderModal();
      });

      document.querySelectorAll('.reminder-type-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.querySelectorAll('.reminder-type-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          bmSelectedReminderType = btn.getAttribute('data-type');
          bmUpdateReminderOptionsVisibility();
          bmUpdateReminderSummary();
        });
      });

      document.querySelectorAll('.weekday-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const day = parseInt(btn.getAttribute('data-day'));
          btn.classList.toggle('active');
          if (bmSelectedWeekdays.includes(day)) {
            bmSelectedWeekdays = bmSelectedWeekdays.filter(d => d !== day);
          } else {
            bmSelectedWeekdays.push(day);
          }
          bmUpdateReminderSummary();
        });
      });

      document.querySelectorAll('.monthly-mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.querySelectorAll('.monthly-mode-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          bmSelectedMonthlyMode = btn.getAttribute('data-mode');
          document.getElementById('reminderMonthlyDayField')?.classList.toggle('hidden', bmSelectedMonthlyMode !== 'day');
          document.getElementById('reminderMonthlyNthField')?.classList.toggle('hidden', bmSelectedMonthlyMode !== 'nth');
          bmUpdateReminderSummary();
        });
      });

      const monthlyDaySelect = document.getElementById('reminderMonthlyDay');
      if (monthlyDaySelect && monthlyDaySelect.options.length === 0) {
        for (let i = 1; i <= 31; i++) {
          const opt = document.createElement('option');
          opt.value = i;
          opt.textContent = i;
          monthlyDaySelect.appendChild(opt);
        }
      }

      ['reminderDate', 'reminderTime', 'reminderDailyTime', 'reminderWeeklyTime',
        'reminderMonthlyTime', 'reminderMonthlyDay', 'reminderMonthlyNth', 'reminderMonthlyWeekday'
      ].forEach(id => {
        document.getElementById(id)?.addEventListener('change', bmUpdateReminderSummary);
      });
    }
  }

  bmReminderModal?.showModal();
}

function bmCloseReminderModal() {
  bmReminderModal?.close();
  bmReminderBookmarkId = null;
}

function bmUpdateReminderOptionsVisibility() {
  document.getElementById('reminderOnceOptions')?.classList.toggle('hidden', bmSelectedReminderType !== 'once');
  document.getElementById('reminderDailyOptions')?.classList.toggle('hidden', bmSelectedReminderType !== 'daily');
  document.getElementById('reminderWeeklyOptions')?.classList.toggle('hidden', bmSelectedReminderType !== 'weekly');
  document.getElementById('reminderMonthlyOptions')?.classList.toggle('hidden', bmSelectedReminderType !== 'monthly');
  document.getElementById('reminderMonthlyDayField')?.classList.toggle('hidden', bmSelectedMonthlyMode !== 'day');
  document.getElementById('reminderMonthlyNthField')?.classList.toggle('hidden', bmSelectedMonthlyMode !== 'nth');
}

function bmUpdateReminderSummary() {
  const summary = document.getElementById('reminderSummary');
  if (!summary) return;
  summary.textContent = bmBuildReminderLabel();
}

function bmBuildReminderLabel() {
  const now = new Date();
  let timeOfDay = '09:00';

  switch (bmSelectedReminderType) {
    case 'once': {
      timeOfDay = document.getElementById('reminderTime')?.value || '09:00';
      const dateStr = document.getElementById('reminderDate')?.value || now.toISOString().split('T')[0];
      const [h, m] = timeOfDay.split(':');
      const d = new Date(dateStr + 'T' + timeOfDay);
      const dateDisplay = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
      return `Remind once on ${dateDisplay} at ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    }
    case 'daily': {
      timeOfDay = document.getElementById('reminderDailyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':');
      return `Remind daily at ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    }
    case 'weekly': {
      timeOfDay = document.getElementById('reminderWeeklyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':');
      if (bmSelectedWeekdays.length === 0) return 'Select at least one day';
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const days = bmSelectedWeekdays.sort().map(d => dayNames[d]).join(', ');
      return `Remind ${days} at ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    }
    case 'monthly': {
      timeOfDay = document.getElementById('reminderMonthlyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':');
      const timeDisplay = `${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
      if (bmSelectedMonthlyMode === 'day') {
        const day = document.getElementById('reminderMonthlyDay')?.value || '1';
        return `Remind on day ${day} of each month at ${timeDisplay}`;
      }
      const nthLabels = ['1st', '2nd', '3rd', '4th', 'Last'];
      const nthVal = parseInt(document.getElementById('reminderMonthlyNth')?.value || '1');
      const nthLabel = nthVal === -1 ? 'Last' : nthLabels[nthVal - 1];
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const dayIdx = parseInt(document.getElementById('reminderMonthlyWeekday')?.value || '1');
      return `Remind ${nthLabel} ${dayNames[dayIdx]} of each month at ${timeDisplay}`;
    }
  }
  return '';
}

function bmBuildReminderData() {
  const now = new Date();
  let timeOfDay = '09:00';
  let time = null;

  switch (bmSelectedReminderType) {
    case 'once': {
      timeOfDay = document.getElementById('reminderTime')?.value || '09:00';
      const dateStr = document.getElementById('reminderDate')?.value;
      if (!dateStr) return null;
      const dt = new Date(dateStr + 'T' + timeOfDay);
      time = Math.floor(dt.getTime() / 1000);
      return { enabled: true, time, timeOfDay, recurrence: 'none' };
    }
    case 'daily': {
      timeOfDay = document.getElementById('reminderDailyTime')?.value || '09:00';
      const dt = new Date();
      const [h, m] = timeOfDay.split(':').map(Number);
      dt.setHours(h, m, 0, 0);
      if (dt.getTime() <= now.getTime()) dt.setDate(dt.getDate() + 1);
      time = Math.floor(dt.getTime() / 1000);
      return { enabled: true, time, timeOfDay, recurrence: 'daily' };
    }
    case 'weekdays':
    case 'weekly': {
      timeOfDay = document.getElementById('reminderWeeklyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':').map(Number);
      if (bmSelectedWeekdays.length === 0) return null;
      const dt = new Date();
      dt.setHours(h, m, 0, 0);
      for (let i = 0; i < 7; i++) {
        const dow = (now.getDay() + i) % 7;
        if (bmSelectedWeekdays.includes(dow)) {
          dt.setDate(now.getDate() + i);
          if (i === 0 && dt.getTime() <= now.getTime()) continue;
          break;
        }
      }
      time = Math.floor(dt.getTime() / 1000);
      const recurrence = bmSelectedReminderType === 'weekdays' ? 'weekdays' : 'weekly';
      return { enabled: true, time, timeOfDay, recurrence, weekdays: [...bmSelectedWeekdays] };
    }
    case 'monthly': {
      timeOfDay = document.getElementById('reminderMonthlyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':').map(Number);
      if (bmSelectedMonthlyMode === 'day') {
        const day = parseInt(document.getElementById('reminderMonthlyDay')?.value || '1');
        const dt = new Date(now.getFullYear(), now.getMonth(), day);
        dt.setHours(h, m, 0, 0);
        if (dt.getTime() <= now.getTime()) dt.setMonth(dt.getMonth() + 1);
        time = Math.floor(dt.getTime() / 1000);
        return { enabled: true, time, timeOfDay, recurrence: 'monthly', monthlyDay: day };
      }
      const nth = parseInt(document.getElementById('reminderMonthlyNth')?.value || '1');
      const weekday = parseInt(document.getElementById('reminderMonthlyWeekday')?.value || '1');
      const dt = bmGetNextNthWeekdayOfMonth(now.getFullYear(), now.getMonth() + 1, nth, weekday, h, m);
      if (dt.getTime() <= now.getTime()) {
        const nextMonth = bmGetNextNthWeekdayOfMonth(now.getFullYear(), now.getMonth() + 2, nth, weekday, h, m);
        time = Math.floor(nextMonth.getTime() / 1000);
      } else {
        time = Math.floor(dt.getTime() / 1000);
      }
      return { enabled: true, time, timeOfDay, recurrence: 'monthlyNth', monthlyNthWeekday: nth, monthlyWeekday: weekday };
    }
  }
  return null;
}

function bmGetNextNthWeekdayOfMonth(year, month, nth, weekday, hour, minute) {
  const lastDayOfMonth = new Date(year, month, 0).getDate();
  if (nth === -1) {
    for (let d = lastDayOfMonth; d >= 1; d--) {
      const dt = new Date(year, month - 1, d);
      if (dt.getDay() === weekday) {
        dt.setHours(hour, minute, 0, 0);
        return dt;
      }
    }
  }
  const firstDay = new Date(year, month - 1, 1);
  const dayOfWeek = firstDay.getDay();
  const daysUntilWeekday = (weekday - dayOfWeek + 7) % 7;
  let targetDate = 1 + daysUntilWeekday + (nth - 1) * 7;
  if (targetDate > lastDayOfMonth) targetDate -= 7;
  const result = new Date(year, month - 1, targetDate);
  result.setHours(hour, minute, 0, 0);
  return result;
}

function bmSaveReminderFromModal() {
  if (!bmReminderBookmarkId) return;
  const data = bmBuildReminderData();
  if (!data) {
    showBmStatus(getMessage('reminderValidationFailed', 'Please configure reminder settings'), 'error');
    return;
  }

  chrome.runtime.sendMessage(
    { action: 'saveReminder', bookmarkId: bmReminderBookmarkId, reminder: data },
    (response) => {
      if (response?.success) {
        const bookmark = bmAllBookmarks.find(b => b.id === bmReminderBookmarkId);
        if (bookmark) bookmark.reminder = response.reminder;
        applyBmFilters();
        bmCloseReminderModal();
        showBmStatus(getMessage('reminderSaved', 'Reminder saved'), 'success');
      } else {
        showBmStatus(getMessage('reminderSaveFailed', 'Failed to save reminder'), 'error');
      }
    }
  );
}

function bmDeleteReminderFromModal() {
  if (!bmReminderBookmarkId) return;

  chrome.runtime.sendMessage(
    { action: 'deleteReminder', bookmarkId: bmReminderBookmarkId },
    (response) => {
      if (response?.success) {
        const bookmark = bmAllBookmarks.find(b => b.id === bmReminderBookmarkId);
        if (bookmark) bookmark.reminder = { enabled: false };
        applyBmFilters();
        bmCloseReminderModal();
        showBmStatus(getMessage('reminderDeleted', 'Reminder removed'), 'success');
      } else {
        showBmStatus(getMessage('reminderDeleteFailed', 'Failed to remove reminder'), 'error');
      }
    }
  );
}

// ========== Bookmark Chat Platform Popup ==========

let bmActiveChatPopup = null;

function bmOpenPlatformPopup(anchorEl, bookmarkIds) {
  if (bmActiveChatPopup) {
    bmActiveChatPopup.remove();
    bmActiveChatPopup = null;
  }

  if (!bookmarkIds || bookmarkIds.length === 0) {
    showBmStatus(getMessage('bookmarkChatNoUrl', 'Cannot start chat: no bookmarks selected'), 'error');
    return;
  }

  chrome.storage.sync.get(['customPlatforms'], (result) => {
    const customPlatforms = result.customPlatforms || [];
    const allEntries = [];

    for (const c of customPlatforms) {
      if (c.enabled !== false) {
        allEntries.push({ domain: c.name, name: c.name, url: c.urlPattern || 'https://' + c.name, color: c.color || '#666', isCustom: true });
      }
    }

    const CHAT_BUILTIN = [
      { domain: 'chatgpt.com', name: 'ChatGPT', url: 'https://chatgpt.com', color: '#10a37f' },
      { domain: 'claude.ai', name: 'Claude', url: 'https://claude.ai/new', color: '#6445a3' },
      { domain: 'gemini.google.com', name: 'Gemini', url: 'https://gemini.google.com/app', color: '#4285f4' },
      { domain: 'copilot.microsoft.com', name: 'Copilot', url: 'https://copilot.microsoft.com', color: '#0078d4' },
      { domain: 'grok.com', name: 'Grok', url: 'https://grok.com', color: '#000000' },
      { domain: 'www.perplexity.ai', name: 'Perplexity', url: 'https://www.perplexity.ai', color: '#5436da' },
      { domain: 'www.kimi.com', name: 'Kimi', url: 'https://www.kimi.com', color: '#1a73e8' },
      { domain: 'poe.com', name: 'Poe', url: 'https://poe.com', color: '#5f4b8b' },
      { domain: 'chat.deepseek.com', name: 'DeepSeek', url: 'https://chat.deepseek.com', color: '#4f6ef7' },
      { domain: 'chat.qwen.ai', name: 'Qwen', url: 'https://chat.qwen.ai', color: '#635bff' },
      { domain: 'huggingface.co/chat', name: 'HuggingChat', url: 'https://huggingface.co/chat', color: '#ffd21e' },
      { domain: 'manus.im', name: 'Manus', url: 'https://manus.im', color: '#1a1a2e' },
    ];
    for (const bp of CHAT_BUILTIN) {
      allEntries.push({ domain: bp.domain, name: bp.name, url: bp.url, color: bp.color, isCustom: false });
    }

    const popup = document.createElement('div');
    popup.className = 'cw-chat-popup';
    popup.style.position = 'fixed';
    popup.style.visibility = 'hidden';

    const rect = anchorEl.getBoundingClientRect();
    const list = document.createElement('div');
    list.className = 'cw-chat-popup-list';

    for (const e of allEntries) {
      const btn = document.createElement('button');
      btn.className = 'cw-chat-popup-item';
      btn.dataset.platform = e.domain;
      btn.dataset.url = e.url;

      const badge = document.createElement('span');
      badge.className = 'cw-chat-popup-badge';
      badge.style.backgroundColor = e.color;
      badge.textContent = e.name;
      btn.appendChild(badge);

      if (e.url) {
        btn.addEventListener('click', ((domain, url) => () => {
          popup.remove();
          bmActiveChatPopup = null;
          chrome.runtime.sendMessage({
            action: 'CONTEXT_SESSION_START',
            bookmarkIds,
            targetPlatform: domain,
            targetUrl: url,
          }, (response) => {
            if (!response || !response.success) {
              showBmStatus(response?.error || 'Failed to start', 'error');
            }
          });
        })(e.domain, e.url));
      } else {
        btn.disabled = true;
        btn.title = 'No URL configured';
      }
      list.appendChild(btn);
    }

    popup.appendChild(list);
    document.body.appendChild(popup);
    bmActiveChatPopup = popup;

    requestAnimationFrame(() => {
      const pw = popup.offsetWidth;
      const ph = popup.offsetHeight;
      let finalLeft = rect.left;
      if (finalLeft + pw > window.innerWidth - 4) finalLeft = window.innerWidth - pw - 4;
      if (finalLeft < 4) finalLeft = 4;
      let finalTop = rect.bottom + 4;
      if (finalTop + ph > window.innerHeight - 4) finalTop = rect.top - ph - 4;
      if (finalTop < 4) finalTop = 4;
      popup.style.left = finalLeft + 'px';
      popup.style.top = finalTop + 'px';
      popup.style.visibility = '';
    });

    function closePopup(e) {
      if (popup && !popup.contains(e.target) && e.target !== anchorEl && !anchorEl.contains(e.target)) {
        popup.remove();
        bmActiveChatPopup = null;
        document.removeEventListener('click', closePopup);
      }
    }
    setTimeout(() => document.addEventListener('click', closePopup), 0);
  });
}

// ========== Bookmark Reminder History (in popup) ==========

function showBmReminderHistoryPanel() {
  const existingPanel = document.querySelector('.bm-reminder-history-panel');
  if (existingPanel) {
    existingPanel.remove();
    return;
  }

  const panel = document.createElement('div');
  panel.className = 'bm-reminder-history-panel';
  panel.innerHTML = `
    <div class="reminder-history-header">
      <span class="reminder-history-title">${getMessage('reminderHistoryTitle', 'Reminder History')}</span>
      <div class="reminder-history-actions">
        <button class="reminder-history-mark-all" id="bmReminderMarkAllBtn">${getMessage('reminderHistoryMarkAllRead', 'Mark all read')}</button>
        <button class="reminder-history-close" id="bmReminderCloseBtn">&times;</button>
      </div>
    </div>
    <div class="reminder-history-list" id="bmReminderHistoryList">
      <div class="reminder-history-loading">${getMessage('reminderHistoryLoading', 'Loading...')}</div>
    </div>
  `;

  document.body.appendChild(panel);

  panel.querySelector('#bmReminderCloseBtn')?.addEventListener('click', () => panel.remove());

  panel.querySelector('#bmReminderMarkAllBtn')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'markAllRemindersRead' }, () => {
      bmLoadReminderBadge();
      bmLoadReminderHistoryList(panel);
    });
  });

  bmLoadReminderHistoryList(panel);

  document.addEventListener('click', function closePanel(e) {
    if (!panel.contains(e.target) && !e.target.closest('#bmReminderHistoryBtn')) {
      panel.remove();
      document.removeEventListener('click', closePanel);
    }
  });
}

function bmLoadReminderBadge() {
  chrome.runtime.sendMessage({ action: 'getUnreadReminderCount' }, (count) => {
    const badge = document.getElementById('bmReminderBadge');
    if (!badge) return;
    if (count > 0) {
      badge.textContent = count > 99 ? '99+' : count;
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  });
}

function bmLoadReminderHistoryList(panel) {
  const listContainer = panel.querySelector('#bmReminderHistoryList');
  if (!listContainer) return;

  chrome.runtime.sendMessage({ action: 'getReminderHistory' }, (history) => {
    if (!history || history.length === 0) {
      listContainer.innerHTML = `<div class="reminder-history-empty">${getMessage('reminderHistoryEmpty', 'No reminders yet')}</div>`;
      return;
    }

    const grouped = bmGroupReminderHistory(history);
    let html = '';

    if (grouped.today.length > 0) {
      html += `<div class="reminder-history-group">
        <div class="reminder-history-group-title">${getMessage('reminderHistoryToday', 'Today')}</div>
        ${bmRenderReminderHistoryItems(grouped.today)}
      </div>`;
    }
    if (grouped.yesterday.length > 0) {
      html += `<div class="reminder-history-group">
        <div class="reminder-history-group-title">${getMessage('reminderHistoryYesterday', 'Yesterday')}</div>
        ${bmRenderReminderHistoryItems(grouped.yesterday)}
      </div>`;
    }
    if (grouped.older.length > 0) {
      html += `<div class="reminder-history-group">
        <div class="reminder-history-group-title">${getMessage('reminderHistoryOlder', 'Older')}</div>
        ${bmRenderReminderHistoryItems(grouped.older)}
      </div>`;
    }

    listContainer.innerHTML = html;

    listContainer.querySelectorAll('.reminder-history-item').forEach(item => {
      item.addEventListener('click', () => {
        const reminderId = item.dataset.reminderId;
        const bookmarkId = item.dataset.bookmarkId;
        const url = item.dataset.url;

        chrome.runtime.sendMessage({ action: 'markReminderRead', reminderId }, () => {
          bmLoadReminderBadge();
          item.classList.remove('unread');
          item.querySelector('.reminder-dot').style.display = 'none';
        });

        if (url && bookmarkId) {
          bmJumpToBookmark(bookmarkId, url);
        } else if (url) {
          openTabInLastFocusedWindow({ url });
        }
      });
    });
  });
}

function bmGroupReminderHistory(history) {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;
  const grouped = { today: [], yesterday: [], older: [] };

  history.forEach(item => {
    if (item.triggeredAt >= todayStart) grouped.today.push(item);
    else if (item.triggeredAt >= yesterdayStart) grouped.yesterday.push(item);
    else grouped.older.push(item);
  });

  return grouped;
}

function bmRenderReminderHistoryItems(items) {
  return items.map(item => {
    const time = new Date(item.triggeredAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const content = item.content || getMessage('bookmarkUntitled', 'Untitled');
    const platform = item.platform || '';
    const dotStyle = item.read ? 'display: none;' : '';
    const unreadClass = item.read ? '' : 'unread';

    return `
      <div class="reminder-history-item ${unreadClass}" data-reminder-id="${item.id}" data-bookmark-id="${item.bookmarkId || ''}" data-url="${escapeHtml(item.url || '')}">
        <span class="reminder-dot" style="${dotStyle}"></span>
        <div class="reminder-history-item-content">
          <div class="reminder-history-item-text">${escapeHtml(content.substring(0, 50))}${content.length > 50 ? '...' : ''}</div>
          <div class="reminder-history-item-meta">
            <span class="reminder-history-item-time">${time}</span>
            ${platform ? `<span class="reminder-history-item-platform">${escapeHtml(platform)}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  detectWindowType();
  initTopTabs();
  renderFilterTabs();
  initDetailModal();
  initChatPlatformsButton();
  loadSearchHistory();
  loadConversations();
  setupEventListeners();
  loadI18n();
  initSyncIndicator();
  initPageCopySection();
  initReminderHistory();
  bmLoadReminderBadge();
});

// Detect if running in popup or standalone window
function detectWindowType() {
  chrome.windows.getCurrent((currentWindow) => {
    // If it's a popup type window (opened via chrome.windows.create)
    if (currentWindow.type === 'popup') {
      document.body.classList.add('resizable');
    }
  });
}

// Load conversations from storage
function loadConversations() {
  chrome.runtime.sendMessage({ action: 'getConversations' }, (response) => {
    if (response?.conversations) {
      allConversations = response.conversations;
      updateTopPlatforms();
      if (searchQuery) {
        // Refresh current search results against the latest data
        performSearch();
      } else {
        // Keep a fresh copy when no search is active
        visibleConversations = [...allConversations];
        displayConversations();
      }
    }

    // New user onboarding: auto-show platform buttons when history is empty
    if (allConversations.length === 0) {
      showChatPlatformsPopup();
    }
  });
}

function getPlatformUsageStats(limit) {
  const counts = new Map();
  for (const conversation of allConversations) {
    if (!conversation?.platform) {
      continue;
    }
    const platformName = String(conversation.platform);
    const currentCount = counts.get(platformName) || 0;
    counts.set(platformName, currentCount + 1);
  }

  const sorted = Array.from(counts.entries())
    .sort((a, b) => {
      if (b[1] !== a[1]) {
        return b[1] - a[1];
      }
      return a[0].localeCompare(b[0]);
    })
    .map(([platform, count]) => ({ platform, count }));

  if (typeof limit === 'number') {
    return sorted.slice(0, limit);
  }
  return sorted;
}

function updateTopPlatforms() {
  topPlatformStats = getPlatformUsageStats(TOP_PLATFORM_LIMIT);
  renderFilterTabs();
}

function renderFilterTabs() {
  const container = document.getElementById('filterTabs');
  if (!container) {
    return;
  }

  container.innerHTML = '';
  const fragment = document.createDocumentFragment();
  const allLabel = getMessage('allPlatforms', 'All');
  fragment.appendChild(createFilterButton('all', allLabel));

  for (const stat of topPlatformStats) {
    const button = createFilterButton(stat.platform, stat.platform);
    const tooltip = getMessage(
      'platformCountTooltip',
      ([count]) => `${count} conversations`,
      [stat.count.toString()]
    );
    if (tooltip) {
      button.title = tooltip;
    }
    fragment.appendChild(button);
  }

  if (currentFilter !== 'all' && currentFilter !== 'more' && currentFilter) {
    const alreadyShown = topPlatformStats.some((stat) => stat.platform === currentFilter);
    if (!alreadyShown) {
      fragment.appendChild(createFilterButton(currentFilter, currentFilter));
    }
  }

  const moreButton = createFilterButton('more', '+');
  moreButton.id = 'moreTab';
  const moreLabel = getMessage('morePlatformsLabel', 'More platforms');
  moreButton.setAttribute('aria-label', moreLabel);
  moreButton.title = moreLabel;
  fragment.appendChild(moreButton);

  container.appendChild(fragment);
}

function createFilterButton(filterValue, label) {
  const button = document.createElement('button');
  button.className = 'tab';
  button.dataset.filter = filterValue;
  button.textContent = label;
  if (filterValue === currentFilter) {
    button.classList.add('active');
  }
  return button;
}

function handleFilterChange(filterValue) {
  if (!filterValue || filterValue === currentFilter) {
    return;
  }

  currentFilter = filterValue;
  renderFilterTabs();
  displayConversations();
}

// Setup event listeners
function setupEventListeners() {
  // Search input with debounce
  const searchInput = document.getElementById('searchInput');
  const clearSearch = document.getElementById('clearSearch');
  const searchSuggestions = document.getElementById('searchSuggestions');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  
  // Debounced search function
  const debouncedSearch = debounce(() => {
    if (searchQuery) {
      performSearch();
    }
  }, SEARCH_DEBOUNCE_MS);

  // Debounced history save function
  const debouncedHistorySave = debounce(() => {
    if (searchQuery && searchQuery.length > 3 && filteredConversationsCache.length > 0) {
      saveSearchHistory(searchQuery);
    }
  }, HISTORY_SAVE_DEBOUNCE_MS);
  
  if (searchInput && clearSearch) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      clearSearch.style.display = searchQuery ? 'block' : 'none';
      
      // Show/update suggestions
      updateSearchSuggestions(e.target.value);
      
      if (searchQuery) {
        debouncedSearch();
        debouncedHistorySave();
      } else {
        visibleConversations = [...allConversations];
        displayConversations();
      }
    });
    
    // Show suggestions on focus
    searchInput.addEventListener('focus', () => {
      updateSearchSuggestions(searchInput.value);
    });
    
    // Hide suggestions on blur only if user did not click inside the dropdown
    searchInput.addEventListener('blur', () => {
      setTimeout(() => {
        if (!suggestionsPointerDown) {
          hideSearchSuggestions();
        }
        suggestionsPointerDown = false;
      }, 150);
    });
    
    // Handle Enter key to save search history
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && searchQuery) {
        saveSearchHistory(searchQuery);
        hideSearchSuggestions();
      } else if (e.key === 'Escape') {
        hideSearchSuggestions();
      } else if (e.key === 'ArrowDown' && searchSuggestions?.style.display !== 'none') {
        e.preventDefault();
        focusNextSuggestion(1);
      } else if (e.key === 'ArrowUp' && searchSuggestions?.style.display !== 'none') {
        e.preventDefault();
        focusNextSuggestion(-1);
      }
    });
    
    clearSearch.addEventListener('click', () => {
      searchInput.value = '';
      searchQuery = '';
      clearSearch.style.display = 'none';
      hideSearchSuggestions();
      visibleConversations = [...allConversations];
      displayConversations();
    });
  }
  
  // Clear history button
  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      suggestionsPointerDown = true;
      showClearHistoryInlineConfirm();
      setTimeout(() => { suggestionsPointerDown = false; }, 300);
    });
  }
  
  // Track pointer inside suggestions to prevent blur-close while interacting
  if (searchSuggestions) {
    const markPointerDown = () => { suggestionsPointerDown = true; };
    const releasePointer = () => { setTimeout(() => { suggestionsPointerDown = false; }, 250); };
    searchSuggestions.addEventListener('mousedown', markPointerDown);
    searchSuggestions.addEventListener('touchstart', markPointerDown);
    searchSuggestions.addEventListener('mouseup', releasePointer);
    searchSuggestions.addEventListener('touchend', releasePointer);
  }

  // Click outside to close suggestions
  document.addEventListener('click', (e) => {
    if (searchSuggestions && !searchSuggestions.contains(e.target) && e.target !== searchInput) {
      hideSearchSuggestions();
    }
  });
  
  // Filter tabs (event delegation for dynamic buttons)
  const filterTabs = document.getElementById('filterTabs');
  if (filterTabs) {
    filterTabs.addEventListener('click', (event) => {
      const tabButton = event.target.closest('.tab');
      if (!tabButton) {
        return;
      }
      const filter = tabButton.dataset.filter;
      if (!filter) {
        return;
      }
      if (filter === 'more') {
        showMorePlatforms();
        return;
      }
      handleFilterChange(filter);
    });
  }
  
  // Prompt Editor button
  const promptEditorBtn = document.getElementById('promptEditorBtn');
  if (promptEditorBtn) {
    promptEditorBtn.addEventListener('click', () => {
      openPromptEditor();
    });
  }

  // Bookmarks button - open bookmark editor popup
  const bookmarksBtn = document.getElementById('bookmarksBtn');
  if (bookmarksBtn) {
    bookmarksBtn.addEventListener('click', (e) => {
      if (e.target.closest('.reminder-badge')) {
        e.stopPropagation();
        return;
      }
      openBookmarkEditor();
    });
  }

  // Settings button
  const settingsBtn = document.getElementById('settingsBtn');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });
  }

  // Welcome / How to use button
  const welcomeBtn = document.getElementById('welcomeBtn');
  if (welcomeBtn) {
    welcomeBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
    });
  }

  // Infinite scroll loader
  const conversationList = document.getElementById('conversationList');
  if (conversationList) {
    conversationList.addEventListener('scroll', handleListScroll);
  }

  // Close detail modal with ESC
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && detailModal && !detailModal.classList.contains('hidden')) {
      hideDetailModal();
    }
  });
}

// Perform search
function performSearch() {
  if (!searchQuery) {
    visibleConversations = [...allConversations];
    displayConversations();
    return;
  }

  chrome.runtime.sendMessage({ 
    action: 'searchConversations', 
    query: searchQuery 
  }, (response) => {
    if (response?.conversations) {
      visibleConversations = response.conversations;
      displayConversations();
    }
  });
}

// Display conversations
function displayConversations(options = {}) {
  const { resetList = true } = options;
  const listContainer = document.getElementById('conversationList');
  const emptyState = document.getElementById('emptyState');

  if (!listContainer || !emptyState) {
    return;
  }

  if (resetList) {
    const sourceConversations = searchQuery ? visibleConversations : allConversations;
    let filtered = Array.isArray(sourceConversations) ? sourceConversations : [];
    if (currentFilter !== 'all') {
      filtered = filtered.filter((conversation) => conversation.platform === currentFilter);
    }

    filteredConversationsCache = filtered;
    renderedCount = 0;
    isLoadingMore = false;
    listContainer.innerHTML = '';
    listContainer.scrollTop = 0;
    currentDetailIndex = -1;  // Reset detail index when displaying new list

    if (!filteredConversationsCache.length) {
      listContainer.style.display = 'none';
      emptyState.style.display = 'flex';
      return;
    }

    listContainer.style.display = 'block';
    emptyState.style.display = 'none';
  }

  appendNextBatch();
}

function appendNextBatch() {
  const listContainer = document.getElementById('conversationList');
  if (!listContainer || !filteredConversationsCache.length) {
    return false;
  }

  const remaining = filteredConversationsCache.length - renderedCount;
  if (remaining <= 0) {
    return false;
  }

  const nextItems = filteredConversationsCache.slice(renderedCount, renderedCount + PAGE_SIZE);
  if (!nextItems.length) {
    return false;
  }

  for (const conversation of nextItems) {
    const item = createConversationItem(conversation);
    listContainer.appendChild(item);
  }

  renderedCount += nextItems.length;
  return true;
}

function handleListScroll(event) {
  if (isLoadingMore) {
    return;
  }

  const container = event.currentTarget;
  if (!container) {
    return;
  }

  const remainingItems = filteredConversationsCache.length - renderedCount;
  if (remainingItems <= 0) {
    return;
  }

  const distanceFromBottom = container.scrollHeight - (container.scrollTop + container.clientHeight);
  if (distanceFromBottom > SCROLL_TRIGGER_OFFSET) {
    return;
  }

  isLoadingMore = true;
  const appended = appendNextBatch();
  requestAnimationFrame(() => {
    isLoadingMore = false;
    if (appended && container.scrollHeight - (container.scrollTop + container.clientHeight) <= SCROLL_TRIGGER_OFFSET) {
      handleListScroll({ currentTarget: container });
    }
  });
}

// Create conversation item element
function createConversationItem(conversation) {
  const item = document.createElement('div');
  item.className = 'conversation-item';
  
  const platformColor = getPlatformColor(conversation.platform);
  const timeAgo = getTimeAgo(conversation.lastUpdated);
  const openLabel = getMessage('conversationOpenButton', 'Open');
  const deleteLabel = getMessage('conversationDeleteButton', 'Delete');
  const confirmLabel = getMessage('conversationDeleteConfirmButton', 'Confirm');
  const cancelLabel = getMessage('conversationDeleteCancelButton', 'Cancel');
  
  // Match type icon HTML (only shown during search)
  const matchIconHtml = getMatchTypeIconHtml(conversation.matchType);
  
  item.innerHTML = `
    <div class="conversation-header">
      <div class="conversation-header-left">
        <div class="platform-badge" style="background-color: ${platformColor}">
          ${conversation.platform}
        </div>
        ${matchIconHtml}
        <div class="conversation-title"></div>
        <div class="conversation-time">${timeAgo}</div>
      </div>
      <div class="conversation-header-right">
        <div class="delete-confirm-actions" style="display: none;">
          <div class="delete-loading-spinner" style="display: none;"></div>
          <button class="btn-small btn-delete-confirm" data-id="${escapeHtml(conversation.id)}" title="${escapeHtml(confirmLabel)}" aria-label="${escapeHtml(confirmLabel)}">
            ${escapeHtml(confirmLabel)}
          </button>
          <button class="btn-small btn-delete-cancel" data-id="${escapeHtml(conversation.id)}" title="${escapeHtml(cancelLabel)}" aria-label="${escapeHtml(cancelLabel)}">
            ${escapeHtml(cancelLabel)}
          </button>
        </div>
        <button class="btn-small btn-delete" data-id="${escapeHtml(conversation.id)}" title="${escapeHtml(deleteLabel)}" aria-label="${escapeHtml(deleteLabel)}">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z"/>
            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
          </svg>
        </button>
        <button class="btn-small btn-open" data-url="${escapeHtml(conversation.url)}">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 0a8 8 0 110 16A8 8 0 018 0zM5.5 7.5l3-3 3 3m-3-3v9"/>
          </svg>
          ${escapeHtml(openLabel)}
        </button>
      </div>
    </div>
    <div class="conversation-summary"></div>
  `;

  const titleElement = item.querySelector('.conversation-title');
  if (titleElement) {
    titleElement.innerHTML = formatHighlightedText(conversation.title);
  }

  const summaryElement = item.querySelector('.conversation-summary');
  if (summaryElement) {
    summaryElement.innerHTML = formatHighlightedText(conversation.summary || '');
  }
  
  // Add context snippets if available (from enhanced search)
  if (searchQuery && conversation.contextSnippets?.length > 0) {
    const snippetsContainer = document.createElement('div');
    snippetsContainer.className = 'context-snippets';
    
    for (const snippet of conversation.contextSnippets) {
      const snippetEl = document.createElement('div');
      snippetEl.className = 'context-snippet';
      snippetEl.innerHTML = formatHighlightedText(snippet.text || snippet);
      snippetsContainer.appendChild(snippetEl);
    }
    
    item.appendChild(snippetsContainer);
  }
  
  // Add event listeners
  item.querySelector('.btn-open').addEventListener('click', (e) => {
    e.stopPropagation();
    const url = e.currentTarget.dataset.url;

    // If we're in search mode, open via background so it can attach search navigation arrows in the new tab.
    if (searchQuery && Array.isArray(filteredConversationsCache) && filteredConversationsCache.length > 0) {
      const currentIndex = filteredConversationsCache.findIndex((c) => c?.id === conversation?.id);
      const navContext = {
        searchQuery,
        resultsList: filteredConversationsCache.map((c) => ({
          id: c.id,
          platform: c.platform,
          url: c.url,
          title: c.title
        })),
        currentIndex: Math.max(0, currentIndex)
      };

      chrome.runtime.sendMessage({
        action: 'openTabWithNavContext',
        url,
        navContext
      });
      return;
    }

    openTabInLastFocusedWindow({ url });
  });
  
  // Delete button - shows confirm/cancel buttons
  item.querySelector('.btn-delete').addEventListener('click', (e) => {
    e.stopPropagation();
    const itemEl = e.currentTarget.closest('.conversation-item');
    const deleteBtn = itemEl.querySelector('.btn-delete');
    const confirmActions = itemEl.querySelector('.delete-confirm-actions');
    
    deleteBtn.style.display = 'none';
    confirmActions.style.display = 'flex';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      if (confirmActions.style.display !== 'none') {
        deleteBtn.style.display = '';
        confirmActions.style.display = 'none';
      }
    }, 5000);
  });
  
  // Confirm delete button
  item.querySelector('.btn-delete-confirm').addEventListener('click', (e) => {
    e.stopPropagation();
    const id = e.currentTarget.dataset.id;
    const itemEl = e.currentTarget.closest('.conversation-item');
    const confirmBtn = itemEl.querySelector('.btn-delete-confirm');
    const cancelBtn = itemEl.querySelector('.btn-delete-cancel');
    const loadingSpinner = itemEl.querySelector('.delete-loading-spinner');
    
    confirmBtn.style.display = 'none';
    cancelBtn.style.display = 'none';
    loadingSpinner.style.display = 'block';
    
    confirmDeleteConversation(id, itemEl);
  });
  
  // Cancel delete button
  item.querySelector('.btn-delete-cancel').addEventListener('click', (e) => {
    e.stopPropagation();
    const itemEl = e.currentTarget.closest('.conversation-item');
    const deleteBtn = itemEl.querySelector('.btn-delete');
    const confirmActions = itemEl.querySelector('.delete-confirm-actions');
    
    deleteBtn.style.display = '';
    confirmActions.style.display = 'none';
  });

  item.addEventListener('click', () => {
    showConversationDetail(conversation);
  });
  
  return item;
}

/**
 * Get match type icon HTML
 * @param {string} matchType - 'phrase', 'keyword', 'prefix', or undefined
 * @returns {string} HTML for the match type icon
 */
function getMatchTypeIconHtml(matchType) {
  if (!matchType || matchType === 'none') {
    return '';
  }
  
  const icons = {
    phrase: {
      svg: `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M12 12a1 1 0 002 0V4a1 1 0 00-2 0v8zm-7-4.5v1.2c.7.2 1.2.5 1.5.9.3.4.5.9.5 1.5 0 .7-.2 1.3-.7 1.8-.5.4-1.1.6-1.8.6-.8 0-1.5-.2-2-.7-.5-.4-.8-1-.8-1.7h1.8c0 .3.1.6.3.7.2.2.4.3.7.3s.6-.1.7-.2c.2-.2.3-.4.3-.6 0-.3-.1-.5-.3-.7-.2-.2-.5-.3-.9-.4l-.5-.1c-.7-.2-1.2-.4-1.6-.8S1 8.4 1 7.8c0-.6.2-1.1.6-1.5.4-.4 1-.7 1.7-.8V4.3h1.2v1.2c.7.1 1.2.4 1.6.8.4.4.6.9.6 1.6H5c0-.3-.1-.5-.3-.7-.2-.2-.4-.3-.7-.3-.2 0-.4.1-.6.2-.2.2-.3.4-.3.6 0 .3.1.5.3.6.2.2.4.3.8.4l.8.2z"/>
      </svg>`,
      label: getMessage('matchTypePhrase', 'Phrase match'),
      color: '#22c55e'
    },
    keyword: {
      svg: `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M2.5 3h11c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5h-11a.5.5 0 01-.5-.5v-1c0-.3.2-.5.5-.5zm0 4h11c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5h-11a.5.5 0 01-.5-.5v-1c0-.3.2-.5.5-.5zm0 4h7c.3 0 .5.2.5.5v1c0 .3-.2.5-.5.5h-7a.5.5 0 01-.5-.5v-1c0-.3.2-.5.5-.5z"/>
      </svg>`,
      label: getMessage('matchTypeKeyword', 'Keyword match'),
      color: '#3b82f6'
    },
    prefix: {
      svg: `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M2 3.5a.5.5 0 01.5-.5h6a.5.5 0 010 1h-6a.5.5 0 01-.5-.5zm0 4a.5.5 0 01.5-.5h4a.5.5 0 010 1h-4a.5.5 0 01-.5-.5zm0 4a.5.5 0 01.5-.5h2a.5.5 0 010 1h-2a.5.5 0 01-.5-.5z"/>
        <path d="M10 7l3 3-3 3V7z" fill-opacity="0.7"/>
      </svg>`,
      label: getMessage('matchTypePrefix', 'Prefix match'),
      color: '#f97316'
    }
  };
  
  const icon = icons[matchType];
  if (!icon) return '';
  
  return `
    <div class="match-type-icon" style="color: ${icon.color};" data-match-type="${matchType}">
      ${icon.svg}
      <span class="match-type-tooltip">${escapeHtml(icon.label)}</span>
    </div>
  `;
}

// Delete conversation
function confirmDeleteConversation(conversationId, itemEl) {
  chrome.runtime.sendMessage({ 
    action: 'deleteConversation', 
    conversationId 
  }, (response) => {
    if (itemEl) {
      const loadingSpinner = itemEl.querySelector('.delete-loading-spinner');
      if (loadingSpinner) {
        loadingSpinner.style.display = 'none';
      }
    }
    if (response?.success) {
      loadConversations();
    }
  });
}

// Get platform color
function getPlatformColor(platformName) {
  const platform = Object.values(PLATFORMS).find(p => p.name === platformName);
  return platform ? platform.color : '#666';
}

// Get time ago string
function getTimeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);

  for (const threshold of TIME_THRESHOLDS) {
    if (seconds >= threshold.limit) {
      continue;
    }
    if (relativeTimeFormatter) {
      if (threshold.immediate) {
        return relativeTimeFormatter.format(0, threshold.unit);
      }
      const value = -Math.floor(seconds / threshold.divisor);
      return relativeTimeFormatter.format(value, threshold.unit);
    }
    return formatRelativeFallback(seconds, threshold);
  }

  return new Date(timestamp).toLocaleDateString(NORMALIZED_LOCALE);
}

function formatRelativeFallback(seconds, threshold) {
  if (threshold.immediate) {
    return 'Just now';
  }
  const value = Math.floor(seconds / threshold.divisor);
  switch (threshold.unit) {
    case 'minute':
      return `${value}m ago`;
    case 'hour':
      return `${value}h ago`;
    case 'day':
      return `${value}d ago`;
    default:
      return `${value}s ago`;
  }
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function shouldHighlightSearch() {
  return Boolean(searchQuery?.length);
}

function escapeRegexPattern(value) {
  return String(value ?? '').replaceAll(REGEX_SPECIAL_CHARS, String.raw`\$&`);
}

function getHighlightRegex() {
  if (!shouldHighlightSearch()) {
    return null;
  }
  const tokens = searchQuery
    .split(/\s+/)
    .map((token) => token.trim())
    .filter(Boolean)
    .map(escapeRegexPattern);
  if (!tokens.length) {
    return null;
  }
  try {
    return new RegExp(`(${tokens.join('|')})`, 'gi');
  } catch (error) {
    console.warn('[ContextWizard Popup] Failed to build highlight regex', error);
    return null;
  }
}

function formatHighlightedText(text = '') {
  const safeText = escapeHtml(text || '');
  const regex = getHighlightRegex();
  if (!regex) {
    return safeText;
  }
  return safeText.replace(regex, '<mark class="keyword-highlight">$1</mark>');
}

function clearHighlights(container) {
  if (!container) {
    return;
  }
  const marks = container.querySelectorAll('mark.keyword-highlight');
  for (const mark of marks) {
    mark.replaceWith(document.createTextNode(mark.textContent || ''));
  }
}

function highlightElementContent(container) {
  if (!container) {
    return;
  }
  const regex = getHighlightRegex();
  clearHighlights(container);
  if (!regex) {
    return;
  }

  const nodesToHighlight = collectHighlightNodes(container, regex);
  for (const { node, text } of nodesToHighlight) {
    replaceNodeWithHighlights(node, text, regex);
  }
}

function collectHighlightNodes(container, regex) {
  const results = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
  while (walker.nextNode()) {
    if (walker.currentNode.parentElement?.closest('.detail-message-role')) {
      continue;
    }
    const nodeValue = walker.currentNode.nodeValue;
    if (!nodeValue?.trim()) {
      continue;
    }
    if (regex.test(nodeValue)) {
      results.push({ node: walker.currentNode, text: nodeValue });
    }
    regex.lastIndex = 0;
  }
  return results;
}

function replaceNodeWithHighlights(node, text, regex) {
  if (!node?.parentNode) {
    return;
  }
  const fragment = document.createDocumentFragment();
  let lastIndex = 0;
  let match;
  regex.lastIndex = 0;
  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex, match.index)));
    }
    const mark = document.createElement('mark');
    mark.className = 'keyword-highlight';
    mark.textContent = match[0];
    fragment.appendChild(mark);
    lastIndex = regex.lastIndex;
  }
  if (lastIndex < text.length) {
    fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
  }
  node.parentNode.replaceChild(fragment, node);
}

// Show more platforms in a modal
function showMorePlatforms() {
  const platformStats = getPlatformUsageStats();
  const modal = document.createElement('div');
  modal.className = 'modal';
  const title = getMessage('allPlatformsModalTitle', 'All Platforms');
  const closeLabel = getMessage('modalCloseButton', 'Close');
  const chipsMarkup = platformStats.map(({ platform, count }) => `
          <button class="platform-chip" data-platform="${escapeHtml(platform)}" style="background-color: ${getPlatformColor(platform)}">
            ${escapeHtml(platform)} (${count})
          </button>
        `).join('');
  const emptyMessage = getMessage('noPlatformsRecorded', 'No platforms recorded yet.');
  const gridContent = chipsMarkup || `<p>${escapeHtml(emptyMessage)}</p>`;

  modal.innerHTML = `
    <div class="modal-content">
      <h3>${escapeHtml(title)}</h3>
      <div class="platform-grid">
        ${gridContent}
      </div>
      <button class="btn-close">${escapeHtml(closeLabel)}</button>
    </div>
  `;

  document.body.appendChild(modal);
  
  // Add event listeners
  for (const chip of modal.querySelectorAll('.platform-chip')) {
    chip.addEventListener('click', (e) => {
      const platform = e.currentTarget.dataset.platform;
      modal.remove();
      handleFilterChange(platform);
    });
  }
  
  modal.querySelector('.btn-close').addEventListener('click', () => {
    modal.remove();
  });
}

// Load internationalization
function loadI18n() {
  const extensionTitle = globalThis.chrome?.i18n?.getMessage('extensionName');
  if (extensionTitle) {
    document.title = extensionTitle;
  }

  for (const element of document.querySelectorAll('[data-i18n]')) {
    applyMessage(element, element.dataset.i18n, (target, message) => {
      target.textContent = message;
    });
  }
  
  for (const element of document.querySelectorAll('[data-i18n-placeholder]')) {
    applyMessage(element, element.dataset.i18nPlaceholder, (target, message) => {
      target.placeholder = message;
    });
  }

  for (const element of document.querySelectorAll('[data-i18n-title]')) {
    applyMessage(element, element.dataset.i18nTitle, (target, message) => {
      target.title = message;
    });
  }

  for (const element of document.querySelectorAll('[data-i18n-aria-label]')) {
    applyMessage(element, element.dataset.i18nAriaLabel, (target, message) => {
      target.setAttribute('aria-label', message);
    });
  }
}

function applyMessage(element, key, applyFn) {
  if (!key || typeof chrome === 'undefined' || !chrome.i18n) {
    return;
  }
  const message = chrome.i18n.getMessage(key);
  if (message) {
    applyFn(element, message);
  }
}

// Chat platforms button functionality
let chatPlatformsPopupTimeout = null;

function initChatPlatformsButton() {
  const chatPlatformsBtn = document.getElementById('chatPlatformsBtn');
  const chatPlatformsPopup = document.getElementById('chatPlatformsPopup');
  
  if (!chatPlatformsBtn || !chatPlatformsPopup) {
    return;
  }

  // Click to toggle
  chatPlatformsBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleChatPlatformsPopup();
  });

  // Mouse enter - show after 0.8s
  chatPlatformsBtn.addEventListener('mouseenter', () => {
    clearTimeout(chatPlatformsPopupTimeout);
    chatPlatformsPopupTimeout = setTimeout(() => {
      showChatPlatformsPopup();
    }, 800);
  });

  // Mouse leave - cancel delayed show
  chatPlatformsBtn.addEventListener('mouseleave', () => {
    clearTimeout(chatPlatformsPopupTimeout);
  });

  // Keep popup open when hovering over it
  chatPlatformsPopup.addEventListener('mouseenter', () => {
    clearTimeout(chatPlatformsPopupTimeout);
  });

  chatPlatformsPopup.addEventListener('mouseleave', () => {
    hideChatPlatformsPopup();
  });

  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (!chatPlatformsBtn.contains(e.target) && !chatPlatformsPopup.contains(e.target)) {
      hideChatPlatformsPopup();
    }
  });
}

function toggleChatPlatformsPopup() {
  const popup = document.getElementById('chatPlatformsPopup');
  if (!popup) return;
  
  if (popup.style.display === 'none') {
    showChatPlatformsPopup();
  } else {
    hideChatPlatformsPopup();
  }
}

function showChatPlatformsPopup() {
  const popup = document.getElementById('chatPlatformsPopup');
  if (!popup) return;
  
  renderChatPlatformsList();
  popup.style.display = 'block';
}

function hideChatPlatformsPopup() {
  const popup = document.getElementById('chatPlatformsPopup');
  if (!popup) return;
  
  popup.style.display = 'none';
}

function renderChatPlatformsList() {
  const listContainer = document.getElementById('chatPlatformsList');
  if (!listContainer) return;

  // Get custom platforms from storage
  chrome.storage.sync.get(['customPlatforms'], (result) => {
    const customPlatforms = result.customPlatforms || [];
    
    // Get platform stats and sort by count
    const platformStats = getPlatformUsageStats();
    const platformStatsMap = new Map(platformStats.map(s => [s.platform, s.count]));
    
    // Combine built-in and custom platforms
    const allPlatformEntries = [];
    
    // Add custom platforms first
    for (const custom of customPlatforms) {
      if (custom.enabled !== false) {
        const resolvedUrl = getCustomPlatformUrl(custom);
        allPlatformEntries.push({
          name: custom.name,
          url: resolvedUrl,
          color: custom.color || '#666',
          count: platformStatsMap.get(custom.name) || 0,
          isCustom: true
        });
      }
    }
    
    // Add built-in platforms
    for (const [domain, platform] of Object.entries(PLATFORMS)) {
      if (platform.enabled !== false) {
        allPlatformEntries.push({
          name: platform.name,
          url: getNewChatUrl(domain, platform),
          color: platform.color,
          count: platformStatsMap.get(platform.name) || 0,
          isCustom: false
        });
      }
    }
    
    // Sort: custom first, then by count (descending)
    allPlatformEntries.sort((a, b) => {
      if (a.isCustom && !b.isCustom) return -1;
      if (!a.isCustom && b.isCustom) return 1;
      return b.count - a.count;
    });
    
    // Render the list
    listContainer.innerHTML = '';
    for (const platform of allPlatformEntries) {
      const item = createChatPlatformItem(platform);
      listContainer.appendChild(item);
    }
  });
}

function getNewChatUrl(domain, platform) {
  // Default new chat URLs for common platforms
  const newChatUrls = {
    'chatgpt.com': 'https://chatgpt.com',
    'claude.ai': 'https://claude.ai/new',
    'gemini.google.com': 'https://gemini.google.com/app',
    'copilot.microsoft.com': 'https://copilot.microsoft.com',
    'grok.com': 'https://grok.com',
    'www.perplexity.ai': 'https://www.perplexity.ai',
    'www.kimi.com': 'https://www.kimi.com',
    'poe.com': 'https://poe.com',
    'chat.deepseek.com': 'https://chat.deepseek.com',
    'chat.qwen.ai': 'https://chat.qwen.ai'
  };
  
  return newChatUrls[domain] || `https://${domain}`;
}

function getCustomPlatformUrl(custom = {}) {
  const explicitUrl = custom.newChatUrl || custom.url;
  if (explicitUrl) {
    return explicitUrl;
  }
  if (custom.urlPattern) {
    const baseFromPattern = extractBaseUrlFromPattern(custom.urlPattern);
    if (baseFromPattern) {
      return baseFromPattern;
    }
  }
  return '';
}

function extractBaseUrlFromPattern(pattern = '') {
  const trimmed = (pattern || '').trim();
  if (!trimmed) {
    return '';
  }
  const wildcardIndex = trimmed.indexOf('*');
  const base = wildcardIndex > -1 ? trimmed.slice(0, wildcardIndex) : trimmed;
  if (!/^https?:\/\//i.test(base)) {
    return `https://${base}`;
  }
  return base;
}

function createChatPlatformItem(platform) {
  const item = document.createElement('button');
  item.className = 'chat-platform-item';
  item.dataset.url = platform.url || '';
  
  const badge = document.createElement('span');
  badge.className = 'chat-platform-badge';
  badge.style.backgroundColor = platform.color;
  
  badge.textContent = platform.name;
  
  item.appendChild(badge);
  
  if (platform.url) {
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      const url = e.currentTarget.dataset.url;
      openTabInLastFocusedWindow({ url });
      hideChatPlatformsPopup();
    });
  } else {
    item.disabled = true;
    item.classList.add('chat-platform-item-disabled');
    item.title = getMessage('missingPlatformUrl', 'No URL configured');
  }
  
  return item;
}

// Detail modal helpers
function initDetailModal() {
  detailModal = document.getElementById('detailModal');
  if (!detailModal) {
    return;
  }

  detailElements = {
    badge: document.getElementById('detailPlatformBadge'),
    time: document.getElementById('detailTime'),
    title: document.getElementById('detailTitle'),
    messages: document.getElementById('detailMessages'),
    status: document.getElementById('detailStatus'),
    openBtn: document.getElementById('detailOpenBtn'),
    copyBtn: document.getElementById('detailCopyBtn'),
    dismissBtn: document.getElementById('detailDismissBtn'),
    closeBtn: document.getElementById('detailCloseBtn')
  };

  if (Object.values(detailElements).some(element => !element)) {
    detailModal = null;
    return;
  }

  detailElements.closeBtn.addEventListener('click', hideDetailModal);
  detailModal.addEventListener('click', (event) => {
    if (event.target === detailModal) {
      hideDetailModal();
    }
  });

  if (detailElements.copyBtn) {
    detailElements.copyBtn.addEventListener('click', async () => {
      const contextText = formatConversationAsContextText(detailConversation);
      if (!contextText) {
        setDetailStatusMessage('conversationCopyContextNothing', 'Nothing to copy');
        return;
      }

      const ok = await copyTextToClipboard(contextText);
      if (ok) {
        setDetailStatusMessage('conversationCopyContextSuccess', 'Copied to clipboard');
      } else {
        setDetailStatusMessage('conversationCopyContextFailed', 'Failed to copy');
      }
    });
  }

  // Setup navigation button listeners
  const navContainer = document.getElementById('detailNavigation');
  if (navContainer) {
    const prevBtn = navContainer.querySelector('.nav-prev');
    const nextBtn = navContainer.querySelector('.nav-next');
    
    if (prevBtn) {
      prevBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        scrollToPreviousMatch();
      });
    }
    
    if (nextBtn) {
      nextBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        scrollToNextMatch();
      });
    }
  }
}

function getDetailStatusElement() {
  return detailElements?.status || null;
}

function setDetailStatusText(text) {
  const statusEl = getDetailStatusElement();
  if (!statusEl) {
    return;
  }

  const value = (text || '').trim();
  statusEl.textContent = value;
  if (value) {
    statusEl.classList.add('visible');
  } else {
    statusEl.classList.remove('visible');
  }

  if (detailStatusClearTimer) {
    clearTimeout(detailStatusClearTimer);
    detailStatusClearTimer = null;
  }

  if (value) {
    detailStatusClearTimer = setTimeout(() => {
      detailStatusClearTimer = null;
      setDetailStatusText('');
    }, GLOBAL_STATUS_CLEAR_MS);
  }
}

function setDetailStatusMessage(messageKey, fallback) {
  setDetailStatusText(getMessage(messageKey, fallback));
}

function showConversationDetail(conversation) {
  if (!detailModal || !conversation) {
    return;
  }

  // Track the index of this conversation in the filtered cache
  currentDetailIndex = filteredConversationsCache.findIndex(c => c.id === conversation.id);

  detailConversation = conversation;
  setDetailStatusText('');

  detailElements.badge.textContent = conversation.platform;
  detailElements.badge.style.backgroundColor = getPlatformColor(conversation.platform);
  detailElements.time.textContent = new Date(conversation.lastUpdated).toLocaleString();
  detailElements.title.innerHTML = formatHighlightedText(conversation.title);

  detailElements.messages.innerHTML = '';
  for (const message of conversation.messages || []) {
    detailElements.messages.appendChild(createDetailMessage(message));
  }

  highlightElementContent(detailElements.messages);

  // Cache current match elements for scrolling navigation.
  detailMatchElements = Array.from(detailElements.messages.querySelectorAll('mark.keyword-highlight'));
  currentMatchCursor = -1;

  if (detailElements.openBtn) {
    detailElements.openBtn.onclick = () => {
      // Pass search navigation context to content script if we're in search mode
      if (searchQuery && currentDetailIndex >= 0 && currentDetailIndex < filteredConversationsCache.length) {
        const navContext = {
          searchQuery,
          resultsList: filteredConversationsCache.map(c => ({
            id: c.id,
            platform: c.platform,
            url: c.url,
            title: c.title
          })),
          currentIndex: currentDetailIndex
        };

        // Open the tab via background so it can deliver nav context to the created tab.
        chrome.runtime.sendMessage({
          action: 'openTabWithNavContext',
          url: conversation.url,
          navContext
        });
        return;
      }
      openTabInLastFocusedWindow({ url: conversation.url });
    };
  }
  if (detailElements.dismissBtn) {
    detailElements.dismissBtn.onclick = hideDetailModal;
  }

  // Update navigation buttons if we're in search mode
  updateNavigationButtons();

  detailModal.classList.remove('hidden');
  detailModal.setAttribute('open', '');
}

function hideDetailModal() {
  if (!detailModal) {
    return;
  }

  detailConversation = null;
  currentDetailIndex = -1;
  detailMatchElements = [];
  currentMatchCursor = -1;
  setDetailStatusText('');
  detailModal.classList.add('hidden');
  detailModal.removeAttribute('open');
  if (typeof detailModal.close === 'function' && detailModal.hasAttribute('open')) {
    try {
      detailModal.close();
    } catch (error) {
      console.warn('ContextWizard: Failed to close detail dialog', error);
    }
  }
}

function createDetailMessage(message) {
  const wrapper = document.createElement('div');
  const role = getDetailMessageRole(message);
  wrapper.className = `detail-message ${role}`;

  const roleLabel = document.createElement('div');
  roleLabel.className = 'detail-message-role';
  roleLabel.textContent = getDetailMessageRoleLabel(role);

  const content = document.createElement('div');
  content.className = 'detail-message-content';
  if (message?.html) {
    content.innerHTML = message.html;
  } else {
    content.textContent = message.content || '';
  }
  wrapper.appendChild(roleLabel);
  wrapper.appendChild(content);
  
  return wrapper;
}

function getDetailMessageRole(message) {
  if (message?.role === 'assistant') {
    return 'assistant';
  }
  if (message?.role === 'user') {
    return 'user';
  }
  return 'unknown';
}

function getDetailMessageRoleLabel(role) {
  if (role === 'user') {
    return getMessage('detailUserMessageLabel', 'You');
  }
  if (role === 'assistant') {
    return getMessage('detailAssistantMessageLabel', 'AI');
  }
  return getMessage('detailUnknownMessageLabel', 'Message');
}

/**
 * Update navigation button visibility and disabled state
 * Shows navigation buttons only when viewing a search result
 */
function updateNavigationButtons() {
  const navContainer = document.getElementById('detailNavigation');
  if (!navContainer) {
    return;
  }

  const prevBtn = navContainer.querySelector('.nav-prev');
  const nextBtn = navContainer.querySelector('.nav-next');
  if (!prevBtn || !nextBtn) {
    return;
  }

  // Only show navigation buttons during search results AND when there are message matches.
  if (!searchQuery || currentDetailIndex < 0 || !detailMatchElements.length) {
    navContainer.style.display = 'none';
    return;
  }

  navContainer.style.display = 'flex';

  const messagesContainer = detailElements?.messages;
  if (!messagesContainer) {
    navContainer.style.display = 'none';
    return;
  }

  const offsets = detailMatchElements.map((el) => computeOffsetWithinContainer(el, messagesContainer));

  // If cursor not set yet, allow the first click to jump to a match (even if there's only one).
  if (currentMatchCursor === -1) {
    prevBtn.disabled = false;
    prevBtn.classList.remove('disabled');
    nextBtn.disabled = false;
    nextBtn.classList.remove('disabled');
    return;
  }

  const hasOnlyOneMatch = detailMatchElements.length === 1;
  prevBtn.disabled = currentMatchCursor <= 0 && !hasOnlyOneMatch;
  prevBtn.classList.toggle('disabled', currentMatchCursor <= 0 && !hasOnlyOneMatch);

  nextBtn.disabled = currentMatchCursor >= detailMatchElements.length - 1 && !hasOnlyOneMatch;
  nextBtn.classList.toggle('disabled', currentMatchCursor >= detailMatchElements.length - 1 && !hasOnlyOneMatch);
}

/**
 * Scroll to previous search match in detail messages
 */
function scrollToPreviousMatch() {
  const messagesContainer = detailElements?.messages;
  if (!messagesContainer) {
    return;
  }

  const marks = detailMatchElements.length ? detailMatchElements : Array.from(messagesContainer.querySelectorAll('mark.keyword-highlight'));
  if (!marks.length) {
    return;
  }

  const offsets = marks.map((el) => computeOffsetWithinContainer(el, messagesContainer));

  if (currentMatchCursor === -1) {
    // First navigation: jump to the last match.
    const targetIndex = offsets.length - 1;
    const targetEl = marks[targetIndex];
    scrollMatchIntoView(targetEl, offsets[targetIndex], messagesContainer);
    currentMatchCursor = targetIndex;
    updateNavigationButtons();
    return;
  }

  const targetIndex = Math.max(0, currentMatchCursor - 1);
  const targetEl = marks[targetIndex];
  scrollMatchIntoView(targetEl, offsets[targetIndex], messagesContainer);
  currentMatchCursor = targetIndex;
  updateNavigationButtons();
}

/**
 * Scroll to next search match in detail messages
 */
function scrollToNextMatch() {
  const messagesContainer = detailElements?.messages;
  if (!messagesContainer) {
    return;
  }

  const marks = detailMatchElements.length ? detailMatchElements : Array.from(messagesContainer.querySelectorAll('mark.keyword-highlight'));
  if (!marks.length) {
    return;
  }

  const offsets = marks.map((el) => computeOffsetWithinContainer(el, messagesContainer));

  if (currentMatchCursor === -1) {
    // First navigation: jump to the first match.
    const targetIndex = 0;
    const targetEl = marks[targetIndex];
    scrollMatchIntoView(targetEl, offsets[targetIndex], messagesContainer);
    currentMatchCursor = targetIndex;
    updateNavigationButtons();
    return;
  }

  const targetIndex = Math.min(offsets.length - 1, currentMatchCursor + 1);
  const targetEl = marks[targetIndex];
  scrollMatchIntoView(targetEl, offsets[targetIndex], messagesContainer);
  currentMatchCursor = targetIndex;
  updateNavigationButtons();
}

// Compute offset of an element relative to a scroll container, handling nested elements (e.g., UL/LI)
// Uses getBoundingClientRect for accurate positioning, accounting for scroll state
function computeOffsetWithinContainer(el, container) {
  if (!el || !container) {
    return 0;
  }

  // Use getBoundingClientRect for accurate viewport-relative positioning
  const elRect = el.getBoundingClientRect();
  const containerRect = container.getBoundingClientRect();

  // Calculate offset: element's top position relative to container top + container's current scroll
  // This ensures accurate positioning regardless of nested elements or complex DOM structure
  const offset = (elRect.top - containerRect.top) + container.scrollTop;

  return Math.max(0, offset);
}

// Scroll a match into view, roughly centered
// Improved version with better centering logic
function scrollMatchIntoView(el, offset, container) {
  if (!container || typeof offset !== 'number') {
    return;
  }

  const targetHeight = el?.getBoundingClientRect()?.height || 16;
  const containerHeight = container.clientHeight;

  // Calculate desired scroll position to center the match in the viewport
  // Subtract half of the remaining space above and below the match
  const viewportSpace = (containerHeight - targetHeight) / 2;
  const desired = offset - Math.max(0, viewportSpace);

  // Ensure we don't scroll past the beginning
  container.scrollTop = Math.max(0, desired);
}

/**
 * Navigate to previous search result (for new tab opening)
 */
function navigateToPreviousResult() {
  if (currentDetailIndex <= 0) {
    return;
  }
  currentDetailIndex--;
  const result = filteredConversationsCache[currentDetailIndex];
  if (result) {
    showConversationDetail(result);
  }
}

/**
 * Navigate to next search result (for new tab opening)
 */
function navigateToNextResult() {
  if (currentDetailIndex >= filteredConversationsCache.length - 1) {
    return;
  }
  currentDetailIndex++;
  const result = filteredConversationsCache[currentDetailIndex];
  if (result) {
    showConversationDetail(result);
  }
}

/**
 * Focus an existing popup window whose tab URL starts with the given URL,
 * or create a new popup if no matching window exists.
 */
function focusOrCreateWindow(url, createOptions) {
  chrome.windows.getAll({ populate: true }, (windows) => {
    const existingWindow = windows.find((w) =>
      w.tabs?.some((tab) => tab.url && tab.url.startsWith(url))
    );
    if (existingWindow) {
      chrome.windows.update(existingWindow.id, { focused: true });
    } else {
      chrome.windows.create(createOptions);
    }
  });
}

function openPromptEditor() {
  const editorUrl = chrome.runtime.getURL('prompt_editor.html');
  focusOrCreateWindow(editorUrl, {
    url: editorUrl,
    type: 'popup',
    width: 600,
    height: 700,
    focused: true
  });
}

function openBookmarkEditor() {
  const editorUrl = chrome.runtime.getURL('bookmark_editor.html');
  focusOrCreateWindow(editorUrl, {
    url: editorUrl,
    type: 'popup',
    width: 500,
    height: 700,
    focused: true
  });
}

// ========== Bookmarks Manager ==========

let bookmarksModal = null;
let allBookmarks = [];
let bookmarksSearchQuery = '';

// Open bookmarks manager
function openBookmarksManager() {
  bookmarksModal = document.getElementById('bookmarksModal');
  if (!bookmarksModal) {
    return;
  }

  bookmarksModal.classList.remove('hidden');
  bookmarksModal.setAttribute('open', '');

  // Load bookmarks
  loadAllBookmarks();

  // Setup event listeners
  const closeBtn = document.getElementById('bookmarksCloseBtn');
  if (closeBtn) {
    closeBtn.onclick = closeBookmarksManager;
  }

  const searchInput = document.getElementById('bookmarksSearchInput');
  if (searchInput) {
    searchInput.value = '';
    searchInput.oninput = debounce((e) => {
      bookmarksSearchQuery = e.target.value.trim();
      filterAndDisplayBookmarks();
    }, 300);
  }

  // ESC to close
  const keyHandler = (e) => {
    if (e.key === 'Escape') {
      closeBookmarksManager();
      document.removeEventListener('keydown', keyHandler);
    }
  };
  document.addEventListener('keydown', keyHandler);
}

// Close bookmarks manager
function closeBookmarksManager() {
  if (bookmarksModal) {
    bookmarksModal.classList.add('hidden');
    bookmarksModal.removeAttribute('open');
  }
}

// Load all bookmarks
function loadAllBookmarks() {
  const listContainer = document.getElementById('bookmarksList');
  if (!listContainer) {
    return;
  }

  // Show loading
  listContainer.innerHTML = `
    <div class="loading">
      <div class="spinner"></div>
      <p data-i18n="bookmarkLoading">Loading bookmarks...</p>
    </div>
  `;

  chrome.runtime.sendMessage({ action: 'getBookmarks' }, (response) => {
    if (response?.success) {
      allBookmarks = response.bookmarks || [];
      filterAndDisplayBookmarks();
    } else {
      listContainer.innerHTML = `<p class="error">${escapeHtml(getMessage('bookmarkLoadError', 'Failed to load bookmarks'))}</p>`;
    }
  });
}

// Filter and display bookmarks
function filterAndDisplayBookmarks() {
  const listContainer = document.getElementById('bookmarksList');
  const emptyState = document.getElementById('bookmarksEmpty');
  
  if (!listContainer || !emptyState) {
    return;
  }

  let filteredBookmarks = allBookmarks;

  // Apply search filter
  if (bookmarksSearchQuery) {
    const query = bookmarksSearchQuery.toLowerCase();
    filteredBookmarks = allBookmarks.filter((bookmark) =>
      (bookmark.content || '').toLowerCase().includes(query) ||
      (bookmark.selectedText || '').toLowerCase().includes(query)
    );
  }

  if (filteredBookmarks.length === 0) {
    listContainer.style.display = 'none';
    emptyState.style.display = 'block';
    return;
  }

  listContainer.style.display = 'block';
  emptyState.style.display = 'none';

  // Group bookmarks by content
  const groupedBookmarks = {};
  filteredBookmarks.forEach((bookmark) => {
    const content = bookmark.content || getMessage('bookmarkUntitled', 'Untitled');
    if (!groupedBookmarks[content]) {
      groupedBookmarks[content] = [];
    }
    groupedBookmarks[content].push(bookmark);
  });

  // Render grouped bookmarks
  let html = '<div class="bookmarks-groups">';
  
  for (const [content, bookmarks] of Object.entries(groupedBookmarks)) {
    html += `
      <div class="bookmark-group">
        <div class="bookmark-group-title">${escapeHtml(content.substring(0, 100))}${content.length > 100 ? '...' : ''}</div>
        <ul class="bookmark-locations">
    `;
    
    bookmarks.forEach((bookmark) => {
      const preview = bookmark.selectedText?.substring(0, 80) || bookmark.content?.substring(0, 80) || '';
      const date = new Date(bookmark.createdAt).toLocaleDateString();
      const jumpLabel = getMessage('bookmarkJumpToLocation', 'Jump to location');
      const deleteLabel = getMessage('bookmarkDeleteButton', 'Delete');
      const platformLabel = bookmark.platform || getMessage('unknownPlatform', 'Unknown');
      
      const selectedText = bookmark.selectedText || '';
      html += `
        <li class="bookmark-location-item" data-bookmark-id="${bookmark.id}" data-selected-text="${selectedText.replace(/"/g, '&quot;')}">
          <div class="bookmark-location-preview">${escapeHtml(preview)}${preview.length >= 80 ? '...' : ''}</div>
          <div class="bookmark-location-meta">
            <span class="bookmark-platform">${escapeHtml(platformLabel)}</span>
            <span class="bookmark-date">${date}</span>
          </div>
          <div class="bookmark-location-actions">
            <button class="btn-jump-bookmark" data-bookmark-id="${bookmark.id}" data-url="${escapeHtml(bookmark.url || '')}">${escapeHtml(jumpLabel)}</button>
            <button class="btn-delete-bookmark" data-bookmark-id="${bookmark.id}">${escapeHtml(deleteLabel)}</button>
          </div>
        </li>
      `;
    });
    
    html += `
        </ul>
      </div>
    `;
  }
  
  html += '</div>';
  listContainer.innerHTML = html;

  // Attach event listeners
  attachBookmarkEventListeners();
}

// Show enhanced SelectedText tip on hover
function showSelectedTextTip(bookmarkItem) {
  const selectedText = bookmarkItem.getAttribute('data-selected-text');
  if (!selectedText) return;

  // Clear any existing timeout
  if (bookmarkItem._tipTimeout) {
    clearTimeout(bookmarkItem._tipTimeout);
  }

  // Set timeout for 0.6 seconds
  bookmarkItem._tipTimeout = setTimeout(() => {
    // Remove any existing tip first
    const existingTip = document.querySelector('.contextwizard-selected-text-tip');
    if (existingTip) {
      existingTip.remove();
    }

    const tip = document.createElement('div');
    tip.className = 'contextwizard-selected-text-tip';
    
    const content = document.createElement('div');
    content.className = 'contextwizard-selected-text-tip-content';
    content.textContent = selectedText;
    
    tip.appendChild(content);
    
    // Position near the target element
    const targetRect = bookmarkItem.getBoundingClientRect();
    tip.style.left = targetRect.left + 'px';
    tip.style.top = (targetRect.bottom + 5) + 'px';
    
    // Ensure tip doesn't go off screen
    setTimeout(() => {
      const tipRect = tip.getBoundingClientRect();
      if (tipRect.right > window.innerWidth) {
        tip.style.left = (window.innerWidth - tipRect.width - 10) + 'px';
      }
      if (tipRect.bottom > window.innerHeight) {
        tip.style.top = (targetRect.top - tipRect.height - 5) + 'px';
      }
    }, 10);
    
    document.body.appendChild(tip);
    
    // Store reference for removal
    bookmarkItem._tipElement = tip;
  }, 600);
}

// Hide SelectedText tip
function hideSelectedTextTip(bookmarkItem) {
  // Clear timeout if exists
  if (bookmarkItem._tipTimeout) {
    clearTimeout(bookmarkItem._tipTimeout);
    bookmarkItem._tipTimeout = null;
  }
  
  // Remove tip if exists
  if (bookmarkItem._tipElement) {
    bookmarkItem._tipElement.remove();
    bookmarkItem._tipElement = null;
  }
}

// Attach event listeners to bookmark items
function attachBookmarkEventListeners() {
  // Jump buttons
  document.querySelectorAll('.btn-jump-bookmark').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const bookmarkId = e.target.getAttribute('data-bookmark-id');
      const url = e.target.getAttribute('data-url');
      jumpToBookmarkLocation(bookmarkId, url);
    });
  });

  // Delete buttons
  document.querySelectorAll('.btn-delete-bookmark').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const bookmarkId = e.target.getAttribute('data-bookmark-id');
      confirmDeleteBookmark(bookmarkId, e.target);
    });
  });

  // Add hover event listeners for SelectedText tip
  document.querySelectorAll('.bookmark-location-item').forEach((item) => {
    item.addEventListener('mouseenter', () => {
      showSelectedTextTip(item);
    });

    item.addEventListener('mouseleave', () => {
      hideSelectedTextTip(item);
    });
  });
}

// Jump to bookmark location
function jumpToBookmarkLocation(bookmarkId, url) {
  if (!url) {
    return;
  }

  // Open URL in new active tab
  openTabInLastFocusedWindow({ url: url, active: true }, (tab) => {
    if (!tab || !tab.id) {
      return;
    }

    // Wait for tab to load, then send message to scroll to bookmark
    const onUpdated = (tabId, changeInfo) => {
      if (tabId !== tab.id || changeInfo.status !== 'complete') {
        return;
      }
      chrome.tabs.onUpdated.removeListener(onUpdated);

      // Send scroll message with longer delay to allow bookmark markers to be created
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, {
          action: 'scrollToBookmark',
          bookmarkId: bookmarkId
        }).catch(() => {
          // Content script may not be ready yet
        });
      }, 2000);
    };

    chrome.tabs.onUpdated.addListener(onUpdated);

    // Safety cleanup
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
    }, 15000);
  });

  // Close bookmarks manager
  closeBookmarksManager();
}

// Confirm delete bookmark
function confirmDeleteBookmark(bookmarkId, buttonElement) {
  const confirmMsg = chrome.i18n.getMessage('bookmarkDeleteConfirm') || 'Delete this bookmark?';
  
  if (!confirm(confirmMsg)) {
    return;
  }

  // Show loading state
  if (buttonElement) {
    buttonElement.textContent = '...';
    buttonElement.disabled = true;
  }

  chrome.runtime.sendMessage(
    { action: 'deleteBookmark', bookmarkId: bookmarkId },
    (response) => {
      if (response?.success) {
        // Remove from local array
        allBookmarks = allBookmarks.filter((b) => b.id !== bookmarkId);
        
        // Refresh display
        filterAndDisplayBookmarks();
      } else {
        alert(getMessage('bookmarkDeleteError', 'Failed to delete bookmark'));
        if (buttonElement) {
          buttonElement.textContent = getMessage('bookmarkDeleteButton', 'Delete');
          buttonElement.disabled = false;
        }
      }
    }
  );
}

// ========== Top-level Tab Switching ==========

const POPUP_TAB_KEY = 'popupActiveTab';
let currentTopTab = 'conversations';

function initTopTabs() {
  const tabs = document.getElementById('topTabs');
  if (!tabs) return;

  tabs.addEventListener('click', (e) => {
    const tabBtn = e.target.closest('.top-tab');
    if (!tabBtn) return;
    const tabId = tabBtn.dataset.tab;
    if (tabId && tabId !== currentTopTab) {
      switchTopTab(tabId);
    }
  });

  // Restore last active tab
  chrome.storage.local.get([POPUP_TAB_KEY], (result) => {
    const saved = result[POPUP_TAB_KEY];
    if (saved && (saved === 'conversations' || saved === 'bookmarks')) {
      switchTopTab(saved);
    }
  });
}

function switchTopTab(tabId) {
  currentTopTab = tabId;

  // Update tab buttons
  const tabs = document.getElementById('topTabs');
  if (tabs) {
    tabs.querySelectorAll('.top-tab').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
  }

  // Show/hide panels using CSS class (not inline style, because .tab-panel has display:none)
  const convPanel = document.getElementById('conversationsPanel');
  const bookmarkPanel = document.getElementById('bookmarksPanel');
  if (convPanel) convPanel.classList.toggle('active', tabId === 'conversations');
  if (bookmarkPanel) bookmarkPanel.classList.toggle('active', tabId === 'bookmarks');

  // Persist
  chrome.storage.local.set({ [POPUP_TAB_KEY]: tabId });

  // Initialize bookmark panel on first switch
  if (tabId === 'bookmarks' && !bookmarkInitialized) {
    bookmarkInitialized = true;
    initBookmarkPanel();
  }
}

// ========== End Tab Switching ==========

// Expose selected helpers for unit tests
if (typeof globalThis !== 'undefined') {
  globalThis.ContextWizardPopupTestHooks = {
    escapeHtml,
    shouldHighlightSearch,
    getHighlightRegex,
    formatHighlightedText,
    highlightElementContent,
    clearHighlights,
    collectHighlightNodes,
    replaceNodeWithHighlights,
    getTimeAgo,
    formatRelativeFallback,
    getPlatformUsageStats,
    getNewChatUrl,
    getCustomPlatformUrl,
    extractBaseUrlFromPattern,
    escapeRegexPattern,
    // Search history functions
    getSearchSuggestions,
    debounce,
    getMatchTypeIconHtml,
    formatConversationAsContextText,
    htmlToPlainText,
    extractMessageText,
    // Navigation functions
    updateNavigationButtons,
    // Prompt Editor function
    openPromptEditor,
    scrollToPreviousMatch,
    scrollToNextMatch,
    computeOffsetWithinContainer,
    scrollMatchIntoView
  };
}

// ── Cloud Sync Indicator ─────────────────────────────────────
function initSyncIndicator() {
  chrome.runtime.sendMessage({ action: 'cloudSync_getSyncStatus' }, (status) => {
    if (chrome.runtime.lastError || !status) return;
    const indicator = document.getElementById('syncIndicator');
    if (!indicator) return;

    if (!status.loggedIn) return; // Don't show if not logged in

    indicator.style.display = 'flex';

    if (status.isSyncing) {
      indicator.classList.add('syncing');
    }
    if (status.hasPendingChanges) {
      indicator.classList.add('has-pending');
      indicator.title = getMessage('cloudSyncPendingChangesTitle', ([count]) => `Cloud Sync - ${count} pending changes • Click to manage`, [String(status.pendingChanges)]);
    } else if (status.lastSyncedAt > 0) {
      const date = new Date(status.lastSyncedAt);
      indicator.title = getMessage('cloudSyncLastSyncedTitle', ([time]) => `Cloud Sync - Last synced: ${time} • Click to manage`, [date.toLocaleString()]);
    }

    indicator.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('options.html#cloudSyncSection') });
    });
  });
}

// ── Page Copy Section (non-AI pages) ──────────────────────────────

let pageCopySourceTabId = null;

function initPageCopySection() {
  chrome.windows.getCurrent((currentWindow) => {
    if (currentWindow?.type === 'popup') {
      initPageCopySectionForStandalone();
    } else {
      initPageCopySectionForActionPopup();
    }
  });
}

function initPageCopySectionForActionPopup() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs?.[0];
    if (!tab?.url) return;
    setupPageCopySection(tab.id, tab.url);
  });
}

function initPageCopySectionForStandalone() {
  chrome.runtime.sendMessage({ action: 'getSourceTabInfo' }, (response) => {
    if (response?.tabId && response?.url) {
      setupPageCopySection(response.tabId, response.url);
    }
  });

  chrome.runtime.onMessage.addListener(function onMsg(message) {
    if (message?.action === 'sourceTabChanged') {
      setupPageCopySection(message.tabId, message.url);
    }
  });
}

function setupPageCopySection(tabId, tabUrl) {
  const section = document.getElementById('pageCopySection');
  if (!section) return;

  const isAiChat = isAiChatUrl(tabUrl);
  if (isAiChat) {
    section.style.display = 'none';
    pageCopySourceTabId = null;
    return;
  }

  pageCopySourceTabId = tabId;
  section.style.display = 'block';

  const copyBtn = document.getElementById('pageCopyBtn');
  const statusEl = document.getElementById('pageCopyStatus');

  if (copyBtn && !copyBtn.dataset.listenerAttached) {
    copyBtn.dataset.listenerAttached = '1';
    copyBtn.addEventListener('click', () => {
      const activeTabId = pageCopySourceTabId;
      if (!activeTabId) return;
      copyBtn.disabled = true;
      chrome.runtime.sendMessage(
        { action: 'copyPage_executeOnTab', tabId: activeTabId },
        async (result) => {
          copyBtn.disabled = false;
          if (!result?.success || !result.text) {
            showPageCopyStatus(statusEl, getMessage(
              result?.text === '' ? 'pageCopyNothing' : 'pageCopyFailed',
              result?.text === '' ? 'No content to copy' : 'Failed to copy'
            ));
            return;
          }
          const ok = await writeClipboard(result.text);
          showPageCopyStatus(statusEl, getMessage(
            ok ? 'pageCopySuccess' : 'pageCopyFailed',
            ok ? 'Copied to clipboard' : 'Failed to copy'
          ));
        }
      );
    });
  }
}

async function writeClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (_) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px;opacity:0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (_e) { /* ignore */ }
    ta.remove();
    return ok;
  }
}

function isAiChatUrl(url) {
  if (!url) return false;
  try {
    const hostname = new URL(url).hostname;
    // Check against built-in platforms
    for (const domain of Object.keys(PLATFORMS)) {
      const domainPart = domain.split('/')[0];
      if (hostname.includes(domainPart)) return true;
    }
  } catch (_) { /* ignore */ }
  return false;
}

function showPageCopyStatus(statusEl, message) {
  if (!statusEl) return;
  statusEl.textContent = message;
  statusEl.style.display = 'block';
  setTimeout(() => {
    statusEl.style.display = 'none';
  }, 2500);
}


// ========== Reminder History Functions ==========

function initReminderHistory() {
  loadUnreadReminderCount();
  setupReminderHistoryButton();
}

function loadUnreadReminderCount() {
  chrome.runtime.sendMessage({ action: 'getUnreadReminderCount' }, (count) => {
    updateBookmarksBtnBadge(count || 0);
  });
}

function updateBookmarksBtnBadge(count) {
  const bookmarksBtn = document.getElementById('bookmarksBtn');
  if (!bookmarksBtn) return;

  let badge = bookmarksBtn.querySelector('.reminder-badge');
  if (count > 0) {
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'reminder-badge';
      bookmarksBtn.appendChild(badge);
    }
    badge.textContent = count > 99 ? '99+' : count;
    badge.style.display = 'flex';
  } else if (badge) {
    badge.style.display = 'none';
  }
}

function setupReminderHistoryButton() {
  const bookmarksBtn = document.getElementById('bookmarksBtn');
  if (!bookmarksBtn) return;

  bookmarksBtn.addEventListener('click', (e) => {
    if (e.target.closest('.reminder-badge')) {
      e.stopPropagation();
      showReminderHistoryPanel();
    }
  });
}

function showReminderHistoryPanel() {
  const existingPanel = document.querySelector('.reminder-history-panel');
  if (existingPanel) {
    existingPanel.remove();
    return;
  }

  const panel = document.createElement('div');
  panel.className = 'reminder-history-panel';
  panel.innerHTML = `
    <div class="reminder-history-header">
      <span class="reminder-history-title">${getMessage('reminderHistoryTitle', 'Reminder History')}</span>
      <div class="reminder-history-actions">
        <button class="reminder-history-mark-all" id="reminderMarkAllBtn">${getMessage('reminderHistoryMarkAllRead', 'Mark all read')}</button>
        <button class="reminder-history-close" id="reminderCloseBtn">&times;</button>
      </div>
    </div>
    <div class="reminder-history-list" id="reminderHistoryList">
      <div class="reminder-history-loading">${getMessage('reminderHistoryLoading', 'Loading...')}</div>
    </div>
  `;

  document.body.appendChild(panel);

  const closeBtn = panel.querySelector('#reminderCloseBtn');
  closeBtn.addEventListener('click', () => panel.remove());

  const markAllBtn = panel.querySelector('#reminderMarkAllBtn');
  markAllBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'markAllRemindersRead' }, () => {
      loadUnreadReminderCount();
      loadReminderHistoryList(panel);
    });
  });

  loadReminderHistoryList(panel);

  document.addEventListener('click', function closePanel(e) {
    if (!panel.contains(e.target) && !e.target.closest('#bookmarksBtn')) {
      panel.remove();
      document.removeEventListener('click', closePanel);
    }
  });
}

function loadReminderHistoryList(panel) {
  const listContainer = panel.querySelector('#reminderHistoryList');
  
  chrome.runtime.sendMessage({ action: 'getReminderHistory' }, (history) => {
    if (!history || history.length === 0) {
      listContainer.innerHTML = `<div class="reminder-history-empty">${getMessage('reminderHistoryEmpty', 'No reminders yet')}</div>`;
      return;
    }

    const grouped = groupReminderHistory(history);
    let html = '';

    if (grouped.today.length > 0) {
      html += `<div class="reminder-history-group">
        <div class="reminder-history-group-title">${getMessage('reminderHistoryToday', 'Today')}</div>
        ${renderReminderHistoryItems(grouped.today)}
      </div>`;
    }

    if (grouped.yesterday.length > 0) {
      html += `<div class="reminder-history-group">
        <div class="reminder-history-group-title">${getMessage('reminderHistoryYesterday', 'Yesterday')}</div>
        ${renderReminderHistoryItems(grouped.yesterday)}
      </div>`;
    }

    if (grouped.older.length > 0) {
      html += `<div class="reminder-history-group">
        <div class="reminder-history-group-title">${getMessage('reminderHistoryOlder', 'Older')}</div>
        ${renderReminderHistoryItems(grouped.older)}
      </div>`;
    }

    listContainer.innerHTML = html;

    listContainer.querySelectorAll('.reminder-history-item').forEach(item => {
      item.addEventListener('click', () => {
        const reminderId = item.dataset.reminderId;
        const bookmarkId = item.dataset.bookmarkId;
        const url = item.dataset.url;
        
        chrome.runtime.sendMessage({ action: 'markReminderRead', reminderId }, () => {
          loadUnreadReminderCount();
          item.classList.remove('unread');
          item.querySelector('.reminder-dot').style.display = 'none';
        });

        if (url && bookmarkId) {
          jumpToBookmarkLocation(bookmarkId, url);
        } else if (url) {
          chrome.tabs.create({ url, active: true });
        }
      });
    });
  });
}

function groupReminderHistory(history) {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;

  const grouped = { today: [], yesterday: [], older: [] };

  history.forEach(item => {
    if (item.triggeredAt >= todayStart) {
      grouped.today.push(item);
    } else if (item.triggeredAt >= yesterdayStart) {
      grouped.yesterday.push(item);
    } else {
      grouped.older.push(item);
    }
  });

  return grouped;
}

function renderReminderHistoryItems(items) {
  return items.map(item => {
    const time = new Date(item.triggeredAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const content = item.content || getMessage('bookmarkUntitled', 'Untitled');
    const platform = item.platform || '';
    const dotStyle = item.read ? 'display: none;' : '';
    const unreadClass = item.read ? '' : 'unread';

    return `
      <div class="reminder-history-item ${unreadClass}" data-reminder-id="${item.id}" data-bookmark-id="${item.bookmarkId || ''}" data-url="${escapeHtml(item.url || '')}">
        <span class="reminder-dot" style="${dotStyle}"></span>
        <div class="reminder-history-item-content">
          <div class="reminder-history-item-text">${escapeHtml(content.substring(0, 50))}${content.length > 50 ? '...' : ''}</div>
          <div class="reminder-history-item-meta">
            <span class="reminder-history-item-time">${time}</span>
            ${platform ? `<span class="reminder-history-item-platform">${escapeHtml(platform)}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}
