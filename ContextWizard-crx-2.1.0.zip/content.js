// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Content script for detecting and extracting AI chat conversations
(function() {
  'use strict';

  // Prevent double-initialization when executeScript races with registered content scripts.
  // The second injection just redefines globalThis helpers (safe IIFEs); only content.js
  // needs to guard its UI setup and message-listener registration.
  if (!globalThis.__cwSkipInit && globalThis.__cwContentInitialized) {
    return;
  }
  if (!globalThis.__cwSkipInit) {
    globalThis.__cwContentInitialized = true;
  }

  let currentPlatform = null;
  let isRecording = false;
  let isCapturing = false;
  let recordingIndicator = null;
  let suppressIndicatorClick = false;
  let lastSavedContent = '';
  let debounceTimer = null;
  let streamingRetryTimer = null;
  const DEBOUNCE_DELAY = 2000; // Wait 2 seconds after last change
  const GENERIC_URL_SEGMENTS = new Set(['app', 'chat', 'conversation', 'conversations', 'c', 'new', 'home', 'inbox', 'main', 'messages', 'settings', 'usage', 'profile', 'account', 'billing', 'dashboard', 'explore', 'library', 'discover', 'login', 'logout', 'signup', 'register', 'admin', 'help', 'support', 'docs', 'about', 'pricing', 'privacy', 'terms', 'projects', 'project', 'search', 'store', 'gpts', 'teams']);
  const CONVERSATION_PARAM_HINTS = ['conversation', 'conv', 'chat', 'thread', 'id', 'session'];
  const DRAG_SUPPRESS_DISTANCE = 3;
  const PENDING_FLUSH_BASE_DELAY = 2000;
  const PENDING_FLUSH_MAX_DELAY = 60000;
  let pendingFlushTimer = null;
  let nextPendingFlushDelay = PENDING_FLUSH_BASE_DELAY;
  let lastCheckedUrl = '';
  let indicatorRecreateTimer = null;
  let capturingGraceTimer = null;
  const CAPTURING_GRACE_DELAY = 5000; // 5s grace before clearing "Recording" on extraction failure
  const SEND_DETECTION_CAPTURE_DELAYS = [500, 2500, 7000];
  let sendDetector = null;
  let sendDetectorInitTimer = null;
  let sendDetectionCaptureTimers = [];

  // Search result navigation state
  let navContainer = null;
  let currentSearchNavContext = null;  // { searchQuery, resultsList, currentIndex }
  let currentNavIndex = -1;

  // In-page match navigation (highlights + scrolling)
  let pageMatchElements = [];
  let pageMatchCursor = -1;
  const PAGE_HIGHLIGHT_CLASS = 'contextwizard-page-highlight';
  let highlightRefreshTimer = null;
  let suppressHighlightRefreshUntil = 0;
  let highlightObserver = null;
  let userIsSelecting = false;
  let selectionCheckTimer = null;

  // Copy button state
  let currentConversation = null;
  let copyButton = null;
  let copyButtonOriginalTitle = '';
  let copyButtonRestoreTimeout = null;
  let copyTooltipElement = null;
  
  // Prompts button state
  let promptsButton = null;
  let promptsPopup = null;
  
  // Bookmark state
  let bookmarkButton = null;
  let bookmarkInputPopup = null;
  let bookmarkViewListButton = null;
  let bookmarkListPopup = null;
  let bookmarkSelectionRange = null;

  // Utility functions
  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  let conversationBookmarks = [];
  let bookmarkMarkers = [];
  let bookmarkButtonCreationPending = false;
  let pendingScrollRequest = null;
  let pendingScrollTimeout = null;

  function getMessage(key, fallback, substitutions) {
    try {
      if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
        const localized = chrome.i18n.getMessage(key, substitutions);
        if (localized) {
          return localized;
        }
      }
    } catch (error) {
      // Fall through to the provided fallback.
    }

    if (typeof fallback === 'function') {
      return fallback(Array.isArray(substitutions) ? substitutions : []);
    }

    return fallback;
  }
  
  // Auto-hide functionality for floating buttons
  let autoHideTimer = null;
  let hoverTimer = null;
  let isButtonsHidden = false;
  const AUTO_HIDE_DELAY = 30000; // 30 seconds
  const HOVER_DELAY = 500; // 0.5 seconds
  
  // Initialize on load
  init();

  // Delayed check for rating banner (ensure page fully loaded)
  setTimeout(() => {
    checkShouldShowRatingBanner();
  }, 5000);
  
  function init() {
    // Skip initialization in test environment to allow unit testing of functions
    if (globalThis.__cwSkipInit) {

      return;
    }
    
    detectPlatform();
    schedulePendingFlush();
    setupSelectionMonitoring();
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        flushPendingConversations();
      }
    });
    if (currentPlatform) {
      // Create indicator first so it exists when loadSettings callback fires
      createRecordingIndicator();
      // Then load settings which will update the indicator
      loadSettings();
      setupMutationObserver();
      setupSendDetector();
      setupUrlChangeObserver();
      // Initialize bookmark functionality
      initBookmarks();
      // Protect indicator from SPA DOM replacement (e.g., Gemini/Angular)
      protectRecordingIndicator();
    }
  }

  /**
   * Setup monitoring for user text selection to prevent highlight refresh from interfering
   */
  function setupSelectionMonitoring() {
    // Monitor selection changes
    document.addEventListener('selectionchange', () => {
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed) {
        // User is actively selecting text
        userIsSelecting = true;
        clearTimeout(selectionCheckTimer);
        selectionCheckTimer = setTimeout(() => {
          // Check if selection is still active after 500ms
          const currentSelection = window.getSelection();
          if (!currentSelection || currentSelection.isCollapsed) {
            userIsSelecting = false;
          }
        }, 500);
      } else {
        // Selection cleared/collapsed
        clearTimeout(selectionCheckTimer);
        selectionCheckTimer = setTimeout(() => {
          userIsSelecting = false;
        }, 100);
      }
    });

    // Additional mouseup handler to detect end of selection
    document.addEventListener('mouseup', () => {
      clearTimeout(selectionCheckTimer);
      selectionCheckTimer = setTimeout(() => {
        const selection = window.getSelection();
        if (!selection || selection.isCollapsed) {
          userIsSelecting = false;
        }
      }, 150);
    });
  }

  /**
   * Setup URL change observer to detect when URL gains a unique conversation ID.
   * This is important for platforms like Gemini where the first prompt is sent
   * at a generic URL (e.g., /app) and then the URL changes to include
   * a conversation ID after the AI responds.
   */
  function setupUrlChangeObserver() {
    lastCheckedUrl = globalThis.location.href;

    // Listen for popstate (browser back/forward navigation)
    globalThis.addEventListener('popstate', handleUrlChange);

    // Intercept pushState and replaceState for SPA navigation
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      handleUrlChange();
    };

    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      handleUrlChange();
    };

    // Navigation API (used by Angular and other modern SPAs like Gemini)
    if (globalThis.navigation) {
      globalThis.navigation.addEventListener('navigate', handleUrlChange);
    }
  }

  /**
   * Handle URL changes and trigger extraction if the URL now has a unique identifier.
   */
  function handleUrlChange() {
    const currentUrl = globalThis.location.href;
    if (currentUrl === lastCheckedUrl) {
      return;
    }

    const previousUrl = lastCheckedUrl;
    lastCheckedUrl = currentUrl;

    if (!isRecording) {
      return;
    }

    // Check if we transitioned from a non-unique URL to a unique one
    const hadUniqueId = hasUniqueConversationContext(previousUrl, currentPlatform);
    const hasUniqueId = hasUniqueConversationContext(currentUrl, currentPlatform);

    if (!hadUniqueId && hasUniqueId) {
      // Small delay to allow DOM to update with the first response
      setTimeout(() => {
        extractAndSaveConversation();
      }, 1000);
    }
  }
  
  // Detect which AI platform we're on
  function detectPlatform() {
    const hostname = globalThis.location.hostname;
    const currentUrl = globalThis.location.href;
    
    // Check default platforms
    for (const [domain, config] of Object.entries(PLATFORMS)) {
      // Extract just the hostname part from domain key (e.g., 'huggingface.co/chat' -> 'huggingface.co')
      const domainPart = domain.split('/')[0];
      if (hostname.includes(domainPart)) {
        currentPlatform = { domain, ...config };
        return;
      }
    }
    
    // Check custom platforms from storage
    chrome.storage.sync.get(['customPlatforms'], (result) => {
      const customPlatforms = (result.customPlatforms || [])
        .map((platform) => ({
          ...platform,
          urlPattern: (platform.urlPattern || '').trim()
        }))
        .filter((platform) => Boolean(platform.urlPattern));

      if (customPlatforms.length > 0) {
        const custom = customPlatforms.find((platform) =>
          matchesCustomPlatform(platform, currentUrl, hostname)
        );

        if (custom) {
          const domain = custom.host || extractHostnameFromPattern(custom.urlPattern);
          const requiresDistinctUrl = custom.requireDistinctUrl !== false;
          currentPlatform = {
            ...custom,
            domain,
            name: custom.name,
            enabled: custom.enabled !== false,
            isCustom: true,
            requireDistinctUrl: requiresDistinctUrl
          };
          // Re-initialize for custom platform
          loadSettings();
          setupMutationObserver();
          setupSendDetector();
          setupUrlChangeObserver();
          createRecordingIndicator();
          initBookmarks();
        }
      }
    });
  }

  function matchesCustomPlatform(platform, currentUrl, hostname) {
    const pattern = platform.urlPattern;
    if (!pattern) {
      return false;
    }
    const normalizedUrl = currentUrl.toLowerCase();
    const normalizedPattern = pattern.toLowerCase();

    if (pattern.includes('*')) {
      const compiled = platform.__compiledPattern || buildWildcardRegex(pattern);
      if (compiled?.test(currentUrl)) {
        platform.__compiledPattern = compiled;
        return true;
      }
    } else if (normalizedUrl.startsWith(normalizedPattern)) {
      return true;
    }

    const host = platform.host || extractHostnameFromPattern(pattern);
    if (host) {
      platform.host = host;
      const normalizedHostname = hostname.toLowerCase();
      const normalizedHost = host.toLowerCase();
      if (
        normalizedHostname === normalizedHost ||
        normalizedHostname.endsWith(`.${normalizedHost}`)
      ) {
        return true;
      }
    }

    return false;
  }

  const SPECIAL_CHARS_REGEX = /[.*+?^${}()|[\]\\]/g;

  function buildWildcardRegex(pattern) {
    try {
      const escapedSegments = pattern
        .split('*')
        .map((segment) => escapeRegex(segment))
        .join('.*');
      return new RegExp(`^${escapedSegments}$`, 'i');
    } catch (error) {
      console.warn('[ContextWizard] Failed to build matcher for custom pattern:', pattern, error);
      return null;
    }
  }

  function escapeRegex(value) {
    return value.replaceAll(SPECIAL_CHARS_REGEX, String.raw`\$&`);
  }

  function extractHostnameFromPattern(pattern) {
    if (!pattern) {
      return '';
    }
    try {
      const normalized = pattern.includes('://') ? pattern : `https://${pattern}`;
      const sanitized = normalized.replaceAll('*', '');
      const url = new URL(sanitized);
      return url.hostname;
    } catch (error) {
      console.warn('[ContextWizard] Unable to parse custom platform host from pattern:', pattern, error);
      return pattern
        .replace(/^https?:\/\//i, '')
        .replaceAll('*', '')
        .replace(/\/.*$/, '')
        .trim();
    }
  }
  
  // Load settings to check if this platform is enabled
  function loadSettings() {
    chrome.storage.sync.get(['platformSettings'], (result) => {
      const settings = result.platformSettings || {};
      const platformKey = currentPlatform.domain;
      
      if (settings[platformKey] === undefined) {
        isRecording = currentPlatform.enabled !== false;
      } else {
        isRecording = settings[platformKey].enabled !== false;
      }
      
      // Check if the recording indicator was removed from DOM during async gap
      // (e.g., by SPA re-render on Gemini/Angular). If so, recreate it before
      // updating visual state so the user sees the indicator.
      if (recordingIndicator && !document.contains(recordingIndicator)) {
        createRecordingIndicator();
      }

      updateRecordingIndicator();
    });
  }

  // Protect recording indicator from SPA DOM replacement (e.g., Gemini/Angular).
  // Uses a MutationObserver to detect when the indicator is removed from the DOM
  // by framework re-renders and recreates it automatically.
  function protectRecordingIndicator() {
    const target = document.documentElement || document.body;
    if (!target) return;
    const observer = new MutationObserver(() => {
      if (indicatorRecreateTimer) return;
      if (recordingIndicator && !document.contains(recordingIndicator)) {
        if (currentPlatform) {
          indicatorRecreateTimer = setTimeout(() => {
            indicatorRecreateTimer = null;
            createRecordingIndicator();
            updateRecordingIndicator();
          }, 0);
        }
      }
    });
    observer.observe(target, { childList: true, subtree: true });
  }
  
  // Create visual indicator for recording status
  function createRecordingIndicator() {
    if (recordingIndicator) {
      recordingIndicator.remove();
    }
    if (copyButton) {
      copyButton.remove();
      copyButton = null;
    }
    suppressIndicatorClick = false;
    recordingIndicator = document.createElement('div');
    recordingIndicator.id = 'contextwizard-indicator';
    const label = chrome.i18n.getMessage('recording') || 'Recording';
    const hint = chrome.i18n.getMessage('recordingIndicatorHint');
    recordingIndicator.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 16 16">
        <circle cx="8" cy="8" r="6" fill="currentColor"/>
      </svg>
      <span class="indicator-label">${label}</span>
    `;
    recordingIndicator.setAttribute('role', 'button');
    recordingIndicator.setAttribute('tabindex', '0');
    recordingIndicator.setAttribute('aria-live', 'polite');
    recordingIndicator.setAttribute('aria-label', hint ? `${label}. ${hint}` : label);
    if (hint) {
      recordingIndicator.setAttribute('title', hint);
    } else {
      recordingIndicator.removeAttribute('title');
    }
    
    // Append to document root (html element) instead of body to avoid z-index stacking context issues
    // This ensures the indicator appears above all other content
    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(recordingIndicator);
    createCopyButton();
    createPromptsButton();
    updateCopyButtonVisibility();

    // Don't call updateRecordingIndicator() here - it will be called from loadSettings()
    // after isRecording is properly set
    recordingIndicator.addEventListener('click', handleIndicatorClick);
    recordingIndicator.addEventListener('keydown', handleIndicatorKeydown);

    // Wait for element to be rendered before initializing position
    setTimeout(() => {
      makeDraggable(recordingIndicator);
      initAutoHideFunctionality();
    }, 100);
  }

  // Create copy button below the recording indicator
  function createCopyButton() {
    if (copyButton) {
      copyButton.remove();
    }

    copyButton = document.createElement('div');
    copyButton.id = 'contextwizard-copy-button';
    copyButton.className = 'contextwizard-copy-button';  // Always icon-only mode
    const copyLabel = chrome.i18n.getMessage('conversationCopyContextButton') || 'Copy';
    const copyHint = chrome.i18n.getMessage('copyButtonHint');
    copyButton.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M4 1.5H3a2 2 0 00-2 2V14a2 2 0 002 2h10a2 2 0 002-2V3.5a2 2 0 00-2-2h-1v1h1a1 1 0 011 1V14a1 1 0 01-1 1H3a1 1 0 01-1-1V3.5a1 1 0 011-1h1v-1z"/>
        <path d="M9.5 1a.5.5 0 01.5.5v1a.5.5 0 01-.5.5h-3a.5.5 0 01-.5-.5v-1a.5.5 0 01.5-.5h3zm-3-1A1.5 1.5 0 005 1.5v1A1.5 1.5 0 006.5 4h3A1.5 1.5 0 0011 2.5v-1A1.5 1.5 0 009.5 0h-3z"/>
      </svg>
    `;
    copyButton.setAttribute('role', 'button');
    copyButton.setAttribute('tabindex', '0');
    copyButton.setAttribute('aria-label', copyLabel);
    if (copyHint) {
      copyButton.setAttribute('title', copyHint);
      copyButtonOriginalTitle = copyHint;
    } else {
      copyButton.removeAttribute('title');
      copyButtonOriginalTitle = '';
    }

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(copyButton);

    copyButton.addEventListener('click', (e) => {
      handleCopyButtonClick(e);
      handleUserInteraction();
    });
    copyButton.addEventListener('keydown', handleCopyButtonKeydown);
  }

  // Create prompts button to the left of copy button
  function createPromptsButton() {
    if (promptsButton) {
      promptsButton.remove();
    }

    promptsButton = document.createElement('div');
    promptsButton.id = 'contextwizard-prompts-button';
    promptsButton.className = 'contextwizard-prompts-button';
    
    const promptsLabel = chrome.i18n.getMessage('promptEditorTemplatesButton') || '常用提示词';
    promptsButton.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M7.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h4zM9 1.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1zM7.5 4a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h4zM9 4.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1zM7.5 7a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h4zM9 7.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1zM7.5 10a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h4zM9 10.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1z"/>
      </svg>
    `;
    
    promptsButton.setAttribute('role', 'button');
    promptsButton.setAttribute('tabindex', '0');
    promptsButton.setAttribute('aria-label', promptsLabel);
    promptsButton.setAttribute('title', promptsLabel);

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(promptsButton);

    promptsButton.addEventListener('click', (e) => {
      handlePromptsButtonClick(e);
      handleUserInteraction();
    });
    promptsButton.addEventListener('keydown', handlePromptsButtonKeydown);
  }

  // Update copy button visibility based on conversation content
  function updateCopyButtonVisibility() {
    if (!copyButton) {
      return;
    }

    const hasContent = currentConversation && currentConversation.messages && currentConversation.messages.length > 0;
    
    // Don't change display if buttons are hidden - the auto-hide functionality will handle this
    if (!isButtonsHidden) {
      copyButton.style.display = hasContent ? 'flex' : 'none';
    }
    
    // Hide tooltip when copy button is hidden
    if (!hasContent) {
      hideCopyTooltip();
    }

    if (hasContent) {
      if (copyButtonRestoreTimeout) {
        clearTimeout(copyButtonRestoreTimeout);
        copyButtonRestoreTimeout = null;
      }
      if (copyButtonOriginalTitle) {
        copyButton.setAttribute('title', copyButtonOriginalTitle);
      } else {
        copyButton.removeAttribute('title');
      }
      updateCopyButtonPosition();
    }
    
    updatePromptsButtonVisibility();
  }

  async function updatePromptsButtonVisibility() {
    if (!promptsButton) return;

    try {
      const result = await new Promise(resolve => {
        chrome.storage.local.get(['promptEditorTemplates'], resolve);
      });
      const hasTemplates = result.promptEditorTemplates && 
                           Object.keys(result.promptEditorTemplates).length > 0;

      if (!isButtonsHidden) {
        promptsButton.style.display = hasTemplates ? 'flex' : 'none';
      }
      if (hasTemplates) {
        updatePromptsButtonPosition();
      }
    } catch (error) {
      console.warn('[ContextWizard] Could not load prompt templates:', error);
      promptsButton.style.display = 'none';
    }
  }

  // Update copy button position to stay below recording indicator
  function updateCopyButtonPosition() {
    if (!copyButton || !recordingIndicator) {
      return;
    }

    const indicatorRect = recordingIndicator.getBoundingClientRect();
    const copyButtonSize = 32;  // Fixed size for icon-only mode

    // Position below the indicator, centered
    const top = indicatorRect.bottom + 8;  // 8px gap
    const left = indicatorRect.left + (indicatorRect.width - copyButtonSize) / 2;

    // Ensure within viewport bounds
    const clampedTop = Math.max(8, Math.min(top, window.innerHeight - copyButtonSize - 8));
    const clampedLeft = Math.max(8, Math.min(left, window.innerWidth - copyButtonSize - 8));

    copyButton.style.top = `${clampedTop}px`;
    copyButton.style.left = `${clampedLeft}px`;
    
    updatePromptsButtonPosition();
  }

  // Update prompts button position to stay left of copy button
  function updatePromptsButtonPosition() {
    if (!promptsButton || !recordingIndicator || !copyButton) {
      return;
    }

    const indicatorRect = recordingIndicator.getBoundingClientRect();
    const promptsButtonSize = 32;
    const copyButtonSize = 32;  // Copy button size
    const gap = 8;  // Gap between buttons

    // Position left of copy button, centered with recording indicator
    const top = indicatorRect.bottom + 8;  // Same as copy button
    const left = indicatorRect.left + (indicatorRect.width - copyButtonSize) / 2 - promptsButtonSize - gap;

    // Ensure within viewport bounds
    const clampedTop = Math.max(8, Math.min(top, window.innerHeight - promptsButtonSize - 8));
    const clampedLeft = Math.max(8, Math.min(left, window.innerWidth - promptsButtonSize - 8));

    promptsButton.style.top = `${clampedTop}px`;
    promptsButton.style.left = `${clampedLeft}px`;
  }

  // Handle copy button click
  function handleCopyButtonClick(event) {
    event.stopPropagation();

    if (copyButtonRestoreTimeout) {
      clearTimeout(copyButtonRestoreTimeout);
      copyButtonRestoreTimeout = null;
    }

    if (!currentConversation || !currentConversation.messages || currentConversation.messages.length === 0) {
      showCopyTooltip(
        copyButton,
        getMessage('conversationCopyContextNothing', 'Nothing to copy'),
        'error'
      );
      copyButtonRestoreTimeout = setTimeout(() => {
        hideCopyTooltip();
      }, 2200);
      return;
    }

    const contextText = formatConversationAsContextText(currentConversation);

    if (!contextText) {
      showCopyTooltip(
        copyButton,
        getMessage('conversationCopyContextNothing', 'Nothing to copy'),
        'error'
      );
      copyButtonRestoreTimeout = setTimeout(() => {
        hideCopyTooltip();
      }, 2200);
      return;
    }

    copyTextToClipboard(contextText).then(success => {
      showCopyTooltip(
        copyButton,
        success
          ? getMessage('conversationCopyContextSuccess', 'Copied to clipboard')
          : getMessage('conversationCopyContextFailed', 'Failed to copy'),
        success ? 'success' : 'error'
      );

      copyButtonRestoreTimeout = setTimeout(() => {
        hideCopyTooltip();
      }, 2200);
    }).catch(error => {
      console.error('[ContextWizard] Error copying context:', error);

      showCopyTooltip(
        copyButton,
        getMessage('conversationCopyContextFailed', 'Failed to copy'),
        'error'
      );
      copyButtonRestoreTimeout = setTimeout(() => {
        hideCopyTooltip();
      }, 2200);
    });
  }
  
  // Show tooltip after copying
  function showCopyTooltip(button, message, type = 'success') {
    if (!button) {
      return;
    }
    
    // Remove existing tooltip
    hideCopyTooltip();
    
    const tooltip = document.createElement('div');
    tooltip.id = 'contextwizard-copy-tooltip';
    tooltip.className = 'contextwizard-copy-tooltip';
    tooltip.textContent = message || getMessage('copiedToClipboard', 'Copied to clipboard');
    
    const buttonRect = button.getBoundingClientRect();
    
    // Anchor to the button and offset upward so the tooltip stays visible.
    const tooltipTop = buttonRect.top;
    const tooltipLeft = buttonRect.left + buttonRect.width / 2;
    const isError = type === 'error';
    
    tooltip.style.position = 'fixed';
    tooltip.style.left = `${tooltipLeft}px`;
    tooltip.style.top = `${tooltipTop}px`;
    tooltip.style.transform = 'translate(-50%, calc(-100% - 8px))';
    tooltip.style.padding = '6px 10px';
    tooltip.style.background = isError ? 'rgba(146, 34, 34, 0.95)' : 'rgba(18, 18, 18, 0.92)';
    tooltip.style.border = `1px solid ${isError ? 'rgba(255, 170, 170, 0.45)' : 'rgba(255, 255, 255, 0.16)'}`;
    tooltip.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.28)';
    tooltip.style.color = '#ffffff';
    tooltip.style.fontSize = '12px';
    tooltip.style.borderRadius = '6px';
    tooltip.style.whiteSpace = 'nowrap';
    tooltip.style.zIndex = '2147483648';
    tooltip.style.pointerEvents = 'none';

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(tooltip);
    copyTooltipElement = tooltip;
  }
  
  // Hide tooltip
  function hideCopyTooltip() {
    if (copyTooltipElement) {
      copyTooltipElement.remove();
      copyTooltipElement = null;
    }
  }

  function handleCopyButtonKeydown(event) {
    if (!copyButton) {
      return;
    }
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleCopyButtonClick(event);
    }
  }

  // Handle prompts button click
  function handlePromptsButtonClick(event) {
    event.preventDefault();
    showPromptsPopup();
  }

  // Handle prompts button keyboard events
  function handlePromptsButtonKeydown(event) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      showPromptsPopup();
    } else if (event.key === 'Escape') {
      hidePromptsPopup();
    }
  }

  // Shared utility functions are loaded from shared-utils.js
  // - extractMessageText
  // - formatConversationAsContextText
  // - copyTextToClipboard

  // ========== Bookmark Functionality ==========
  // Create bookmark button next to copy button
   function createBookmarkButton() {
    if (bookmarkButtonCreationPending) {
      return;
    }
    bookmarkButtonCreationPending = true;
    
    if (bookmarkButton) {
      bookmarkButton.remove();
    }

    bookmarkButton = document.createElement('div');
    bookmarkButton.id = 'contextwizard-bookmark-button';
    bookmarkButton.className = 'contextwizard-inactive'; // Start as inactive
    const bookmarkLabel = chrome.i18n.getMessage('bookmarkButton') || 'Bookmark';
    const bookmarkHint = chrome.i18n.getMessage('bookmarkButtonTooltip') || 'Create bookmark';
    bookmarkButton.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor">
        <path d="M3 3a2 2 0 012-2h10a2 2 0 012 2v14.5a.5.5 0 01-.777.416L10 14.101l-6.223 3.815A.5.5 0 013 17.5V3z"/>
      </svg>
    `;
    bookmarkButton.setAttribute('role', 'button');
    bookmarkButton.setAttribute('tabindex', '0');
    bookmarkButton.setAttribute('aria-label', bookmarkLabel);
    bookmarkButton.setAttribute('title', bookmarkHint);
    bookmarkButton.style.display = 'none'; // Hidden until text is selected
    bookmarkButton.style.position = 'fixed'; // Use fixed positioning to follow recording indicator

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(bookmarkButton);
    
    bookmarkButton.addEventListener('click', handleBookmarkButtonClick);
    bookmarkButton.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        handleBookmarkButtonClick(event);
      }
    });
    
    bookmarkButtonCreationPending = false;
  }

  // Create bookmark view list button next to copy button
  function createBookmarkViewListButton() {
    if (bookmarkViewListButton) {
      bookmarkViewListButton.remove();
    }

    bookmarkViewListButton = document.createElement('div');
    bookmarkViewListButton.id = 'contextwizard-bookmark-view-list-button';
    const viewListHint = chrome.i18n.getMessage('bookmarkViewListTooltip') || 'View bookmarks in this conversation';
    // Use same bookmark icon as in popup.html
    bookmarkViewListButton.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor">
        <path d="M3 3a2 2 0 012-2h10a2 2 0 012 2v14.5a.5.5 0 01-.777.416L10 14.101l-6.223 3.815A.5.5 0 013 17.5V3z"/>
      </svg>
    `;
    bookmarkViewListButton.setAttribute('role', 'button');
    bookmarkViewListButton.setAttribute('tabindex', '0');
    bookmarkViewListButton.setAttribute('aria-label', viewListHint);
    bookmarkViewListButton.setAttribute('title', viewListHint);
    bookmarkViewListButton.style.display = 'none'; // Hidden until bookmarks exist

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(bookmarkViewListButton);

    bookmarkViewListButton.addEventListener('click', handleBookmarkViewListClick);
    bookmarkViewListButton.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        handleBookmarkViewListClick(event);
      }
    });
  }

  // Detect whether a selection lives inside an editable region (e.g. the chat
  // input box). Bookmarks only make sense for read-only AI response text, so
  // selections inside <input>, <textarea>, or contenteditable must be ignored.
  function isSelectionInEditable(selection) {
    if (!selection || selection.rangeCount === 0) {
      return false;
    }
    const range = selection.getRangeAt(0);
    let node = range.commonAncestorContainer;
    if (node && node.nodeType !== Node.ELEMENT_NODE) {
      node = node.parentElement;
    }
    if (!node) {
      return false;
    }
    if (node.isContentEditable) {
      return true;
    }
    return !!node.closest('input, textarea, [contenteditable="true"], [contenteditable=""]');
  }

  // Monitor text selection to show/hide bookmark button
  function monitorTextSelection() {
    // Use both mouseup and selectionchange for better coverage
    let selectionTimeout = null;

    const isSelectionInContextWizardUI = (sel) => {
      if (!sel || sel.rangeCount === 0) return false;
      const range = sel.getRangeAt(0);
      const container = range.startContainer;
      const node = container.nodeType === Node.ELEMENT_NODE ? container : container.parentNode;
      return !!(node && node.closest && (
        node.closest('#contextwizard-bookmark-list-popup') ||
        node.closest('#contextwizard-bookmark-input-popup') ||
        node.closest('#contextwizard-recording-indicator') ||
        node.closest('#contextwizard-copy-button') ||
        node.closest('#contextwizard-bookmark-button') ||
        node.closest('#contextwizard-bookmark-view-list-button') ||
        node.closest('.contextwizard-tooltip') ||
        node.closest('.contextwizard-detail-panel') ||
        node.closest('.contextwizard-chat-popup')
      ));
    };

    const handleSelection = () => {
      clearTimeout(selectionTimeout);
      selectionTimeout = setTimeout(() => {
        const selection = window.getSelection();
        const hasSelection = selection && !selection.isCollapsed && selection.toString().trim().length > 0
          && !isSelectionInEditable(selection)
          && !isSelectionInContextWizardUI(selection);

        if (hasSelection) {
          const selectedText = selection.toString().trim();
          createBookmarkInputPopup(selectedText, selection);
        } else if (!bookmarkInputPopup) {
          // Only hide if popup is not already shown
          hideBookmarkButton();
        }
        // If popup is shown but no selection, keep popup visible
      }, 800);
    };

    document.addEventListener('mouseup', handleSelection);
    document.addEventListener('selectionchange', handleSelection);
    
    // Hide popup on mousedown (start of new selection), but not if clicking on popup
    document.addEventListener('mousedown', (e) => {
      if (e.target.closest('#contextwizard-bookmark-input-popup')) {
        return;
      }
      // Hide popup when clicking outside
      hideBookmarkButton();
    });
  }

  // Hide copy button label (when bookmark button is shown)
  function hideCopyButtonLabel() {
    if (!copyButton) return;
    copyButton.classList.add('icon-only');
  }

  // Show copy button label (when bookmark button is hidden)
  function showCopyButtonLabel() {
    if (!copyButton) return;
    copyButton.classList.remove('icon-only');
  }

  // Show bookmark button relative to recording indicator
  function showBookmarkButton(selection) {
    if (!bookmarkButton) {
      return;
    }

    if (!isButtonsHidden) {
      bookmarkButton.style.display = 'flex';
    }
    bookmarkButton.style.position = 'fixed';

    // Must hide label first to ensure dimensions are correct (32x32) for positioning calculations
    hideCopyButtonLabel();
    
    adjustCopyButtonPositionForBookmark();
    updateBookmarkButtonPosition();
  }

  // Adjust copy button position when bookmark button is shown (move left to make room)
  function adjustCopyButtonPositionForBookmark() {
    if (!copyButton || !recordingIndicator) {
      return;
    }

    const indicatorRect = recordingIndicator.getBoundingClientRect();
    const copyButtonSize = 32;
    const bookmarkButtonSize = 32;
    const buttonGap = 8;  // Gap between copy button and bookmark button
    const offsetFromCenter = (bookmarkButtonSize + buttonGap) / 2;

    // Position copy button to the left of center to make room for bookmark button
    const top = indicatorRect.bottom + 8;
    const left = indicatorRect.left + (indicatorRect.width - copyButtonSize) / 2 - offsetFromCenter;

    // Ensure within viewport bounds
    const clampedTop = Math.max(8, Math.min(top, window.innerHeight - copyButtonSize - 8));
    const clampedLeft = Math.max(8, Math.min(left, window.innerWidth - copyButtonSize - bookmarkButtonSize - buttonGap - 8));

    copyButton.style.top = `${clampedTop}px`;
    copyButton.style.left = `${clampedLeft}px`;
  }

  // Restore copy button position when bookmark button is hidden
  function restoreCopyButtonPosition() {
    updateCopyButtonPosition();
  }

  // Update bookmark button position to stay to the right of copy button
  function updateBookmarkButtonPosition() {
    if (!bookmarkButton || !copyButton || !recordingIndicator) {
      return;
    }

    const copyButtonRect = copyButton.getBoundingClientRect();
    const bookmarkButtonRect = bookmarkButton.getBoundingClientRect();
    const bookmarkButtonWidth = bookmarkButtonRect.width || 32;
    const bookmarkButtonHeight = bookmarkButtonRect.height || 32;
    const buttonGap = 8;  // Gap between buttons

    // Position bookmark button to the right of copy button, same top
    const top = copyButtonRect.top;
    const left = copyButtonRect.right + buttonGap;

    // Ensure within viewport bounds
    const clampedTop = Math.max(8, Math.min(top, window.innerHeight - bookmarkButtonHeight - 8));
    const clampedLeft = Math.max(8, Math.min(left, window.innerWidth - bookmarkButtonWidth - 8));

    bookmarkButton.style.top = `${clampedTop}px`;
    bookmarkButton.style.left = `${clampedLeft}px`;
  }

  // Hide bookmark button
  function hideBookmarkButton() {
    if (bookmarkButton && !isButtonsHidden) {
      bookmarkButton.style.display = 'none';
    }
    if (bookmarkInputPopup) {
      bookmarkInputPopup.remove();
      bookmarkInputPopup = null;
      bookmarkSelectionRange = null;
    }
    restoreCopyButtonPosition();
    showCopyButtonLabel();
  }

  // Check if selection spans multiple lines
  function isSelectionMultiLine(selection) {
    if (!selection || selection.rangeCount === 0) return false;
    
    const range = selection.getRangeAt(0);
    
    // Method 1: Check if there are actual line breaks in the selected text
    const selectedText = selection.toString();
    const lineBreaks = selectedText.match(/\n/g);
    if (lineBreaks && lineBreaks.length > 0) {
      return true;
    }
    
    // Method 2: Check by comparing bounding rectangles
    // This is the most reliable method for detecting visual multi-line selections
    try {
      const rects = range.getClientRects();
      if (rects.length > 1) {
        // Check if rectangles are vertically separated (indicating different lines)
        // Sometimes there can be multiple rects for the same line due to formatting
        let firstRectTop = rects[0].top;
        for (let i = 1; i < rects.length; i++) {
          // If we find a rect that's significantly below the first one, it's a new line
          if (rects[i].top - firstRectTop > 10) { // 10px threshold to account for minor formatting differences
            return true;
          }
        }
      }
    } catch (e) {
      // Fallback if getClientRects fails
    }
    
    // Method 3: Check if selection spans multiple block-level elements
    // Only consider it multi-line if it spans different block elements
    const startContainer = range.startContainer;
    const endContainer = range.endContainer;
    
    if (startContainer !== endContainer) {
      // Get the closest block-level elements
      const getBlockParent = (node) => {
        while (node && node !== document.body) {
          // Skip text nodes and other non-element nodes
          if (node.nodeType === Node.ELEMENT_NODE) {
            const display = window.getComputedStyle(node).display;
            if (display === 'block' || display === 'flex' || display === 'grid' || 
                node.tagName === 'P' || node.tagName === 'DIV' || node.tagName === 'LI') {
              return node;
            }
          }
          node = node.parentNode;
        }
        return null;
      };
      
      const startBlock = getBlockParent(startContainer);
      const endBlock = getBlockParent(endContainer);
      
      // Only consider it multi-line if it spans different block elements
      if (startBlock && endBlock && startBlock !== endBlock) {
        return true;
      }
    }
    
    return false;
  }

  // Handle bookmark button click
  function handleBookmarkButtonClick(event) {
    event.stopPropagation();
    
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      return;
    }

    const selectedText = selection.toString().trim();
    if (!selectedText) {
      return;
    }

    createBookmarkInputPopup(selectedText, selection);
  }

  function buildReminderSummary(r) {
    if (!r || !r.enabled) return '';
    const timeStr = r.timeOfDay || '09:00';
    const [h, m] = timeStr.split(':');
    const time = `${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    switch (r.recurrence) {
      case 'daily': return '\u23F0 ' + getMessage('reminderSummaryDaily', `Daily at ${time}`, [time]);
      case 'weekdays': return '\u23F0 ' + getMessage('reminderSummaryWeekdays', `Weekdays at ${time}`, [time]);
      case 'weekly': {
        if (r.weekdays && r.weekdays.length > 0) {
          const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
          const days = r.weekdays.sort().map(d => dayNames[d]).join(', ');
          return `\u23F0 ${days} at ${time}`;
        }
        return '\u23F0 ' + getMessage('reminderSummaryWeekdays', `Weekdays at ${time}`, [time]);
      }
      case 'monthly':
      case 'monthlyNth': {
        if (r.monthlyNthWeekday != null && r.monthlyWeekday != null) {
          const nthLabels = ['', '1st', '2nd', '3rd', '4th', 'Last'];
          const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
          const nth = r.monthlyNthWeekday === -1 ? 'Last' : nthLabels[r.monthlyNthWeekday];
          return `\u23F0 ${nth} ${dayNames[r.monthlyWeekday]} of month at ${time}`;
        }
        const day = String(r.monthlyDay || 1);
        return '\u23F0 ' + getMessage('reminderSummaryMonthlyDay', `Day ${day} of month at ${time}`, [day, time]);
      }
      case 'none':
      default: {
        if (r.time) {
          const d = new Date(r.time * 1000);
          const date = d.toLocaleDateString();
          return '\u23F0 ' + getMessage('reminderSummaryOnce', `${date} ${time}`, [date, time]);
        }
        return '\u23F0 ' + getMessage('reminderSummaryFallback', 'Reminder set');
      }
    }
  }

  // Create input popup for bookmark creation
  function createBookmarkInputPopup(selectedText, selection) {
    if (bookmarkInputPopup) {
      bookmarkInputPopup.remove();
      bookmarkInputPopup = null;
      bookmarkSelectionRange = null;
    }

    if (!selection || selection.isCollapsed) {
      return;
    }

    // Never offer bookmarks for text selected inside an editable field
    // (the chat input box selects text but is not bookmarkable content).
    if (isSelectionInEditable(selection)) {
      return;
    }

    const range = selection.getRangeAt(0);
    if (!range) {
      return;
    }

    // Store the range for later use when saving the bookmark
    bookmarkSelectionRange = range;

    const rect = range.getBoundingClientRect();

    if (rect.width === 0 && rect.height === 0) {
      return;
    }

    // Safely get i18n messages with fallback
    let placeholder = 'Bookmark content...';
    let createBtnText = 'Create';
    let cancelBtnText = 'Cancel';
    let copiedToClipboardText = 'Selected text copied to clipboard';
    try {
      placeholder = chrome.i18n.getMessage('bookmarkCreatePlaceholder') || placeholder;
      createBtnText = chrome.i18n.getMessage('bookmarkCreateButton') || createBtnText;
      cancelBtnText = chrome.i18n.getMessage('bookmarkCancelButton') || cancelBtnText;
      copiedToClipboardText = chrome.i18n.getMessage('bookmarkCopiedToClipboard') || copiedToClipboardText;
    } catch (e) {
      // Using defaults
    }

    // Copy selected text to clipboard with formatting
    const copyToClipboard = async () => {
      try {
        // Try to copy with formatting first
        if (typeof copyFormattedContent === 'function') {
          const success = await copyFormattedContent(selection);
          if (success) {
            return;
          }
        }
        
        // Fallback to plain text copy
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(selectedText);
        } else {
          const textarea = document.createElement('textarea');
          textarea.value = selectedText;
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
        }
      } catch (e) {
        // Copy failed silently
      }
    };
    copyToClipboard();

    bookmarkInputPopup = document.createElement('div');
    bookmarkInputPopup.id = 'contextwizard-bookmark-input-popup';
    
    // Suppress highlight refresh while popup is open to prevent range invalidation
    suppressHighlightRefreshUntil = Date.now() + 5000;
    
    bookmarkInputPopup.style.position = 'fixed';
    const reminderBtnLabel = getMessage('bookmarkReminderButton', 'Set reminder');
    const reminderOnceLabel = getMessage('reminderTypeOnce', 'Once');
    const reminderDailyLabel = getMessage('reminderTypeDaily', 'Daily');
    const reminderWeeklyLabel = getMessage('reminderTypeWeekly', 'Weekly');
    const reminderMonthlyLabel = getMessage('reminderTypeMonthly', 'Monthly');
    const reminderSaveLabel = getMessage('reminderSaveBtn', 'OK');
    const reminderCancelLabel = getMessage('reminderCancelBtn', 'Cancel');
    const reminderTimeLabel = getMessage('reminderTimeLabel', 'Time');
    const reminderRepeatDaysLabel = getMessage('reminderRepeatDays', 'Repeat on');
    const reminderRepeatModeLabel = getMessage('reminderRepeatMode', 'Repeat');
    const reminderMonthlyByDayLabel = getMessage('reminderMonthlyByDay', 'By date');
    const reminderMonthlyByNthLabel = getMessage('reminderMonthlyByNth', 'By weekday');
    const reminderDayOfMonthLabel = getMessage('reminderDayOfMonth', 'Day of month');
    const weekdaySun = getMessage('weekdaySun', 'S');
    const weekdayMon = getMessage('weekdayMon', 'M');
    const weekdayTue = getMessage('weekdayTue', 'T');
    const weekdayWed = getMessage('weekdayWed', 'W');
    const weekdayThu = getMessage('weekdayThu', 'T');
    const weekdayFri = getMessage('weekdayFri', 'F');
    const weekdaySat = getMessage('weekdaySat', 'S');

    const monthlyDayOptions = Array.from({length: 31}, (_, i) => `<option value="${i + 1}">${i + 1}</option>`).join('');

    // Auto-recommend bookmark name when in ContextChat state
    let recommendedName = selectedText.substring(0, 200);
    const ctxSession = globalThis.__contextSession;
    if (ctxSession && typeof ctxSession.generateBookmarkName === 'function') {
      recommendedName = ctxSession.generateBookmarkName();
    }
    const safeName = recommendedName.replace(/"/g, '&quot;');

    bookmarkInputPopup.innerHTML = `
      <input type="text" 
        id="contextwizard-bookmark-input" 
        placeholder="${placeholder}"
        value="${safeName}"
        list="contextwizard-bookmark-suggestions"
      />
      <datalist id="contextwizard-bookmark-suggestions"></datalist>
      <div class="contextwizard-bookmark-reminder-panel" id="contextwizard-bookmark-reminder-panel">
        <div class="contextwizard-reminder-row">
          <button class="contextwizard-reminder-type-btn active" data-type="once">${reminderOnceLabel}</button>
          <button class="contextwizard-reminder-type-btn" data-type="daily">${reminderDailyLabel}</button>
          <button class="contextwizard-reminder-type-btn" data-type="weekly">${reminderWeeklyLabel}</button>
          <button class="contextwizard-reminder-type-btn" data-type="monthly">${reminderMonthlyLabel}</button>
        </div>
        <div class="contextwizard-reminder-options" id="contextwizard-reminder-once-options">
          <div class="contextwizard-reminder-row">
            <input type="date" id="contextwizard-reminder-date" class="contextwizard-reminder-input">
            <input type="time" id="contextwizard-reminder-time" class="contextwizard-reminder-input" value="09:00">
          </div>
        </div>
        <div class="contextwizard-reminder-options hidden" id="contextwizard-reminder-daily-options">
          <div class="contextwizard-reminder-row">
            <label class="contextwizard-reminder-label">${reminderTimeLabel}</label>
            <input type="time" id="contextwizard-reminder-daily-time" class="contextwizard-reminder-input" value="09:00">
          </div>
        </div>
        <div class="contextwizard-reminder-options hidden" id="contextwizard-reminder-weekly-options">
          <div class="contextwizard-reminder-row">
            <label class="contextwizard-reminder-label">${reminderTimeLabel}</label>
            <input type="time" id="contextwizard-reminder-weekly-time" class="contextwizard-reminder-input" value="09:00">
          </div>
          <div class="contextwizard-reminder-row">
            <label class="contextwizard-reminder-label">${reminderRepeatDaysLabel}</label>
            <div class="contextwizard-reminder-weekday-btns">
              <button class="contextwizard-weekday-btn" data-day="0">${weekdaySun}</button>
              <button class="contextwizard-weekday-btn active" data-day="1">${weekdayMon}</button>
              <button class="contextwizard-weekday-btn active" data-day="2">${weekdayTue}</button>
              <button class="contextwizard-weekday-btn active" data-day="3">${weekdayWed}</button>
              <button class="contextwizard-weekday-btn active" data-day="4">${weekdayThu}</button>
              <button class="contextwizard-weekday-btn active" data-day="5">${weekdayFri}</button>
              <button class="contextwizard-weekday-btn" data-day="6">${weekdaySat}</button>
            </div>
          </div>
        </div>
        <div class="contextwizard-reminder-options hidden" id="contextwizard-reminder-monthly-options">
          <div class="contextwizard-reminder-row">
            <label class="contextwizard-reminder-label">${reminderTimeLabel}</label>
            <input type="time" id="contextwizard-reminder-monthly-time" class="contextwizard-reminder-input" value="09:00">
          </div>
          <div class="contextwizard-reminder-row">
            <label class="contextwizard-reminder-label">${reminderRepeatModeLabel}</label>
            <div class="contextwizard-reminder-monthly-mode-group">
              <button class="contextwizard-monthly-mode-btn active" data-mode="day">${reminderMonthlyByDayLabel}</button>
              <button class="contextwizard-monthly-mode-btn" data-mode="nth">${reminderMonthlyByNthLabel}</button>
            </div>
          </div>
          <div class="contextwizard-reminder-row" id="contextwizard-reminder-monthly-day-field">
            <label class="contextwizard-reminder-label">${reminderDayOfMonthLabel}</label>
            <select id="contextwizard-reminder-monthly-day" class="contextwizard-reminder-input">${monthlyDayOptions}</select>
          </div>
          <div class="contextwizard-reminder-row hidden" id="contextwizard-reminder-monthly-nth-field">
            <select id="contextwizard-reminder-monthly-nth" class="contextwizard-reminder-input contextwizard-reminder-select-small">
              <option value="1">1st</option>
              <option value="2">2nd</option>
              <option value="3">3rd</option>
              <option value="4">4th</option>
              <option value="-1">Last</option>
            </select>
            <select id="contextwizard-reminder-monthly-weekday" class="contextwizard-reminder-input contextwizard-reminder-select-small">
              <option value="0">${getMessage('weekdaySunday', 'Sunday')}</option>
              <option value="1">${getMessage('weekdayMonday', 'Monday')}</option>
              <option value="2">${getMessage('weekdayTuesday', 'Tuesday')}</option>
              <option value="3">${getMessage('weekdayWednesday', 'Wednesday')}</option>
              <option value="4">${getMessage('weekdayThursday', 'Thursday')}</option>
              <option value="5">${getMessage('weekdayFriday', 'Friday')}</option>
              <option value="6">${getMessage('weekdaySaturday', 'Saturday')}</option>
            </select>
          </div>
        </div>
        <div class="contextwizard-reminder-row contextwizard-reminder-actions">
          <button id="contextwizard-reminder-ok" class="contextwizard-reminder-ok">${reminderSaveLabel}</button>
          <button id="contextwizard-reminder-cancel" class="contextwizard-reminder-cancel">${reminderCancelLabel}</button>
        </div>
      </div>
      <div class="contextwizard-bookmark-buttons">
        <div class="contextwizard-reminder-summary hidden" id="contextwizard-reminder-summary"></div>
        <button id="contextwizard-bookmark-reminder-btn" class="contextwizard-bookmark-reminder-btn" title="${reminderBtnLabel}">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.995-14.901a1 1 0 1 0-1.99 0A5.002 5.002 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7 0-2.42-1.72-4.44-4.005-4.901z"/>
          </svg>
        </button>
        <button id="contextwizard-bookmark-create-btn">${createBtnText}</button>
        <button id="contextwizard-bookmark-cancel-btn">${cancelBtnText}</button>
      </div>
      <div class="contextwizard-copied-toast">${copiedToClipboardText}</div>
    `;

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(bookmarkInputPopup);

    // Position popup near selection with viewport clamping
    const popupRect = bookmarkInputPopup.getBoundingClientRect();
    const popupWidth = popupRect.width || 280;
    const popupHeight = popupRect.height || 0;
    const margin = 8;
    const spacing = 6;

    let left = rect.left + (rect.width / 2) - (popupWidth / 2);
    left = Math.max(margin, Math.min(left, window.innerWidth - popupWidth - margin));

    let top = rect.bottom + spacing;
    if (top + popupHeight + margin > window.innerHeight) {
      top = rect.top - popupHeight - spacing;
    }
    top = Math.max(margin, Math.min(top, window.innerHeight - popupHeight - margin));

    bookmarkInputPopup.style.left = `${left}px`;
    bookmarkInputPopup.style.top = `${top}px`;

    // Load autocomplete suggestions
    loadBookmarkSuggestions();

    // Focus input
    const input = document.getElementById('contextwizard-bookmark-input');
    input?.focus();
    input?.select();

    // Handle create button (reminder variable will be declared below)
    const createBtn = document.getElementById('contextwizard-bookmark-create-btn');

    // Handle cancel button
    const cancelBtn = document.getElementById('contextwizard-bookmark-cancel-btn');
    cancelBtn?.addEventListener('click', () => {
      bookmarkInputPopup.remove();
      bookmarkInputPopup = null;
      bookmarkSelectionRange = null;
      hideBookmarkButton();
    });

    // Handle Escape key
    input?.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        cancelBtn?.click();
      }
    });

    // Reminder picker logic
    let pendingReminder = null;
    const reminderBtn = document.getElementById('contextwizard-bookmark-reminder-btn');
    const reminderPanel = document.getElementById('contextwizard-bookmark-reminder-panel');
    const reminderDate = document.getElementById('contextwizard-reminder-date');
    const reminderTime = document.getElementById('contextwizard-reminder-time');
    const reminderOk = document.getElementById('contextwizard-reminder-ok');
    const reminderCancel = document.getElementById('contextwizard-reminder-cancel');

    // Set default date to today
    if (reminderDate) {
      reminderDate.value = new Date().toISOString().split('T')[0];
    }

    let selectedReminderType = 'once';
    let selectedWeekdays = [1, 2, 3, 4, 5];
    let selectedMonthlyMode = 'day';

    reminderBtn?.addEventListener('click', () => {
      reminderPanel?.classList.toggle('open');
      reminderBtn.classList.toggle('active');
    });

    // Type button click handler
    bookmarkInputPopup.querySelectorAll('.contextwizard-reminder-type-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        bookmarkInputPopup.querySelectorAll('.contextwizard-reminder-type-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedReminderType = btn.getAttribute('data-type');
        updateReminderOptionsVisibility();
      });
    });

    // Weekday button click handler
    bookmarkInputPopup.querySelectorAll('.contextwizard-weekday-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const day = parseInt(btn.getAttribute('data-day'));
        btn.classList.toggle('active');
        if (selectedWeekdays.includes(day)) {
          selectedWeekdays = selectedWeekdays.filter(d => d !== day);
        } else {
          selectedWeekdays.push(day);
        }
      });
    });

    // Monthly mode button click handler
    bookmarkInputPopup.querySelectorAll('.contextwizard-monthly-mode-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        bookmarkInputPopup.querySelectorAll('.contextwizard-monthly-mode-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedMonthlyMode = btn.getAttribute('data-mode');
        document.getElementById('contextwizard-reminder-monthly-day-field')?.classList.toggle('hidden', selectedMonthlyMode !== 'day');
        document.getElementById('contextwizard-reminder-monthly-nth-field')?.classList.toggle('hidden', selectedMonthlyMode !== 'nth');
      });
    });

    function updateReminderOptionsVisibility() {
      document.getElementById('contextwizard-reminder-once-options')?.classList.toggle('hidden', selectedReminderType !== 'once');
      document.getElementById('contextwizard-reminder-daily-options')?.classList.toggle('hidden', selectedReminderType !== 'daily');
      document.getElementById('contextwizard-reminder-weekly-options')?.classList.toggle('hidden', selectedReminderType !== 'weekly');
      document.getElementById('contextwizard-reminder-monthly-options')?.classList.toggle('hidden', selectedReminderType !== 'monthly');
    }

    reminderOk?.addEventListener('click', () => {
      const now = new Date();

      if (selectedReminderType === 'once') {
        const dateStr = reminderDate?.value;
        const timeOfDay = document.getElementById('contextwizard-reminder-time')?.value || '09:00';
        if (!dateStr) return;
        const dt = new Date(dateStr + 'T' + timeOfDay);
        pendingReminder = { enabled: true, time: Math.floor(dt.getTime() / 1000), timeOfDay, recurrence: 'none' };
      } else if (selectedReminderType === 'daily') {
        const timeOfDay = document.getElementById('contextwizard-reminder-daily-time')?.value || '09:00';
        const [h, m] = timeOfDay.split(':').map(Number);
        const dt = new Date();
        dt.setHours(h, m, 0, 0);
        if (dt.getTime() <= now.getTime()) dt.setDate(dt.getDate() + 1);
        pendingReminder = { enabled: true, time: Math.floor(dt.getTime() / 1000), timeOfDay, recurrence: 'daily' };
      } else if (selectedReminderType === 'weekly') {
        const timeOfDay = document.getElementById('contextwizard-reminder-weekly-time')?.value || '09:00';
        const [h, m] = timeOfDay.split(':').map(Number);
        if (selectedWeekdays.length === 0) return;
        const dt = new Date();
        dt.setHours(h, m, 0, 0);
        do {
          dt.setDate(dt.getDate() + 1);
        } while (!selectedWeekdays.includes(dt.getDay()) || dt.getTime() <= now.getTime());
        pendingReminder = { enabled: true, time: Math.floor(dt.getTime() / 1000), timeOfDay, recurrence: 'weekly', weekdays: [...selectedWeekdays] };
      } else if (selectedReminderType === 'monthly') {
        const timeOfDay = document.getElementById('contextwizard-reminder-monthly-time')?.value || '09:00';
        const [h, m] = timeOfDay.split(':').map(Number);
        const dt = new Date();
        dt.setHours(h, m, 0, 0);
        if (selectedMonthlyMode === 'day') {
          const day = parseInt(document.getElementById('contextwizard-reminder-monthly-day')?.value || '1');
          dt.setDate(day);
          if (dt.getTime() <= now.getTime()) dt.setMonth(dt.getMonth() + 1);
          pendingReminder = { enabled: true, time: Math.floor(dt.getTime() / 1000), timeOfDay, recurrence: 'monthly', monthlyDay: day };
        } else {
          const nth = parseInt(document.getElementById('contextwizard-reminder-monthly-nth')?.value || '1');
          const weekday = parseInt(document.getElementById('contextwizard-reminder-monthly-weekday')?.value || '1');
          const year = dt.getFullYear();
          const month = dt.getMonth();
          const lastDayOfMonth = new Date(year, month + 1, 0).getDate();

          if (nth === -1) {
            for (let d = lastDayOfMonth; d >= 1; d--) {
              if (new Date(year, month, d).getDay() === weekday) {
                dt.setDate(d);
                break;
              }
            }
          } else {
            const firstDayOfWeekday = new Date(year, month, 1).getDay();
            const daysUntilFirst = (weekday - firstDayOfWeekday + 7) % 7;
            const targetDate = 1 + daysUntilFirst + (nth - 1) * 7;
            if (targetDate > lastDayOfMonth) {
              for (let d = lastDayOfMonth; d >= 1; d--) {
                if (new Date(year, month, d).getDay() === weekday) {
                  dt.setDate(d);
                  break;
                }
              }
            } else {
              dt.setDate(targetDate);
            }
          }
          if (dt.getTime() <= now.getTime()) dt.setMonth(dt.getMonth() + 1);
          pendingReminder = { enabled: true, time: Math.floor(dt.getTime() / 1000), timeOfDay, recurrence: 'monthly', monthlyNthWeekday: nth, monthlyWeekday: weekday };
        }
      }

      reminderPanel?.classList.remove('open');
      reminderBtn?.classList.remove('active');
      reminderBtn?.classList.add('has-reminder');

      const summaryEl = document.getElementById('contextwizard-reminder-summary');
      if (summaryEl && pendingReminder) {
        summaryEl.textContent = buildReminderSummary(pendingReminder);
        summaryEl.classList.remove('hidden');
      }
    });

    reminderCancel?.addEventListener('click', () => {
      pendingReminder = null;
      reminderPanel?.classList.remove('open');
      reminderBtn?.classList.remove('active', 'has-reminder');
      const summaryEl = document.getElementById('contextwizard-reminder-summary');
      if (summaryEl) {
        summaryEl.textContent = '';
        summaryEl.classList.add('hidden');
      }
    });

    // Pass reminder to saveBookmark
    const origCreateHandler = createBtn?.onclick;
    createBtn?.removeEventListener('click', createBtn._origHandler);
    createBtn._origHandler = () => {
      const content = input.value.trim();
      if (content) {
        saveBookmark(selectedText, content, selection, pendingReminder);
      }
    };
    createBtn?.addEventListener('click', createBtn._origHandler);
  }

  // Load bookmark autocomplete suggestions
  function loadBookmarkSuggestions() {
    try {
      chrome.runtime.sendMessage({ action: 'getBookmarks' }, (response) => {
        if (response?.success && response.bookmarks) {
          const datalist = document.getElementById('contextwizard-bookmark-suggestions');
          if (!datalist) return;

          // Get unique bookmark contents
          const uniqueContents = [...new Set(response.bookmarks.map(b => b.content))];
          
          datalist.innerHTML = uniqueContents
            .slice(0, 10) // Limit to 10 suggestions
            .map(content => `<option value="${content}"></option>`)
            .join('');
        }
      });
    } catch (error) {
      // Extension context may be invalidated (e.g., extension reloaded/updated)
      console.warn('[ContextWizard] Extension context invalidated:', error.message || error);
    }
  }

  // Save bookmark
  function saveBookmark(selectedText, content, selection, reminder) {
    if (!currentConversation) {
      // If conversation not yet captured, show error message
      alert(getMessage('bookmarkNeedConversation', 'Please wait for the conversation to be captured first.'));
      hideBookmarkButton();
      if (bookmarkInputPopup) {
        bookmarkInputPopup.remove();
        bookmarkInputPopup = null;
        bookmarkSelectionRange = null;
      }
      return;
    }
    
    // Validate selectedText
    if (!selectedText || !selectedText.trim()) {
      alert(getMessage('bookmarkSelectTextRequired', 'Please select some text to bookmark.'));
      return;
    }

 // Calculate position information
      // Use the stored range from when the popup was created, not the current selection
      // (which may be within the popup itself)
      let range = bookmarkSelectionRange;
      
      // Check if range is still valid (not invalidated by highlight refresh)
      if (!range || !range.startContainer?.isConnected) {
        // Try to get a fresh range from current selection
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0 && !selection.isCollapsed) {
          range = selection.getRangeAt(0);
          // Verify the new range is valid
          if (!range.startContainer?.isConnected) {
            alert(getMessage('bookmarkSelectionInvalidated', 'Selection was invalidated by page update. Please try again.'));
            if (bookmarkInputPopup) {
              bookmarkInputPopup.remove();
              bookmarkInputPopup = null;
              bookmarkSelectionRange = null;
            }
            hideBookmarkButton();
            return;
          }
        } else {
          alert(getMessage('bookmarkSelectionInvalidated', 'Selection was invalidated by page update. Please try again.'));
          if (bookmarkInputPopup) {
            bookmarkInputPopup.remove();
            bookmarkInputPopup = null;
            bookmarkSelectionRange = null;
          }
          hideBookmarkButton();
          return;
        }
      }
      const { messageIndex, htmlOffset, messageAttribute, charOffsetInMessage } = calculateBookmarkPosition(range);

      // Get the exact text from the DOM range, preserving the actual content
      const exactText = range.toString();
      const trimmedText = exactText.trim();

      if (!trimmedText) {
        alert(getMessage('bookmarkSelectTextRequired', 'Please select some text to bookmark.'));
        return;
      }

      const bookmark = {
        content: content || trimmedText.substring(0, 100),
        selectedText: trimmedText.substring(0, 200),
        actualLength: Math.min(exactText.length, 500),
        htmlOffset: htmlOffset,
        charOffsetInMessage: charOffsetInMessage,
        url: currentConversation.url || window.location.href,
        platform: currentConversation.platform || currentPlatform?.name || 'Unknown',
        messageIndex: messageIndex,
        messageAttribute: messageAttribute
      };

      if (reminder && reminder.enabled) {
        bookmark.reminder = reminder;
      }

     try {
       chrome.runtime.sendMessage(
         { action: 'saveBookmark', bookmark: bookmark },
        (response) => {
          if (response?.success) {
            // Add the saved bookmark (with ID from server) to local array
            const savedBookmark = response.bookmark || { ...bookmark, id: response.bookmarkId || Date.now() };
            conversationBookmarks.push(savedBookmark);
            
            // Show success message
            showBookmarkSuccessMessage();
            
            // Hide input popup and button
            if (bookmarkInputPopup) {
              bookmarkInputPopup.remove();
              bookmarkInputPopup = null;
              bookmarkSelectionRange = null;
            }
            hideBookmarkButton();
            
            // Create marker immediately before clearing selection
            const marker = createBookmarkMarker(savedBookmark);
            if (marker) {
              bookmarkMarkers.push(marker);
            }
            
            // Clear selection
            window.getSelection()?.removeAllRanges();
            
            // Update UI (show bookmark list button if needed)
            updateBookmarkViewListButtonVisibility();

            // Refresh bookmark list popup if it's open
            if (bookmarkListPopup) {
              refreshBookmarkListContent();
            }
          } else if (response?.error === 'duplicate') {
            // Show duplicate warning
            showBookmarkDuplicateWarning(bookmark, response.existingBookmark);
          } else {
            alert(getMessage('bookmarkSaveFailed', 'Failed to save bookmark'));
          }
        }
      );
    } catch (error) {
      // Extension context may be invalidated (e.g., extension reloaded/updated)
      alert(getMessage('bookmarkExtensionContextInvalidated', 'Extension context invalidated. Please reload the page and try again.'));
      hideBookmarkButton();
      if (bookmarkInputPopup) {
        bookmarkInputPopup.remove();
        bookmarkInputPopup = null;
        bookmarkSelectionRange = null;
      }
    }
  }

  // Calculate bookmark position (messageIndex, htmlOffset)
  function calculateBookmarkPosition(range) {
    const startContainer = range.startContainer;
    const startOffset = range.startOffset;
    
    let messageElement = startContainer.nodeType === Node.TEXT_NODE 
      ? startContainer.parentElement 
      : startContainer;
    
    let messageAttribute = 'data-message-index';
    while (messageElement && !messageElement.matches?.('[data-message-index]')) {
      if (messageElement.hasAttribute?.('data-start')) {
        messageAttribute = 'data-start';
        break;
      }
      messageElement = messageElement.parentElement;
    }
    
    const messageIndex = messageElement?.getAttribute('data-message-index') 
      ? parseInt(messageElement.getAttribute('data-message-index'), 10) 
      : messageElement?.getAttribute('data-start')
        ? parseInt(messageElement.getAttribute('data-start'), 10)
        : 0;
    
    const htmlOffset = calculateAbsoluteOffset(startContainer, startOffset);
    const charOffsetInMessage = messageElement
      ? calculateOffsetInMessage(messageElement, startContainer, startOffset)
      : 0;
    
    return { 
      messageIndex, 
      messageAttribute,
      htmlOffset,
      charOffsetInMessage
    };
  }
  
  function calculateAbsoluteOffset(node, offset) {
    if (!document.body) return 0;
    
    let totalOffset = 0;
    
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (textNode) => {
          const parent = textNode.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (parent.closest?.('#contextwizard-indicator') || 
              parent.closest?.('#contextwizard-nav-container') ||
              parent.closest?.('#contextwizard-bookmark-button') ||
              parent.closest?.('#contextwizard-bookmark-input-popup') ||
              parent.closest?.('#contextwizard-bookmark-list-popup')) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    
    let currentNode;
    while ((currentNode = walker.nextNode())) {
      if (currentNode === node) {
        return totalOffset + offset;
      }
      totalOffset += currentNode.textContent?.length || 0;
    }
    
    return 0;
  }

  // Calculate character offset within a specific parent element
  function calculateOffsetInMessage(parentElement, node, offset) {
    if (!parentElement || !node) return 0;
    let totalOffset = 0;
    const walker = document.createTreeWalker(
      parentElement,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (textNode) => {
          if (!textNode.parentElement) return NodeFilter.FILTER_REJECT;
          if (textNode.parentElement.closest?.('#contextwizard-indicator') ||
              textNode.parentElement.closest?.('#contextwizard-nav-container') ||
              textNode.parentElement.closest?.('#contextwizard-bookmark-button') ||
              textNode.parentElement.closest?.('#contextwizard-bookmark-input-popup') ||
              textNode.parentElement.closest?.('#contextwizard-bookmark-list-popup')) {
            return NodeFilter.FILTER_REJECT;
          }
          if (textNode.parentElement.classList?.contains('contextwizard-bookmark-text-highlight')) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    let currentNode;
    while ((currentNode = walker.nextNode())) {
      if (currentNode === node) {
        return totalOffset + offset;
      }
      totalOffset += currentNode.textContent?.length || 0;
    }
    return 0;
  }

  // Show bookmark success message
  function showBookmarkSuccessMessage() {
    const message = document.createElement('div');
    message.className = 'contextwizard-bookmark-success-message';
    message.textContent = chrome.i18n.getMessage('bookmarkCreatedSuccess') || 'Bookmark created';
    
    document.body.appendChild(message);
    
    setTimeout(() => {
      message.remove();
    }, 3000);
  }

  // Show bookmark duplicate warning
  function showBookmarkDuplicateWarning(newBookmark, existingBookmark) {
    const warning = chrome.i18n.getMessage('bookmarkDuplicateWarning') || 
      'A bookmark already exists at this location. Do you want to replace it?';
    
    if (confirm(warning)) {
      // Delete existing and save new
      try {
        chrome.runtime.sendMessage(
          { action: 'deleteBookmark', bookmarkId: existingBookmark.id },
          (response) => {
            if (response?.success) {
              // Try saving again
              try {
                chrome.runtime.sendMessage(
                  { action: 'saveBookmark', bookmark: newBookmark },
                  (response) => {
                    if (response?.success) {
                      showBookmarkSuccessMessage();
                      if (bookmarkInputPopup) {
                        bookmarkInputPopup.remove();
                        bookmarkInputPopup = null;
                        bookmarkSelectionRange = null;
                      }
                      hideBookmarkButton();
                      window.getSelection()?.removeAllRanges();
                      updateBookmarkViewListButtonVisibility();

                      // Refresh bookmark list popup if it's open
                      if (bookmarkListPopup) {
                        bookmarkListPopup._cleanup?.();
                        bookmarkListPopup.remove();
                        bookmarkListPopup = null;
                        showBookmarkListPopup();
                      }
                    }
                  }
                );
              } catch (error) {
                console.warn('[ContextWizard] Extension context invalidated:', error.message || error);
              }
            }
          }
        );
      } catch (error) {
        // Extension context may be invalidated
      }
    } else {
      // User cancelled
      if (bookmarkInputPopup) {
        bookmarkInputPopup.remove();
        bookmarkInputPopup = null;
        bookmarkSelectionRange = null;
      }
    }
  }

  // Load bookmarks for current conversation
  function loadConversationBookmarks() {
    if (!currentConversation?.id) {
      return;
    }

    try {
      chrome.runtime.sendMessage(
        { 
          action: 'getBookmarksByConversation', 
          url: currentConversation.url || window.location.href 
        },
        (response) => {
          if (response?.success) {
            conversationBookmarks = response.bookmarks || [];
            
            // Update UI
            updateBookmarkViewListButtonVisibility();
            
            // Restore bookmark markers after page loads
            if (conversationBookmarks.length > 0) {
              requestIdleCallback(() => {
                restoreBookmarkMarkers();
              }, { timeout: 2000 });
            }
          }
        }
      );
    } catch (error) {
      console.warn('[ContextWizard] Extension context invalidated:', error.message || error);
    }
  }

  // Update bookmark view list button visibility
  function updateBookmarkViewListButtonVisibility() {
    if (!bookmarkViewListButton) {
      return;
    }

    if (conversationBookmarks.length > 0) {
      if (!isButtonsHidden) {
        bookmarkViewListButton.style.display = 'flex';
      }
      updateBookmarkViewListButtonPosition();
      
      // Update bookmark button to active state
      if (bookmarkButton) {
        bookmarkButton.classList.remove('contextwizard-inactive');
        bookmarkButton.classList.add('contextwizard-active');
      }
    } else {
      if (!isButtonsHidden) {
        bookmarkViewListButton.style.display = 'none';
      }
    }
  }

  // Update bookmark view list button position to stay to the right of copy button
  function updateBookmarkViewListButtonPosition() {
    if (!bookmarkViewListButton || !recordingIndicator) {
      return;
    }

    const indicatorRect = recordingIndicator.getBoundingClientRect();
    const buttonSize = 32;
    const copyButtonSize = 32;
    const gap = 8;  // gap between copy button and bookmark button

    // Copy button is centered below indicator
    const copyButtonLeft = indicatorRect.left + (indicatorRect.width - copyButtonSize) / 2;
    const copyButtonTop = indicatorRect.bottom + 8;

    // Bookmark button is to the right of copy button
    const top = copyButtonTop;
    const left = copyButtonLeft + copyButtonSize + gap;

    // Ensure within viewport bounds
    const clampedTop = Math.max(8, Math.min(top, window.innerHeight - buttonSize - 8));
    const clampedLeft = Math.max(8, Math.min(left, window.innerWidth - buttonSize - 8));

    bookmarkViewListButton.style.top = `${clampedTop}px`;
    bookmarkViewListButton.style.left = `${clampedLeft}px`;
  }

  // Handle bookmark view list button click - toggle popup visibility
  function handleBookmarkViewListClick(event) {
    event.stopPropagation();
    if (bookmarkListPopup) {
      bookmarkListPopup.remove();
      bookmarkListPopup = null;
    } else {
      showBookmarkListPopup();
    }
  }

  // Show bookmark list popup for current conversation
  // Show bookmark list popup
  let popupDragState = null;
  let popupResizeState = null;

  function showBookmarkListPopup() {
    // If popup already exists, just refresh the list content
    if (bookmarkListPopup) {
      refreshBookmarkListContent();
      return;
    }

    bookmarkListPopup = document.createElement('div');
    bookmarkListPopup.id = 'contextwizard-bookmark-list-popup';
    bookmarkListPopup.style.top = '100px';
    bookmarkListPopup.style.left = '100px';

    const title = getMessage('bookmarkListTitle', 'Bookmarks');
    const closeLabel = getMessage('detailCloseButton', 'Close');

    let content = `<div class="contextwizard-bookmark-list-header">
      <h3>${title}</h3>
      <button class="contextwizard-bookmark-list-close" aria-label="${escapeHtml(closeLabel)}">&times;</button>
    </div>
    <div class="contextwizard-bookmark-list-content"></div>
    <div class="contextwizard-bookmark-list-resize-handle"></div>`;
    bookmarkListPopup.innerHTML = content;

    document.body.appendChild(bookmarkListPopup);

    // Refresh the list content (after popup is created)
    refreshBookmarkListContent();

    // Handle close button
    const closeBtn = bookmarkListPopup.querySelector('.contextwizard-bookmark-list-close');
    closeBtn?.addEventListener('click', () => {
      if (bookmarkListPopup) {
        bookmarkListPopup.remove();
        bookmarkListPopup = null;
      }
    });

    // Handle drag on header
    const header = bookmarkListPopup.querySelector('.contextwizard-bookmark-list-header');
    header.addEventListener('mousedown', (e) => {
      if (e.target === closeBtn) return;
      popupDragState = {
        startX: e.clientX,
        startY: e.clientY,
        startLeft: bookmarkListPopup.offsetLeft,
        startTop: bookmarkListPopup.offsetTop
      };
      bookmarkListPopup.classList.add('dragging');
      e.preventDefault();
    });

    // Handle resize
    const resizeHandle = bookmarkListPopup.querySelector('.contextwizard-bookmark-list-resize-handle');
    resizeHandle.addEventListener('mousedown', (e) => {
      popupResizeState = {
        startX: e.clientX,
        startY: e.clientY,
        startWidth: bookmarkListPopup.offsetWidth,
        startHeight: bookmarkListPopup.offsetHeight
      };
      bookmarkListPopup.classList.add('resizing');
      e.preventDefault();
      e.stopPropagation();
    });

    // Global mouse move/up handlers
    document.addEventListener('mousemove', handlePopupMouseMove);
    document.addEventListener('mouseup', handlePopupMouseUp);

    // Store cleanup function
    bookmarkListPopup._cleanup = () => {
      document.removeEventListener('mousemove', handlePopupMouseMove);
      document.removeEventListener('mouseup', handlePopupMouseUp);
    };
  }

  function refreshBookmarkListContent() {
    if (!bookmarkListPopup) return;

    const emptyMessage = getMessage('bookmarkListEmpty', 'No bookmarks in this conversation');
    const contentContainer = bookmarkListPopup.querySelector('.contextwizard-bookmark-list-content');
    const untitledText = getMessage('bookmarkUntitled', 'Untitled');
    const deleteText = getMessage('bookmarkDeleteButton', 'Delete');

    if (conversationBookmarks.length === 0) {
      contentContainer.innerHTML = `<p class="contextwizard-bookmark-list-empty">${emptyMessage}</p>`;
    } else {
      const openManagerText = escapeHtml(getMessage('bookmarkOpenManager', 'Open in Bookmark Manager'));
      const openManagerTooltipText = escapeHtml(getMessage('bookmarkOpenManagerTooltip', 'Open this bookmark in Bookmark Manager'));
      let listHtml = '<ul class="contextwizard-bookmark-list">';
      conversationBookmarks.forEach((bookmark) => {
        const content = bookmark.content || untitledText;
        const selectedText = bookmark.selectedText || '';
        const truncatedSelectedText = selectedText.length > 50 ? selectedText.substring(0, 50) + '...' : selectedText;
        listHtml += `
          <li class="contextwizard-bookmark-item" data-bookmark-id="${bookmark.id}" data-selected-text="${selectedText.replace(/"/g, '&quot;')}">
            <div class="contextwizard-bookmark-content" data-tooltip="${content.replace(/"/g, '&quot;')}">${escapeHtml(content)}</div>
            <div class="contextwizard-bookmark-selected-text">${escapeHtml(truncatedSelectedText)}</div>
            <div class="contextwizard-bookmark-item-actions">
              <button class="contextwizard-bookmark-open-manager" data-bookmark-id="${bookmark.id}" title="${openManagerTooltipText}">${openManagerText}</button>
              <button class="contextwizard-bookmark-delete" data-bookmark-id="${bookmark.id}">${escapeHtml(deleteText)}</button>
            </div>
          </li>
        `;
      });
      listHtml += '</ul>';
      contentContainer.innerHTML = listHtml;
    }

    // Re-attach click handlers for bookmark items
    bookmarkListPopup.querySelectorAll('.contextwizard-bookmark-item').forEach((item) => {
      item.addEventListener('click', (e) => {
        const bookmarkId = item.getAttribute('data-bookmark-id');
        const deleteBtn = item.querySelector('.contextwizard-bookmark-delete');
        const confirmBtn = item.querySelector('.contextwizard-bookmark-confirm');
        const cancelBtn = item.querySelector('.contextwizard-bookmark-cancel');
        const openManagerBtn = item.querySelector('.contextwizard-bookmark-open-manager');

        if (e.target === confirmBtn || e.target === cancelBtn) {
          return;
        }

        if (e.target === deleteBtn) {
          showDeleteConfirmation(item, bookmarkId);
          return;
        }

        if (e.target === openManagerBtn) {
          if (bookmarkId) {
            try {
              chrome.runtime.sendMessage({ action: 'openBookmarkManager', bookmarkId });
            } catch (err) {
              console.warn('[ContextWizard] Failed to send openBookmarkManager message:', err);
            }
          }
          return;
        }

        jumpToBookmark(bookmarkId, item);
      });

      // Add hover event listeners for SelectedText tip
      item.addEventListener('mouseenter', () => {
        showSelectedTextTip(item);
      });

      item.addEventListener('mouseleave', () => {
        hideSelectedTextTip(item);
      });
    });
  }

  function handlePopupMouseMove(e) {
    if (popupDragState) {
      const deltaX = e.clientX - popupDragState.startX;
      const deltaY = e.clientY - popupDragState.startY;
      bookmarkListPopup.style.left = (popupDragState.startLeft + deltaX) + 'px';
      bookmarkListPopup.style.top = (popupDragState.startTop + deltaY) + 'px';
      bookmarkListPopup.style.transform = 'none';
    } else if (popupResizeState) {
      const deltaX = e.clientX - popupResizeState.startX;
      const deltaY = e.clientY - popupResizeState.startY;
      const newWidth = Math.max(300, popupResizeState.startWidth + deltaX);
      const newHeight = Math.max(200, popupResizeState.startHeight + deltaY);
      bookmarkListPopup.style.width = newWidth + 'px';
      bookmarkListPopup.style.height = newHeight + 'px';
    }
  }

  function handlePopupMouseUp() {
    if (popupDragState) {
      popupDragState = null;
      bookmarkListPopup?.classList.remove('dragging');
    }
    if (popupResizeState) {
      popupResizeState = null;
      bookmarkListPopup?.classList.remove('resizing');
    }
  }

  function showDeleteConfirmation(item, bookmarkId) {
    const actionsDiv = item.querySelector('.contextwizard-bookmark-item-actions');
    actionsDiv.innerHTML = `
      <button class="contextwizard-bookmark-confirm" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('conversationDeleteConfirmButton', 'Confirm'))}</button>
      <button class="contextwizard-bookmark-cancel" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('bookmarkCancelButton', 'Cancel'))}</button>
    `;

    const confirmBtn = actionsDiv.querySelector('.contextwizard-bookmark-confirm');
    const cancelBtn = actionsDiv.querySelector('.contextwizard-bookmark-cancel');

    confirmBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      confirmDeleteBookmark(bookmarkId);
    });

    cancelBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      cancelDeleteConfirmation(item, bookmarkId);
    });
  }

  function cancelDeleteConfirmation(item, bookmarkId) {
    const name = conversationBookmarks.find(b => b.id === bookmarkId)?.content || getMessage('bookmarkUntitled', 'Untitled');
    const truncatedName = name.length > 30 ? name.substring(0, 30) + '...' : name;
    const actionsDiv = item.querySelector('.contextwizard-bookmark-item-actions');
    actionsDiv.innerHTML = `<button class="contextwizard-bookmark-delete" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('bookmarkDeleteButton', 'Delete'))}</button>`;

    // Re-attach delete handler
    actionsDiv.querySelector('.contextwizard-bookmark-delete').addEventListener('click', (e) => {
      e.stopPropagation();
      showDeleteConfirmation(item, bookmarkId);
    });
  }

  // Jump to bookmark location
  function jumpToBookmark(bookmarkId, itemElement) {
    const bookmark = conversationBookmarks.find(b => b.id === bookmarkId);
    if (!bookmark) {
      return;
    }

    // Find bookmark marker element (highlight with data-bookmark-marker-id)
    // Only search outside popup to avoid false positives
    const allMarkers = document.querySelectorAll(`[data-bookmark-marker-id="${bookmarkId}"]`);
    let marker = null;
    for (const m of allMarkers) {
      if (!bookmarkListPopup?.contains(m)) {
        marker = m;
        break;
      }
    }

    if (marker) {
      marker.scrollIntoView({ behavior: 'smooth', block: 'center' });

      // Highlight temporarily
      marker.classList.add('contextwizard-bookmark-marker-highlight');
      setTimeout(() => {
        marker.classList.remove('contextwizard-bookmark-marker-highlight');
      }, 2000);
    }

    // Visual feedback on item
    if (itemElement) {
      itemElement.classList.add('jumping');
      setTimeout(() => {
        itemElement.classList.remove('jumping');
      }, 300);
    }
  }

  // Confirm delete bookmark
  function confirmDeleteBookmark(bookmarkId) {
    try {
      chrome.runtime.sendMessage(
        { action: 'deleteBookmark', bookmarkId: bookmarkId },
        (response) => {
          if (response?.success) {
            // Remove from local array
            conversationBookmarks = conversationBookmarks.filter(b => b.id !== bookmarkId);

            // Remove all markers (highlight elements) - may be multiple for long text spanning nodes
            const markers = document.querySelectorAll(`[data-bookmark-marker-id="${bookmarkId}"]`);
            const parentsToNormalize = new Set();
            markers.forEach(marker => {
              if (marker && marker.parentNode) {
                const parent = marker.parentNode;
                // Replace highlight with its text content
                const text = document.createTextNode(marker.textContent);
                parent.replaceChild(text, marker);
                // Track parent for normalization (merging adjacent text nodes)
                parentsToNormalize.add(parent);
              }
            });

            // Normalize parents to merge adjacent text nodes
            parentsToNormalize.forEach(parent => {
              if (parent && parent.normalize) {
                parent.normalize();
              }
            });

            // Update UI
            updateBookmarkViewListButtonVisibility();

            // Refresh list popup if open
            if (bookmarkListPopup) {
              refreshBookmarkListContent();
            }
          }
        }
      );
    } catch (error) {
      console.warn('[ContextWizard] Extension context invalidated:', error.message || error);
    }
  }

   // Restore bookmark markers on page
   function restoreBookmarkMarkers() {
     // Clear existing markers (highlights) - find all bookmark highlights in the DOM
     const existingMarkers = document.querySelectorAll('.contextwizard-bookmark-text-highlight');
     const parentsToNormalize = new Set();
     existingMarkers.forEach(marker => {
       if (marker && marker.parentNode) {
         const parent = marker.parentNode;
         parent.replaceChild(document.createTextNode(marker.textContent), marker);
         parentsToNormalize.add(parent);
       }
     });
     
     // Normalize parents to merge adjacent text nodes
     parentsToNormalize.forEach(parent => {
       if (parent && parent.normalize) {
         parent.normalize();
       }
     });
     
     bookmarkMarkers = [];
    if (conversationBookmarks.length === 0) {
      return;
    }

    conversationBookmarks.forEach((bookmark) => {
      try {
        const marker = createBookmarkMarker(bookmark);
        if (marker) {
          bookmarkMarkers.push(marker);
        }
      } catch (error) {
        console.warn('[ContextWizard] Failed to create bookmark marker for:', bookmark?.id, error);
      }
    });

    // Check if there's a pending scroll request
    if (pendingScrollRequest) {
      const { bookmarkId, sendResponse } = pendingScrollRequest;
      const allMarkers = document.querySelectorAll(`[data-bookmark-marker-id="${bookmarkId}"]`);
      let marker = null;
      for (const m of allMarkers) {
        if (!bookmarkListPopup?.contains(m)) {
          marker = m;
          break;
        }
      }
      if (marker) {
        marker.scrollIntoView({ behavior: 'smooth', block: 'center' });
        marker.classList.add('contextwizard-bookmark-marker-highlight');
        setTimeout(() => {
          marker.classList.remove('contextwizard-bookmark-marker-highlight');
        }, 2000);
        pendingScrollRequest = null;
        clearTimeout(pendingScrollTimeout);
        sendResponse({ success: true, found: true });
      }
    }
  }

  // Create bookmark marker at bookmark position
  function createBookmarkMarker(bookmark) {
    if (!bookmark.selectedText && !bookmark.content) {
      return null;
    }
    
    // Use content as fallback if selectedText is missing
    // Require selected text for marker creation (legacy formats are no longer supported)
    if (!bookmark.selectedText) {
      return null;
    }

    // Use text search to find the bookmark location (similar to search highlighting)
    const result = findAndHighlightBookmarkText(bookmark);
    
    if (result) {
      return result;
    }
    
    console.warn('[ContextWizard] Could not create bookmark marker for:', bookmark.id, '- text may not be present in current page');
    return null;
  }

 // Walk text nodes within a parent to find (node, index) at a given char offset
  function findPositionByCharOffset(parentElement, charOffset) {
    if (!parentElement || charOffset < 0) return null;
    let accumulated = 0;
    const walker = document.createTreeWalker(
      parentElement,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (textNode) => {
          if (!textNode.parentElement) return NodeFilter.FILTER_REJECT;
          if (textNode.parentElement.closest?.('#contextwizard-indicator') ||
              textNode.parentElement.closest?.('#contextwizard-nav-container') ||
              textNode.parentElement.closest?.('#contextwizard-bookmark-button') ||
              textNode.parentElement.closest?.('#contextwizard-bookmark-input-popup') ||
              textNode.parentElement.closest?.('#contextwizard-bookmark-list-popup')) {
            return NodeFilter.FILTER_REJECT;
          }
          if (textNode.parentElement.classList?.contains('contextwizard-bookmark-text-highlight')) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    let currentNode;
    while ((currentNode = walker.nextNode())) {
      const len = currentNode.textContent?.length || 0;
      if (accumulated + len > charOffset) {
        return { node: currentNode, index: charOffset - accumulated };
      }
      accumulated += len;
    }
    return null;
  }

  // Find and highlight bookmark text using flexible matching algorithm
    function findAndHighlightBookmarkText(bookmark) {
     const searchText = bookmark.selectedText?.trim();
     if (!searchText) {
       console.warn('[ContextWizard] findAndHighlightBookmarkText: No text found for bookmark:', bookmark.id);
       return null;
     }
     
     // Use stored actualLength if available, otherwise use searchText length
     const highlightLength = bookmark.actualLength || searchText.length;
     
      // Step 0: Position-first approach - use charOffsetInMessage for exact positioning
      // Prevents bookmark drift by locating via stored offset rather than text matching
      if (bookmark.messageIndex != null && bookmark.charOffsetInMessage != null) {
        let messageEl = null;
        if (bookmark.messageAttribute) {
          messageEl = document.querySelector(`[${bookmark.messageAttribute}="${bookmark.messageIndex}"]`);
        }
        if (!messageEl) {
          messageEl = document.querySelector(`[data-message-index="${bookmark.messageIndex}"]`) ||
                      document.querySelector(`[data-start="${bookmark.messageIndex}"]`);
        }
        if (messageEl) {
          const pos = findPositionByCharOffset(messageEl, bookmark.charOffsetInMessage);
          if (pos) {
            const verifyText = bookmark.selectedText?.trim();
            if (verifyText) {
              const textAtPos = (pos.node.textContent || '').substring(pos.index, pos.index + verifyText.length);
              if (textAtPos === verifyText) {

                return createBookmarkHighlight(pos.node, pos.index, bookmark.actualLength || verifyText.length, bookmark);
              }

            } else {
              // No text to verify - still use position if we have it

              return createBookmarkHighlight(pos.node, pos.index, bookmark.actualLength || 1, bookmark);
            }
          } else {

          }
        } else {

        }
      }

      // Step 1: Try to find text within the specific message if messageIndex is available
      if (bookmark.messageIndex !== undefined && bookmark.messageIndex !== null) {
       // If htmlOffset is available, find ALL matches and use offset for disambiguation
       if (bookmark.htmlOffset !== undefined && bookmark.htmlOffset !== null) {
         const allMatchesInMessage = findAllMatchesWithRobustSearch(searchText, bookmark.messageIndex, bookmark.messageAttribute);
         if (allMatchesInMessage.length > 0) {
           const closestMatch = findClosestMatchByOffset(allMatchesInMessage, bookmark.htmlOffset);
           if (closestMatch) {
             const actualMatchLength = closestMatch.matchedLength || highlightLength;

             return createBookmarkHighlight(closestMatch.node, closestMatch.index, actualMatchLength, bookmark);
           }
         }
       } else {
         // No htmlOffset available, use first match (backward compatible)
         const robustMatch = findTextWithRobustSearch(searchText, bookmark.messageIndex, bookmark.messageAttribute);
         if (robustMatch) {
           const actualMatchLength = robustMatch.matchedLength || highlightLength;
           return createBookmarkHighlight(robustMatch.node, robustMatch.index, actualMatchLength, bookmark);
         }
       }
     }
     
      // Step 2: Fallback to global search if message-specific search fails or messageIndex is not available
      const globalRobustMatch = findTextWithRobustSearch(searchText);
      if (globalRobustMatch) {
        // If we have htmlOffset from bookmark, use findClosestMatchByOffset to find the correct match
        if (bookmark.htmlOffset !== undefined && bookmark.htmlOffset !== null) {
          // Find all matches in the document
          const allMatches = findAllTextMatches(searchText);
          if (allMatches.length > 0) {
            const closestMatch = findClosestMatchByOffset(allMatches, bookmark.htmlOffset);
            if (closestMatch) {
              const actualMatchLength = closestMatch.matchedLength || highlightLength;
              return createBookmarkHighlight(closestMatch.node, closestMatch.index, actualMatchLength, bookmark);
            }
          }
        }
        // Use the global match directly if no htmlOffset or no closest match found
        const actualMatchLength = globalRobustMatch.matchedLength || highlightLength;
        return createBookmarkHighlight(globalRobustMatch.node, globalRobustMatch.index, actualMatchLength, bookmark);
      }
     
     // Step 2: Try container-level search (handles inline tags within a block)
     const containerMatches = findAllTextMatchesByContainer(searchText);
     if (containerMatches.length > 0) {
       const closestMatch = findClosestMatchByOffset(containerMatches, bookmark.htmlOffset || 0);
       const actualMatchLength = closestMatch.matchedLength || highlightLength;
       return createBookmarkHighlight(closestMatch.node, closestMatch.index, actualMatchLength, bookmark);
     }
     
     // Step 3: Try to use browser's native find functionality first
     if (window.find && !isInExtensionContext()) {
       try {
         // Store current selection
         const currentSelection = window.getSelection();
         const savedRange = currentSelection.rangeCount > 0 ? currentSelection.getRangeAt(0) : null;
         
         // Use browser's find to locate the text
         const found = window.find(searchText, false, false, false, false, false, false);
         
         if (found) {
           const foundRange = currentSelection.getRangeAt(0);
           const match = {
             node: foundRange.startContainer,
             index: foundRange.startOffset,
             htmlOffset: calculateTextOffset(foundRange.startContainer) + foundRange.startOffset
           };
           
           // Use the exact length of the found range
           const actualMatchLength = foundRange.toString().length;
           
           // Restore original selection
           currentSelection.removeAllRanges();
           if (savedRange) {
             currentSelection.addRange(savedRange);
           }
           
           return createBookmarkHighlight(match.node, match.index, actualMatchLength, bookmark);
         }
         
         // Restore original selection if not found
         currentSelection.removeAllRanges();
         if (savedRange) {
           currentSelection.addRange(savedRange);
         }
       } catch (e) {

       }
     }
     
    // Step 4: Try exact match with our manual search
     let allMatches = findAllTextMatches(searchText);
     
     if (allMatches.length > 0) {
       if (allMatches.length === 1) {
         return createBookmarkHighlight(allMatches[0].node, allMatches[0].index, highlightLength, bookmark);
       }
       
       // Step 3: Find match closest to htmlOffset
       const closestMatch = findClosestMatchByOffset(allMatches, bookmark.htmlOffset || 0);
       return createBookmarkHighlight(closestMatch.node, closestMatch.index, highlightLength, bookmark);
     }
     
    // Step 5: Try fuzzy matching - normalize whitespace and try shorter versions
     const normalizedSearch = normalizeTextForSearch(searchText);
     
     // Try progressively shorter versions of the search text
     for (let length = searchText.length; length >= 20; length -= 10) {
       const shortText = searchText.substring(0, length).trim();
       if (shortText.length < 20) break;
       
       const shortMatches = findAllTextMatches(shortText);
       if (shortMatches.length > 0) {

         const closestMatch = findClosestMatchByOffset(shortMatches, bookmark.htmlOffset || 0);
         // Use the shortened text length since that's what we matched
         return createBookmarkHighlight(closestMatch.node, closestMatch.index, shortText.length, bookmark);
       }
     }
     
    // Step 6: Try with normalized text (remove extra whitespace, special chars)
     const normalizedMatches = findAllTextMatchesFuzzy(normalizedSearch);
     if (normalizedMatches.length > 0) {

       const closestMatch = findClosestMatchByOffset(normalizedMatches, bookmark.htmlOffset || 0);
       return createBookmarkHighlight(closestMatch.node, closestMatch.index, highlightLength, bookmark);
     }
     
    // Step 7: Try to find text that spans across multiple nodes (e.g., text with HTML tags)
     const multiNodeMatch = findMultiNodeTextMatch(searchText);
     if (multiNodeMatch) {
       return createBookmarkHighlight(multiNodeMatch.startNode, multiNodeMatch.startIndex, highlightLength, bookmark);
     }
     
    // Step 8: Try common text variations (handles truncation, punctuation differences)
     const variations = generateTextVariations(searchText);
     for (const variation of variations) {
       const variationMatches = findAllTextMatches(variation);
       if (variationMatches.length > 0) {
         const closestMatch = findClosestMatchByOffset(variationMatches, bookmark.htmlOffset || 0);
         return createBookmarkHighlight(closestMatch.node, closestMatch.index, variation.length, bookmark);
       }
     }
     
     return null;
   }
   
   // Generate common variations of search text to handle truncation and punctuation differences
   function generateTextVariations(text) {
     const variations = [];
     
     // 1. Remove trailing punctuation
     const withoutTrailingPunctuation = text.replace(/[.,;:!?\s]+$/g, '').trim();
     if (withoutTrailingPunctuation !== text) {
       variations.push(withoutTrailingPunctuation);
     }
     
     // 2. Add common trailing punctuation if missing
     const withTrailingColon = text.replace(/:\s*$/g, '').trim();
     if (withTrailingColon !== text) {
       variations.push(withTrailingColon + ':');
     }
     
     // 3. Try without any trailing punctuation
     const withoutAllTrailing = text.replace(/[^\w\s]+$/g, '').trim();
     if (withoutAllTrailing !== text && withoutAllTrailing !== withoutTrailingPunctuation) {
       variations.push(withoutAllTrailing);
     }
     
     // 4. Try with common separators (for cases where text spans HTML elements)
     const textWithoutSpaces = text.replace(/\s+/g, ' ').trim();
     if (textWithoutSpaces !== text) {
       variations.push(textWithoutSpaces);
     }
     
     // 5. Try removing extra spaces and normalizing
     const normalizedText = text.replace(/\s+/g, ' ').trim();
     if (normalizedText !== text) {
       variations.push(normalizedText);
     }
     
     // 6. Try removing the last word (handles cases where text was cut off)
     const words = text.split(/\s+/);
     if (words.length > 2) {
       const withoutLastWord = words.slice(0, -1).join(' ').trim();
       variations.push(withoutLastWord);
     }
     
return variations.filter(v => v && v.length >= 5); // Only meaningful variations
    }
    
    // Normalize text for more flexible searching
    function normalizeTextForSearch(text) {
     return text
       .replace(/\s+/g, ' ')  // Replace multiple whitespace with single space
       .replace(/[^\w\s]/g, '')  // Remove special characters
       .trim();
   }
   
   // Check if we're in an extension context where window.find might not work properly
   function isInExtensionContext() {
     try {
       // Check if we're in a content script environment
       return typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;
     } catch (e) {
       return false;
     }
   }
   
   // Find all exact text matches in the document
   function findAllTextMatches(searchText) {
     const matches = [];
     
     if (!document.body || !searchText) {
       return matches;
     }
     
     const walker = document.createTreeWalker(
       document.body,
       NodeFilter.SHOW_TEXT,
       {
         acceptNode: (textNode) => {
           const parent = textNode.parentElement;
           if (!parent) return NodeFilter.FILTER_REJECT;
           if (parent.closest?.('#contextwizard-indicator') || 
               parent.closest?.('#contextwizard-nav-container') ||
               parent.closest?.('#contextwizard-bookmark-button') ||
               parent.closest?.('#contextwizard-bookmark-input-popup') ||
               parent.closest?.('#contextwizard-bookmark-list-popup')) {
             return NodeFilter.FILTER_REJECT;
           }
           if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
             return NodeFilter.FILTER_REJECT;
           }
           return NodeFilter.FILTER_ACCEPT;
         }
       }
     );
     
     let currentNode;
     while ((currentNode = walker.nextNode())) {
       const text = currentNode.textContent || '';
       let index = 0;
       
       while ((index = text.indexOf(searchText, index)) !== -1) {
         matches.push({
           node: currentNode,
           index: index,
           htmlOffset: calculateTextOffset(currentNode) + index
         });
         index += searchText.length;
       }
     }
     
     return matches;
   }

   // Find text matches by searching container elements' textContent
   function findAllTextMatchesByContainer(searchText) {
     const matches = [];
     if (!document.body || !searchText) {
       return matches;
     }

     const walker = document.createTreeWalker(
       document.body,
       NodeFilter.SHOW_ELEMENT,
       {
         acceptNode: (element) => {
           if (!element || element === document.body) return NodeFilter.FILTER_SKIP;
           if (element.closest?.('#contextwizard-indicator') || 
               element.closest?.('#contextwizard-nav-container') ||
               element.closest?.('#contextwizard-bookmark-button') ||
               element.closest?.('#contextwizard-bookmark-input-popup') ||
               element.closest?.('#contextwizard-bookmark-list-popup')) {
             return NodeFilter.FILTER_REJECT;
           }
           if (element.classList?.contains('contextwizard-bookmark-text-highlight')) {
             return NodeFilter.FILTER_REJECT;
           }
           return NodeFilter.FILTER_ACCEPT;
         }
       }
     );

     let currentElement;
     while ((currentElement = walker.nextNode())) {
       const text = currentElement.textContent || '';
       const index = text.indexOf(searchText);
       if (index !== -1) {
         const pos = findTextPositionInElement(currentElement, index);
         if (pos?.node) {
           matches.push({
             node: pos.node,
             index: pos.offset,
             htmlOffset: calculateTextOffset(pos.node) + pos.offset
           });
         }
       }
     }

     return matches;
   }
   
   // Find fuzzy text matches using normalized text comparison
   function findAllTextMatchesFuzzy(searchText) {
     const matches = [];
     
     if (!document.body || !searchText) {
       return matches;
     }
     
     const normalizedSearch = normalizeTextForSearch(searchText);
     
     const walker = document.createTreeWalker(
       document.body,
       NodeFilter.SHOW_TEXT,
       {
         acceptNode: (textNode) => {
           const parent = textNode.parentElement;
           if (!parent) return NodeFilter.FILTER_REJECT;
           if (parent.closest?.('#contextwizard-indicator') || 
               parent.closest?.('#contextwizard-nav-container') ||
               parent.closest?.('#contextwizard-bookmark-button') ||
               parent.closest?.('#contextwizard-bookmark-input-popup') ||
               parent.closest?.('#contextwizard-bookmark-list-popup')) {
             return NodeFilter.FILTER_REJECT;
           }
           if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
             return NodeFilter.FILTER_REJECT;
           }
           return NodeFilter.FILTER_ACCEPT;
         }
       }
     );
     
     let currentNode;
     while ((currentNode = walker.nextNode())) {
       const text = currentNode.textContent || '';
       const normalizedText = normalizeTextForSearch(text);
       
       if (normalizedText.includes(normalizedSearch)) {
         const index = text.indexOf(searchText); // Try to find original text first
         const actualIndex = index !== -1 ? index : 0; // Fallback to start of node
         
         matches.push({
           node: currentNode,
           index: actualIndex,
           htmlOffset: calculateTextOffset(currentNode) + actualIndex
         });
       }
     }
     
return matches;
    }
    
    // Robust text search that handles HTML tags properly
    function findTextWithRobustSearch(searchText, targetMessageIndex, messageAttribute) {
      if (!document.body || !searchText || searchText.length < 3) {
        return null;
      }

      // Determine search scope: specific message or entire document
      let searchRoot = document.body;
      if (targetMessageIndex !== undefined && targetMessageIndex !== null) {
        // Use the specific message attribute if provided, otherwise try both
        let messageElement = null;
        if (messageAttribute) {
          messageElement = document.querySelector(`[${messageAttribute}="${targetMessageIndex}"]`);
        }
        
        if (!messageElement) {
          // Fallback to try both attributes
          messageElement = document.querySelector(`[data-message-index="${targetMessageIndex}"]`) ||
                         document.querySelector(`[data-start="${targetMessageIndex}"]`);
        }
        
        if (messageElement) {
          searchRoot = messageElement;

        } else {
          console.warn('[ContextWizard] Message element not found for index:', targetMessageIndex, 'falling back to global search');
        }
      }
      
      // Method 1: Look for exact matches in individual text nodes first
      const walker = document.createTreeWalker(
        searchRoot,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: (textNode) => {
            const parent = textNode.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            if (parent.closest?.('#contextwizard-indicator') || 
                parent.closest?.('#contextwizard-nav-container') ||
                parent.closest?.('#contextwizard-bookmark-button') ||
                parent.closest?.('#contextwizard-bookmark-input-popup') ||
                parent.closest?.('#contextwizard-bookmark-list-popup')) {
              return NodeFilter.FILTER_REJECT;
            }
            if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
              return NodeFilter.FILTER_REJECT;
            }
            return NodeFilter.FILTER_ACCEPT;
          }
        }
      );
      
      const allTextNodes = [];
      let currentNode;
      while ((currentNode = walker.nextNode())) {
        allTextNodes.push(currentNode);
      }

      // Method 2: Look for exact matches in single nodes
      for (let i = 0; i < allTextNodes.length; i++) {
        const nodeText = allTextNodes[i].textContent || '';
        const index = nodeText.indexOf(searchText);
        if (index !== -1) {
          // Calculate actual matched text length (in case it includes trailing whitespace)
          const matchedText = nodeText.substring(index, index + searchText.length);

          return {
            node: allTextNodes[i],
            index: index,
            htmlOffset: calculateTextOffset(allTextNodes[i]) + index,
            matchedLength: searchText.length // Use trimmed length for single-node matches
          };
        }
      }
      
      // Method 3: Look for matches across consecutive text nodes (most important for HTML tags)
      for (let i = 0; i < allTextNodes.length; i++) {
        let accumulatedText = '';
        const nodeRange = [];
        
        // Accumulate text from nodes with the same parent
        for (let j = i; j < Math.min(i + 10, allTextNodes.length); j++) {
          const node1Parent = allTextNodes[j].parentElement;
          const node2Parent = allTextNodes[i].parentElement;
          
          // Only continue if nodes share the same parent or are siblings
          if (node1Parent === node2Parent || 
              (node1Parent && node2Parent && node1Parent.parentElement === node2Parent.parentElement)) {
            
            accumulatedText += allTextNodes[j].textContent || '';
            nodeRange.push(allTextNodes[j]);
            
            const matchIndex = accumulatedText.indexOf(searchText);
            if (matchIndex !== -1) {
              const matchedText = accumulatedText.substring(matchIndex, matchIndex + searchText.length);
              
              // Find which specific node contains the start of the match
              let offset = 0;
              for (let k = 0; k < nodeRange.length; k++) {
                const nodeText = nodeRange[k].textContent || '';
                if (offset + nodeText.length >= matchIndex) {
                  return {
                    node: nodeRange[k],
                    index: matchIndex - offset,
                    htmlOffset: calculateTextOffset(nodeRange[k]) + (matchIndex - offset),
                    matchedLength: searchText.length // Use trimmed length for consistency
                  };
                }
                offset += nodeText.length;
              }
            }
          } else {
            break;
          }
        }
      }
      
      return null;
    }

    // Find ALL matches within a specific message using robust search
    // Returns an array of matches, each with node, index, htmlOffset, and matchedLength
    function findAllMatchesWithRobustSearch(searchText, targetMessageIndex, messageAttribute) {
      const matches = [];
      
      if (!document.body || !searchText || searchText.length < 3) {
        return matches;
      }
      
      // Determine search scope: specific message or entire document
      let searchRoot = document.body;
      if (targetMessageIndex !== undefined && targetMessageIndex !== null) {
        // Use the specific message attribute if provided, otherwise try both
        let messageElement = null;
        if (messageAttribute) {
          messageElement = document.querySelector(`[${messageAttribute}="${targetMessageIndex}"]`);
        }
        
        if (!messageElement) {
          // Fallback to try both attributes
          messageElement = document.querySelector(`[data-message-index="${targetMessageIndex}"]`) ||
                         document.querySelector(`[data-start="${targetMessageIndex}"]`);
        }
        
        if (messageElement) {
          searchRoot = messageElement;
        } else {
          // Message element not found, return empty matches
          return matches;
        }
      }
      
      // Get all text nodes within the search root
      const walker = document.createTreeWalker(
        searchRoot,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: (textNode) => {
            const parent = textNode.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            if (parent.closest?.('#contextwizard-indicator') || 
                parent.closest?.('#contextwizard-nav-container') ||
                parent.closest?.('#contextwizard-bookmark-button') ||
                parent.closest?.('#contextwizard-bookmark-input-popup') ||
                parent.closest?.('#contextwizard-bookmark-list-popup')) {
              return NodeFilter.FILTER_REJECT;
            }
            if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
              return NodeFilter.FILTER_REJECT;
            }
            return NodeFilter.FILTER_ACCEPT;
          }
        }
      );
      
      const allTextNodes = [];
      let currentNode;
      while ((currentNode = walker.nextNode())) {
        allTextNodes.push(currentNode);
      }
      
      // Method 1: Find all exact matches in single nodes
      for (let i = 0; i < allTextNodes.length; i++) {
        const nodeText = allTextNodes[i].textContent || '';
        let searchIndex = 0;
        
        while ((searchIndex = nodeText.indexOf(searchText, searchIndex)) !== -1) {
          matches.push({
            node: allTextNodes[i],
            index: searchIndex,
            htmlOffset: calculateTextOffset(allTextNodes[i]) + searchIndex,
            matchedLength: searchText.length
          });
          searchIndex += searchText.length;
        }
      }
      
      // Method 2: Find matches across consecutive text nodes
      for (let i = 0; i < allTextNodes.length; i++) {
        let accumulatedText = '';
        const nodeRange = [];
        
        // Accumulate text from nodes with the same parent
        for (let j = i; j < Math.min(i + 10, allTextNodes.length); j++) {
          const node1Parent = allTextNodes[j].parentElement;
          const node2Parent = allTextNodes[i].parentElement;
          
          // Only continue if nodes share the same parent or are siblings
          if (node1Parent === node2Parent || 
              (node1Parent && node2Parent && node1Parent.parentElement === node2Parent.parentElement)) {
            
            accumulatedText += allTextNodes[j].textContent || '';
            nodeRange.push(allTextNodes[j]);
            
            let matchIndex = 0;
            while ((matchIndex = accumulatedText.indexOf(searchText, matchIndex)) !== -1) {
              // Find which specific node contains the start of the match
              let offset = 0;
              for (let k = 0; k < nodeRange.length; k++) {
                const nodeText = nodeRange[k].textContent || '';
                if (offset + nodeText.length > matchIndex) {
                  // Check if this match is already recorded (avoid duplicates from Method 1)
                  const nodeMatchIndex = matchIndex - offset;
                  const existingMatch = matches.find(m => 
                    m.node === nodeRange[k] && m.index === nodeMatchIndex
                  );
                  
                  if (!existingMatch) {
                    matches.push({
                      node: nodeRange[k],
                      index: nodeMatchIndex,
                      htmlOffset: calculateTextOffset(nodeRange[k]) + nodeMatchIndex,
                      matchedLength: searchText.length
                    });
                  }
                  break;
                }
                offset += nodeText.length;
              }
              matchIndex += searchText.length;
            }
          } else {
            break;
          }
        }
      }
      
      return matches;
    }

    // Find text using browser's native capabilities to handle HTML content
    function findMultiNodeTextMatch(searchText) {
      if (!document.body || !searchText || searchText.length < 5) {
        return null;
      }
      
      // Method 1: Use a more flexible text search that accounts for HTML structure
      const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: (textNode) => {
            const parent = textNode.parentElement;
            if (!parent) return NodeFilter.FILTER_REJECT;
            if (parent.closest?.('#contextwizard-indicator') || 
                parent.closest?.('#contextwizard-nav-container') ||
                parent.closest?.('#contextwizard-bookmark-button') ||
                parent.closest?.('#contextwizard-bookmark-input-popup') ||
                parent.closest?.('#contextwizard-bookmark-list-popup')) {
              return NodeFilter.FILTER_REJECT;
            }
            if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
              return NodeFilter.FILTER_REJECT;
            }
            return NodeFilter.FILTER_ACCEPT;
          }
        }
      );
      
      // Method 2: Use XPath to find text content that matches regardless of HTML structure
      try {
        // Create an XPath that looks for the text content anywhere in the document
        const escapedText = searchText.replace(/'/g, "\\'");
        const xpath = `//text()[contains(., '${escapedText}')]`;
        
        const xpathResult = document.evaluate(
          xpath,
          document.body,
          null,
          XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
          null
        );
        
        for (let i = 0; i < xpathResult.snapshotLength; i++) {
          const textNode = xpathResult.snapshotItem(i);
          const textContent = textNode.textContent || '';
          const index = textContent.indexOf(searchText);
          
          if (index !== -1) {
            return {
              startNode: textNode,
              startIndex: index
            };
          }
        }
      } catch (e) {

      }
      
      // Method 3: Manual search with improved HTML awareness
      const allTextNodes = [];
      let currentNode;
      while ((currentNode = walker.nextNode())) {
        allTextNodes.push(currentNode);
      }
      
      // Try to match by checking if the sequence of text nodes contains our search text
      for (let i = 0; i < allTextNodes.length; i++) {
        let accumulatedText = '';
        
        // Accumulate text from consecutive sibling nodes
        for (let j = i; j < Math.min(i + 5, allTextNodes.length); j++) {
          if (areInSameContext(allTextNodes[i], allTextNodes[j])) {
            accumulatedText += allTextNodes[j].textContent || '';
            
            // Check if our search text appears in the accumulated text
            const matchIndex = accumulatedText.indexOf(searchText);
            if (matchIndex !== -1) {
              // Find which node contains the start of the match
              let offset = 0;
              for (let k = i; k <= j; k++) {
                const nodeText = allTextNodes[k].textContent || '';
                if (offset + nodeText.length >= matchIndex) {
                  return {
                    startNode: allTextNodes[k],
                    startIndex: matchIndex - offset
                  };
                }
                offset += nodeText.length;
              }
            }
          } else {
            break;
          }
        }
      }
      
      return null;
    }
    
    // Check if two nodes are in the same logical context (not separated by block elements)
    function areInSameContext(node1, node2) {
      if (!node1 || !node2) return false;
      
      let current = node1;
      while (current && current !== document.body) {
        if (current === node2) return true;
        
        // If we hit a block element, they're not in the same context
        if (current.nodeType === Node.ELEMENT_NODE) {
          const display = window.getComputedStyle(current).display;
          if (display === 'block' || display === 'flex' || display === 'grid' ||
              current.tagName === 'P' || current.tagName === 'DIV' || current.tagName === 'LI') {
            return false;
          }
        }
        
        current = current.nextSibling;
      }
      
      return false;
    }
    
    // Check if two text nodes are siblings (have same parent and are adjacent)
    function areTextNodesSiblings(node1, node2) {
      if (!node1 || !node2 || node1.parentNode !== node2.parentNode) {
        return false;
      }
      
      const children = Array.from(node1.parentNode.childNodes);
      const index1 = children.indexOf(node1);
      const index2 = children.indexOf(node2);
      
      return Math.abs(index1 - index2) <= 2; // Allow for non-text nodes between them
    }
    
    // Find the match closest to the target htmlOffset
   function findClosestMatchByOffset(matches, targetOffset) {
      if (!matches || matches.length === 0) {
        return null;
      }
      
      // Find the closest match and its distance
      let closest = matches[0];
      let closestDistance = Math.abs(matches[0].htmlOffset - targetOffset);
      for (let i = 1; i < matches.length; i++) {
        const distance = Math.abs(matches[i].htmlOffset - targetOffset);
        if (distance < closestDistance) {
          closest = matches[i];
          closestDistance = distance;
        }
      }
      
      // If all matches are too far from the target offset, return null.
      // This threshold prevents bookmark drift: when the page has changed,
      // a match that's very distant from the saved offset is likely wrong.
      const MAX_DRIFT_THRESHOLD = 500;
      if (closestDistance > MAX_DRIFT_THRESHOLD) {

        return null;
      }
      
      return closest;
    }
   
   // Calculate the HTML offset of a text position within a node
   function calculateTextOffset(targetNode) {
     let offset = 0;
     
     const walker = document.createTreeWalker(
       document.body,
       NodeFilter.SHOW_TEXT,
       {
         acceptNode: (textNode) => {
           const parent = textNode.parentElement;
           if (!parent) return NodeFilter.FILTER_REJECT;
           if (parent.closest?.('#contextwizard-indicator') || 
               parent.closest?.('#contextwizard-nav-container') ||
               parent.closest?.('#contextwizard-bookmark-button') ||
               parent.closest?.('#contextwizard-bookmark-input-popup') ||
               parent.closest?.('#contextwizard-bookmark-list-popup')) {
             return NodeFilter.FILTER_REJECT;
           }
           if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
             return NodeFilter.FILTER_REJECT;
           }
           return NodeFilter.FILTER_ACCEPT;
         }
       }
     );
     
     let currentNode;
     while ((currentNode = walker.nextNode())) {
       if (currentNode === targetNode) {
         break;
       }
       offset += currentNode.textContent?.length || 0;
     }
     
     return offset;
   }
  
   // Find text position using HTML document offset, then verify with context
   // Create a bookmark highlight at specific position
   function createBookmarkHighlight(textNode, index, length, bookmark) {
     const text = textNode.nodeValue || '';
     
// Check if textNode is still in DOM and valid
      if (!textNode.parentNode) {
        console.warn('[ContextWizard] createBookmarkHighlight: Text node parent is null, skipping highlight for bookmark:', bookmark.id);
        return null;
      }
      
      // Additional validation: check if text node is still connected to document
      if (!document.body.contains(textNode)) {
        console.warn('[ContextWizard] createBookmarkHighlight: Text node not connected to document, skipping highlight for bookmark:', bookmark.id);
        return null;
      }
      
      // If the highlight spans multiple nodes, use a range-based highlight
      if (index < 0 || length <= 0) {
        console.warn('[ContextWizard] createBookmarkHighlight: Invalid index/length bounds for bookmark:', bookmark.id, 'index:', index, 'length:', length, 'textLength:', text.length);
        return null;
      }
      
      // Clamp the length to not exceed the available text in this node
      const availableLength = text.length - index;
      if (length > availableLength) {

        return createBookmarkHighlightAcrossNodes(textNode, index, length, bookmark);
      }
      
      // Additional safety: ensure we don't highlight more than what's actually there
      const safeLength = Math.min(length, availableLength);

     // Create document fragment with highlighted text
     const frag = document.createDocumentFragment();
     
     if (index > 0) {
       frag.appendChild(document.createTextNode(text.slice(0, index)));
     }
     
     const mark = document.createElement('mark');
     mark.className = 'contextwizard-bookmark-text-highlight';
     mark.setAttribute('data-bookmark-id', bookmark.id);
     mark.setAttribute('data-bookmark-marker-id', bookmark.id);
     mark.setAttribute('title', bookmark.content);
     mark.textContent = text.slice(index, index + safeLength);
     frag.appendChild(mark);
     
     if (index + safeLength < text.length) {
       frag.appendChild(document.createTextNode(text.slice(index + safeLength)));
     }
     
     textNode.parentNode?.replaceChild(frag, textNode);
     
     
     // Add hover preview
     mark.addEventListener('mouseenter', () => {
       showBookmarkMarkerPreview(mark, bookmark);
     });
     
     mark.addEventListener('mouseleave', () => {
       // Delay hide to allow mouse to enter preview
       if (bookmarkPreviewTimeout) {
         clearTimeout(bookmarkPreviewTimeout);
       }
       bookmarkPreviewTimeout = setTimeout(() => {
         hideBookmarkMarkerPreview();
       }, 150);
     });
     
     return mark;
   }

   // Create a highlight that can span across multiple text nodes
   function createBookmarkHighlightAcrossNodes(startNode, startIndex, length, bookmark) {
     if (!startNode || !document.body.contains(startNode)) {
       console.warn('[ContextWizard] createBookmarkHighlightAcrossNodes: Start node not connected to document for bookmark:', bookmark.id);
       return null;
     }

     const range = document.createRange();
     range.setStart(startNode, startIndex);

     let remaining = length;
     const startText = startNode.textContent || '';
     const availableInStart = Math.max(0, startText.length - startIndex);
     if (availableInStart >= remaining) {
       range.setEnd(startNode, startIndex + remaining);
       return createBookmarkHighlightFromRange(range, bookmark);
     }

     remaining -= availableInStart;

     let currentNode = startNode;
     while (remaining > 0) {
       currentNode = getNextSearchableTextNode(currentNode);
       if (!currentNode) {
         console.warn('[ContextWizard] createBookmarkHighlightAcrossNodes: Could not find end node for bookmark:', bookmark.id);
         return null;
       }

       const nodeText = currentNode.textContent || '';
       if (nodeText.length >= remaining) {
         range.setEnd(currentNode, remaining);
         remaining = 0;
         break;
       }
       remaining -= nodeText.length;
     }

     if (remaining > 0) {
       console.warn('[ContextWizard] createBookmarkHighlightAcrossNodes: Remaining length not exhausted for bookmark:', bookmark.id);
       return null;
     }

     return createBookmarkHighlightFromRange(range, bookmark);
   }

   function createBookmarkHighlightFromRange(range, bookmark) {
     const textNodes = [];
     const walker = document.createTreeWalker(
       range.commonAncestorContainer,
       NodeFilter.SHOW_TEXT,
       {
         acceptNode: (textNode) => {
           const parent = textNode.parentElement;
           if (!parent) return NodeFilter.FILTER_REJECT;
           if (parent.closest?.('#contextwizard-indicator') || 
               parent.closest?.('#contextwizard-nav-container') ||
               parent.closest?.('#contextwizard-bookmark-button') ||
               parent.closest?.('#contextwizard-bookmark-input-popup') ||
               parent.closest?.('#contextwizard-bookmark-list-popup')) {
             return NodeFilter.FILTER_REJECT;
           }
           if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
             return NodeFilter.FILTER_REJECT;
           }
           return range.intersectsNode(textNode) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
         }
       }
     );

     let currentNode;
     while ((currentNode = walker.nextNode())) {
       textNodes.push(currentNode);
     }

     if (textNodes.length === 0) {
       console.warn('[ContextWizard] createBookmarkHighlightFromRange: No text nodes in range for bookmark:', bookmark.id);
       return null;
     }

     const marks = [];
     for (const node of textNodes) {
       const nodeText = node.nodeValue || '';
       if (!nodeText.trim()) {
         continue;
       }
       const start = node === range.startContainer ? range.startOffset : 0;
       const end = node === range.endContainer ? range.endOffset : nodeText.length;

       if (start >= end || start < 0 || end > nodeText.length) {
         continue;
       }

       const frag = document.createDocumentFragment();
       if (start > 0) {
         frag.appendChild(document.createTextNode(nodeText.slice(0, start)));
       }

       const mark = document.createElement('mark');
       mark.className = 'contextwizard-bookmark-text-highlight';
       mark.setAttribute('data-bookmark-id', bookmark.id);
       mark.setAttribute('data-bookmark-marker-id', bookmark.id);
       mark.setAttribute('title', bookmark.content);
       mark.textContent = nodeText.slice(start, end);
       frag.appendChild(mark);

       if (end < nodeText.length) {
         frag.appendChild(document.createTextNode(nodeText.slice(end)));
       }

       node.parentNode?.replaceChild(frag, node);

       mark.addEventListener('mouseenter', () => {
         showBookmarkMarkerPreview(mark, bookmark);
       });

       mark.addEventListener('mouseleave', () => {
         if (bookmarkPreviewTimeout) {
           clearTimeout(bookmarkPreviewTimeout);
         }
         bookmarkPreviewTimeout = setTimeout(() => {
           hideBookmarkMarkerPreview();
         }, 150);
       });

       marks.push(mark);
     }

     return marks[0] || null;
   }

   function getNextSearchableTextNode(startNode) {
     const walker = document.createTreeWalker(
       document.body,
       NodeFilter.SHOW_TEXT,
       {
         acceptNode: (textNode) => {
           const parent = textNode.parentElement;
           if (!parent) return NodeFilter.FILTER_REJECT;
           if (parent.closest?.('#contextwizard-indicator') || 
               parent.closest?.('#contextwizard-nav-container') ||
               parent.closest?.('#contextwizard-bookmark-button') ||
               parent.closest?.('#contextwizard-bookmark-input-popup') ||
               parent.closest?.('#contextwizard-bookmark-list-popup')) {
             return NodeFilter.FILTER_REJECT;
           }
           if (parent.classList?.contains('contextwizard-bookmark-text-highlight')) {
             return NodeFilter.FILTER_REJECT;
           }
           return NodeFilter.FILTER_ACCEPT;
         }
       }
     );

     let currentNode;
     let foundStart = false;
     while ((currentNode = walker.nextNode())) {
       if (!foundStart) {
         if (currentNode === startNode) {
           foundStart = true;
         }
         continue;
       }
       return currentNode;
     }

     return null;
   }
  
  // Find text position in element by character offset
  function findTextPositionInElement(element, charOffset) {
    const walker = document.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
      null
    );
    
    let currentOffset = 0;
    let currentNode;
    
    while ((currentNode = walker.nextNode())) {
      const nodeLength = currentNode.textContent?.length || 0;
      
      if (currentOffset + nodeLength >= charOffset) {
        // Found the text node
        return {
          node: currentNode,
          offset: charOffset - currentOffset
        };
      }
      
      currentOffset += nodeLength;
    }
    
    return null;
  }

  // Show bookmark marker preview on hover
  let bookmarkMarkerPreview = null;
  let bookmarkPreviewTimeout = null;

  function showBookmarkMarkerPreview(marker, bookmark) {
    if (bookmarkPreviewTimeout) {
      clearTimeout(bookmarkPreviewTimeout);
      bookmarkPreviewTimeout = null;
    }
    
    if (bookmarkMarkerPreview) {
      bookmarkMarkerPreview.remove();
    }

    bookmarkMarkerPreview = document.createElement('div');
    bookmarkMarkerPreview.className = 'contextwizard-bookmark-marker-preview';
    const openManagerLabel = escapeHtml(getMessage('bookmarkOpenManager', 'Open in Bookmark Manager'));
    const openManagerTooltip = escapeHtml(getMessage('bookmarkOpenManagerTooltip', 'Open this bookmark in Bookmark Manager'));
    bookmarkMarkerPreview.innerHTML = `
      <div class="contextwizard-bookmark-marker-preview-content">${bookmark.content}</div>
      <div class="contextwizard-bookmark-marker-preview-buttons">
        <button class="contextwizard-bookmark-marker-preview-open-manager" data-bookmark-id="${bookmark.id}" title="${openManagerTooltip}">${openManagerLabel}</button>
        <button class="contextwizard-bookmark-marker-preview-delete" data-bookmark-id="${bookmark.id}">${escapeHtml(getMessage('bookmarkDeleteButton', 'Delete'))}</button>
        <button class="contextwizard-bookmark-marker-preview-cancel hidden" data-bookmark-id="${bookmark.id}">${escapeHtml(getMessage('bookmarkCancelButton', 'Cancel'))}</button>
      </div>
    `;
    
    document.body.appendChild(bookmarkMarkerPreview);
    
    // Position near marker
    const rect = marker.getBoundingClientRect();
    bookmarkMarkerPreview.style.top = `${rect.bottom + window.scrollY + 5}px`;
    bookmarkMarkerPreview.style.left = `${rect.left + window.scrollX}px`;
    
    // Handle delete button
    const deleteBtn = bookmarkMarkerPreview.querySelector('.contextwizard-bookmark-marker-preview-delete');
    const cancelBtn = bookmarkMarkerPreview.querySelector('.contextwizard-bookmark-marker-preview-cancel');
    let deleteConfirmMode = false;

    deleteBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!deleteConfirmMode) {
        deleteConfirmMode = true;
        deleteBtn.textContent = getMessage('conversationDeleteConfirmButton', 'Confirm');
        cancelBtn.classList.remove('hidden');
        deleteBtn.style.background = 'rgba(239, 68, 68, 0.3)';
        deleteBtn.style.borderColor = 'rgba(239, 68, 68, 0.5)';
      } else {
        const bookmarkId = deleteBtn.getAttribute('data-bookmark-id');
        confirmDeleteBookmark(bookmarkId);
        hideBookmarkMarkerPreview();
      }
    });

    // Handle cancel button
    cancelBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteConfirmMode = false;
      deleteBtn.textContent = 'Delete';
      cancelBtn.classList.add('hidden');
      deleteBtn.style.background = '';
      deleteBtn.style.borderColor = '';
    });

    // Handle open in Bookmark Manager button
    const openManagerBtn = bookmarkMarkerPreview.querySelector('.contextwizard-bookmark-marker-preview-open-manager');
    openManagerBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      const bookmarkId = openManagerBtn.getAttribute('data-bookmark-id');
      if (bookmarkId) {
        try {
          chrome.runtime.sendMessage({ action: 'openBookmarkManager', bookmarkId });
        } catch (err) {
          console.warn('[ContextWizard] Failed to send openBookmarkManager message:', err);
        }
      }
      hideBookmarkMarkerPreview();
    });
    
    // Add mouse events to preview to keep it open
    bookmarkMarkerPreview.addEventListener('mouseenter', () => {
      if (bookmarkPreviewTimeout) {
        clearTimeout(bookmarkPreviewTimeout);
        bookmarkPreviewTimeout = null;
      }
    });
    
    bookmarkMarkerPreview.addEventListener('mouseleave', () => {
      hideBookmarkMarkerPreview();
    });
  }

  // Hide bookmark marker preview
  function hideBookmarkMarkerPreview() {
    if (bookmarkPreviewTimeout) {
      clearTimeout(bookmarkPreviewTimeout);
      bookmarkPreviewTimeout = null;
    }
    
    if (bookmarkMarkerPreview) {
      bookmarkMarkerPreview.remove();
      bookmarkMarkerPreview = null;
    }
    
    // Backup: remove any orphaned preview elements
    const orphaned = document.querySelector('.contextwizard-bookmark-marker-preview');
    if (orphaned) {
      orphaned.remove();
    }
  }

  // Initialize bookmark functionality
  function initBookmarks() {
    // Clean up any existing popup on init (page refresh scenario)
    if (bookmarkListPopup) {
      bookmarkListPopup._cleanup?.();
      bookmarkListPopup.remove();
      bookmarkListPopup = null;
    }

    createBookmarkButton();
    createBookmarkViewListButton();
    monitorTextSelection();

    // Load bookmarks when conversation is detected
    if (currentConversation) {
      loadConversationBookmarks();
    }
  }

  // Tag message elements with indices for bookmark positioning
  function tagMessageElements() {
    if (!currentConversation || !currentConversation.messages) {
      return;
    }

    // Use message-extractor to find message elements
    const platform = currentPlatform;
    if (!platform) {
      return;
    }

    const extractor = new MessageExtractor(platform);
    const conversationArea = extractor.findConversationArea();
    if (!conversationArea) {
      return;
    }

    const textBlocks = extractor.extractTextBlocks(conversationArea);
    
    // Tag each text block element with its message index
    textBlocks.forEach((block, index) => {
      if (block.element) {
        block.element.setAttribute('data-message-index', index);
      }
    });


  }

  // Make element draggable
  function makeDraggable(element) {
    // Defensive: remove any duplicate floating controls that may have been left behind
    dedupeFloatingControls(element);
    let isDragging = false;
    let currentX;
    let currentY;
    let initialX;
    let initialY;
    let xOffset = null;
    let yOffset = null;
    let dragStartOffsetX = 0;
    let dragStartOffsetY = 0;
    let suppressAttachedUpdates = false;

    // Use top/left positioning to avoid transform stacking quirks on host pages
    element.style.position = 'fixed';
    element.style.bottom = 'auto';
    element.style.right = 'auto';
    
    element.addEventListener('mousedown', dragStart);
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', dragEnd);
    
    // Touch events for mobile
    element.addEventListener('touchstart', dragStart, { passive: false });
    document.addEventListener('touchmove', drag);
    document.addEventListener('touchend', dragEnd);

    function dedupeFloatingControls(currentIndicator) {
      const ids = ['contextwizard-indicator', 'contextwizard-copy-button', 'contextwizard-prompts-button', 'contextwizard-bookmark-button', 'contextwizard-bookmark-view-list-button'];
      ids.forEach((id) => {
        const nodes = document.querySelectorAll(`#${id}`);
        nodes.forEach((node) => {
          if (id === 'contextwizard-indicator') {
            if (node !== currentIndicator && nodes.length > 1) {
              node.remove();
            }
          } else {
            // For buttons, keep the first instance only
            if (node !== nodes[0]) {
              node.remove();
            }
          }
        });
      });
    }
    
    function dragStart(e) {
      const { clientX, clientY } = getClientPosition(e);
      const rect = element.getBoundingClientRect();

      // Seed offsets from the element's current position if we don't have one yet.
      if (!Number.isFinite(xOffset)) {
        xOffset = rect.left;
      }
      if (!Number.isFinite(yOffset)) {
        yOffset = rect.top;
      }

      initialX = clientX;
      initialY = clientY;

      if (e.target === element || element.contains(e.target)) {
        dedupeFloatingControls(element);
        isDragging = true;
        suppressAttachedUpdates = false; // Allow updates during drag
        dragStartOffsetX = xOffset;
        dragStartOffsetY = yOffset;
        suppressIndicatorClick = false;
        element.classList.add('dragging');

        // Show all buttons when starting drag and reset auto-hide timer
        handleUserInteraction();
      }
    }
    
    function drag(e) {
      if (isDragging) {
        e.preventDefault();
        const { clientX, clientY } = getClientPosition(e);

        const deltaX = clientX - initialX;
        const deltaY = clientY - initialY;
        
        currentX = dragStartOffsetX + deltaX;
        currentY = dragStartOffsetY + deltaY;
        
        const totalDeltaX = Math.abs(currentX - dragStartOffsetX);
        const totalDeltaY = Math.abs(currentY - dragStartOffsetY);
        if (!suppressIndicatorClick && (totalDeltaX > DRAG_SUPPRESS_DISTANCE || totalDeltaY > DRAG_SUPPRESS_DISTANCE)) {
          suppressIndicatorClick = true;
        }

        xOffset = currentX;
        yOffset = currentY;
        
        setTranslate(currentX, currentY, element);
        
        // Update attached button positions during drag
        if (!suppressAttachedUpdates) {
          if (copyButton && copyButton.style.display !== 'none') {
            updateCopyButtonPosition();
          }
          if (promptsButton && promptsButton.style.display !== 'none') {
            updatePromptsButtonPosition();
          }
          if (bookmarkButton && bookmarkButton.style.display !== 'none') {
            updateBookmarkButtonPosition();
          }
          if (bookmarkViewListButton && bookmarkViewListButton.style.display !== 'none') {
            updateBookmarkViewListButtonPosition();
          }
        }
      }
    }
    
    function dragEnd() {
      if (isDragging) {
        initialX = currentX;
        initialY = currentY;
        isDragging = false;
        element.classList.remove('dragging');
        
        // Ensure final position is within viewport bounds
        clampPositionToViewport();
        
        // Save position to storage
        try {
          chrome.storage.local.set({
            indicatorPosition: { x: xOffset, y: yOffset }
          });
        } catch (_) { /* Extension context may be invalidated */ }

        // Clean up any accidental duplicates after drag
        dedupeFloatingControls(element);

        // Reset auto-hide timer after drag
        resetAutoHideTimer();

        // Final position update for attached buttons
        requestAnimationFrame(() => {
          if (copyButton && copyButton.style.display !== 'none') {
            updateCopyButtonPosition();
          }
          if (promptsButton && promptsButton.style.display !== 'none') {
            updatePromptsButtonPosition();
          }
          if (bookmarkButton && bookmarkButton.style.display !== 'none') {
            updateBookmarkButtonPosition();
          }
          if (bookmarkViewListButton && bookmarkViewListButton.style.display !== 'none') {
            updateBookmarkViewListButtonPosition();
          }
        });

        if (suppressIndicatorClick) {
          setTimeout(() => {
            suppressIndicatorClick = false;
          }, 150);
        }
      }
    }

    // Normalize mouse / touch coordinates
    function getClientPosition(event) {
      if (event.type.startsWith('touch')) {
        const touch = event.touches[0] || event.changedTouches[0];
        return { clientX: touch?.clientX ?? 0, clientY: touch?.clientY ?? 0 };
      }
      return { clientX: event.clientX, clientY: event.clientY };
    }
    
    // Clamp position to viewport bounds, accounting for element size
    function clampPositionToViewport() {
      if (!Number.isFinite(xOffset) || !Number.isFinite(yOffset)) {
        const rect = element.getBoundingClientRect();
        xOffset = Number.isFinite(rect.left) ? rect.left : 0;
        yOffset = Number.isFinite(rect.top) ? rect.top : 0;
      }
      let elementWidth, elementHeight;
      
      const rect = element.getBoundingClientRect();
      
      if (rect.width > 0 && rect.height > 0) {
        elementWidth = rect.width;
        elementHeight = rect.height;
      } else {
        elementWidth = element.offsetWidth || 150;
        elementHeight = element.offsetHeight || 40;
      }
      
      const maxX = Math.max(0, window.innerWidth - elementWidth);
      const maxY = Math.max(0, window.innerHeight - elementHeight);
      
      let finalX = Math.max(0, Math.min(xOffset, maxX));
      let finalY = Math.max(0, Math.min(yOffset, maxY));
      
      if (finalX !== xOffset || finalY !== yOffset) {
        xOffset = finalX;
        yOffset = finalY;
        setTranslate(finalX, finalY, element);
      }
    }
    
    function setTranslate(xPos, yPos, el) {
      el.style.left = `${xPos}px`;
      el.style.top = `${yPos}px`;
      el.style.transform = 'translate(0, 0)';

      // Also update the navigation container position
      if (navContainer) {
        updateNavigationContainerPosition();
      }

      // Also update the copy button position (skip during drag for fly-in animation)
      if (copyButton && !isDragging && !suppressAttachedUpdates) {
        updateCopyButtonPosition();
      }

      // Also update prompts button position (skip during drag for fly-in animation)
      if (promptsButton && !isDragging && !suppressAttachedUpdates) {
        updatePromptsButtonPosition();
      }

      // Also update the bookmark button position (skip during drag for fly-in animation)
      if (bookmarkButton && !isDragging && !suppressAttachedUpdates && bookmarkButton.style.display !== 'none') {
        updateBookmarkButtonPosition();
      }
      
      // Also update the bookmark view list button position (skip during drag for fly-in animation)
      if (bookmarkViewListButton && !isDragging && !suppressAttachedUpdates && bookmarkViewListButton.style.display !== 'none') {
        updateBookmarkViewListButtonPosition();
      }
    }
    
    // Monitor for window resize and reposition if needed
    window.addEventListener('resize', () => {
      clampPositionToViewport();
      updateCopyButtonPosition();
      if (promptsButton && promptsButton.style.display !== 'none') {
        updatePromptsButtonPosition();
      }
      if (bookmarkButton && bookmarkButton.style.display !== 'none') {
        updateBookmarkButtonPosition();
      }
      if (bookmarkViewListButton && bookmarkViewListButton.style.display !== 'none') {
        updateBookmarkViewListButtonPosition();
      }
    });
    
    // Expose clampPositionToViewport to be callable from outside
    makeDraggable.clampPositionToViewport = clampPositionToViewport;
    
    // Load saved position
    chrome.storage.local.get(['indicatorPosition'], (result) => {
      if (result.indicatorPosition) {
        // Validate saved position - ensure it's within visible bounds
        let savedX = result.indicatorPosition.x;
        let savedY = result.indicatorPosition.y;
        
        // Ensure position is not negative (outside viewport)
        savedX = Math.max(0, savedX);
        savedY = Math.max(0, savedY);
        
        // Ensure position is not beyond viewport bounds
        const maxX = window.innerWidth - 100; // Leave some margin
        const maxY = window.innerHeight - 50; // Leave some margin
        savedX = Math.min(savedX, maxX);
        savedY = Math.min(savedY, maxY);

        xOffset = savedX;
        yOffset = savedY;
        initialX = savedX;
        initialY = savedY;
        
        // Apply saved position
        setTranslate(savedX, savedY, element);
      } else {
        // Initialize with default position (bottom-right corner)
        
        // Force element to be visible to get its size
        const originalDisplay = element.style.display;
        element.style.display = 'flex';
        element.style.visibility = 'hidden';
        
        // Get element dimensions
        const rect = element.getBoundingClientRect();
        const elementWidth = rect.width || 150; // fallback width
        const elementHeight = rect.height || 40; // fallback height
        
        // Restore original visibility
        element.style.display = originalDisplay;
        element.style.visibility = 'visible';
        
        // Smart calculation of right margin
        // 1. Account for scrollbar (if visible)
        const hasScrollbar = document.documentElement.scrollHeight > window.innerHeight;
        const scrollbarWidth = hasScrollbar ? 15 : 0;
        
        // 2. Find rightmost fixed/sticky element in top-right area (top 200px)
        let maxRightElementWidth = 0;
        const topRightElements = document.elementsFromPoint(window.innerWidth - 1, 100);
        
        for (const el of topRightElements) {
          if (el === element || el === document.documentElement || el === document.body) continue;
          const style = window.getComputedStyle(el);
          const position = style.position;
          
          if (position === 'fixed' || position === 'sticky') {
            const elRect = el.getBoundingClientRect();
            const elWidth = elRect.width;
            const rightEdge = window.innerWidth - elRect.right;
            
            // If element is on the right side of the screen
            if (rightEdge < 100) {
              maxRightElementWidth = Math.max(maxRightElementWidth, elWidth + rightEdge);

            }
          }
        }
        
        // 3. Calculate responsive base margin based on viewport width
        let baseMargin = 20;
        if (window.innerWidth > 1600) {
          baseMargin = 60; // Extra large screens
        } else if (window.innerWidth > 1200) {
          baseMargin = 50; // Large screens
        } else if (window.innerWidth > 768) {
          baseMargin = 40; // Medium screens
        } else {
          baseMargin = 30; // Small/mobile screens
        }
        
        // 4. Combine all factors: scrollbar + found elements + base margin
        // Move left/up to provide more space for Title changes and lower buttons
        const defaultRight = Math.max(baseMargin - 80, maxRightElementWidth + 20) + scrollbarWidth;
        const defaultBottom = 30;
        const initialXPos = window.innerWidth - elementWidth - defaultRight;
        const initialYPos = window.innerHeight - elementHeight - defaultBottom;


        xOffset = initialXPos;
        yOffset = initialYPos;
        initialX = initialXPos;
        initialY = initialYPos;
        
        setTranslate(xOffset, yOffset, element);
      }
    });
  } // End of makeDraggable function
  
  // Update recording indicator visibility.
  // When transitioning from capturing→idle, apply a grace period so brief DOM
  // disruptions (e.g. Gemini sidebar open/close) don't flicker the indicator.
  function setCapturingState(capturing) {
    if (capturing) {
      // Succeeding — clear any pending idle transition and activate immediately
      clearTimeout(capturingGraceTimer);
      capturingGraceTimer = null;
      if (!isCapturing) {
        isCapturing = true;
        updateRecordingIndicator();
      }
      return;
    }
    // Extraction failed — delay the idle switch so transient DOM glitches don't flicker
    if (isCapturing && !capturingGraceTimer) {
      capturingGraceTimer = setTimeout(() => {
        capturingGraceTimer = null;
        isCapturing = false;
        updateRecordingIndicator();
      }, CAPTURING_GRACE_DELAY);
    }
  }

  function updateRecordingIndicator() {
    if (recordingIndicator) {
      const shouldBeActive = isRecording;
      recordingIndicator.classList.toggle('active', shouldBeActive);
      recordingIndicator.setAttribute('aria-hidden', String(!shouldBeActive));
      
      // Toggle recording state class
      recordingIndicator.classList.toggle('recording', isCapturing);
      
      // Update label
      const labelEl = recordingIndicator.querySelector('.indicator-label');
      if (labelEl) {
        const key = isCapturing ? 'recording' : 'statusIdle';
        const text = chrome.i18n.getMessage(key) || (isCapturing ? 'Recording' : 'Idle');
        labelEl.textContent = text;
        
        // Update aria-label
        const hint = chrome.i18n.getMessage('recordingIndicatorHint');
        recordingIndicator.setAttribute('aria-label', hint ? `${text}. ${hint}` : text);
        
        // Check bounds after label change (text length change may affect button width)
        setTimeout(() => {
          if (recordingIndicator && makeDraggable.clampPositionToViewport) {
            makeDraggable.clampPositionToViewport();
          }
        }, 10);
      }
    }
  }
  
  function handleIndicatorClick(event) {
    if (!recordingIndicator || suppressIndicatorClick) {
      event?.preventDefault();
      return;
    }
    openPopupWindow();
  }

  function handleIndicatorKeydown(event) {
    if (!recordingIndicator) {
      return;
    }
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleIndicatorClick(event);
    }
  }

  function openPopupWindow() {
    try {
      chrome.runtime.sendMessage({ action: 'openPopupWindow' }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('[ContextWizard] Failed to open popup window:', chrome.runtime.lastError.message);
        } else if (response?.success === false && response?.error) {
          console.warn('[ContextWizard] Popup window request rejected:', response.error);
        }
      });
    } catch (_) { /* Extension context may be invalidated */ }
  }

  // Auto-hide functionality for floating buttons
  function initAutoHideFunctionality() {
    if (!recordingIndicator) return;
    
    // Add event listeners for user interaction
    recordingIndicator.addEventListener('click', handleUserInteraction);
    recordingIndicator.addEventListener('mouseenter', handleMouseEnter);
    recordingIndicator.addEventListener('mouseleave', handleMouseLeave);
    
    // Add event listeners for all floating buttons
    if (copyButton) {
      copyButton.addEventListener('click', handleUserInteraction);
    }
    if (promptsButton) {
      promptsButton.addEventListener('click', handleUserInteraction);
    }
    if (bookmarkButton) {
      bookmarkButton.addEventListener('click', handleUserInteraction);
    }
    if (bookmarkViewListButton) {
      bookmarkViewListButton.addEventListener('click', handleUserInteraction);
    }
    if (navContainer) {
      const prevBtn = navContainer.querySelector('.nav-prev');
      const nextBtn = navContainer.querySelector('.nav-next');
      if (prevBtn) prevBtn.addEventListener('click', handleUserInteraction);
      if (nextBtn) nextBtn.addEventListener('click', handleUserInteraction);
    }
    
    // Start the auto-hide timer
    resetAutoHideTimer();
  }

  function handleUserInteraction() {
    resetAutoHideTimer();
    if (isButtonsHidden) {
      showFloatingButtons();
    }
  }

  function handleMouseEnter() {
    clearTimeout(hoverTimer);
    hoverTimer = setTimeout(() => {
      if (isButtonsHidden) {
        showFloatingButtons();
      }
    }, HOVER_DELAY);
  }

  function handleMouseLeave() {
    clearTimeout(hoverTimer);
  }

  function resetAutoHideTimer() {
    clearTimeout(autoHideTimer);
    autoHideTimer = setTimeout(() => {
      hideFloatingButtons();
    }, AUTO_HIDE_DELAY);
  }

  function hideFloatingButtons() {
    if (isButtonsHidden) return;
    
    const indicatorRect = recordingIndicator.getBoundingClientRect();
    const centerX = indicatorRect.left + indicatorRect.width / 2;
    const centerY = indicatorRect.top + indicatorRect.height / 2;
    
    // Hide navigation container (above)
    if (navContainer && navContainer.style.display !== 'none') {
      const navRect = navContainer.getBoundingClientRect();
      const navCenterX = navRect.left + navRect.width / 2;
      const navCenterY = navRect.top + navRect.height / 2;
      navContainer.style.setProperty('--center-x', `${centerX - navCenterX}px`);
      navContainer.style.setProperty('--center-y', `${centerY - navCenterY}px`);
      navContainer.classList.remove('contextwizard-auto-show');
      navContainer.classList.add('contextwizard-auto-hide');
      setTimeout(() => {
        if (navContainer) {
          navContainer.style.display = 'none';
          navContainer.classList.remove('contextwizard-auto-hide');
        }
      }, 300);
    }
    
    // Hide copy button (below)
    if (copyButton && copyButton.style.display !== 'none') {
      const copyRect = copyButton.getBoundingClientRect();
      const copyCenterX = copyRect.left + copyRect.width / 2;
      const copyCenterY = copyRect.top + copyRect.height / 2;
      copyButton.style.setProperty('--center-x', `${centerX - copyCenterX}px`);
      copyButton.style.setProperty('--center-y', `${centerY - copyCenterY}px`);
      copyButton.classList.remove('contextwizard-auto-show');
      copyButton.classList.add('contextwizard-auto-hide');
      setTimeout(() => {
        if (copyButton) {
          copyButton.style.display = 'none';
          copyButton.classList.remove('contextwizard-auto-hide');
        }
      }, 300);
    }
    
    // Hide prompts button (left of copy)
    if (promptsButton && promptsButton.style.display !== 'none') {
      const promptsRect = promptsButton.getBoundingClientRect();
      const promptsCenterX = promptsRect.left + promptsRect.width / 2;
      const promptsCenterY = promptsRect.top + promptsRect.height / 2;
      promptsButton.style.setProperty('--center-x', `${centerX - promptsCenterX}px`);
      promptsButton.style.setProperty('--center-y', `${centerY - promptsCenterY}px`);
      promptsButton.classList.remove('contextwizard-auto-show');
      promptsButton.classList.add('contextwizard-auto-hide');
      setTimeout(() => {
        if (promptsButton) {
          promptsButton.style.display = 'none';
          promptsButton.classList.remove('contextwizard-auto-hide');
        }
      }, 300);
    }
    
    // Hide bookmark button (right of copy) - only if it's visible
    if (bookmarkButton && bookmarkButton.style.display !== 'none') {
      const bookmarkRect = bookmarkButton.getBoundingClientRect();
      const bookmarkCenterX = bookmarkRect.left + bookmarkRect.width / 2;
      const bookmarkCenterY = bookmarkRect.top + bookmarkRect.height / 2;
      bookmarkButton.style.setProperty('--center-x', `${centerX - bookmarkCenterX}px`);
      bookmarkButton.style.setProperty('--center-y', `${centerY - bookmarkCenterY}px`);
      bookmarkButton.classList.remove('contextwizard-auto-show');
      bookmarkButton.classList.add('contextwizard-auto-hide');
      setTimeout(() => {
        if (bookmarkButton) {
          bookmarkButton.style.display = 'none';
          bookmarkButton.classList.remove('contextwizard-auto-hide');
        }
      }, 300);
    }
    
    // Hide bookmark view list button - only if it's visible
    if (bookmarkViewListButton && bookmarkViewListButton.style.display !== 'none') {
      const viewListRect = bookmarkViewListButton.getBoundingClientRect();
      const viewListCenterX = viewListRect.left + viewListRect.width / 2;
      const viewListCenterY = viewListRect.top + viewListRect.height / 2;
      bookmarkViewListButton.style.setProperty('--center-x', `${centerX - viewListCenterX}px`);
      bookmarkViewListButton.style.setProperty('--center-y', `${centerY - viewListCenterY}px`);
      bookmarkViewListButton.classList.remove('contextwizard-auto-show');
      bookmarkViewListButton.classList.add('contextwizard-auto-hide');
      setTimeout(() => {
        if (bookmarkViewListButton) {
          bookmarkViewListButton.style.display = 'none';
          bookmarkViewListButton.classList.remove('contextwizard-auto-hide');
        }
      }, 300);
    }
    
    isButtonsHidden = true;
  }

  async function showFloatingButtons() {
    if (!isButtonsHidden) return;
    
    // Check for prompts button availability asynchronously
    const shouldShowPrompts = await checkPromptsAvailability();
    
    // Get Recording button center position
    const indicatorRect = recordingIndicator.getBoundingClientRect();
    const recordingCenterX = indicatorRect.left + indicatorRect.width / 2;
    const recordingCenterY = indicatorRect.top + indicatorRect.height / 2;
    
    // Show navigation container first
    if (navContainer && shouldShowNavigationContainer()) {
      navContainer.style.display = 'flex';
      // Wait for layout to update before getting position
      requestAnimationFrame(() => {
        const navRect = navContainer.getBoundingClientRect();
        const navCenterX = navRect.left + navRect.width / 2;
        const navCenterY = navRect.top + navRect.height / 2;
        navContainer.style.setProperty('--center-x', `${recordingCenterX - navCenterX}px`);
        navContainer.style.setProperty('--center-y', `${recordingCenterY - navCenterY}px`);
        navContainer.classList.add('contextwizard-auto-show');
        setTimeout(() => {
          if (navContainer) {
            navContainer.classList.remove('contextwizard-auto-show');
            navContainer.classList.remove('contextwizard-auto-hide');
          }
        }, 300);
      });
    }
    
    // Show copy button
    if (copyButton && shouldShowCopyButton()) {
      copyButton.style.display = 'flex';
      requestAnimationFrame(() => {
        const copyRect = copyButton.getBoundingClientRect();
        const copyCenterX = copyRect.left + copyRect.width / 2;
        const copyCenterY = copyRect.top + copyRect.height / 2;
        copyButton.style.setProperty('--center-x', `${recordingCenterX - copyCenterX}px`);
        copyButton.style.setProperty('--center-y', `${recordingCenterY - copyCenterY}px`);
        copyButton.classList.add('contextwizard-auto-show');
        setTimeout(() => {
          if (copyButton) {
            copyButton.classList.remove('contextwizard-auto-show');
            copyButton.classList.remove('contextwizard-auto-hide');
          }
        }, 300);
      });
    }
    
    // Show prompts button
    if (promptsButton && shouldShowPrompts) {
      promptsButton.style.display = 'flex';
      requestAnimationFrame(() => {
        const promptsRect = promptsButton.getBoundingClientRect();
        const promptsCenterX = promptsRect.left + promptsRect.width / 2;
        const promptsCenterY = promptsRect.top + promptsRect.height / 2;
        promptsButton.style.setProperty('--center-x', `${recordingCenterX - promptsCenterX}px`);
        promptsButton.style.setProperty('--center-y', `${recordingCenterY - promptsCenterY}px`);
        promptsButton.classList.add('contextwizard-auto-show');
        setTimeout(() => {
          if (promptsButton) {
            promptsButton.classList.remove('contextwizard-auto-show');
            promptsButton.classList.remove('contextwizard-auto-hide');
          }
        }, 300);
      });
    }
    
    // Show bookmark button if conditions are met
    if (bookmarkButton && shouldShowBookmarkButton()) {
      bookmarkButton.style.display = 'flex';
      requestAnimationFrame(() => {
        const bookmarkRect = bookmarkButton.getBoundingClientRect();
        const bookmarkCenterX = bookmarkRect.left + bookmarkRect.width / 2;
        const bookmarkCenterY = bookmarkRect.top + bookmarkRect.height / 2;
        bookmarkButton.style.setProperty('--center-x', `${recordingCenterX - bookmarkCenterX}px`);
        bookmarkButton.style.setProperty('--center-y', `${recordingCenterY - bookmarkCenterY}px`);
        bookmarkButton.classList.add('contextwizard-auto-show');
        setTimeout(() => {
          if (bookmarkButton) {
            bookmarkButton.classList.remove('contextwizard-auto-show');
            bookmarkButton.classList.remove('contextwizard-auto-hide');
          }
        }, 300);
      });
    }
    
    // Show bookmark view list button if conditions are met
    if (bookmarkViewListButton && shouldShowBookmarkViewListButton()) {
      bookmarkViewListButton.style.display = 'flex';
      requestAnimationFrame(() => {
        const viewListRect = bookmarkViewListButton.getBoundingClientRect();
        const viewListCenterX = viewListRect.left + viewListRect.width / 2;
        const viewListCenterY = viewListRect.top + viewListRect.height / 2;
        bookmarkViewListButton.style.setProperty('--center-x', `${recordingCenterX - viewListCenterX}px`);
        bookmarkViewListButton.style.setProperty('--center-y', `${recordingCenterY - viewListCenterY}px`);
        bookmarkViewListButton.classList.add('contextwizard-auto-show');
        setTimeout(() => {
          if (bookmarkViewListButton) {
            bookmarkViewListButton.classList.remove('contextwizard-auto-show');
            bookmarkViewListButton.classList.remove('contextwizard-auto-hide');
          }
        }, 300);
      });
    }
    
    isButtonsHidden = false;
    resetAutoHideTimer();
  }

  async function checkPromptsAvailability() {
    if (!promptsButton) return false;
    
    try {
      const result = await new Promise(resolve => {
        chrome.storage.local.get(['promptEditorTemplates'], resolve);
      });
      return result.promptEditorTemplates && 
             Object.keys(result.promptEditorTemplates).length > 0;
    } catch (error) {
      console.warn('[ContextWizard] Could not load prompt templates:', error);
      return false;
    }
  }

  // Helper functions to determine if buttons should be shown
  function shouldShowNavigationContainer() {
    return navContainer && currentSearchNavContext && pageMatchElements.length > 0;
  }

  function shouldShowCopyButton() {
    return currentConversation && currentConversation.messages && currentConversation.messages.length > 0;
  }

  function shouldShowPromptsButton() {
    // This will be checked asynchronously in updatePromptsButtonVisibility
    return promptsButton !== null;
  }

  function shouldShowBookmarkButton() {
    // Bookmark button shows when text is selected
    const selection = window.getSelection();
    return selection && !selection.isCollapsed && selection.toString().trim().length > 0;
  }

  function shouldShowBookmarkViewListButton() {
    // Bookmark view list button shows when bookmarks exist
    return conversationBookmarks && conversationBookmarks.length > 0;
  }

  /**
   * Create and display search result navigation container above the recording indicator
   */
  function createSearchNavigationUI() {
    if (navContainer) {
      navContainer.remove();
    }
    
    navContainer = document.createElement('div');
    navContainer.id = 'contextwizard-nav-container';
    navContainer.className = 'nav-container';
    navContainer.style.display = 'none';

    const prevLabel = (globalThis.chrome?.i18n?.getMessage('previousSearchResult')) || 'Previous search result';
    const nextLabel = (globalThis.chrome?.i18n?.getMessage('nextSearchResult')) || 'Next search result';
    navContainer.innerHTML = `
      <button class="nav-btn nav-prev" title="${prevLabel}" aria-label="${prevLabel}">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <path d="M11.354 1.646a.5.5 0 010 .708L5.707 8l5.647 5.646a.5.5 0 01-.708.708l-6-6a.5.5 0 010-.708l6-6a.5.5 0 01.708 0z"/>
        </svg>
      </button>
      <button class="nav-btn nav-next" title="${nextLabel}" aria-label="${nextLabel}">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <path d="M4.646 1.646a.5.5 0 01.708 0l6 6a.5.5 0 010 .708l-6 6a.5.5 0 01-.708-.708L10.293 8 4.646 2.354a.5.5 0 010-.708z"/>
        </svg>
      </button>
    `;
    
    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(navContainer);
    
    const prevBtn = navContainer.querySelector('.nav-prev');
    const nextBtn = navContainer.querySelector('.nav-next');
    
    if (prevBtn) {
      prevBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        scrollToPreviousPageMatch();
      });
    }
    
    if (nextBtn) {
      nextBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        scrollToNextPageMatch();
      });
    }
  }

  function clearPageHighlights() {
    if (!pageMatchElements.length) {
      return;
    }

    for (const mark of pageMatchElements) {
      const parent = mark.parentNode;
      if (!parent) {
        continue;
      }
      parent.replaceChild(document.createTextNode(mark.textContent || ''), mark);
      parent.normalize();
    }

    pageMatchElements = [];
    pageMatchCursor = -1;
  }

  function isSkippableHighlightParent(node) {
    if (!node || node.nodeType !== Node.ELEMENT_NODE) {
      return true;
    }

    // Never highlight inside editable fields (e.g., ChatGPT composer is contenteditable).
    // Modifying text nodes inside editors can reset the user's caret position.
    if (node.isContentEditable) {
      return true;
    }
    if (node.closest?.('[contenteditable="true"], [contenteditable="plaintext-only"], [role="textbox"]')) {
      return true;
    }
    const tag = node.tagName;
    return (
      tag === 'SCRIPT' ||
      tag === 'STYLE' ||
      tag === 'NOSCRIPT' ||
      tag === 'TEXTAREA' ||
      tag === 'INPUT' ||
      tag === 'SELECT' ||
      tag === 'OPTION'
    );
  }

  function highlightPageMatches(query) {
    // Don't clear/refresh highlights if user is actively selecting text
    if (userIsSelecting) {
      return;
    }
    
    clearPageHighlights();

    const q = (query || '').trim();
    if (!q) {
      return;
    }

    // Match both the full phrase and each whitespace-separated token.
    // For the full phrase, allow flexible whitespace (e.g. spaces/newlines) via \s+.
    const escapeForRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const tokens = [];
    tokens.push(q);
    for (const part of q.split(/\s+/g)) {
      if (part) {
        tokens.push(part);
      }
    }

    const seen = new Set();
    const patterns = [];

    // Full phrase pattern (flex whitespace)
    const phraseParts = q.split(/\s+/g).filter(Boolean);
    if (phraseParts.length) {
      const phrasePattern = phraseParts.map(escapeForRegex).join('\\s+');
      seen.add(`phrase:${phrasePattern}`);
      patterns.push({ pattern: phrasePattern, weight: q.length + 1000 });
    }

    for (const token of tokens) {
      const t = token.trim();
      if (!t) {
        continue;
      }
      // Avoid super noisy 1-char tokens.
      if (t.length < 2) {
        continue;
      }
      const pat = escapeForRegex(t);
      const key = `tok:${pat}`;
      if (seen.has(key)) {
        continue;
      }
      seen.add(key);
      patterns.push({ pattern: pat, weight: t.length });
    }

    if (!patterns.length) {
      return;
    }

    // Prefer longer matches when alternatives overlap.
    patterns.sort((a, b) => b.weight - a.weight);
    let regex;
    try {
      regex = new RegExp(patterns.map((p) => p.pattern).join('|'), 'gi');
    } catch {
      return;
    }

    const root = document.body || document.documentElement;
    if (!root) {
      return;
    }

    suppressHighlightRefreshUntil = Date.now() + 750;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (textNode) => {
        if (!textNode?.nodeValue || !textNode.nodeValue.trim()) {
          return NodeFilter.FILTER_REJECT;
        }
        const parent = textNode.parentElement;
        if (!parent || isSkippableHighlightParent(parent)) {
          return NodeFilter.FILTER_REJECT;
        }

        // Avoid highlighting our own UI.
        if (parent.closest?.('#contextwizard-indicator') || parent.closest?.('#contextwizard-nav-container')) {
          return NodeFilter.FILTER_REJECT;
        }

        // Avoid re-highlighting inside our own marks.
        if (parent.classList?.contains(PAGE_HIGHLIGHT_CLASS)) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const toProcess = [];
    while (walker.nextNode()) {
      toProcess.push(walker.currentNode);
    }

    for (const textNode of toProcess) {
      const text = textNode.nodeValue;
      if (!text) {
        continue;
      }
      regex.lastIndex = 0;
      const matches = [];
      let m;
      while ((m = regex.exec(text)) !== null) {
        if (m[0]) {
          matches.push({ index: m.index, length: m[0].length });
        }
        if (regex.lastIndex === m.index) {
          regex.lastIndex++;
        }
      }
      if (!matches.length) {
        continue;
      }

      const frag = document.createDocumentFragment();
      let last = 0;
      for (const hit of matches) {
        if (hit.index > last) {
          frag.appendChild(document.createTextNode(text.slice(last, hit.index)));
        }
        const mark = document.createElement('mark');
        mark.className = PAGE_HIGHLIGHT_CLASS;
        mark.textContent = text.slice(hit.index, hit.index + hit.length);
        frag.appendChild(mark);
        pageMatchElements.push(mark);
        last = hit.index + hit.length;
      }
      if (last < text.length) {
        frag.appendChild(document.createTextNode(text.slice(last)));
      }

      textNode.parentNode?.replaceChild(frag, textNode);
    }

    pageMatchCursor = -1;
  }

  function scheduleHighlightRefresh() {
    if (!currentSearchNavContext?.searchQuery) {
      return;
    }
    if (Date.now() < suppressHighlightRefreshUntil) {
      return;
    }
    // Don't refresh highlights if user is actively selecting text or creating a bookmark
    if (userIsSelecting || bookmarkInputPopup) {
      clearTimeout(highlightRefreshTimer);
      highlightRefreshTimer = setTimeout(() => {
        scheduleHighlightRefresh();
      }, 300);
      return;
    }
    clearTimeout(highlightRefreshTimer);
    highlightRefreshTimer = setTimeout(() => {
      if (!currentSearchNavContext?.searchQuery) {
        return;
      }
      if (Date.now() < suppressHighlightRefreshUntil) {
        return;
      }
      // Double check user is not selecting and not creating a bookmark
      if (userIsSelecting || bookmarkInputPopup) {
        scheduleHighlightRefresh();
        return;
      }
      const keepCursor = pageMatchCursor;
      try {
        highlightPageMatches(currentSearchNavContext.searchQuery);
      } catch {
        clearPageHighlights();
      }
      if (keepCursor >= 0 && pageMatchElements.length) {
        pageMatchCursor = Math.min(keepCursor, pageMatchElements.length - 1);
      }
      updateNavigationButtonStates();
    }, 250);
  }

  function ensureHighlightObserver() {
    if (highlightObserver || !document.body) {
      return;
    }
    highlightObserver = new MutationObserver(() => {
      scheduleHighlightRefresh();
    });
    highlightObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function updateNavigationButtonStates() {
    if (!navContainer) {
      return;
    }
    const prevBtn = navContainer.querySelector('.nav-prev');
    const nextBtn = navContainer.querySelector('.nav-next');
    if (!prevBtn || !nextBtn) {
      return;
    }

    if (!pageMatchElements.length) {
      prevBtn.disabled = true;
      prevBtn.classList.toggle('disabled', true);
      nextBtn.disabled = true;
      nextBtn.classList.toggle('disabled', true);
      return;
    }

    // Allow first click even with one match.
    if (pageMatchCursor === -1) {
      prevBtn.disabled = false;
      prevBtn.classList.toggle('disabled', false);
      nextBtn.disabled = false;
      nextBtn.classList.toggle('disabled', false);
      return;
    }

    prevBtn.disabled = pageMatchCursor <= 0;
    prevBtn.classList.toggle('disabled', prevBtn.disabled);
    nextBtn.disabled = pageMatchCursor >= pageMatchElements.length - 1;
    nextBtn.classList.toggle('disabled', nextBtn.disabled);
  }

  function scrollToPageMatch(index) {
    if (index < 0 || index >= pageMatchElements.length) {
      return;
    }
    pageMatchCursor = index;
    const el = pageMatchElements[index];
    try {
      el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    } catch {
      el.scrollIntoView(true);
    }
    updateNavigationButtonStates();
  }

  function scrollToNextPageMatch() {
    if (!pageMatchElements.length) {
      return;
    }
    if (pageMatchCursor === -1) {
      scrollToPageMatch(0);
      return;
    }
    scrollToPageMatch(Math.min(pageMatchElements.length - 1, pageMatchCursor + 1));
  }

  function scrollToPreviousPageMatch() {
    if (!pageMatchElements.length) {
      return;
    }
    if (pageMatchCursor === -1) {
      scrollToPageMatch(pageMatchElements.length - 1);
      return;
    }
    scrollToPageMatch(Math.max(0, pageMatchCursor - 1));
  }

  /**
   * Update the position of the navigation container to stay above the recording indicator
   */
  function updateNavigationContainerPosition() {
    if (!navContainer || !recordingIndicator) {
      return;
    }
    
    const rect = recordingIndicator.getBoundingClientRect();
    // Measure nav size (fallback to defaults if hidden)
    const navRect = navContainer.getBoundingClientRect();
    const navWidth = (navRect.width || navContainer.offsetWidth || 64);
    const navHeight = (navRect.height || navContainer.offsetHeight || 32);
    
    // Position above the indicator
    const top = rect.top - navHeight - 8;  // 8px gap
    const left = rect.left + (rect.width - navWidth) / 2;
    
    navContainer.style.top = `${Math.max(8, top)}px`;
    navContainer.style.left = `${Math.max(8, Math.min(left, window.innerWidth - navWidth - 8))}px`;
  }

  /**
   * Update navigation buttons disabled state based on current index
   */
  function updateNavigationButtonStates() {
    if (!navContainer || !currentSearchNavContext) {
      return;
    }
    
    const prevBtn = navContainer.querySelector('.nav-prev');
    const nextBtn = navContainer.querySelector('.nav-next');
    
    if (!prevBtn || !nextBtn) {
      return;
    }
    
    if (!pageMatchElements.length) {
      prevBtn.disabled = true;
      prevBtn.classList.toggle('disabled', true);
      nextBtn.disabled = true;
      nextBtn.classList.toggle('disabled', true);
      return;
    }

    // Allow first click even with one match.
    if (pageMatchCursor === -1) {
      prevBtn.disabled = false;
      prevBtn.classList.toggle('disabled', false);
      nextBtn.disabled = false;
      nextBtn.classList.toggle('disabled', false);
      return;
    }

    const hasOnlyOneMatch = pageMatchElements.length === 1;
    prevBtn.disabled = pageMatchCursor <= 0 && !hasOnlyOneMatch;
    prevBtn.classList.toggle('disabled', pageMatchCursor <= 0 && !hasOnlyOneMatch);
    nextBtn.disabled = pageMatchCursor >= pageMatchElements.length - 1 && !hasOnlyOneMatch;
    nextBtn.classList.toggle('disabled', pageMatchCursor >= pageMatchElements.length - 1 && !hasOnlyOneMatch);
  }

  /**
   * Navigate to previous search result
   */
  function navigateToPreviousSearchResult() {
    if (!currentSearchNavContext || currentNavIndex <= 0) {
      return;
    }
    currentNavIndex--;
    navigateToSearchResult(currentNavIndex);
  }

  /**
   * Navigate to next search result
   */
  function navigateToNextSearchResult() {
    if (!currentSearchNavContext || currentNavIndex >= currentSearchNavContext.resultsList.length - 1) {
      return;
    }
    currentNavIndex++;
    navigateToSearchResult(currentNavIndex);
  }

  /**
   * Navigate to a specific search result by index
   */
  function navigateToSearchResult(index) {
    if (!currentSearchNavContext || index < 0) {
      return;
    }

    // Kept for backward compatibility, but search navigation is now in-page.
    currentNavIndex = index;
    updateNavigationButtonStates();
  }

  /**
   * Show or hide the navigation UI based on search context
   */
  function updateNavigationUI() {
    if (!navContainer) {
      createSearchNavigationUI();
    }
    
    if (!currentSearchNavContext) {
      if (!isButtonsHidden) {
        navContainer.style.display = 'none';
      }
      return;
    }
    
    if (!isButtonsHidden) {
      navContainer.style.display = 'flex';
      updateNavigationContainerPosition();
      updateNavigationButtonStates();
    }
  }
  
  // Setup MutationObserver to detect conversation changes
  function setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      if (!isRecording) return;
      
      // Debounce to avoid excessive saves
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        extractAndSaveConversation();
      }, DEBOUNCE_DELAY);
    });
    
    // Observe the entire document for changes
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  function setupSendDetector(attempt = 0) {
    if (sendDetector || !currentPlatform) {
      return;
    }

    const platformName = currentPlatform.domain || globalThis.location.hostname;
    const platformConfig = globalThis.PLATFORM_INPUT_CONFIG?.[platformName];
    if (typeof globalThis.SendDetector !== 'function' || !platformConfig) {
      if (attempt < 20 && !sendDetectorInitTimer) {
        sendDetectorInitTimer = setTimeout(() => {
          sendDetectorInitTimer = null;
          setupSendDetector(attempt + 1);
        }, 250);
      }
      return;
    }

    sendDetector = new globalThis.SendDetector(platformConfig, platformName);
    sendDetector.start(() => {
      if (!isRecording) return;
      scheduleSendDetectedExtraction();
    });
  }

  function scheduleSendDetectedExtraction() {
    sendDetectionCaptureTimers.forEach((timer) => clearTimeout(timer));
    sendDetectionCaptureTimers = SEND_DETECTION_CAPTURE_DELAYS.map((delay) => setTimeout(() => {
      if (isRecording) {
        extractAndSaveConversation();
      }
    }, delay));
  }
  
  // Extract conversation content from the page
  function extractAndSaveConversation() {
    try {

      // Avoid polluting captured HTML/text with temporary page highlights.
      const restoreQuery = currentSearchNavContext?.searchQuery || '';
      const restoreCursor = pageMatchCursor;
      const hadHighlights = pageMatchElements.length > 0;
      if (hadHighlights) {
        clearPageHighlights();
      }
      
      // Use the universal MessageExtractor
      const extractor = new MessageExtractor(currentPlatform);
      const conversation = extractor.extract();

      if (hadHighlights && restoreQuery) {
        try {
          highlightPageMatches(restoreQuery);
          if (restoreCursor >= 0 && pageMatchElements.length) {
            pageMatchCursor = Math.min(restoreCursor, pageMatchElements.length - 1);
          }
          updateNavigationButtonStates();
        } catch {
          clearPageHighlights();
        }
      }
      
      if (!conversation) {
        setCapturingState(false);
        return;
      }
      
      if (!conversation.messages?.length) {
        setCapturingState(false);
        return;
      }

      // Skip saving while assistant streaming is still in progress
      // (e.g., "Thinking..." or "Thought for Xs" placeholders from ChatGPT)
      if (hasStreamingIndicators(conversation.messages)) {
        scheduleStreamingRetry();
        return;
      }

      clearStreamingRetry();

      if (!hasUniqueConversationContext(conversation.url, currentPlatform)) {
        setCapturingState(false);
        return;
      }
      
      setCapturingState(true);
      
      // Generate a timestamp-independent fingerprint for deduping
      const fingerprint = createConversationFingerprint(conversation.messages);
      if (!fingerprint) {
        return;
      }
      
      if (fingerprint === lastSavedContent) {
        return;
      }
      
      lastSavedContent = fingerprint;
      conversation.fingerprint = fingerprint;

      currentConversation = conversation;
      updateCopyButtonVisibility();

      // Tag message elements for bookmarks
      tagMessageElements();
      
      // Load bookmarks for this conversation
      loadConversationBookmarks();

      // Send to background script for storage
      try {
        chrome.runtime.sendMessage({
          action: 'saveConversation',
          conversation: conversation
        });
      } catch (error) {
        if (error.message.includes('Extension context invalidated')) {
          // Extension was reloaded, content script needs to be reloaded too
          // Save to localStorage as fallback and schedule retry
          persistPendingConversation(conversation);
          schedulePendingFlush();
        } else {
          throw error;
        }
      }

      // Increment rating chat count if user hasn't rated yet
      chrome.storage.local.get(['rating_has_rated'], (data) => {
        if (!data.rating_has_rated) {
          chrome.storage.local.get(['rating_chat_count'], (countData) => {
            const current = (countData.rating_chat_count || 0) + 1;
            chrome.storage.local.set({ rating_chat_count: current });
          });
        }
      });

      // Check if rating banner should be shown after successful extraction
      checkShouldShowRatingBanner();

    } catch (error) {
      console.error('ContextWizard: Error extracting conversation:', error);
    }
  }

  function scheduleStreamingRetry() {
    clearStreamingRetry();
    streamingRetryTimer = setTimeout(() => {
      streamingRetryTimer = null;
      if (isRecording) {
        extractAndSaveConversation();
      }
    }, DEBOUNCE_DELAY);
  }

  function clearStreamingRetry() {
    if (streamingRetryTimer) {
      clearTimeout(streamingRetryTimer);
      streamingRetryTimer = null;
    }
  }

  function persistPendingConversation(conversation) {
    try {
      const saved = JSON.parse(localStorage.getItem('contextwizard_pending') || '[]');
      saved.push(conversation);
      localStorage.setItem('contextwizard_pending', JSON.stringify(saved));

    } catch (error) {
      console.error('[ContextWizard] Failed to store pending conversation:', error);
    }
  }

  function schedulePendingFlush(delay = nextPendingFlushDelay) {
    clearTimeout(pendingFlushTimer);
    pendingFlushTimer = setTimeout(() => {
      flushPendingConversations();
    }, delay);
  }

  function flushPendingConversations() {
    clearTimeout(pendingFlushTimer);
    const pending = getPendingConversations();
    if (!pending.length) {
      nextPendingFlushDelay = PENDING_FLUSH_BASE_DELAY;
      return;
    }
    sendPendingSequentially(pending)
      .then(() => {
        nextPendingFlushDelay = PENDING_FLUSH_BASE_DELAY;
      })
      .catch((error) => {
        nextPendingFlushDelay = Math.min(nextPendingFlushDelay * 2, PENDING_FLUSH_MAX_DELAY);
        schedulePendingFlush(nextPendingFlushDelay);
      });
  }

  function getPendingConversations() {
    try {
      return JSON.parse(localStorage.getItem('contextwizard_pending') || '[]');
    } catch (error) {
      console.error('[ContextWizard] Failed to parse pending conversations:', error);
      localStorage.removeItem('contextwizard_pending');
      return [];
    }
  }

  function sendPendingSequentially(queue) {
    return new Promise((resolve, reject) => {
      processPendingQueue([...queue], resolve, reject);
    });
  }

  function processPendingQueue(pendingQueue, resolve, reject) {
    if (!pendingQueue.length) {
      localStorage.removeItem('contextwizard_pending');
      resolve();
      return;
    }

    const conversation = pendingQueue.shift();
    chrome.runtime.sendMessage({
      action: 'saveConversation',
      conversation
    }, () => {
      if (chrome.runtime.lastError) {
        pendingQueue.unshift(conversation);
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      processPendingQueue(pendingQueue, resolve, reject);
    });
  }

  function hasUniqueConversationContext(url, platform) {
    const needsDistinctUrl = platform?.requireDistinctUrl ?? true;
    if (!needsDistinctUrl) {
      return true;
    }

    let parsedUrl;
    try {
      parsedUrl = new URL(url);
    } catch (error) {
      return true;
    }

    if (platform?.chatPathPrefix) {
      return parsedUrl.pathname.startsWith(platform.chatPathPrefix);
    }

    if (urlHasIdentifierInPath(parsedUrl.pathname)) {
      return true;
    }

    if (urlHasIdentifierInSearch(parsedUrl.searchParams)) {
      return true;
    }

    if (urlHasIdentifierInHash(parsedUrl.hash)) {
      return true;
    }

    return false;
  }

  function urlHasIdentifierInPath(pathname = '') {
    const segments = pathname.split('/').filter(Boolean);
    return segments.some(isLikelyIdentifierSegment);
  }

  function urlHasIdentifierInSearch(searchParams) {
    if (!searchParams) {
      return false;
    }
    for (const [key, value] of searchParams.entries()) {
      if (!value) {
        continue;
      }
      const normalizedKey = key.toLowerCase();
      const matchesHint = CONVERSATION_PARAM_HINTS.some((hint) => normalizedKey.includes(hint));
      if (!matchesHint) {
        continue;
      }
      if (value.trim().length >= 6) {
        return true;
      }
    }
    return false;
  }

  function urlHasIdentifierInHash(hashValue = '') {
    if (!hashValue) {
      return false;
    }
    const cleaned = hashValue.replace(/^#/, '').trim();
    if (!cleaned) {
      return false;
    }
    const hashSegments = cleaned.split('/').filter(Boolean);
    return hashSegments.some(isLikelyIdentifierSegment);
  }

  function isLikelyIdentifierSegment(segment) {
    if (!segment) {
      return false;
    }
    const sanitized = segment.replace(/^[^a-z0-9]+/i, '');
    if (!sanitized) {
      return false;
    }
    const normalized = sanitized.toLowerCase();
    if (GENERIC_URL_SEGMENTS.has(normalized)) {
      return false;
    }
    if (normalized.length < 8) {
      return false;
    }
    return /^[a-z0-9_.-]+$/i.test(sanitized);
  }
  
  // Listen for messages from popup/background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleRecording') {
      isRecording = request.enabled;
      updateRecordingIndicator();
      sendResponse({ success: true });
    } else if (request.action === 'extractNow') {
      extractAndSaveConversation();
      sendResponse({ success: true });
    } else if (request.action === 'checkPending') {
      // Check for pending conversations in localStorage
      try {
        const pending = JSON.parse(localStorage.getItem('contextwizard_pending') || '[]');
        if (pending.length > 0) {

          // Send each pending conversation to background
          for (const conv of pending) {
            try {
              chrome.runtime.sendMessage({
                action: 'saveConversation',
                conversation: conv
              });
            } catch (e) {
              console.error('[ContextWizard] Failed to send pending conversation:', e);
            }
          }
          // Clear pending after sending
          localStorage.removeItem('contextwizard_pending');

        }
      } catch (e) {
        console.error('[ContextWizard] Failed to check pending conversations:', e);
      }
      sendResponse({ success: true });
    } else if (request.action === 'receiveSearchNavContext') {
      // Receive search navigation context from popup
      currentSearchNavContext = request.navContext;
      currentNavIndex = request.navContext?.currentIndex ?? 0;
      createSearchNavigationUI();
      try {
        highlightPageMatches(currentSearchNavContext?.searchQuery || '');
      } catch (e) {
        clearPageHighlights();
      }
      ensureHighlightObserver();
      updateNavigationUI();
      sendResponse({ success: true });
    } else if (request.action === 'checkBookmarkReady') {
      // Check if bookmarks are loaded and markers are ready
      const hasBookmarks = conversationBookmarks.length > 0;
      const hasMarkers = document.querySelectorAll('[data-bookmark-marker-id]').length > 0;
      sendResponse({ 
        success: true, 
        ready: hasBookmarks && hasMarkers,
        hasBookmarks: hasBookmarks,
        hasMarkers: hasMarkers
      });
    } else if (request.action === 'scrollToBookmark') {
      // Scroll to bookmark location with retry mechanism
      const bookmarkId = request.bookmarkId;
      const processScroll = () => {
        const allMarkers = document.querySelectorAll(`[data-bookmark-marker-id="${bookmarkId}"]`);
        let marker = null;
        for (const m of allMarkers) {
          if (!bookmarkListPopup?.contains(m)) {
            marker = m;
            break;
          }
        }
        if (marker) {
          marker.scrollIntoView({ behavior: 'smooth', block: 'center' });
          marker.classList.add('contextwizard-bookmark-marker-highlight');
          setTimeout(() => {
            marker.classList.remove('contextwizard-bookmark-marker-highlight');
          }, 2000);
          return true;
        }
        return false;
      };

      if (processScroll()) {
        sendResponse({ success: true, found: true });
      } else {
        // Bookmark marker not ready yet, queue request for retry
        // Check if bookmarks are still loading
        if (conversationBookmarks.length === 0) {
          // Bookmarks not loaded yet, extend timeout
          pendingScrollRequest = { bookmarkId, sendResponse };
          clearTimeout(pendingScrollTimeout);
          pendingScrollTimeout = setTimeout(() => {
            if (pendingScrollRequest?.bookmarkId === bookmarkId) {
              pendingScrollRequest = null;
              sendResponse({ success: false, found: false });
            }
          }, 10000); // Extended timeout for bookmark loading
        } else {
          // Bookmarks loaded but markers not ready, use standard timeout
          pendingScrollRequest = { bookmarkId, sendResponse };
          clearTimeout(pendingScrollTimeout);
          pendingScrollTimeout = setTimeout(() => {
            if (pendingScrollRequest?.bookmarkId === bookmarkId) {
              pendingScrollRequest = null;
              sendResponse({ success: false, found: false });
            }
          }, 5000);
        }
      }
    } else if (request.action === 'CONTEXT_SESSION_START') {
      // Bookmark Context Chat: initialize session with bookmarks and conversations
      const { bookmarks, conversations, bookmarkGroup } = request;
      if (typeof globalThis.ContextSession !== 'undefined') {
        const tabId = sender.tab?.id || 0;
        const platformName = currentPlatform?.domain || window.location.hostname;
        const platformConfig = globalThis.PLATFORM_INPUT_CONFIG?.[platformName] || {};
        const session = new globalThis.ContextSession(bookmarkGroup, platformName, tabId, platformConfig);
        session.setBookmarks(bookmarks || []);
        session.setConversations(conversations || []);
        globalThis.__contextSession = session;

        // Initialize (or replace) the ContextPanel on the AI platform page
        if (typeof globalThis.ContextPanel !== 'undefined') {
          if (globalThis.__contextPanel) {
            globalThis.__contextPanel.destroy();
          }
          const panel = new globalThis.ContextPanel();
          panel.init(session);
          globalThis.__contextPanel = panel;
        }

        // Clear any stale draft the platform may have restored (e.g. ChatGPT localStorage draft)
        // Delay to let the platform finish restoring its own state before we wipe it.
        setTimeout(() => {
          const inputEl = typeof globalThis.findPlatformInput === 'function'
            ? globalThis.findPlatformInput(platformName)
            : (document.querySelector('[contenteditable="true"]') || document.querySelector('textarea'));
          if (!inputEl) return;
          if (inputEl.isContentEditable || inputEl.getAttribute('contenteditable') === 'true') {
            if (inputEl.innerHTML.trim()) {
              inputEl.innerHTML = '';
              inputEl.dispatchEvent(new InputEvent('input', { bubbles: true }));
            }
          } else if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
            if (inputEl.value.trim()) {
              inputEl.value = '';
              inputEl.dispatchEvent(new Event('input', { bubbles: true }));
            }
          }
        }, 800);

        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: 'ContextSession not loaded' });
      }
    } else if (request.action === 'GET_BOOKMARK_CONTEXT_DATA') {
      const session = globalThis.__contextSession;
      if (session) {
        const payload = session.getInjectionPayload(request.checkedBookmarkIds);
        sendResponse({ success: true, payload });
      } else {
        sendResponse({ success: false, error: 'No active session' });
      }
    } else if (request.action === 'INJECT_CONTEXT') {
      // Inject context into current platform input
      const { platformName, text } = request;
      if (typeof globalThis.injectContext !== 'undefined') {
        globalThis.injectContext(platformName || currentPlatform?.domain, text).then(result => {
          sendResponse(result);
        }).catch(err => {
          sendResponse({ success: false, error: err.message });
        });
        return true; // async
      } else {
        sendResponse({ success: false, error: 'ContentInjector not loaded' });
      }
    }
  });

  // ========== Prompts Popup Functionality ==========
  
  // Create prompts popup
  function createPromptsPopup() {
    if (promptsPopup) {
      promptsPopup.remove();
    }

    // Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'contextwizard-prompts-backdrop';
    backdrop.className = 'contextwizard-prompts-backdrop';

    // Popup
    promptsPopup = document.createElement('div');
    promptsPopup.id = 'contextwizard-prompts-popup';
    promptsPopup.className = 'contextwizard-prompts-popup';
    
    promptsPopup.innerHTML = `
      <div class="prompts-header">
        <h3>${chrome.i18n.getMessage('promptEditorTemplatesTitle') || '常用提示词'}</h3>
        <div class="prompts-header-actions">
          <button id="prompts-edit-btn" class="prompts-edit-btn">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
              <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5L13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175l-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
            </svg>
            ${chrome.i18n.getMessage('promptEditorTemplatesEditButton') || '编辑'}
          </button>
          <button id="prompts-close-btn" class="prompts-close-btn">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
              <path d="M4.293 4.293a1 1 0 011.414 0L8 6.586l2.293-2.293a1 1 0 111.414 1.414L9.414 8l2.293 2.293a1 1 0 01-1.414 1.414L8 9.414l-2.293 2.293a1 1 0 01-1.414-1.414L6.586 8 4.293 5.707a1 1 0 010-1.414z"/>
            </svg>
          </button>
        </div>
      </div>
      <div id="prompts-list" class="prompts-list">
        <!-- 动态加载常用提示词列表 -->
      </div>
    `;

    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(backdrop);
    targetElement.appendChild(promptsPopup);

    // Event listeners
    backdrop.addEventListener('click', hidePromptsPopup);
    document.getElementById('prompts-close-btn').addEventListener('click', hidePromptsPopup);
    document.getElementById('prompts-edit-btn').addEventListener('click', handleEditPrompts);
    
    // Load templates
    loadPromptsList();
  }

  // Show prompts popup
  function showPromptsPopup() {
    if (!promptsPopup) {
      createPromptsPopup();
    }
    
    // Position popup near prompts button
    const buttonRect = promptsButton.getBoundingClientRect();
    const popupWidth = 320;
    const popupMaxHeight = 400;
    
    let left = buttonRect.left - popupWidth + 32; // Align with button
    let top = buttonRect.top - 10;
    
    // Ensure within viewport
    if (left < 8) left = 8;
    if (left + popupWidth > window.innerWidth - 8) {
      left = window.innerWidth - popupWidth - 8;
    }
    if (top + popupMaxHeight > window.innerHeight - 8) {
      top = window.innerHeight - popupMaxHeight - 8;
    }
    if (top < 8) top = 8;

    promptsPopup.style.left = left + 'px';
    promptsPopup.style.top = top + 'px';
    
    promptsPopup.classList.remove('hidden');
    document.getElementById('contextwizard-prompts-backdrop').classList.remove('hidden');
    
    loadPromptsList(); // Refresh list
  }

  // Hide prompts popup
  function hidePromptsPopup() {
    if (promptsPopup) {
      promptsPopup.classList.add('hidden');
      const backdrop = document.getElementById('contextwizard-prompts-backdrop');
      if (backdrop) {
        backdrop.classList.add('hidden');
      }
    }
  }

  // Load prompts list from storage
  async function loadPromptsList() {
    try {
      const result = await chrome.storage.local.get(['promptEditorTemplates']);
      const templates = result.promptEditorTemplates || {};
      const listElement = document.getElementById('prompts-list');
      
      if (!listElement) return;

      listElement.innerHTML = '';

      if (Object.keys(templates).length === 0) {
        listElement.innerHTML = `
          <div class="prompts-empty">
            ${chrome.i18n.getMessage('promptEditorTemplatesEmpty') || '暂无常用提示词'}
          </div>
        `;
        return;
      }

      // Sort by usage count
      const sortedTemplates = Object.entries(templates).sort((a, b) => {
        const usageA = a[1].usageCount || 0;
        const usageB = b[1].usageCount || 0;
        return usageB - usageA;
      });

      sortedTemplates.forEach(([promptText, templateData]) => {
        const item = document.createElement('div');
        item.className = 'prompt-item';
        item.innerHTML = `
          <div class="prompt-text">${escapeHtml(promptText)}</div>
          <div class="prompt-usage">${templateData.usageCount || 0}</div>
        `;
        
        item.addEventListener('click', () => handlePromptSelection(promptText));
        listElement.appendChild(item);
      });
    } catch (error) {
      console.error('[ContextWizard] Error loading prompts list:', error);
      const listElement = document.getElementById('prompts-list');
      if (listElement) {
        listElement.innerHTML = `
          <div class="prompts-empty">
            加载失败，请重试
          </div>
        `;
      }
    }
  }

  function handlePromptSelection(promptText) {
    const platformName = currentPlatform?.domain || currentPlatform?.name;

    const doInject = () => {
      if (typeof globalThis.injectContext === 'function') {
        return globalThis.injectContext(platformName, promptText);
      }
      return Promise.resolve({ success: false, clipboard: false });
    };

    const fallbackToClipboard = () => {
      navigator.clipboard.writeText(promptText).then(() => {
        showFloatingTip(chrome.i18n.getMessage('promptCopiedToClipboard') || '已复制到剪贴板');
        hidePromptsPopup();
        updatePromptUsage(promptText);
      }).catch(error => {
        console.error('[ContextWizard] Error copying to clipboard:', error);
        showFloatingTip(chrome.i18n.getMessage('promptInjectFailed') || '注入失败，请重试');
      });
    };

    doInject().then(result => {
      if (result && result.success) {
        hidePromptsPopup();
        showFloatingTip(chrome.i18n.getMessage('promptInjected') || '已注入输入框');
        updatePromptUsage(promptText);
        const inputEl = typeof globalThis.findPlatformInput === 'function'
          ? globalThis.findPlatformInput(platformName) : null;
        if (inputEl) {
          setTimeout(() => inputEl.focus(), 50);
        }
      } else if (result && result.clipboard) {
        showFloatingTip(chrome.i18n.getMessage('promptCopiedToClipboard') || '已复制到剪贴板');
        hidePromptsPopup();
        updatePromptUsage(promptText);
      } else {
        fallbackToClipboard();
      }
    }).catch(error => {
      console.error('[ContextWizard] Error injecting prompt:', error);
      fallbackToClipboard();
    });
  }

  // Update prompt usage count
  function updatePromptUsage(promptText) {
    chrome.storage.local.get(['promptEditorTemplates'], (result) => {
      const templates = result.promptEditorTemplates || {};
      if (templates[promptText]) {
        templates[promptText].usageCount = (templates[promptText].usageCount || 0) + 1;
        chrome.storage.local.set({ promptEditorTemplates: templates });
      }
    });
  }

  // Handle edit prompts
  function handleEditPrompts() {
    // Open PromptEditor with templates tab via background script
    chrome.runtime.sendMessage({
      action: 'openPromptEditor',
      tab: 'templates'
    }, (response) => {
      if (!response?.success) {
        console.error('[ContextWizard] Failed to open prompt editor:', response?.error);
      }
    });
    
    hidePromptsPopup();
  }

  // Show floating tip
  function showFloatingTip(message) {
    const tip = document.createElement('div');
    tip.className = 'contextwizard-floating-tip';
    tip.textContent = message;
    
    // Position near prompts button
    if (promptsButton) {
      const buttonRect = promptsButton.getBoundingClientRect();
      tip.style.left = (buttonRect.left - 100) + 'px';
      tip.style.top = buttonRect.top + 'px';
    }
    
    const targetElement = document.documentElement || document.body;
    targetElement.appendChild(tip);
    
    // Auto-remove after animation
    setTimeout(() => {
      if (tip.parentNode) {
        tip.parentNode.removeChild(tip);
      }
    }, 2000);
  }

  // Show enhanced SelectedText tip on hover
  function showSelectedTextTip(bookmarkItem) {
    const selectedText = bookmarkItem.getAttribute('data-selected-text');
    if (!selectedText) return;

    // Clear any existing timeout
    if (bookmarkItem._tipTimeout) {
      clearTimeout(bookmarkItem._tipTimeout);
    }

    // Set timeout for 0.6 seconds
    bookmarkItem._tipTimeout = setTimeout(() => {
      // Remove any existing tip first
      const existingTip = document.querySelector('.contextwizard-selected-text-tip');
      if (existingTip) {
        existingTip.remove();
      }

      const tip = document.createElement('div');
      tip.className = 'contextwizard-selected-text-tip';
      
      const content = document.createElement('div');
      content.className = 'contextwizard-selected-text-tip-content';
      content.textContent = selectedText;
      
      tip.appendChild(content);
      
      // Position near the target element
      const targetRect = bookmarkItem.getBoundingClientRect();
      tip.style.left = targetRect.left + 'px';
      tip.style.top = (targetRect.bottom + 5) + 'px';
      
      // Ensure tip doesn't go off screen
      setTimeout(() => {
        const tipRect = tip.getBoundingClientRect();
        if (tipRect.right > window.innerWidth) {
          tip.style.left = (window.innerWidth - tipRect.width - 10) + 'px';
        }
        if (tipRect.bottom > window.innerHeight) {
          tip.style.top = (targetRect.top - tipRect.height - 5) + 'px';
        }
      }, 10);
      
      document.body.appendChild(tip);
      
      // Store reference for removal
      bookmarkItem._tipElement = tip;
    }, 600);
  }

  // Hide SelectedText tip
  function hideSelectedTextTip(bookmarkItem) {
    // Clear timeout if exists
    if (bookmarkItem._tipTimeout) {
      clearTimeout(bookmarkItem._tipTimeout);
      bookmarkItem._tipTimeout = null;
    }
    
    // Remove tip if exists
    if (bookmarkItem._tipElement) {
      bookmarkItem._tipElement.remove();
      bookmarkItem._tipElement = null;
    }
  }

   // Utility function to escape HTML
   function escapeHtml(text) {
     const div = document.createElement('div');
     div.textContent = text;
     return div.innerHTML;
   }

  // ========== Rating Banner Module ==========

  function checkShouldShowRatingBanner() {
    chrome.storage.local.get([
      'rating_install_date',
      'rating_chat_count',
      'rating_has_rated',
      'rating_dismissed_count',
      'rating_last_dismissed_time'
    ], (data) => {
      if (data.rating_has_rated) return;

      const daysInstalled = (Date.now() - (data.rating_install_date || Date.now())) / (1000 * 60 * 60 * 24);
      const chatCount = data.rating_chat_count || 0;
      const dismissedCount = data.rating_dismissed_count || 0;
      const lastDismissedTime = data.rating_last_dismissed_time || 0;

      // Cooldown period: 7 days before showing again after dismiss
      const daysSinceLastDismiss = (Date.now() - lastDismissedTime) / (1000 * 60 * 60 * 24);
      if (dismissedCount > 0 && daysSinceLastDismiss < 7) return;

      // Aha Moment: installed for 3+ days AND 12+ deep interactions
      if (daysInstalled >= 3 && chatCount >= 12) {
        // 20% initial grayscale
        const grayScaleRandom = Math.floor(Math.random() * 100);
        if (grayScaleRandom < 20) {
          renderRatingBanner();
        }
      }
    });
  }

  function renderRatingBanner() {
    if (document.getElementById('cw-rating-banner')) return;

    const indicator = document.getElementById('contextwizard-indicator');
    if (!indicator) return;

    const banner = document.createElement('div');
    banner.id = 'cw-rating-banner';
    banner.className = 'cw-rating-banner';

    const rateText = chrome.i18n.getMessage('ratingBannerRateText') || 'ContextWizard 帮到你了吗？如果它帮你省下了切标签的时间，能否花 10 秒给个 5 星好评？';
    const btnRate = chrome.i18n.getMessage('ratingBannerBtnRate') || '赞，支持一下';
    const btnFeedback = chrome.i18n.getMessage('ratingBannerBtnFeedback') || '有Bug/要吐槽';
    const btnDismiss = chrome.i18n.getMessage('ratingBannerBtnDismiss') || '暂时不用';

    banner.innerHTML = `
      <div class="cw-rating-text">${rateText}</div>
      <div class="cw-rating-actions">
        <button id="cw-rating-rate" class="cw-rating-btn cw-rating-btn-primary">${btnRate}</button>
        <button id="cw-rating-feedback" class="cw-rating-btn cw-rating-btn-secondary">${btnFeedback}</button>
        <button id="cw-rating-dismiss" class="cw-rating-btn cw-rating-btn-ghost">${btnDismiss}</button>
      </div>
    `;

    const target = document.documentElement || document.body;
    target.appendChild(banner);

    requestAnimationFrame(() => {
      banner.classList.add('cw-rating-visible');
    });

    // Detect Edge to use correct store URL
    const isEdge = navigator.userAgent.includes('Edg/');
    const storeUrl = isEdge
      ? 'https://microsoftedge.microsoft.com/addons/detail/contextwizard/nknoacgaapoeboehlgelolgbifgcimli'
      : 'https://chromewebstore.google.com/detail/contextwizard-ai-chat-man/lmhnmmedgmnfggecdalkancllnekofnb/reviews';

    document.getElementById('cw-rating-rate').addEventListener('click', () => {
      chrome.storage.local.set({ rating_has_rated: true });
      banner.classList.remove('cw-rating-visible');
      setTimeout(() => banner.remove(), 300);
      window.open(storeUrl);
    });

    document.getElementById('cw-rating-feedback').addEventListener('click', () => {
      banner.classList.remove('cw-rating-visible');
      setTimeout(() => banner.remove(), 300);
      window.open('https://github.com/dqj1998/contextwizard-feedback/issues/new');
    });

    document.getElementById('cw-rating-dismiss').addEventListener('click', () => {
      chrome.storage.local.get(['rating_dismissed_count'], (data) => {
        chrome.storage.local.set({
          rating_dismissed_count: (data.rating_dismissed_count || 0) + 1,
          rating_last_dismissed_time: Date.now()
        });
      });
      banner.classList.remove('cw-rating-visible');
      setTimeout(() => banner.remove(), 300);
    });
  }

  function getNextNthWeekdayForMonth(year, month, nth, weekday) {
    const lastDayOfMonth = new Date(year, month + 1, 0).getDate();
    const dt = new Date(year, month, 1);

    if (nth === -1) {
      for (let d = lastDayOfMonth; d >= 1; d--) {
        if (new Date(year, month, d).getDay() === weekday) {
          dt.setDate(d);
          return dt;
        }
      }
    } else {
      const firstDayOfWeekday = new Date(year, month, 1).getDay();
      const daysUntilFirst = (weekday - firstDayOfWeekday + 7) % 7;
      const targetDate = 1 + daysUntilFirst + (nth - 1) * 7;
      if (targetDate > lastDayOfMonth) {
        for (let d = lastDayOfMonth; d >= 1; d--) {
          if (new Date(year, month, d).getDay() === weekday) {
            dt.setDate(d);
            return dt;
          }
        }
      } else {
        dt.setDate(targetDate);
      }
    }
    return dt;
  }

    // Export functions for testing
   globalThis.ContextWizardContentTestHooks = {
     findClosestMatchByOffset,
     findAllTextMatches,
     findAllTextMatchesByContainer,
     findTextWithRobustSearch,
     findAndHighlightBookmarkText,
     calculateTextOffset,
     createBookmarkHighlight,
     createBookmarkMarker,
     findMultiNodeTextMatch,
     generateTextVariations,
     getNextNthWeekdayForMonth
   };
   
 })();

function hasStreamingIndicators(messages) {
  if (!Array.isArray(messages) || !messages.length) return false;
  const lastAssistant = [...messages].reverse().find((message) => message?.role === 'assistant');
  if (!lastAssistant) return false;

  const text = (lastAssistant.content || '').trim();
  const streamingPattern = /^(thinking|generating|responding|typing)[.\s…]*$|^thought\s+for\s+\d+s[.\s…]*$/i;
  return !text || streamingPattern.test(text);
}

function normalizeMessageText(text) {
  return (text || '').replaceAll(/\s+/g, ' ').trim();
}

function createConversationFingerprint(messages) {
  if (!Array.isArray(messages) || !messages.length) {
    return '';
  }
  const normalized = messages.map((message) => ({
    role: message.role,
    content: normalizeMessageText(message.content)
  }));
  return JSON.stringify(normalized);
}
