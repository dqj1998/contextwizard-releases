// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Seed data for first-install default Replacement Settings and Common Prompts.
// Provides localized defaults for 12 supported languages.

const SEED_DATA = {
  ar: {
    replacements: {
      'من اجل': 'لـ',
      'كثير من': 'عدة',
      'في الواقع': 'فعلاً'
    },
    templates: {
      'لخص المحتوى التالي:': { usageCount: 0, createdAt: 0 },
      'ترجم إلى الإنجليزية:': { usageCount: 0, createdAt: 0 },
      'اشرح هذا بمصطلحات بسيطة:': { usageCount: 0, createdAt: 0 }
    }
  },
  de: {
    replacements: {
      'um zu': 'zu',
      'ein großes': 'viele',
      'in der Tat': 'tatsächlich'
    },
    templates: {
      'Fasse den folgenden Inhalt zusammen:': { usageCount: 0, createdAt: 0 },
      'Übersetze ins Englische:': { usageCount: 0, createdAt: 0 },
      'Erkläre das in einfachen Worten:': { usageCount: 0, createdAt: 0 }
    }
  },
  en: {
    replacements: {
      'in order to': 'to',
      'recieve': 'receive',
      'a lot of': 'many'
    },
    templates: {
      'Summarize the following:': { usageCount: 0, createdAt: 0 },
      'Translate to English:': { usageCount: 0, createdAt: 0 },
      'Explain this in simple terms:': { usageCount: 0, createdAt: 0 }
    }
  },
  es: {
    replacements: {
      'con el fin de': 'para',
      'muchos': 'varios',
      'en realidad': 'de hecho'
    },
    templates: {
      'Resume el siguiente contenido:': { usageCount: 0, createdAt: 0 },
      'Traduce al inglés:': { usageCount: 0, createdAt: 0 },
      'Explica esto en términos simples:': { usageCount: 0, createdAt: 0 }
    }
  },
  fr: {
    replacements: {
      'afin de': 'pour',
      'beaucoup de': 'de nombreux',
      'en fait': 'effectivement'
    },
    templates: {
      'Résumez le contenu suivant :': { usageCount: 0, createdAt: 0 },
      'Traduire en anglais :': { usageCount: 0, createdAt: 0 },
      'Expliquez cela en termes simples :': { usageCount: 0, createdAt: 0 }
    }
  },
  hi: {
    replacements: {
      'के लिए': 'को',
      'बहुत सारे': 'कई',
      'वास्तव में': 'सच में'
    },
    templates: {
      'निम्नलिखित सामग्री का सारांश दें:': { usageCount: 0, createdAt: 0 },
      'अंग्रेजी में अनुवाद करें:': { usageCount: 0, createdAt: 0 },
      'इसे सरल शब्दों में समझाएं:': { usageCount: 0, createdAt: 0 }
    }
  },
  it: {
    replacements: {
      'al fine di': 'per',
      'molti': 'diversi',
      'in realtà': 'effettivamente'
    },
    templates: {
      'Riassumi il contenuto seguente:': { usageCount: 0, createdAt: 0 },
      'Traduci in inglese:': { usageCount: 0, createdAt: 0 },
      'Spiega questo in parole semplici:': { usageCount: 0, createdAt: 0 }
    }
  },
  ja: {
    replacements: {
      'において': 'で',
      'たくさん': '多数の',
      'についてです': 'について'
    },
    templates: {
      '以下を要約してください：': { usageCount: 0, createdAt: 0 },
      '英語に翻訳してください：': { usageCount: 0, createdAt: 0 },
      '分かりやすく説明してください：': { usageCount: 0, createdAt: 0 }
    }
  },
  ko: {
    replacements: {
      '에 있어서': '에서',
      '많은': '다수의',
      '입니다': '입니다'
    },
    templates: {
      '다음을 요약해 주세요：': { usageCount: 0, createdAt: 0 },
      '영어로 번역해 주세요：': { usageCount: 0, createdAt: 0 },
      '쉽게 설명해 주세요：': { usageCount: 0, createdAt: 0 }
    }
  },
  pt_BR: {
    replacements: {
      'a fim de': 'para',
      'muitos': 'vários',
      'na verdade': 'de fato'
    },
    templates: {
      'Resuma o seguinte conteúdo:': { usageCount: 0, createdAt: 0 },
      'Traduza para o inglês:': { usageCount: 0, createdAt: 0 },
      'Explique isso em termos simples:': { usageCount: 0, createdAt: 0 }
    }
  },
  ru: {
    replacements: {
      'для того чтобы': 'чтобы',
      'много': 'множество',
      'на самом деле': 'фактически'
    },
    templates: {
      'Кратко опишите следующее:': { usageCount: 0, createdAt: 0 },
      'Переведите на английский:': { usageCount: 0, createdAt: 0 },
      'Объясните это простыми словами:': { usageCount: 0, createdAt: 0 }
    }
  },
  zh_CN: {
    replacements: {
      '因此': '所以',
      '在的': '在',
      '非常': '很'
    },
    templates: {
      '总结以下内容：': { usageCount: 0, createdAt: 0 },
      '翻译成英文：': { usageCount: 0, createdAt: 0 },
      '用简单的话解释：': { usageCount: 0, createdAt: 0 }
    }
  }
};

const SUPPORTED_LOCALES = Object.keys(SEED_DATA);

function getSeedData(locale) {
  if (!locale) return SEED_DATA.en;
  const normalized = locale.replace('-', '_');
  if (SEED_DATA[normalized]) return SEED_DATA[normalized];
  const langCode = normalized.split('_')[0];
  if (SEED_DATA[langCode]) return SEED_DATA[langCode];
  return SEED_DATA.en;
}

function getSeedReplacements(locale) {
  const data = getSeedData(locale);
  const result = {};
  for (const [original, replacement] of Object.entries(data.replacements)) {
    result[original] = { replacement, ignoreCase: true };
  }
  return result;
}

function getSeedTemplates(locale) {
  const data = getSeedData(locale);
  const result = {};
  const ts = Date.now();
  for (const [text, meta] of Object.entries(data.templates)) {
    result[text] = { usageCount: meta.usageCount, createdAt: ts + Object.keys(result).length };
  }
  return result;
}

if (typeof globalThis !== 'undefined') {
  globalThis.SeedData = { getSeedData, getSeedReplacements, getSeedTemplates, SUPPORTED_LOCALES };
}
