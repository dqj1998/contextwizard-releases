(function () {
  'use strict';

  class ContextSession {
    constructor(bookmarkGroup, platformName, tabId, platformConfig) {
      this.bookmarkGroup = bookmarkGroup;
      this.platformName = platformName;
      this.tabId = tabId;
      this.platformConfig = platformConfig;
      this.sessionKey = `${platformName}:${tabId}:${bookmarkGroup.id}`;

      this.state = {
        checkedBookmarkIds: [],
      };

      this.restoreState();
    }

    // ---- 面板状态 ----

    setCheckedBookmarkIds(ids) {
      this.state.checkedBookmarkIds = ids;
      this.persistState();
    }

    getPanelState() {
      return {
        bookmarkStates: (this._bookmarks || []).map(b => {
          const fullContent = b.annotation || b.content || b.selectedText || '';
          return {
            bookmarkId: b.id,
            bookmarkName: b.annotation || b.selectedText || b.content || '',
            checked: this.state.checkedBookmarkIds.includes(b.id),
            url: b.url || '',
            fullContent,
            selectedText: b.selectedText || '',
            snippet: fullContent.slice(0, 150),
          };
        }),
      };
    }

    // ---- 注入载荷 ----

    getInjectionPayload(checkedBookmarkIds, queryText) {
      const ids = checkedBookmarkIds || this.state.checkedBookmarkIds;
      if (!ids || ids.length === 0) return null;
      if (!queryText || queryText.trim().length < 5) return null;

      const bookmarks = (this._bookmarks || []).filter(b => ids.includes(b.id));
      if (bookmarks.length === 0) return null;

      const result = globalThis.extractForSession(queryText.trim(), bookmarks, this._conversations || []);
      if (!result.contextBlock) return null;

      this.persistState();
      return result;
    }

    setBookmarks(bookmarks) {
      this._bookmarks = bookmarks;
      if (!bookmarks || bookmarks.length === 0) return;

      if (this.state.checkedBookmarkIds.length === 0) {
        this.state.checkedBookmarkIds = bookmarks.map(b => b.id);
      }
    }

    setConversations(conversations) {
      this._conversations = conversations || [];
    }

    // ---- 持久化 ----

    persistState() {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.session) return;
      try {
        chrome.storage.session.set({
          [this.sessionKey]: {
            checkedBookmarkIds: this.state.checkedBookmarkIds,
          }
        });
      } catch (e) {
        console.warn('[ContextSession] storage.session write failed', e);
      }
    }

    restoreState() {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.session) return;
      try {
        chrome.storage.session.get([this.sessionKey], (result) => {
          if (result && result[this.sessionKey]) {
            const saved = result[this.sessionKey];
            this.state.checkedBookmarkIds = saved.checkedBookmarkIds || [];
          }
        });
      } catch (e) {
        console.warn('[ContextSession] Failed to restore state', e);
      }
    }

    // ---- 推荐书签名称 ----

    generateBookmarkName() {
      return this.bookmarkGroup?.name || '';
    }

    // ---- 清理 ----

    destroy() {
    }
  }

  globalThis.ContextSession = ContextSession;
})();
