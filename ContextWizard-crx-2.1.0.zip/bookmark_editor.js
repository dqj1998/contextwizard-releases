// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Bookmark Manager script for viewing and managing bookmarks

const getMessage = (key, fallback, substitutions) => {
  if (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function') {
    const localized = chrome.i18n.getMessage(key, substitutions);
    if (localized) {
      return localized;
    }
  }
  if (typeof fallback === 'function') {
    return fallback(Array.isArray(substitutions) ? substitutions : []);
  }
  return fallback;
};

const BOOKMARKS_KEY = 'bookmarks';
const MAX_UNDO_LEVELS = 20;

let allBookmarks = [];
let allBookmarkGroups = [];
let filteredBookmarks = [];
let bookmarksList = null;
let bookmarksEmpty = null;
let searchInput = null;
let searchClearBtn = null;
let platformFilter = null;
let sortFilter = null;
let statusElement = null;
let refreshBtn = null;
let undoBtn = null;
let undoStack = [];
let draggedBookmarkId = null;

let reminderModal = null;
let reminderBookmarkId = null;
let selectedReminderType = 'once';
let selectedWeekdays = [];
let selectedMonthlyMode = 'day';
let pendingScrollBookmarkId = null;

document.addEventListener('DOMContentLoaded', initializeBookmarkEditor);

function initializeBookmarkEditor() {
  bookmarksList = document.getElementById('bookmarksList');
  bookmarksEmpty = document.getElementById('bookmarksEmpty');
  searchInput = document.getElementById('bookmarkSearchInput');
  searchClearBtn = document.getElementById('searchClearBtn');
  platformFilter = document.getElementById('platformFilter');
  sortFilter = document.getElementById('sortFilter');
  statusElement = document.getElementById('editorStatus');
  refreshBtn = document.getElementById('editorRefreshBtn');
  undoBtn = document.getElementById('editorUndoBtn');

  const closeBtn = document.getElementById('editorCloseBtn');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeBookmarkEditor);
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', refreshBookmarks);
  }

  if (undoBtn) {
    undoBtn.addEventListener('click', undoLastAction);
  }

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
      e.preventDefault();
      undoLastAction();
    }
  });

  searchInput.addEventListener('input', handleSearch);
  searchClearBtn.addEventListener('click', clearSearch);
  platformFilter.addEventListener('change', applyFilters);
  sortFilter.addEventListener('change', applyFilters);

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes[BOOKMARKS_KEY]) {
      loadBookmarks();
    }
  });

  initReminderModal();
  initEditorReminderHistory();
  loadBookmarks();

  const hashBookmarkId = getBookmarkIdFromHash();
  if (hashBookmarkId) {
    pendingScrollBookmarkId = hashBookmarkId;
    window.history.replaceState(null, '', window.location.pathname);
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'scrollToBookmarkId' && message.bookmarkId) {
      scrollToBookmarkInManager(message.bookmarkId);
    }
  });
}

function closeBookmarkEditor() {
  if (window.opener) {
    window.close();
  } else if (chrome.tabs && chrome.tabs.getCurrent) {
    chrome.tabs.getCurrent((tab) => {
      if (tab) {
        chrome.tabs.remove(tab.id);
      } else {
        window.close();
      }
    });
  } else {
    window.close();
  }
}

function getBookmarkIdFromHash() {
  const hash = window.location.hash;
  if (!hash || !hash.startsWith('#bookmarkId=')) return null;
  return decodeURIComponent(hash.substring('#bookmarkId='.length));
}

function scrollToBookmarkInManager(bookmarkId) {
  if (!bookmarkId) return;

  const tryScroll = (retries) => {
    const el = document.querySelector(`.bookmark-item[data-bookmark-id="${bookmarkId}"]`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('bookmark-scroll-highlight');
      setTimeout(() => el.classList.remove('bookmark-scroll-highlight'), 2000);
      return;
    }
    if (retries > 0) {
      setTimeout(() => tryScroll(retries - 1), 200);
    }
  };
  tryScroll(10);
}

function loadBookmarks() {
  bookmarksList.innerHTML = '<div class="loading-state">' + getMessage('bookmarkLoading', 'Loading bookmarks...') + '</div>';

  chrome.storage.local.get([BOOKMARKS_KEY, 'bookmarkGroups'], (result) => {
    if (chrome.runtime.lastError) {
      bookmarksList.innerHTML = '<div class="error-state"><p>' + escapeHtml(getMessage('bookmarkLoadError', 'Failed to load bookmarks')) + '</p></div>';
      return;
    }

    allBookmarks = result[BOOKMARKS_KEY] || [];
    allBookmarks.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    allBookmarkGroups = result.bookmarkGroups || [];
    allBookmarkGroups.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

    populatePlatformFilter();
    applyFilters();
  });
}

function refreshBookmarks() {
  if (refreshBtn) {
    refreshBtn.disabled = true;
    refreshBtn.classList.add('loading');
  }
  
  loadBookmarks();
  
  showStatus(getMessage('bookmarkRefreshed', 'Bookmark list refreshed'), 'success');
  
  if (refreshBtn) {
    setTimeout(() => {
      refreshBtn.disabled = false;
      refreshBtn.classList.remove('loading');
    }, 500);
  }
}

function populatePlatformFilter() {
  const platforms = [...new Set(allBookmarks.map(b => b.platform).filter(Boolean))];

  const defaultOption = platformFilter.querySelector('option[value=""]');
  platformFilter.innerHTML = '';
  platformFilter.appendChild(defaultOption);

  platforms.forEach(platform => {
    const option = document.createElement('option');
    option.value = platform;
    option.textContent = platform;
    platformFilter.appendChild(option);
  });
}

function handleSearch(e) {
  const query = e.target.value.trim();
  searchClearBtn.classList.toggle('hidden', !query);
  applyFilters();
}

function clearSearch() {
  searchInput.value = '';
  searchClearBtn.classList.add('hidden');
  applyFilters();
}

function applyFilters() {
  const searchQuery = searchInput.value.toLowerCase().trim();
  const platform = platformFilter.value;
  const sort = sortFilter.value;

  filteredBookmarks = [...allBookmarks];

  if (searchQuery) {
    filteredBookmarks = filteredBookmarks.filter(bookmark =>
      (bookmark.content || '').toLowerCase().includes(searchQuery) ||
      (bookmark.selectedText || '').toLowerCase().includes(searchQuery)
    );
  }

  if (platform) {
    filteredBookmarks = filteredBookmarks.filter(bookmark => bookmark.platform === platform);
  }

  switch (sort) {
    case 'oldest':
      filteredBookmarks.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      break;
    case 'content':
      filteredBookmarks.sort((a, b) => (a.content || '').localeCompare(b.content || ''));
      break;
    case 'newest':
    default:
      filteredBookmarks.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      break;
  }

  renderBookmarks();
}

function renderBookmarks() {
  if (filteredBookmarks.length === 0) {
    bookmarksList.innerHTML = '';
    bookmarksEmpty.classList.remove('hidden');
    return;
  }

  bookmarksEmpty.classList.add('hidden');

  const groupedBookmarks = groupByContent(filteredBookmarks);

  let html = '';

  for (const [content, bookmarks] of Object.entries(groupedBookmarks)) {
    const duplicateCount = bookmarks.length - 1;
    const title = escapeHtml(content.length > 100 ? content.substring(0, 100) + '...' : content);

    html += `
      <div class="bookmarks-group" data-group-content="${escapeAttr(content)}">
        <div class="bookmarks-group-title">
          <span class="bookmarks-group-title-text">${title}</span>
          <input class="bookmark-group-name-input" type="text" value="${escapeAttr(content)}" style="display:none">
          <button class="bookmark-group-rename-btn" title="${escapeHtml(getMessage('bookmarkRenameButton', 'Rename'))}">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
              <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
            </svg>
          </button>
          ${duplicateCount > 0 ? `<span class="duplicate-count">(+${duplicateCount} more)</span>` : ''}
          <button class="bookmark-group-chat-btn" title="${escapeHtml(getMessage('bookmarkChatTitle', 'Chat with context'))}" data-i18n-title="bookmarkChatTitle">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
              <path d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.8 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.297-.365a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.78 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.97 9.97 0 0 1-2.812-.472l-.382-.232z"/>
            </svg>
          </button>
        </div>
    `;

    bookmarks.forEach(bookmark => {
      html += renderBookmarkItem(bookmark);
    });

    html += '</div>';
  }

  bookmarksList.innerHTML = html;

  document.querySelectorAll('.bookmark-item').forEach(item => {
    item.addEventListener('click', (e) => {
      const deleteBtn = e.target.closest('.bookmark-delete-btn');
      if (deleteBtn) {
        e.stopPropagation();
        toggleDeleteMode(deleteBtn);
        return;
      }
      const reminderBtn = e.target.closest('.bookmark-reminder-btn');
      if (reminderBtn) {
        e.stopPropagation();
        openReminderModal(reminderBtn.getAttribute('data-bookmark-id'));
        return;
      }
      if (e.target.closest('.confirm-delete-btn') || e.target.closest('.cancel-delete-btn')) {
        return;
      }
      const bookmarkId = item.getAttribute('data-bookmark-id');
      const url = item.getAttribute('data-url');
      jumpToBookmark(bookmarkId, url);
    });
  });

  // Group rename button handlers
  document.querySelectorAll('.bookmark-group-rename-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      startRenameGroup(btn);
    });
  });

  // Group rename input handlers
  document.querySelectorAll('.bookmark-group-name-input').forEach(input => {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.stopPropagation();
        commitRenameGroup(input);
      } else if (e.key === 'Escape') {
        e.stopPropagation();
        cancelRenameGroup(input);
      }
    });
    input.addEventListener('blur', () => {
      commitRenameGroup(input);
    });
  });

  document.querySelectorAll('.bookmark-group-chat-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const group = btn.closest('.bookmarks-group');
      if (!group) return;
      const bookmarkItems = group.querySelectorAll('.bookmark-item');
      const bookmarkIds = [];
      bookmarkItems.forEach(item => {
        const id = item.getAttribute('data-bookmark-id');
        if (id) bookmarkIds.push(id);
      });
      if (bookmarkIds.length > 0) {
        openPlatformPopup(btn, bookmarkIds);
      }
    });
  });

  setupDragAndDrop();

  if (pendingScrollBookmarkId) {
    const bid = pendingScrollBookmarkId;
    pendingScrollBookmarkId = null;
    scrollToBookmarkInManager(bid);
  }
}

function groupByContent(bookmarks) {
  const groups = {};

  bookmarks.forEach(bookmark => {
    const content = bookmark.content || getMessage('bookmarkUntitled', 'Untitled');
    if (!groups[content]) {
      groups[content] = [];
    }
    groups[content].push(bookmark);
  });

  return groups;
}

function renderBookmarkItem(bookmark) {
  const date = bookmark.createdAt ? new Date(bookmark.createdAt).toLocaleDateString() : '';
  const platform = escapeHtml(bookmark.platform || getMessage('unknownPlatform', 'Unknown'));
  const url = escapeHtml(bookmark.url || '');
  const openConversationTitle = escapeHtml(getMessage('bookmarkOpenConversation', 'Click to open conversation'));
  const deleteTitle = escapeHtml(getMessage('bookmarkDeleteButton', 'Delete'));
  const reminderTitle = escapeHtml(getMessage('bookmarkReminderButton', 'Set reminder'));
  const hasReminder = bookmark.reminder && bookmark.reminder.enabled;
  const reminderActiveClass = hasReminder ? ' active' : '';
  const reminderIndicator = renderBookmarkReminderIndicator(bookmark);

  return `
    <div class="bookmark-item" draggable="true" data-bookmark-id="${bookmark.id}" data-url="${url}" title="${openConversationTitle}">
      <div class="bookmark-header">
        <span class="bookmark-content">${escapeHtml(bookmark.selectedText || '')}</span>
        <button class="bookmark-reminder-btn${reminderActiveClass}" data-bookmark-id="${bookmark.id}" title="${reminderTitle}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2zm.995-14.901a1 1 0 1 0-1.99 0A5.002 5.002 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7 0-2.42-1.72-4.44-4.005-4.901z"/>
          </svg>
        </button>
        <button class="bookmark-delete-btn" data-bookmark-id="${bookmark.id}" title="${deleteTitle}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
            <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0V6a.5.5 0 001 0V6z"/>
            <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4 4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
          </svg>
        </button>
      </div>
      <div class="bookmark-meta">
        <span class="bookmark-platform">${platform}</span>
        <span class="bookmark-date">${date}</span>
        ${reminderIndicator}
      </div>
    </div>
  `;
}

function jumpToBookmark(bookmarkId, url) {
  if (!url) {
    showStatus(getMessage('bookmarkJumpError', 'Unable to jump to bookmark location'), 'error');
    return;
  }

  const sendScrollMessage = (tabId) => {
    const maxRetries = 10;
    const checkDelay = 500;
    let retryCount = 0;

    const checkAndScroll = () => {
      chrome.tabs.sendMessage(tabId, {
        action: 'checkBookmarkReady'
      }, (readyResponse) => {
        if (chrome.runtime.lastError) {
          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(checkAndScroll, checkDelay);
          }
          return;
        }

        if (readyResponse && readyResponse.ready) {
          // Content script is ready, attempt to scroll
          chrome.tabs.sendMessage(tabId, {
            action: 'scrollToBookmark',
            bookmarkId: bookmarkId
          }, (scrollResponse) => {
            if (chrome.runtime.lastError) {
              // Scroll message failed silently
            }
          });
        } else {
          // Not ready yet, retry
          if (retryCount < maxRetries) {
            retryCount++;
            setTimeout(checkAndScroll, checkDelay);
          } else {
            // Max retries reached, try scrolling anyway
            chrome.tabs.sendMessage(tabId, {
              action: 'scrollToBookmark',
              bookmarkId: bookmarkId
            });
          }
        }
      });
    };

    // Start with an initial delay to allow page loading
    setTimeout(checkAndScroll, 1500);
  };

  const createTab = (windowId) => {
    const createProps = { url: url, active: true };
    if (windowId) {
      createProps.windowId = windowId;
    }

    chrome.tabs.create(createProps, (tab) => {
      if (chrome.runtime.lastError) {
        showStatus(getMessage('bookmarkJumpError', 'Failed to open URL'), 'error');
        return;
      }

      if (tab && tab.id) {
        sendScrollMessage(tab.id);
      }
    });
  };

  chrome.windows.getLastFocused({ windowTypes: ['normal'] }, (win) => {
    if (!chrome.runtime.lastError && win && win.id) {
      createTab(win.id);
      return;
    }

    // Fallback: just create the tab (Chrome will choose a window)
    createTab();
  });

  showStatus(getMessage('bookmarkJumpSuccess', 'Navigated to bookmark location'), 'success');
}

function toggleDeleteMode(deleteBtn) {
  const bookmarkItem = deleteBtn.closest('.bookmark-item');
  const bookmarkId = deleteBtn.getAttribute('data-bookmark-id');

  if (deleteBtn.classList.contains('in-delete-mode')) {
    deleteBtn.classList.remove('in-delete-mode');
    deleteBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
      <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0V6a.5.5 0 001 0V6z"/>
      <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4 4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
    </svg>`;
    const deleteActions = bookmarkItem.querySelector('.delete-actions');
    if (deleteActions) {
      deleteActions.remove();
    }
  } else {
    document.querySelectorAll('.bookmark-delete-btn.in-delete-mode').forEach(btn => {
      btn.classList.remove('in-delete-mode');
      btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
        <path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0V6a.5.5 0 001 0V6z"/>
        <path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4 4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
      </svg>`;
      const existingActions = btn.closest('.bookmark-item').querySelector('.delete-actions');
      if (existingActions) {
        existingActions.remove();
      }
    });

    deleteBtn.classList.add('in-delete-mode');
    deleteBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
      <path d="M8 15A7 7 0 118 1a7 7 0 010 14zm0 1A8 8 0 118 0a8 8 0 010 16z"/>
      <path d="M10 10.5a.5.5 0 01-1 0V9a.5.5 0 011 0v1.5z"/>
    </svg>`;

    const deleteActions = document.createElement('div');
    deleteActions.className = 'delete-actions';
    deleteActions.innerHTML = `
      <button class="confirm-delete-btn" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('bookmarkDeleteButton', 'Delete'))}</button>
      <button class="cancel-delete-btn" data-bookmark-id="${bookmarkId}">${escapeHtml(getMessage('bookmarkCancelButton', 'Cancel'))}</button>
    `;
    bookmarkItem.appendChild(deleteActions);

    bookmarkItem.querySelector('.confirm-delete-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      deleteBookmark(bookmarkId);
    });

    bookmarkItem.querySelector('.cancel-delete-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      toggleDeleteMode(deleteBtn);
    });
  }
}

function showStatus(message, type) {
  if (!statusElement) return;

  statusElement.textContent = message;
  statusElement.className = 'editor-status visible ' + type;

  setTimeout(() => {
    statusElement.classList.remove('visible');
  }, 3000);
}

function deleteBookmark(bookmarkId) {
  pushUndoState();
  chrome.runtime.sendMessage(
    { action: 'deleteBookmark', bookmarkId: bookmarkId },
    (response) => {
      if (response?.success) {
        allBookmarks = allBookmarks.filter((b) => b.id !== bookmarkId);
        applyFilters();
      } else {
        undoStack.pop();
        updateUndoButton();
        showStatus(getMessage('bookmarkDeleteError', 'Failed to delete bookmark'), 'error');
      }
    }
  );
}

function pushUndoState() {
  undoStack.push(JSON.parse(JSON.stringify(allBookmarks)));
  if (undoStack.length > MAX_UNDO_LEVELS) undoStack.shift();
  updateUndoButton();
}

function updateUndoButton() {
  if (!undoBtn) return;
  undoBtn.disabled = undoStack.length === 0;
  const label = getMessage('bookmarkUndo', 'Undo');
  undoBtn.title = undoStack.length > 0 ? `${label} (${undoStack.length})` : label;
  undoBtn.setAttribute('aria-label', undoBtn.title);
}

function undoLastAction() {
  if (undoStack.length === 0) return;
  allBookmarks = undoStack.pop();
  chrome.storage.local.set({ [BOOKMARKS_KEY]: allBookmarks }, () => {
    if (chrome.runtime.lastError) {
      showStatus(getMessage('bookmarkUndoError', 'Failed to undo'), 'error');
      return;
    }
    applyFilters();
    updateUndoButton();
    showStatus(getMessage('bookmarkUndoSuccess', 'Undo successful'), 'success');
  });
}

function setupDragAndDrop() {
  document.querySelectorAll('.bookmark-item').forEach(item => {
    item.addEventListener('dragstart', (e) => {
      draggedBookmarkId = item.getAttribute('data-bookmark-id');
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', draggedBookmarkId);
    });

    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      draggedBookmarkId = null;
    });
  });

  document.querySelectorAll('.bookmarks-group').forEach(groupEl => {
    let enterCount = 0;
    const groupContent = groupEl.getAttribute('data-group-content');

    groupEl.addEventListener('dragenter', (e) => {
      if (!draggedBookmarkId) return;
      const dragged = allBookmarks.find(b => b.id === draggedBookmarkId);
      if (!dragged || dragged.content === groupContent) return;
      e.preventDefault();
      enterCount++;
      groupEl.classList.add('drag-over');
    });

    groupEl.addEventListener('dragleave', () => {
      enterCount--;
      if (enterCount <= 0) {
        enterCount = 0;
        groupEl.classList.remove('drag-over');
      }
    });

    groupEl.addEventListener('dragover', (e) => {
      if (!draggedBookmarkId) return;
      const dragged = allBookmarks.find(b => b.id === draggedBookmarkId);
      if (!dragged || dragged.content === groupContent) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
    });

    groupEl.addEventListener('drop', (e) => {
      e.preventDefault();
      enterCount = 0;
      groupEl.classList.remove('drag-over');
      if (!draggedBookmarkId) return;

      const dragged = allBookmarks.find(b => b.id === draggedBookmarkId);
      if (!dragged || dragged.content === groupContent) return;

      pushUndoState();
      dragged.content = groupContent;

      chrome.storage.local.set({ [BOOKMARKS_KEY]: allBookmarks }, () => {
        if (chrome.runtime.lastError) {
          undoStack.pop();
          updateUndoButton();
          showStatus(getMessage('bookmarkMoveError', 'Failed to move bookmark'), 'error');
          return;
        }
        applyFilters();
        showStatus(getMessage('bookmarkMoved', 'Bookmark moved to group'), 'success');
      });
    });
  });
}

function escapeAttr(text) {
  if (!text) return '';
  return escapeHtml(text).replace(/"/g, '&quot;');
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}


// ========== Reminder Functions ==========

function renderBookmarkReminderIndicator(bookmark) {
  const r = bookmark.reminder;
  if (!r || !r.enabled) return '';

  const label = getReminderCronLabel(r);
  return `<span class="bookmark-reminder-next" title="${escapeAttr(label)}">⏰ ${escapeHtml(label)}</span>`;
}

function getReminderCronLabel(r) {
  if (!r || !r.enabled) return '';
  const timeStr = r.timeOfDay || '09:00';
  const [h, m] = timeStr.split(':');
  const timeDisplay = `${h.padStart(2, '0')}:${m.padStart(2, '0')}`;

  switch (r.recurrence) {
    case 'daily':
      return `Daily at ${timeDisplay}`;
    case 'weekdays':
      return `Weekdays at ${timeDisplay}`;
    case 'weekly': {
      if (!r.weekdays || r.weekdays.length === 0) return `Weekly at ${timeDisplay}`;
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const days = r.weekdays.sort().map(d => dayNames[d]).join(', ');
      return `${days} at ${timeDisplay}`;
    }
    case 'monthly':
    case 'monthlyNth': {
      if (r.monthlyNthWeekday != null && r.monthlyWeekday != null) {
        const nthLabels = ['', '1st', '2nd', '3rd', '4th', 'Last'];
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const nth = r.monthlyNthWeekday === -1 ? 'Last' : nthLabels[r.monthlyNthWeekday];
        return `${nth} ${dayNames[r.monthlyWeekday]} of month at ${timeDisplay}`;
      }
      const day = r.monthlyDay || 1;
      return `Day ${day} of month at ${timeDisplay}`;
    }
    case 'none':
    default: {
      if (r.time) {
        const d = new Date(r.time * 1000);
        return `Once: ${d.toLocaleDateString()} ${timeDisplay}`;
      }
      return '';
    }
  }
}

function initReminderModal() {
  reminderModal = document.getElementById('reminderModal');
  const closeBtn = document.getElementById('reminderModalCloseBtn');
  const cancelBtn = document.getElementById('reminderCancelBtn');
  const saveBtn = document.getElementById('reminderSaveBtn');
  const deleteBtn = document.getElementById('reminderDeleteBtn');

  closeBtn?.addEventListener('click', closeReminderModal);
  cancelBtn?.addEventListener('click', closeReminderModal);
  saveBtn?.addEventListener('click', saveReminderFromModal);
  deleteBtn?.addEventListener('click', deleteReminderFromModal);

  reminderModal?.addEventListener('click', (e) => {
    if (e.target === reminderModal) closeReminderModal();
  });

  document.querySelectorAll('.reminder-type-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.reminder-type-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedReminderType = btn.getAttribute('data-type');
      updateReminderOptionsVisibility();
      updateReminderSummary();
    });
  });

  document.querySelectorAll('.weekday-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const day = parseInt(btn.getAttribute('data-day'));
      btn.classList.toggle('active');
      if (selectedWeekdays.includes(day)) {
        selectedWeekdays = selectedWeekdays.filter(d => d !== day);
      } else {
        selectedWeekdays.push(day);
      }
      updateReminderSummary();
    });
  });

  document.querySelectorAll('.monthly-mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.monthly-mode-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedMonthlyMode = btn.getAttribute('data-mode');
      document.getElementById('reminderMonthlyDayField')?.classList.toggle('hidden', selectedMonthlyMode !== 'day');
      document.getElementById('reminderMonthlyNthField')?.classList.toggle('hidden', selectedMonthlyMode !== 'nth');
      updateReminderSummary();
    });
  });

  populateMonthlyDaySelect();

  const updateSummaryInputs = ['reminderDate', 'reminderTime', 'reminderDailyTime',
    'reminderWeeklyTime', 'reminderMonthlyTime', 'reminderMonthlyDay',
    'reminderMonthlyNth', 'reminderMonthlyWeekday'];
  updateSummaryInputs.forEach(id => {
    document.getElementById(id)?.addEventListener('change', updateReminderSummary);
  });
}

function populateMonthlyDaySelect() {
  const select = document.getElementById('reminderMonthlyDay');
  if (!select) return;
  for (let i = 1; i <= 31; i++) {
    const opt = document.createElement('option');
    opt.value = i;
    opt.textContent = i;
    select.appendChild(opt);
  }
}

function openReminderModal(bookmarkId) {
  reminderBookmarkId = bookmarkId;
  const bookmark = allBookmarks.find(b => b.id === bookmarkId);
  if (!bookmark) return;

  const label = document.getElementById('reminderBookmarkLabel');
  if (label) {
    label.textContent = bookmark.content || bookmark.selectedText || 'Untitled';
  }

  const r = bookmark.reminder || {};
  if (r.enabled && r.time) {
    const dt = new Date(r.time * 1000);
    const dateStr = dt.toISOString().split('T')[0];
    const timeStr = (r.timeOfDay || `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`);

    const recurrence = r.recurrence || 'none';
    if (recurrence === 'none') {
      selectedReminderType = 'once';
    } else if (recurrence === 'daily') {
      selectedReminderType = 'daily';
    } else if (recurrence === 'weekdays' || recurrence === 'weekly') {
      selectedReminderType = 'weekly';
    } else if (recurrence === 'monthly' || recurrence === 'monthlyNth') {
      selectedReminderType = 'monthly';
    } else {
      selectedReminderType = 'once';
    }

    document.getElementById('reminderDate').value = dateStr;
    document.getElementById('reminderTime').value = timeStr;
    document.getElementById('reminderDailyTime').value = timeStr;
    document.getElementById('reminderWeeklyTime').value = timeStr;
    document.getElementById('reminderMonthlyTime').value = timeStr;

    if (recurrence === 'weekdays') {
      selectedWeekdays = [1, 2, 3, 4, 5];
    } else {
      selectedWeekdays = r.weekdays ? [...r.weekdays] : [];
    }

    if (recurrence === 'monthlyNth' || (recurrence === 'monthly' && r.monthlyNthWeekday != null)) {
      selectedMonthlyMode = 'nth';
      document.getElementById('reminderMonthlyNth').value = r.monthlyNthWeekday ?? 1;
      document.getElementById('reminderMonthlyWeekday').value = r.monthlyWeekday ?? 1;
    } else {
      selectedMonthlyMode = 'day';
      document.getElementById('reminderMonthlyDay').value = r.monthlyDay || 1;
    }
  } else {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes() + 5).padStart(2, '0')}`;

    selectedReminderType = 'once';
    selectedWeekdays = [];
    selectedMonthlyMode = 'day';

    document.getElementById('reminderDate').value = dateStr;
    document.getElementById('reminderTime').value = timeStr;
    document.getElementById('reminderDailyTime').value = '09:00';
    document.getElementById('reminderWeeklyTime').value = '09:00';
    document.getElementById('reminderMonthlyTime').value = '09:00';
    document.getElementById('reminderMonthlyDay').value = '1';
    document.getElementById('reminderMonthlyNth').value = '1';
    document.getElementById('reminderMonthlyWeekday').value = '1';
  }

  document.querySelectorAll('.reminder-type-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-type') === selectedReminderType);
  });
  document.querySelectorAll('.weekday-btn').forEach(btn => {
    const day = parseInt(btn.getAttribute('data-day'));
    btn.classList.toggle('active', selectedWeekdays.includes(day));
  });
  document.querySelectorAll('.monthly-mode-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-mode') === selectedMonthlyMode);
  });

  updateReminderOptionsVisibility();
  updateReminderSummary();

  const hasReminder = r.enabled && r.time;
  document.getElementById('reminderDeleteBtn')?.classList.toggle('hidden', !hasReminder);

  reminderModal?.showModal();
}

function closeReminderModal() {
  reminderModal?.close();
  reminderBookmarkId = null;
}

function updateReminderOptionsVisibility() {
  document.getElementById('reminderOnceOptions')?.classList.toggle('hidden', selectedReminderType !== 'once');
  document.getElementById('reminderDailyOptions')?.classList.toggle('hidden', selectedReminderType !== 'daily');
  document.getElementById('reminderWeeklyOptions')?.classList.toggle('hidden', selectedReminderType !== 'weekly');
  document.getElementById('reminderMonthlyOptions')?.classList.toggle('hidden', selectedReminderType !== 'monthly');

  document.getElementById('reminderMonthlyDayField')?.classList.toggle('hidden', selectedMonthlyMode !== 'day');
  document.getElementById('reminderMonthlyNthField')?.classList.toggle('hidden', selectedMonthlyMode !== 'nth');
}

function updateReminderSummary() {
  const summary = document.getElementById('reminderSummary');
  if (!summary) return;

  const label = buildReminderLabel();
  summary.textContent = label;
}

function buildReminderLabel() {
  const now = new Date();
  let timeOfDay = '09:00';
  let dateStr = now.toISOString().split('T')[0];

  switch (selectedReminderType) {
    case 'once': {
      timeOfDay = document.getElementById('reminderTime')?.value || '09:00';
      dateStr = document.getElementById('reminderDate')?.value || dateStr;
      const [h, m] = timeOfDay.split(':');
      const d = new Date(dateStr + 'T' + timeOfDay);
      const dateDisplay = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
      return `Remind once on ${dateDisplay} at ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    }
    case 'daily': {
      timeOfDay = document.getElementById('reminderDailyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':');
      return `Remind daily at ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    }
    case 'weekly': {
      timeOfDay = document.getElementById('reminderWeeklyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':');
      if (selectedWeekdays.length === 0) return 'Select at least one day';
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const days = selectedWeekdays.sort().map(d => dayNames[d]).join(', ');
      return `Remind ${days} at ${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
    }
    case 'monthly': {
      timeOfDay = document.getElementById('reminderMonthlyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':');
      const timeDisplay = `${h.padStart(2, '0')}:${m.padStart(2, '0')}`;
      if (selectedMonthlyMode === 'day') {
        const day = document.getElementById('reminderMonthlyDay')?.value || '1';
        return `Remind on day ${day} of each month at ${timeDisplay}`;
      }
      const nthLabels = ['1st', '2nd', '3rd', '4th', 'Last'];
      const nthVal = parseInt(document.getElementById('reminderMonthlyNth')?.value || '1');
      const nthLabel = nthVal === -1 ? 'Last' : nthLabels[nthVal - 1];
      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const dayIdx = parseInt(document.getElementById('reminderMonthlyWeekday')?.value || '1');
      return `Remind ${nthLabel} ${dayNames[dayIdx]} of each month at ${timeDisplay}`;
    }
  }
  return '';
}

function buildReminderData() {
  const now = new Date();
  let timeOfDay = '09:00';
  let time = null;

  switch (selectedReminderType) {
    case 'once': {
      timeOfDay = document.getElementById('reminderTime')?.value || '09:00';
      const dateStr = document.getElementById('reminderDate')?.value;
      if (!dateStr) return null;
      const dt = new Date(dateStr + 'T' + timeOfDay);
      time = Math.floor(dt.getTime() / 1000);
      return { enabled: true, time, timeOfDay, recurrence: 'none' };
    }
    case 'daily': {
      timeOfDay = document.getElementById('reminderDailyTime')?.value || '09:00';
      const dt = new Date();
      const [h, m] = timeOfDay.split(':').map(Number);
      dt.setHours(h, m, 0, 0);
      if (dt.getTime() <= now.getTime()) dt.setDate(dt.getDate() + 1);
      time = Math.floor(dt.getTime() / 1000);
      return { enabled: true, time, timeOfDay, recurrence: 'daily' };
    }
    case 'weekdays': {
      timeOfDay = document.getElementById('reminderWeeklyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':').map(Number);
      if (selectedWeekdays.length === 0) return null;
      const dt = new Date();
      dt.setHours(h, m, 0, 0);
      for (let i = 0; i < 7; i++) {
        const dow = (now.getDay() + i) % 7;
        if (selectedWeekdays.includes(dow)) {
          dt.setDate(now.getDate() + i);
          if (i === 0 && dt.getTime() <= now.getTime()) continue;
          break;
        }
      }
      time = Math.floor(dt.getTime() / 1000);
      return { enabled: true, time, timeOfDay, recurrence: 'weekdays' };
    }
    case 'weekly': {
      timeOfDay = document.getElementById('reminderWeeklyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':').map(Number);
      if (selectedWeekdays.length === 0) return null;
      const dt = new Date();
      dt.setHours(h, m, 0, 0);
      for (let i = 0; i < 7; i++) {
        const dow = (now.getDay() + i) % 7;
        if (selectedWeekdays.includes(dow)) {
          dt.setDate(now.getDate() + i);
          if (i === 0 && dt.getTime() <= now.getTime()) continue;
          break;
        }
      }
      time = Math.floor(dt.getTime() / 1000);
      return { enabled: true, time, timeOfDay, recurrence: 'weekly', weekdays: [...selectedWeekdays] };
    }
    case 'monthly': {
      timeOfDay = document.getElementById('reminderMonthlyTime')?.value || '09:00';
      const [h, m] = timeOfDay.split(':').map(Number);
      if (selectedMonthlyMode === 'day') {
        const day = parseInt(document.getElementById('reminderMonthlyDay')?.value || '1');
        const dt = new Date(now.getFullYear(), now.getMonth(), day);
        dt.setHours(h, m, 0, 0);
        if (dt.getTime() <= now.getTime()) dt.setMonth(dt.getMonth() + 1);
        time = Math.floor(dt.getTime() / 1000);
        return { enabled: true, time, timeOfDay, recurrence: 'monthly', monthlyDay: day };
      }
      const nth = parseInt(document.getElementById('reminderMonthlyNth')?.value || '1');
      const weekday = parseInt(document.getElementById('reminderMonthlyWeekday')?.value || '1');
      const dt = getNextNthWeekdayOfMonthJS(now.getFullYear(), now.getMonth() + 1, nth, weekday, h, m);
      if (dt.getTime() <= now.getTime()) {
        const nextMonth = getNextNthWeekdayOfMonthJS(now.getFullYear(), now.getMonth() + 2, nth, weekday, h, m);
        time = Math.floor(nextMonth.getTime() / 1000);
      } else {
        time = Math.floor(dt.getTime() / 1000);
      }
      return { enabled: true, time, timeOfDay, recurrence: 'monthlyNth', monthlyNthWeekday: nth, monthlyWeekday: weekday };
    }
  }
  return null;
}

function getNextNthWeekdayOfMonthJS(year, month, nth, weekday, hour, minute) {
  const lastDayOfMonth = new Date(year, month, 0).getDate();

  if (nth === -1) {
    for (let d = lastDayOfMonth; d >= 1; d--) {
      const dt = new Date(year, month - 1, d);
      if (dt.getDay() === weekday) {
        dt.setHours(hour, minute, 0, 0);
        return dt;
      }
    }
  }

  const firstDay = new Date(year, month - 1, 1);
  const dayOfWeek = firstDay.getDay();
  const daysUntilWeekday = (weekday - dayOfWeek + 7) % 7;
  let targetDate = 1 + daysUntilWeekday + (nth - 1) * 7;
  if (targetDate > lastDayOfMonth) targetDate -= 7;
  const result = new Date(year, month - 1, targetDate);
  result.setHours(hour, minute, 0, 0);
  return result;
}

function saveReminderFromModal() {
  if (!reminderBookmarkId) return;
  const data = buildReminderData();
  if (!data) {
    showStatus(getMessage('reminderValidationFailed', 'Please configure reminder settings'), 'error');
    return;
  }

  chrome.runtime.sendMessage(
    { action: 'saveReminder', bookmarkId: reminderBookmarkId, reminder: data },
    (response) => {
      if (response?.success) {
        const bookmark = allBookmarks.find(b => b.id === reminderBookmarkId);
        if (bookmark) bookmark.reminder = response.reminder;
        applyFilters();
        closeReminderModal();
        showStatus(getMessage('reminderSaved', 'Reminder saved'), 'success');
      } else {
        showStatus(getMessage('reminderSaveFailed', 'Failed to save reminder'), 'error');
      }
    }
  );
}

function deleteReminderFromModal() {
  if (!reminderBookmarkId) return;

  chrome.runtime.sendMessage(
    { action: 'deleteReminder', bookmarkId: reminderBookmarkId },
    (response) => {
      if (response?.success) {
        const bookmark = allBookmarks.find(b => b.id === reminderBookmarkId);
        if (bookmark) bookmark.reminder = { enabled: false };
        applyFilters();
        closeReminderModal();
        showStatus(getMessage('reminderDeleted', 'Reminder removed'), 'success');
      } else {
        showStatus(getMessage('reminderDeleteFailed', 'Failed to remove reminder'), 'error');
      }
    }
  );
}


// ========== Editor Reminder History Functions ==========

function initEditorReminderHistory() {
  loadEditorReminderBadge();
  setupEditorReminderHistoryButton();
}

function loadEditorReminderBadge() {
  chrome.runtime.sendMessage({ action: 'getUnreadReminderCount' }, (count) => {
    updateEditorReminderBadge(count || 0);
  });
}

function updateEditorReminderBadge(count) {
  const badge = document.getElementById('editorReminderBadge');
  if (!badge) return;

  if (count > 0) {
    badge.textContent = count > 99 ? '99+' : count;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

function setupEditorReminderHistoryButton() {
  const btn = document.getElementById('editorReminderHistoryBtn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    showEditorReminderHistoryPanel();
  });
}

function showEditorReminderHistoryPanel() {
  const existingPanel = document.querySelector('.editor-reminder-history-panel');
  if (existingPanel) {
    existingPanel.remove();
    return;
  }

  const panel = document.createElement('div');
  panel.className = 'editor-reminder-history-panel';
  panel.innerHTML = `
    <div class="editor-reminder-history-header">
      <span class="editor-reminder-history-title">${getMessage('reminderHistoryTitle', 'Reminder History')}</span>
      <div class="editor-reminder-history-actions">
        <button class="editor-reminder-history-mark-all" id="editorReminderMarkAllBtn">${getMessage('reminderHistoryMarkAllRead', 'Mark all read')}</button>
        <button class="editor-reminder-history-close" id="editorReminderCloseBtn">&times;</button>
      </div>
    </div>
    <div class="editor-reminder-history-list" id="editorReminderHistoryList">
      <div class="editor-reminder-history-loading">${getMessage('reminderHistoryLoading', 'Loading...')}</div>
    </div>
  `;

  document.body.appendChild(panel);

  const closeBtn = panel.querySelector('#editorReminderCloseBtn');
  closeBtn.addEventListener('click', () => panel.remove());

  const markAllBtn = panel.querySelector('#editorReminderMarkAllBtn');
  markAllBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'markAllRemindersRead' }, () => {
      loadEditorReminderBadge();
      loadEditorReminderHistoryList(panel);
    });
  });

  loadEditorReminderHistoryList(panel);

  document.addEventListener('click', function closePanel(e) {
    if (!panel.contains(e.target) && !e.target.closest('#editorReminderHistoryBtn')) {
      panel.remove();
      document.removeEventListener('click', closePanel);
    }
  });
}

function loadEditorReminderHistoryList(panel) {
  const listContainer = panel.querySelector('#editorReminderHistoryList');
  
  chrome.runtime.sendMessage({ action: 'getReminderHistory' }, (history) => {
    if (!history || history.length === 0) {
      listContainer.innerHTML = `<div class="editor-reminder-history-empty">${getMessage('reminderHistoryEmpty', 'No reminders yet')}</div>`;
      return;
    }

    const grouped = groupEditorReminderHistory(history);
    let html = '';

    if (grouped.today.length > 0) {
      html += `<div class="editor-reminder-history-group">
        <div class="editor-reminder-history-group-title">${getMessage('reminderHistoryToday', 'Today')}</div>
        ${renderEditorReminderHistoryItems(grouped.today)}
      </div>`;
    }

    if (grouped.yesterday.length > 0) {
      html += `<div class="editor-reminder-history-group">
        <div class="editor-reminder-history-group-title">${getMessage('reminderHistoryYesterday', 'Yesterday')}</div>
        ${renderEditorReminderHistoryItems(grouped.yesterday)}
      </div>`;
    }

    if (grouped.older.length > 0) {
      html += `<div class="editor-reminder-history-group">
        <div class="editor-reminder-history-group-title">${getMessage('reminderHistoryOlder', 'Older')}</div>
        ${renderEditorReminderHistoryItems(grouped.older)}
      </div>`;
    }

    listContainer.innerHTML = html;

    listContainer.querySelectorAll('.editor-reminder-history-item').forEach(item => {
      item.addEventListener('click', () => {
        const reminderId = item.dataset.reminderId;
        const bookmarkId = item.dataset.bookmarkId;
        const url = item.dataset.url;
        
        chrome.runtime.sendMessage({ action: 'markReminderRead', reminderId }, () => {
          loadEditorReminderBadge();
          item.classList.remove('unread');
          item.querySelector('.editor-reminder-dot').style.display = 'none';
        });

        if (url && bookmarkId) {
          jumpToBookmark(bookmarkId, url);
        } else if (url) {
          window.open(url, '_blank');
        }
      });
    });
  });
}

function groupEditorReminderHistory(history) {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;

  const grouped = { today: [], yesterday: [], older: [] };

  history.forEach(item => {
    if (item.triggeredAt >= todayStart) {
      grouped.today.push(item);
    } else if (item.triggeredAt >= yesterdayStart) {
      grouped.yesterday.push(item);
    } else {
      grouped.older.push(item);
    }
  });

  return grouped;
}

function renderEditorReminderHistoryItems(items) {
  return items.map(item => {
    const time = new Date(item.triggeredAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const content = item.content || getMessage('bookmarkUntitled', 'Untitled');
    const platform = item.platform || '';
    const dotStyle = item.read ? 'display: none;' : '';
    const unreadClass = item.read ? '' : 'unread';

    return `
      <div class="editor-reminder-history-item ${unreadClass}" data-reminder-id="${item.id}" data-bookmark-id="${item.bookmarkId || ''}" data-url="${escapeHtml(item.url || '')}">
        <span class="editor-reminder-dot" style="${dotStyle}"></span>
        <div class="editor-reminder-history-item-content">
          <div class="editor-reminder-history-item-text">${escapeHtml(content.substring(0, 50))}${content.length > 50 ? '...' : ''}</div>
          <div class="editor-reminder-history-item-meta">
            <span class="editor-reminder-history-item-time">${time}</span>
            ${platform ? `<span class="editor-reminder-history-item-platform">${escapeHtml(platform)}</span>` : ''}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// ========== Group Rename Functions ==========

function startRenameGroup(renameBtn) {
  const groupEl = renameBtn.closest('.bookmarks-group');
  if (!groupEl) return;

  const nameText = groupEl.querySelector('.bookmarks-group-title-text');
  const nameInput = groupEl.querySelector('.bookmark-group-name-input');
  if (!nameText || !nameInput) return;

  nameText.style.display = 'none';
  nameInput.style.display = 'block';
  nameInput.focus();
  nameInput.select();
}

function commitRenameGroup(input) {
  const groupEl = input.closest('.bookmarks-group');
  if (!groupEl) return;

  const nameText = groupEl.querySelector('.bookmarks-group-title-text');
  const oldName = groupEl.getAttribute('data-group-content');
  const newName = input.value.trim();

  if (!newName || newName === oldName) {
    cancelRenameGroup(input);
    return;
  }

  chrome.runtime.sendMessage(
    { action: 'renameBookmarkGroup', oldName, newName },
    (response) => {
      if (response?.success) {
        nameText.textContent = newName;
        groupEl.setAttribute('data-group-content', newName);
        nameText.style.display = '';
        input.style.display = 'none';
        showStatus(getMessage('bookmarkRenameSuccess', 'Bookmark renamed'), 'success');
        applyFilters();
      } else {
        showStatus(getMessage('bookmarkRenameError', 'Failed to rename bookmark'), 'error');
        cancelRenameGroup(input);
      }
    }
  );
}

function cancelRenameGroup(input) {
  const groupEl = input.closest('.bookmarks-group');
  if (!groupEl) return;

  const nameText = groupEl.querySelector('.bookmarks-group-title-text');
  if (nameText) {
    nameText.style.display = '';
  }
  input.style.display = 'none';
  input.value = groupEl.getAttribute('data-group-content') || '';
}

// ── Chat Platform Popup（同主弹窗 "Open chat platforms"） ──

var CHAT_BUILTIN_PLATFORMS = [
  { domain: 'chatgpt.com', name: 'ChatGPT', url: 'https://chatgpt.com', color: '#10a37f' },
  { domain: 'claude.ai', name: 'Claude', url: 'https://claude.ai/new', color: '#6445a3' },
  { domain: 'gemini.google.com', name: 'Gemini', url: 'https://gemini.google.com/app', color: '#4285f4' },
  { domain: 'copilot.microsoft.com', name: 'Copilot', url: 'https://copilot.microsoft.com', color: '#0078d4' },
  { domain: 'grok.com', name: 'Grok', url: 'https://grok.com', color: '#000000' },
  { domain: 'www.perplexity.ai', name: 'Perplexity', url: 'https://www.perplexity.ai', color: '#5436da' },
  { domain: 'www.kimi.com', name: 'Kimi', url: 'https://www.kimi.com', color: '#1a73e8' },
  { domain: 'poe.com', name: 'Poe', url: 'https://poe.com', color: '#5f4b8b' },
  { domain: 'chat.deepseek.com', name: 'DeepSeek', url: 'https://chat.deepseek.com', color: '#4f6ef7' },
  { domain: 'chat.qwen.ai', name: 'Qwen', url: 'https://chat.qwen.ai', color: '#635bff' },
  { domain: 'huggingface.co/chat', name: 'HuggingChat', url: 'https://huggingface.co/chat', color: '#ffd21e' },
  { domain: 'manus.im', name: 'Manus', url: 'https://manus.im', color: '#1a1a2e' },
];

var activeChatPopup = null;

function openPlatformPopup(anchorEl, bookmarkIds) {
  if (activeChatPopup) {
    activeChatPopup.remove();
    activeChatPopup = null;
  }

  if (!bookmarkIds || bookmarkIds.length === 0) {
    showStatus(getMessage('bookmarkChatNoUrl', 'Cannot start chat: no bookmarks selected'), 'error');
    return;
  }

  chrome.storage.sync.get(['customPlatforms'], function(result) {
    var customPlatforms = result.customPlatforms || [];
    var allEntries = [];

    for (var ci = 0; ci < customPlatforms.length; ci++) {
      var c = customPlatforms[ci];
      if (c.enabled !== false) {
        allEntries.push({ domain: c.name, name: c.name, url: c.urlPattern || 'https://' + c.name, color: c.color || '#666', isCustom: true });
      }
    }
    for (var bi = 0; bi < CHAT_BUILTIN_PLATFORMS.length; bi++) {
      var bp = CHAT_BUILTIN_PLATFORMS[bi];
      allEntries.push({ domain: bp.domain, name: bp.name, url: bp.url, color: bp.color, isCustom: false });
    }

    var popup = document.createElement('div');
    popup.className = 'cw-chat-popup';
    popup.style.position = 'fixed';
    popup.style.visibility = 'hidden';

    var rect = anchorEl.getBoundingClientRect();

    var list = document.createElement('div');
    list.className = 'cw-chat-popup-list';

    for (var ei = 0; ei < allEntries.length; ei++) {
      var e = allEntries[ei];
      var btn = document.createElement('button');
      btn.className = 'cw-chat-popup-item';
      btn.dataset.platform = e.domain;
      btn.dataset.url = e.url;

      var badge = document.createElement('span');
      badge.className = 'cw-chat-popup-badge';
      badge.style.backgroundColor = e.color;
      badge.textContent = e.name;
      btn.appendChild(badge);

      if (e.url) {
        btn.addEventListener('click', (function(domain, url) {
          return function() {
            popup.remove();
            activeChatPopup = null;
            chrome.runtime.sendMessage({
              action: 'CONTEXT_SESSION_START',
              bookmarkIds: bookmarkIds,
              targetPlatform: domain,
              targetUrl: url,
            }, function(response) {
              if (!response || !response.success) {
                showStatus(response?.error || 'Failed to start', 'error');
              }
            });
          };
        })(e.domain, e.url));
      } else {
        btn.disabled = true;
        btn.title = 'No URL configured';
      }
      list.appendChild(btn);
    }

    popup.appendChild(list);
    document.body.appendChild(popup);
    activeChatPopup = popup;

    // Position after render so we have actual dimensions
    var pw = popup.offsetWidth;
    var ph = popup.offsetHeight;
    var finalLeft = rect.left;
    if (finalLeft + pw > window.innerWidth - 4) finalLeft = window.innerWidth - pw - 4;
    if (finalLeft < 4) finalLeft = 4;
    var finalTop = rect.bottom + 4;
    if (finalTop + ph > window.innerHeight - 4) finalTop = rect.top - ph - 4;
    if (finalTop < 4) finalTop = 4;
    popup.style.left = finalLeft + 'px';
    popup.style.top = finalTop + 'px';
    popup.style.visibility = '';

    function closePopup(e) {
      if (popup && !popup.contains(e.target) && e.target !== anchorEl && !anchorEl.contains(e.target)) {
        popup.remove();
        activeChatPopup = null;
        document.removeEventListener('click', closePopup);
      }
    }
    setTimeout(function() { document.addEventListener('click', closePopup); }, 0);
  });
}
