/**
 * ContextWizard Cloud Sync — Change Tracker Module
 * 
 * Monitors local data changes (conversations, bookmarks, templates, settings)
 * and maintains a changelog in chrome.storage.local for diff sync.
 * 
 * The changelog records what changed since the last successful sync,
 * enabling the diff module to generate minimal payloads.
 */

const CW_CHANGELOG_KEY = 'cw_sync_changelog';
const CW_TRACKER_LAST_SYNC_KEY = 'cw_sync_last_synced_at';

/**
 * @typedef {Object} ChangeEntry
 * @property {'conversation'|'bookmark'|'promptTemplate'|'searchHistory'|'settings'} type
 * @property {string} id - item ID (or 'bulk' for batch changes)
 * @property {'upsert'|'delete'} action
 * @property {number} timestamp - when the change happened
 */

/**
 * Record a data change to the changelog.
 * @param {'conversation'|'bookmark'|'promptTemplate'|'searchHistory'|'settings'} type
 * @param {string} id
 * @param {'upsert'|'delete'} action
 */
async function recordChange(type, id, action) {
  const changelog = await _getChangelog();

  changelog.changes.push({
    type,
    id: id || 'bulk',
    action: action || 'upsert',
    timestamp: Date.now(),
  });

  // Cap changelog at 5000 entries to prevent unbounded growth
  if (changelog.changes.length > 5000) {
    changelog.changes = changelog.changes.slice(-5000);
  }

  await _saveChangelog(changelog);
}

/**
 * Get all changes since the last sync.
 * @returns {Promise<ChangeEntry[]>}
 */
async function getChangesSinceLastSync() {
  const changelog = await _getChangelog();
  return changelog.changes;
}

/**
 * Check if there are any pending changes to sync.
 * @returns {Promise<boolean>}
 */
async function hasPendingChanges() {
  const changelog = await _getChangelog();
  return changelog.changes.length > 0;
}

/**
 * Get the timestamp of the last successful sync.
 * @returns {Promise<number>} Unix timestamp in ms, or 0 if never synced
 */
async function getLastSyncedAt() {
  return new Promise((resolve) => {
    chrome.storage.local.get(CW_TRACKER_LAST_SYNC_KEY, (result) => {
      resolve(result[CW_TRACKER_LAST_SYNC_KEY] || 0);
    });
  });
}

/**
 * Mark sync as complete — clear the changelog and update last sync time.
 */
async function markSyncComplete() {
  const now = Date.now();
  await new Promise((resolve) => {
    chrome.storage.local.set({
      [CW_CHANGELOG_KEY]: { changes: [] },
      [CW_TRACKER_LAST_SYNC_KEY]: now,
    }, resolve);
  });
}

/**
 * Get a summary of pending changes (grouped by type).
 * @returns {Promise<Object>}
 */
async function getChangeSummary() {
  const changelog = await _getChangelog();
  const summary = {};

  for (const entry of changelog.changes) {
    const key = `${entry.type}:${entry.action}`;
    summary[key] = (summary[key] || 0) + 1;
  }

  return {
    totalChanges: changelog.changes.length,
    breakdown: summary,
  };
}

/**
 * Get unique IDs of changed items by type.
 * Useful for the diff module to know exactly which items to include.
 * @param {'conversation'|'bookmark'|'promptTemplate'} type
 * @returns {Promise<{upserted: Set<string>, deleted: Set<string>}>}
 */
async function getChangedIds(type) {
  const changelog = await _getChangelog();
  const upserted = new Set();
  const deleted = new Set();

  for (const entry of changelog.changes) {
    if (entry.type !== type) continue;
    if (entry.action === 'delete') {
      deleted.add(entry.id);
      upserted.delete(entry.id); // If deleted after upsert, only delete matters
    } else {
      upserted.add(entry.id);
      deleted.delete(entry.id); // If upserted after delete, only upsert matters
    }
  }

  return { upserted, deleted };
}

// ── Internal ─────────────────────────────────────────────────

async function _getChangelog() {
  return new Promise((resolve) => {
    chrome.storage.local.get(CW_CHANGELOG_KEY, (result) => {
      resolve(result[CW_CHANGELOG_KEY] || { changes: [] });
    });
  });
}

async function _saveChangelog(changelog) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [CW_CHANGELOG_KEY]: changelog }, resolve);
  });
}

// Export
if (typeof globalThis !== 'undefined') {
  globalThis.CloudSyncTracker = {
    recordChange,
    getChangesSinceLastSync,
    hasPendingChanges,
    getLastSyncedAt,
    markSyncComplete,
    getChangeSummary,
    getChangedIds,
    CW_CHANGELOG_KEY,
    CW_LAST_SYNC_KEY: CW_TRACKER_LAST_SYNC_KEY,
  };
}
