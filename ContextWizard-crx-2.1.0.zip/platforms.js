// ContextWizard © 2025 amiPro, LLC. All rights reserved.
// Use governed by the ContextWizard EULA (see LICENSE.txt).
// Platform configurations for AI chat platforms
// Note: Most message extraction is now handled by the universal MessageExtractor
// These configs only provide optional hints for better extraction

(function() {
  'use strict';

  // Prevent double-injection when executeScript races with registered content scripts.
  // globalThis.__cwPlatformsInjected is set to true on first execution in the isolated world.
  // The __cwSkipInit flag allows tests to bypass the guard.
  if (!globalThis.__cwSkipInit && globalThis.__cwPlatformsInjected) { return; }
  if (!globalThis.__cwSkipInit) { globalThis.__cwPlatformsInjected = true; }

  const PLATFORMS = {
    'chatgpt.com': {
      name: 'ChatGPT',
      enabled: true,
      requireDistinctUrl: true,
      selectors: {
        conversationTitle: 'h1',
        conversationArea: '[role="presentation"] [data-testid*="conversation"], main'
      },
      classPatterns: {
        messageElement: /group\/message|message-block|prose/
      },
      color: '#10a37f'
    },

    'claude.ai': {
      name: 'Claude',
      enabled: true,
      chatPathPrefix: '/chat/',
      selectors: {
        conversationTitle: 'h1, [data-testid="chat-title"]',
        conversationArea: '[data-testid="chat-messages"], [class*="overflow-y-auto"]:not([class*="nav"]):not([class*="sidebar"]), main'
      },
      classPatterns: {
        messageContent: /message-text|message-container|prose|chat-message/
      },
      color: '#cc9b7a'
    },

    'gemini.google.com': {
      name: 'Gemini',
      enabled: true,
      requireDistinctUrl: false,
      selectors: {
        conversationTitle: 'h1, [data-test-id="conversation-title"]',
        conversationArea: 'chat-window-content, main'
      },
      color: '#4285f4'
    },

    'copilot.microsoft.com': {
      name: 'Copilot',
      enabled: true,
      selectors: {
        conversationTitle: 'h1, .title',
        conversationArea: 'section[class*="conversation"]:not([class*="history"]), main'
      },
      color: '#0078d4'
    },

    'grok.com': {
      name: 'Grok',
      enabled: true,
      selectors: {
        conversationTitle: 'h1',
        conversationArea: 'main, [class*="grok-content-area"], [data-testid="drop-container"]'
      },
      classPatterns: {
        messageElement: /message|user-message|assistant-message/,
        userMessage: /user/i,
        assistantMessage: /assistant|bot|model/i
      },
      color: '#000000'
    },

    'www.perplexity.ai': {
      name: 'Perplexity',
      enabled: true,
      selectors: {
        conversationTitle: 'h1'
      },
      color: '#20808d'
    },

    'www.kimi.com': {
      name: 'Kimi',
      enabled: true,
      selectors: {
        conversationTitle: 'h1, [data-testid="chat-title"]'
      },
      color: '#5b8ef4'
    },

    'poe.com': {
      name: 'Poe',
      enabled: true,
      selectors: {
        conversationTitle: 'h1'
      },
      color: '#e8484d'
    },

    'huggingface.co/chat': {
      name: 'HuggingFace Chat',
      enabled: true,
      selectors: {
        conversationTitle: 'h1',
        conversationArea: 'main, [class*="overflow-y-auto"]'
      },
      classPatterns: {
        messageContent: /whitespace-pre-wrap|message-text|chat-bubble|message-content/,
        userMessage: /user|you|human/i,
        assistantMessage: /assistant|ai|response|model/i
      },
      color: '#ffd21e'
    },

    'chat.deepseek.com': {
      name: 'DeepSeek',
      enabled: true,
      selectors: {
        conversationTitle: 'h1, .chat-title'
      },
      color: '#0066ff'
    },

    'chat.qwen.ai': {
      name: 'Qwen',
      enabled: true,
      selectors: {
        conversationTitle: 'h1, .conversation-title'
      },
      color: '#5b4cff'
    },

    'manus.im': {
      name: 'Manus',
      enabled: true,
      requireDistinctUrl: true,
      selectors: {
        conversationTitle: 'h1, .chat-title',
        conversationArea: 'main'
      },
      classPatterns: {
        messageContent: /whitespace-pre-wrap|max-w-none|message|text-\[16px\]/,
        messageWrapper: /flex flex-col|message-turn|message-box/
      },
      color: '#6366f1'
    }
  };

  // Export for use in other modules
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = PLATFORMS;
  } else {
    // Ensure global availability for browser environment
    (typeof globalThis !== 'undefined' ? globalThis : window).PLATFORMS = PLATFORMS;
  }
})();
