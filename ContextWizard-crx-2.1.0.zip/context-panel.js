(function () {
  'use strict';

  class ContextPanel {
    constructor() {
      this.panel = null;
      this.toastEl = null;
      this.session = null;
      this.isDragging = false;
      this.dragOffset = { x: 0, y: 0 };
      this._bookmarkCheckboxes = [];
      this._injectBtn = null;
      this._listEl = null;
      this._footerStatusEl = null;
      this._footerEl = null;
      this._injected = false;
      this._injectedBookmarkIds = [];
      this._periodicSyncTimer = null;
      this._monitoredInputEl = null;
    }

    init(session) {
      this.session = session;
      if (this.panel) return;
      this.createPanel();
      this.attachListeners();
      this.startInputMonitoring();
      this.refresh();
    }

    destroy() {
      if (this._periodicSyncTimer) {
        clearInterval(this._periodicSyncTimer);
        this._periodicSyncTimer = null;
      }
      if (this.panel) {
        this.panel.remove();
        this.panel = null;
      }
      this.session = null;
    }

    createPanel() {
      this.panel = document.createElement('div');
      this.panel.className = 'cw-context-panel';
      this.panel.innerHTML = [
        '<div class="cw-context-panel-header">',
        '  <h3>Bookmark Context</h3>',
        '</div>',
        '<div class="cw-context-panel-list" role="list" tabindex="-1">',
        '  <div style="padding:20px;text-align:center;color:#9ca3af;font-size:12px">Loading bookmarks...</div>',
        '</div>',
        '<div class="cw-context-panel-footer">',
        '  <span class="cw-context-footer-status"></span>',
        '  <button class="cw-inject-btn" disabled>Inject Context</button>',
        '</div>',
        '<div class="cw-context-toast"></div>',
      ].join('\n');

      document.body.appendChild(this.panel);

      this._listEl = this.panel.querySelector('.cw-context-panel-list');
      this._injectBtn = this.panel.querySelector('.cw-inject-btn');
      this._footerStatusEl = this.panel.querySelector('.cw-context-footer-status');
      this._footerEl = this.panel.querySelector('.cw-context-panel-footer');
      this.toastEl = this.panel.querySelector('.cw-context-toast');

      this.recalcPosition();
    }

    attachListeners() {
      this._injectBtn.addEventListener('click', () => this.handleInject());

      this.panel.addEventListener('keydown', (e) => this.handleKeyNav(e));

      this.initDrag();

      this.panel.querySelector('.cw-context-panel-header').addEventListener('dblclick', () => {
        this.recalcPosition();
      });
    }

    startInputMonitoring() {
      this._startInputMonitoringWithRetry(0);
      this._startPeriodicSync();
    }

    _startInputMonitoringWithRetry(attempt) {
      if (!this.panel) return; // Panel already destroyed
      const inputEl = this.findInput();
      if (inputEl && inputEl !== this._monitoredInputEl) {
        this._monitoredInputEl = inputEl;
        const handler = () => this.syncButtonState();
        inputEl.addEventListener('input', handler);
        inputEl.addEventListener('keyup', handler);
        this.syncButtonState();
        this.recalcPosition(); // Position panel now that input is known
        return;
      }
      if (inputEl) {
        // Already monitoring this element — just sync state
        this.syncButtonState();
        return;
      }
      if (attempt < 10) {
        var self = this;
        setTimeout(function() { self._startInputMonitoringWithRetry(attempt + 1); }, 500);
      }
    }

    _startPeriodicSync() {
      if (this._periodicSyncTimer) return;
      var self = this;
      this._periodicSyncTimer = setInterval(function() {
        if (self._injected || !self.panel) {
          clearInterval(self._periodicSyncTimer);
          self._periodicSyncTimer = null;
          return;
        }
        // Re-attach if input element was replaced (SPA navigation)
        var currentInput = self.findInput();
        if (currentInput && currentInput !== self._monitoredInputEl) {
          self._startInputMonitoringWithRetry(0);
        }
        self.syncButtonState();
      }, 500);
    }

    getQueryText() {
      const inputEl = this.findInput();
      if (!inputEl) return '';
      if (inputEl.isContentEditable || inputEl.getAttribute('contenteditable') === 'true') {
        return (inputEl.innerText || inputEl.textContent || '').trim();
      }
      return (inputEl.value || '').trim();
    }

    syncButtonState() {
      if (!this._injectBtn || this._injected) return;
      const checkedCount = (this._bookmarkCheckboxes || []).filter(function(cb) { return cb.checked; }).length;
      const queryText = this.getQueryText();
      const queryValid = queryText.length >= 5;

      if (checkedCount > 0 && queryValid) {
        this._injectBtn.disabled = false;
        if (this._footerStatusEl) {
          this._footerStatusEl.textContent = checkedCount + ' selected \u00B7 ready';
        }
      } else {
        this._injectBtn.disabled = true;
        if (this._footerStatusEl) {
          if (checkedCount === 0) {
            this._footerStatusEl.textContent = 'Select bookmarks';
          } else if (!queryValid) {
            this._footerStatusEl.textContent = 'Type a question (\u22655 chars)';
          }
        }
      }
    }

    refresh() {
      if (!this.session) return;
      const state = this.session.getPanelState();
      if (!state) return;

      this.renderBookmarkList(state.bookmarkStates || []);
    }

    renderBookmarkList(bookmarkStates) {
      if (!this._listEl) return;

      const checkedIds = this.session ? this.session.state.checkedBookmarkIds : [];

      this._listEl.innerHTML = '';
      this._bookmarkCheckboxes = [];

      if (!bookmarkStates || bookmarkStates.length === 0) {
        this._listEl.innerHTML = '<div style="padding:20px;text-align:center;color:#9ca3af;font-size:12px">No bookmarks available</div>';
        this.syncButtonState();
        return;
      }

      for (const bs of bookmarkStates) {
        const item = document.createElement('div');
        item.className = 'cw-context-panel-item';
        item.setAttribute('tabindex', '0');
        item.dataset.bookmarkId = bs.bookmarkId;
        item.dataset.url = bs.url || '';

        const label = bs.selectedText || bs.bookmarkName || bs.snippet || (bs.bookmarkId ? this.truncateText(bs.bookmarkId, 60) : 'Bookmark');
        const fullContent = bs.fullContent || '';
        const url = bs.url || '';

        if (this._injected) {
          // 注入后：只读模式，区分已注入/未注入
          var isInjected = this._injectedBookmarkIds.indexOf(bs.bookmarkId) >= 0;
          item.classList.add('cw-item-readonly');
          if (isInjected) {
            item.classList.add('cw-item-injected');
          }

          var text = document.createElement('span');
          text.className = 'cw-bookmark-text';
          text.textContent = label;
          if (!isInjected) {
            var note = document.createElement('span');
            note.className = 'cw-bookmark-skip-note';
            note.textContent = ' (not injected)';
            text.appendChild(note);
          }
          item.appendChild(text);

          if (url) {
            var self = this;
            item.addEventListener('click', function() {
              self.openBookmarkUrl(url, bs.bookmarkId);
            });
            item.style.cursor = 'pointer';
          }

          if (fullContent) {
            var self = this;
            text.addEventListener('mouseenter', function() {
              self.showPreview(text, fullContent);
            });
            text.addEventListener('mouseleave', function() {
              self.hidePreview();
            });
          }
        } else {
          // 注入前：checkbox + URL 按钮
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.checked = bs.checked;
          checkbox.dataset.bookmarkId = bs.bookmarkId;

          const textWrap = document.createElement('div');
          textWrap.className = 'cw-bookmark-text-wrap';

          const text = document.createElement('span');
          text.className = 'cw-bookmark-text';
          text.textContent = label;
          textWrap.appendChild(text);

          const previewText = fullContent || label;
          if (previewText) {
            var self = this;
            text.addEventListener('mouseenter', function() {
              self.showPreview(text, previewText);
            });
            text.addEventListener('mouseleave', function() {
              self.hidePreview();
            });
          }

          var self = this;
          const actions = document.createElement('div');
          actions.className = 'cw-bookmark-actions';

          if (url) {
            const openBtn = document.createElement('button');
            openBtn.className = 'cw-bookmark-open-btn';
            openBtn.textContent = '\u2197';
            openBtn.title = 'Open source page';
            openBtn.addEventListener('click', function(e) {
              e.stopPropagation();
              self.openBookmarkUrl(url, bs.bookmarkId);
            });
            actions.appendChild(openBtn);
          }

          item.appendChild(checkbox);
          item.appendChild(textWrap);
          item.appendChild(actions);

          checkbox.addEventListener('change', function() {
            self.onCheckboxChange();
          });

          item.addEventListener('click', function(e) {
            if (e.target !== checkbox && !e.target.closest('.cw-bookmark-actions')) {
              checkbox.checked = !checkbox.checked;
              self.onCheckboxChange();
            }
          });

          this._bookmarkCheckboxes.push(checkbox);
        }

        this._listEl.appendChild(item);
      }

      if (!this._injected) {
        this.syncButtonState();
      }
    }

    openBookmarkUrl(url, bookmarkId) {
      if (!url) return;
      var currentUrl = window.location.href;
      var isSamePage = currentUrl === url || currentUrl.startsWith(url.split('?')[0]);
      if (isSamePage && bookmarkId) {
        chrome.runtime.sendMessage({
          action: 'scrollToBookmark',
          bookmarkId: bookmarkId,
          tabId: 0
        }).catch(function() {});
      } else {
        window.open(url, '_blank');
        if (bookmarkId) {
          setTimeout(function() {
            chrome.runtime.sendMessage({
              action: 'scrollToBookmark',
              bookmarkId: bookmarkId,
              targetUrl: url
            }).catch(function() {});
          }, 1500);
        }
      }
    }

    onCheckboxChange() {
      var checkedIds = [];
      for (var i = 0; i < this._bookmarkCheckboxes.length; i++) {
        if (this._bookmarkCheckboxes[i].checked) {
          checkedIds.push(this._bookmarkCheckboxes[i].dataset.bookmarkId);
        }
      }
      if (this.session) {
        this.session.setCheckedBookmarkIds(checkedIds);
      }
      this.syncButtonState();
    }

    handleInject() {
      if (!this.session) return;

      var checkedIds = [];
      for (var i = 0; i < this._bookmarkCheckboxes.length; i++) {
        if (this._bookmarkCheckboxes[i].checked) {
          checkedIds.push(this._bookmarkCheckboxes[i].dataset.bookmarkId);
        }
      }

      if (checkedIds.length === 0) {
        this.showToast('Please select at least one bookmark');
        return;
      }

      var queryText = this.getQueryText();
      if (queryText.length < 5) {
        this.showToast('Please type a question (at least 5 characters)');
        return;
      }

      var payload = this.session.getInjectionPayload(checkedIds, queryText);
      if (!payload || !payload.contextBlock) {
        this.showToast('No relevant context found');
        return;
      }

      var platformName = this.session.platformName;
      var self = this;
      globalThis.injectContextPrepend(platformName, payload.contextBlock).then(function(result) {
        if (result && result.clipboard) {
          self.showToast('Auto-inject failed, copied to clipboard');
        } else if (result && result.alreadyInjected) {
          self.showToast('Context already injected');
        } else {
          self.showToast('Context injected (' + payload.totalChars + ' chars)');
        }
        self._injectedBookmarkIds = checkedIds;
        self.enterReadOnlyMode();
      });
    }

    enterReadOnlyMode() {
      this._injected = true;
      if (this._injectBtn) {
        this._injectBtn.style.display = 'none';
      }
      if (this._footerStatusEl) {
        this._footerStatusEl.textContent = '';
      }
      if (this._footerEl) {
        this._footerEl.style.display = 'none';
      }
      this.refresh();
    }

    showToast(message) {
      if (!this.toastEl) return;
      this.toastEl.textContent = message;
      this.toastEl.classList.add('cw-toast-visible');
      var self = this;
      setTimeout(function() {
        self.toastEl.classList.remove('cw-toast-visible');
      }, 3000);
    }

    showPreview(targetEl, content) {
      this.hidePreview();
      var preview = document.createElement('div');
      preview.className = 'cw-bookmark-preview';
      preview.textContent = content;
      document.body.appendChild(preview);
      var panelRect = this.panel.getBoundingClientRect();
      var rect = targetEl.getBoundingClientRect();
      preview.style.left = Math.min(rect.left, window.innerWidth - 320) + 'px';
      preview.style.top = (rect.bottom + 4) + 'px';
      preview.style.maxWidth = '300px';
      this._previewEl = preview;
    }

    hidePreview() {
      if (this._previewEl) {
        this._previewEl.remove();
        this._previewEl = null;
      }
    }

    truncateText(str, maxLen) {
      if (!str) return '';
      if (Array.from(str).length <= maxLen) return str;
      try {
        var seg = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
        var result = '';
        for (var s of seg.segment(str)) {
          if (Array.from(result).length + 1 > maxLen) break;
          result += s.segment;
        }
        return result + '...';
      } catch (e) {
        return Array.from(str).slice(0, maxLen).join('') + '...';
      }
    }

    handleKeyNav(e) {
      if (this._injected) return;

      var items = this.panel.querySelectorAll('.cw-context-panel-item:not(.cw-item-readonly)');
      var currentEl = e.target.closest('.cw-context-panel-item');
      var currentIndex = -1;
      for (var i = 0; i < items.length; i++) {
        if (items[i] === currentEl) { currentIndex = i; break; }
      }

      switch (e.key) {
        case 'ArrowDown':
        case 'ArrowRight':
          e.preventDefault();
          if (currentIndex < items.length - 1) {
            items[currentIndex + 1].focus();
          }
          break;
        case 'ArrowUp':
        case 'ArrowLeft':
          e.preventDefault();
          if (currentIndex > 0) {
            items[currentIndex - 1].focus();
          }
          break;
        case ' ':
          if (e.target.closest('.cw-context-panel-item')) {
            e.preventDefault();
            var cb = e.target.closest('.cw-context-panel-item').querySelector('input[type="checkbox"]');
            if (cb) {
              cb.checked = !cb.checked;
              this.onCheckboxChange();
            }
          }
          break;
        case 'Enter':
          if (e.target === this._injectBtn) {
            e.preventDefault();
            this.handleInject();
          }
          break;
      }
    }

    initDrag() {
      var header = this.panel.querySelector('.cw-context-panel-header');
      if (!header) return;
      var self = this;

      header.addEventListener('mousedown', function(e) {
        if (e.target.tagName === 'BUTTON') return;
        self.isDragging = true;
        self.dragOffset.x = e.clientX - self.panel.offsetLeft;
        self.dragOffset.y = e.clientY - self.panel.offsetTop;
        self.panel.style.cursor = 'grabbing';
      });

      document.addEventListener('mousemove', function(e) {
        if (!self.isDragging) return;
        e.preventDefault();
        self.panel.style.left = (e.clientX - self.dragOffset.x) + 'px';
        self.panel.style.top = (e.clientY - self.dragOffset.y) + 'px';
        self.panel.style.right = 'auto';
        self.panel.style.bottom = 'auto';
      });

      document.addEventListener('mouseup', function() {
        if (self.isDragging) {
          self.isDragging = false;
          if (self.panel) self.panel.style.cursor = '';
        }
      });
    }

    recalcPosition() {
      var input = this.findInput();
      if (!input) {
        // Input not found yet — park at top-right so panel is visible while we wait
        if (!this.panel.style.right) {
          this.panel.style.right = '12px';
          this.panel.style.top = '80px';
          this.panel.style.left = 'auto';
          this.panel.style.bottom = 'auto';
        }
        return;
      }

      var rect = input.getBoundingClientRect();
      var panelW = this.panel.offsetWidth || 320;
      var panelH = this.panel.offsetHeight || 400;

      var left = Math.min(
        rect.right - panelW,
        window.innerWidth - panelW - 12
      );
      if (left < 12) left = 12;

      var top = rect.top - panelH - 12;
      if (top < 8) {
        top = rect.bottom + 8;
      }
      if (top + panelH > window.innerHeight - 8) {
        top = Math.max(8, window.innerHeight - panelH - 8);
      }

      this.panel.style.left = left + 'px';
      this.panel.style.top = top + 'px';
      this.panel.style.right = 'auto';
      this.panel.style.bottom = 'auto';
    }

    findInput() {
      if (!this.session) return null;
      if (globalThis.findPlatformInput) {
        return globalThis.findPlatformInput(this.session.platformName);
      }
      return document.querySelector('[contenteditable="true"]') ||
             document.querySelector('textarea');
    }

    getPanel() {
      return this.panel;
    }
  }

  globalThis.ContextPanel = ContextPanel;
})();
