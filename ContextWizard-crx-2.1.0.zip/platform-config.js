// PLATFORM_INPUT_CONFIG — 平台发送检测 + 注入策略配置表
// 来源：P0-A 平台调研 + P0-A.5 注入策略原型验证
// 生成日期：2026-06-24
// 注意：主平台（ChatGPT/Claude/Gemini）已验证，其余为 best effort
// 加载方式: content script (CONTENT_SCRIPT_FILES), 通过 globalThis 共享

(function () {
'use strict';

const PLATFORM_INPUT_CONFIG = {
  'chatgpt.com': {
    // ----- 发送检测 -----
    inputSelector: '#prompt-textarea',
    inputType: 'contenteditable',         // ProseMirror div[contenteditable]
    sendButtonSelector: 'button[data-testid="send-button"], button[aria-label="Send prompt"]',
    sendEvent: 'enter',                    // Enter 发送
    messageListSelector: '[data-message-author-role="user"]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,               // SPA 导航不视为发送

    // ----- 注入策略 -----
    // 验证结果：ProseMirror contenteditable → execCommand('insertText') 已验证可行
    // 回退方案：直接设置 innerText + dispatch InputEvent
    injectionStrategy: 'execCommand',      // verified: 通过 P0-A.5 原型验证
    injectionFallback: 'directInput',
    injectionVerified: true,

    // 稳定性
    stability: 'high',                     // data-* 属性稳定的，多次改版未变
  },

  'claude.ai': {
    // ----- 发送检测 -----
    inputSelector: 'div.ProseMirror',
    inputType: 'contenteditable',         // Tiptap/ProseMirror div[contenteditable]
    sendButtonSelector: 'button[aria-label="Send Message"], button[aria-label="Send message"]',
    sendEvent: 'enter',
    messageListSelector: '.font-user-message',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,

    // ----- 注入策略 -----
    // 验证结果：ProseMirror contenteditable → execCommand('insertText') 已验证可行
    // 注意：Claude 的 ProseMirror 需要额外 dispatch InputEvent 才能触发 React 更新
    injectionStrategy: 'execCommand',
    injectionFallback: 'directInput',
    injectionVerified: true,

    stability: 'medium',                   // .font-user-message 类名可能变，ProseMirror 稳定
  },

  'gemini.google.com': {
    // ----- 发送检测 -----
    inputSelector: '.ql-editor',
    inputType: 'contenteditable',         // Angular + Quill.js div[contenteditable]
    sendButtonSelector: 'button[aria-label="Send message"], button.send-button',
    sendEvent: 'enter',
    messageListSelector: 'user-query, .query-text',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,

    // ----- 注入策略 -----
    // 验证结果：Quill contenteditable → execCommand('insertText') 可工作
    // 风险：Angular 的变更检测可能需要额外 trigger
    injectionStrategy: 'execCommand',
    injectionFallback: 'directInput',
    injectionVerified: true,

    stability: 'low',                      // Angular 混淆类名频繁变化，custom elements 略稳定
  },

  // ----- Best-effort 平台（未注入验证，使用通用模式） -----

  'copilot.microsoft.com': {
    inputSelector: 'textarea, [contenteditable="true"]',
    inputType: 'unknown',
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '[data-testid="message"]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  'perplexity.ai': {
    inputSelector: 'textarea, [contenteditable="true"]',
    inputType: 'unknown',                 // 待调研
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '[data-message-id]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  'chat.deepseek.com': {
    inputSelector: 'textarea, [contenteditable="true"]',
    inputType: 'unknown',
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '.message-item',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  'grok.com': {
    inputSelector: 'textarea, [contenteditable="true"]',
    inputType: 'unknown',
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '[data-testid="message"]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  'poe.com': {
    inputSelector: 'textarea, [contenteditable="true"]',
    inputType: 'unknown',
    sendButtonSelector: 'button[aria-label="Send"]',
    sendEvent: 'enter',
    messageListSelector: '.ChatMessage_message',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  // www-prefixed alias so platforms.js key 'www.perplexity.ai' resolves without normalization
  'www.perplexity.ai': {
    inputSelector: ['textarea[rows]', 'textarea', '[contenteditable="true"]'],
    inputType: 'unknown',
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '[data-message-id]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  'chat.qwen.ai': {
    inputSelector: ['textarea', '[contenteditable="true"]'],
    inputType: 'unknown',
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '[class*="message"]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },

  'manus.im': {
    inputSelector: ['textarea', '[contenteditable="true"]'],
    inputType: 'unknown',
    sendButtonSelector: 'button[type="submit"]',
    sendEvent: 'enter',
    messageListSelector: '[class*="message"]',
    eventDedupWindowMs: 800,
    urlChangeIsSend: false,
    injectionStrategy: 'generic',
    injectionFallback: 'directInput',
    injectionVerified: false,
    stability: 'unknown',
  },
};

// 注入策略函数映射（由 ContentInjector 使用）
const INJECTION_STRATEGY_FUNCTIONS = {
  // execCommand('insertText') — 已验证适用于 ProseMirror/Quill contenteditable
  execCommand: (el, text) => {
    el.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);

    const success = document.execCommand('insertText', false, text);
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: text,
    }));
    return success !== false;
  },

  // 直接设置 innerText + dispatch InputEvent — 回退方案
  directInput: (el, text) => {
    el.focus();
    el.innerText = text;
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertFromPaste',
    }));
    return true;
  },

  // 通用回退 — 同时尝试多种方式
  generic: (el, text) => {
    // 先尝试 execCommand
    try {
      el.focus();
      const sel = window.getSelection();
      const r = document.createRange();
      r.selectNodeContents(el);
      r.collapse(false);
      sel.removeAllRanges();
      sel.addRange(r);
      if (document.execCommand('insertText', false, text)) {
        el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }));
        return true;
      }
    } catch (e) { /* fall through */ }
    // 再试直接设置
    try {
      el.innerText = text;
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertFromPaste' }));
      return true;
    } catch (e) { /* fall through */ }
    // 最后试 value 方式
    try {
      el.value = text;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    } catch (e) {
      return false;
    }
  },
};

globalThis.PLATFORM_INPUT_CONFIG = PLATFORM_INPUT_CONFIG;
globalThis.INJECTION_STRATEGY_FUNCTIONS = INJECTION_STRATEGY_FUNCTIONS;

})();

if (typeof module !== 'undefined') {
  module.exports = { PLATFORM_INPUT_CONFIG, INJECTION_STRATEGY_FUNCTIONS };
}
