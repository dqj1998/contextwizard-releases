/**
 * Shared utility functions for ContextWizard
 * This module provides common functions used by both content.js and popup.js
 */

(function(global) {
  'use strict';

  /**
   * Convert HTML to plain text
   */
  function htmlToPlainText(html) {
    if (!html || typeof html !== 'string') {
      return '';
    }

    const normalized = html
      .replaceAll(/<\s*br\s*\/?\s*>/gi, '\n')
      .replaceAll(/<\s*\/\s*(p|div|li|pre|h[1-6]|tr)\s*>/gi, '\n')
      .replaceAll(/<\s*\/\s*(ul|ol|table)\s*>/gi, '\n');

    const container = document.createElement('div');
    container.innerHTML = normalized;
    let text = container.textContent || '';
    text = text
      .replaceAll('\r\n', '\n')
      .replaceAll(/[ \t]+\n/g, '\n')
      .replaceAll(/\n{3,}/g, '\n\n')
      .trim();
    return text;
  }

  /**
   * Extract text content from a message object
   * Supports string, array, and object content formats
   */
  function extractMessageText(message) {
    if (!message) {
      return '';
    }

    if (typeof message.content === 'string') {
      return message.content.trim();
    }

    if (Array.isArray(message.content)) {
      const textParts = [];
      for (const part of message.content) {
        if (part && typeof part.text === 'string' && part.text.trim()) {
          textParts.push(part.text);
        }
      }
      return textParts.join('\n');
    }

    if (message.content && typeof message.content.text === 'string') {
      return message.content.text;
    }

    const htmlText = htmlToPlainText(message.html);
    if (htmlText) {
      return htmlText;
    }

    return String(message.content || '');
  }

  /**
   * Format conversation as context text for copying to clipboard
   */
  function formatConversationAsContextText(conversation) {
    const blocks = [];
    for (const message of conversation?.messages || []) {
      const text = extractMessageText(message);
      if (!text) {
        continue;
      }

      const role = typeof message?.role === 'string' ? message.role : '';
      let prefix = '';
      if (role === 'user') {
        prefix = 'User: ';
      } else if (role === 'assistant') {
        prefix = 'Assistant: ';
      } else if (role === 'system') {
        prefix = 'System: ';
      }

      blocks.push(prefix ? `${prefix}${text}` : text);
    }

    return blocks.join('\n\n');
  }

  /**
   * Copy text to clipboard with fallback
   */
  async function copyTextToClipboard(text) {
    if (typeof text !== 'string') {
      return false;
    }

    try {
      if (globalThis.navigator?.clipboard?.writeText) {
        await globalThis.navigator.clipboard.writeText(text);
        return true;
      }
    } catch (error) {

    }

    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      textArea.style.top = '-9999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      return successful;
    } catch (error) {

      return false;
    }
  }

  /**
   * Copy formatted content to clipboard (HTML + plain text fallback)
   */
  async function copyFormattedContent(selection) {
    if (!selection || selection.rangeCount === 0) {
      return false;
    }

    const textContent = selectionToString(selection, 'text/plain');
    const htmlContent = createRichTextHTML(selection);
    const htmlPayload = buildHtmlClipboardPayload(htmlContent);

    // Modern Clipboard API with explicit HTML + plain text
    try {
      if (globalThis.navigator?.clipboard?.write) {
        const clipboardItem = new ClipboardItem({
          'text/html': new Blob([htmlPayload], { type: 'text/html' }),
          'text/plain': new Blob([textContent], { type: 'text/plain' })
        });

        await navigator.clipboard.write([clipboardItem]);
        return true;
      }
    } catch (error) {
      console.warn('[ContextWizard] Clipboard API copy failed, trying fallback:', error.message);
    }

    // Fallback: intercept copy event and force text/html using execCommand selection
    try {
      const eventCopySuccess = copyViaClipboardEvent(selection, htmlPayload, textContent);
      if (eventCopySuccess) {
        return true;
      }
    } catch (error) {
      console.warn('[ContextWizard] Copy event clipboard write failed:', error.message);
    }

    // Legacy fallback: contenteditable trick
    try {
      const contentEditableSuccess = await tryContentEditableCopy(selection);
      if (contentEditableSuccess) {
        return true;
      }
    } catch (error) {
      console.warn('[ContextWizard] Contenteditable copy failed:', error.message);
    }

    // Plain text fallback
    return await copyTextToClipboard(textContent);
  }

  // Build a clipboard-friendly HTML document with explicit fragment markers
  function buildHtmlClipboardPayload(htmlContent) {
    const startMarker = '<!--StartFragment-->';
    const endMarker = '<!--EndFragment-->';
    const wrappedHtml = `<!DOCTYPE html><html><body>${startMarker}${htmlContent}${endMarker}</body></html>`;
    return wrappedHtml;
  }

  // Use the copy event + execCommand to push both HTML and plain text onto the clipboard.
  // We create a temporary selection so execCommand('copy') has a valid target, then restore the original selection.
  function copyViaClipboardEvent(originalSelection, htmlContent, textContent) {
    const selection = window.getSelection();
    if (!selection) {
      return false;
    }

    // Snapshot current ranges to restore later
    const savedRanges = [];
    for (let i = 0; i < selection.rangeCount; i++) {
      savedRanges.push(selection.getRangeAt(i).cloneRange());
    }

    let handled = false;
    const listener = (event) => {
      try {
        if (event.clipboardData) {
          event.clipboardData.setData('text/html', htmlContent);
          event.clipboardData.setData('text/plain', textContent);
          event.preventDefault();
          handled = true;
        }
      } catch (error) {

      }
    };

    // Build a temporary container to host the selection we want to copy
    const tempContainer = document.createElement('div');
    tempContainer.style.position = 'fixed';
    tempContainer.style.left = '-9999px';
    tempContainer.style.top = '-9999px';
    tempContainer.style.opacity = '0';
    tempContainer.innerHTML = htmlContent;
    document.body.appendChild(tempContainer);

    // Select the temporary content
    selection.removeAllRanges();
    const tempRange = document.createRange();
    tempRange.selectNodeContents(tempContainer);
    selection.addRange(tempRange);

    document.addEventListener('copy', listener, true);
    const execSuccess = document.execCommand('copy');
    document.removeEventListener('copy', listener, true);

    // Cleanup
    selection.removeAllRanges();
    document.body.removeChild(tempContainer);

    // Restore original selection if we had one
    if (savedRanges.length) {
      savedRanges.forEach((r) => selection.addRange(r));
    } else if (originalSelection && originalSelection.rangeCount) {
      selection.addRange(originalSelection.getRangeAt(0));
    }

    return handled && execSuccess;
  }

  /**
   * Try copying using contenteditable method for maximum format preservation
   */
  async function tryContentEditableCopy(selection) {
    if (!selection || selection.rangeCount === 0) {
      return false;
    }

    try {
      // Create a hidden contenteditable div
      const hiddenDiv = document.createElement('div');
      hiddenDiv.style.position = 'fixed';
      hiddenDiv.style.left = '-9999px';
      hiddenDiv.style.top = '-9999px';
      hiddenDiv.style.opacity = '0';
      hiddenDiv.style.pointerEvents = 'none';
      hiddenDiv.contentEditable = 'true';
      
      // Clone the selected content
      const range = selection.getRangeAt(0);
      const clonedContents = range.cloneContents();
      hiddenDiv.appendChild(clonedContents);
      
      document.body.appendChild(hiddenDiv);
      
      // Select the content in the contenteditable div
      const newRange = document.createRange();
      newRange.selectNodeContents(hiddenDiv);
      const newSelection = window.getSelection();
      newSelection.removeAllRanges();
      newSelection.addRange(newRange);
      
      // Execute copy command
      const success = document.execCommand('copy');
      
      // Cleanup
      newSelection.removeAllRanges();
      document.body.removeChild(hiddenDiv);
      
      // Restore original selection
      newSelection.addRange(range);
      
      return success;
    } catch (error) {

      return false;
    }
  }

  /**
   * Create rich text HTML from selection preserving all formatting
   */
  function createRichTextHTML(selection) {
    try {
      if (!selection || selection.rangeCount === 0) {
        return selection.toString();
      }

      const range = selection.getRangeAt(0);
      
      // Use a more robust method to extract HTML
      const container = document.createElement('div');
      
      // Clone the range contents preserving all nodes
      const clonedContents = range.cloneContents();
      container.appendChild(clonedContents);
      
      // Ensure list items are properly wrapped
      const walker = document.createTreeWalker(
        container,
        NodeFilter.SHOW_ELEMENT,
        {
          acceptNode: function(node) {
            return node.tagName === 'LI' ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
          }
        }
      );
      
      // Process list items to ensure they have proper parent UL/OL
      const listItems = [];
      let listItem;
      while (listItem = walker.nextNode()) {
        listItems.push(listItem);
      }
      
      listItems.forEach(li => {
        if (!li.parentElement || !['UL', 'OL'].includes(li.parentElement.tagName)) {
          const ul = document.createElement('ul');
          ul.style.margin = '0';
          ul.style.paddingLeft = '20px';
          li.parentNode.insertBefore(ul, li);
          ul.appendChild(li);
        }
      });
      
      let htmlContent = container.innerHTML;
      
      // Add meta information for better clipboard compatibility
      htmlContent = `<meta charset="utf-8"><style>body { font-family: system-ui, -apple-system, sans-serif; }</style><body>${htmlContent}</body>`;
      
      // Clean up the HTML to ensure it's well-formed
      htmlContent = htmlContent
        .replace(/<meta[^>]*>/, '') // Remove meta tag, keep only style
        .replace(/<\/?body[^>]*>/g, ''); // Remove body tags for cleaner HTML
      
      return htmlContent;
    } catch (error) {

      return selection.toString();
    }
  }

  /**
   * Convert selection to string in specified format
   */
  function selectionToString(selection, mimeType = 'text/plain') {
    try {
      if (mimeType === 'text/html' && selection.rangeCount > 0) {
        return createRichTextHTML(selection);
      } else {
        return selection.toString();
      }
    } catch (error) {

      return selection.toString();
    }
  }

  // Export to global scope for compatibility
  global.ContextWizardShared = {
    htmlToPlainText,
    extractMessageText,
    formatConversationAsContextText,
    copyTextToClipboard,
    copyFormattedContent,
    selectionToString,
    createRichTextHTML,
    tryContentEditableCopy
  };

  // Also export individual functions for direct access
  global.extractMessageText = extractMessageText;
  global.formatConversationAsContextText = formatConversationAsContextText;
  global.copyTextToClipboard = copyTextToClipboard;
  global.copyFormattedContent = copyFormattedContent;
  global.selectionToString = selectionToString;
  global.createRichTextHTML = createRichTextHTML;
  global.tryContentEditableCopy = tryContentEditableCopy;
  global.htmlToPlainText = htmlToPlainText;

})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this));
