// ContentInjector — 平台独立的内容注入执行器
// 基于 platform-config.js 的已验证注入策略，支持 contenteditable 和 textarea
// 加载方式: content script (CONTENT_SCRIPT_FILES), 通过 globalThis 共享

(function () {
  'use strict';

  function findPlatformInput(platformName) {
    const config = globalThis.PLATFORM_INPUT_CONFIG;
    if (!config) return null;
    // Try exact match first, then normalize www prefix mismatch
    let pc = config[platformName];
    if (!pc) {
      const alt = platformName.startsWith('www.') ? platformName.slice(4) : 'www.' + platformName;
      pc = config[alt];
    }
    if (!pc) return null;

    const selectors = Array.isArray(pc.inputSelector) ? pc.inputSelector : [pc.inputSelector];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }

    for (const sel of ['[contenteditable="true"]', 'textarea', '[role="textbox"]']) {
      const el = document.querySelector(sel);
      if (el) return el;
    }

    return null;
  }

  function isContentEditable(el) {
    return el && (el.isContentEditable || el.getAttribute('contenteditable') === 'true');
  }

  function isTextarea(el) {
    return el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT');
  }

  function injectExecCommand(el, text) {
    el.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);

    const success = document.execCommand('insertText', false, text);
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: text,
    }));
    return success !== false;
  }

  function injectDirectInput(el, text) {
    el.focus();
    el.innerText = text;
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertFromPaste',
    }));
    return true;
  }

  function injectNativeSetter(el, text) {
    const proto = el instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) {
      descriptor.set.call(el, text);
    } else {
      el.value = text;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.focus();
    el.setSelectionRange(text.length, text.length);
    return true;
  }

  async function injectContext(platformName, text) {
    const inputEl = findPlatformInput(platformName);
    if (!inputEl) {
      await copyToClipboard(text);
      return { success: false, fallbackUsed: true, clipboard: true, error: 'No input element found' };
    }

    let success = false;
    let fallbackUsed = false;

    if (isContentEditable(inputEl)) {
      success = injectExecCommand(inputEl, text);
      if (!success) {
        injectDirectInput(inputEl, text);
        success = true;
        fallbackUsed = true;
      }
    } else if (isTextarea(inputEl)) {
      try {
        injectNativeSetter(inputEl, text);
        success = true;
      } catch (e) {
        inputEl.value = text;
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        success = true;
        fallbackUsed = true;
      }
    } else {
      try {
        injectExecCommand(inputEl, text);
        success = true;
        fallbackUsed = true;
      } catch (e) {
        await copyToClipboard(text);
        return { success: false, fallbackUsed: true, clipboard: true, error: e.message };
      }
    }

    setTimeout(() => {
      if (inputEl) {
        inputEl.selectionStart = inputEl.selectionEnd = (inputEl.value || '').length;
        inputEl.focus();
      }
    }, 50);

    return { success, fallbackUsed, clipboard: false };
  }

  async function injectContextPrepend(platformName, contextBlock) {
    const SEPARATOR = '\n--- Bookmark Context ---\n';
    const END_SEPARATOR = '\n--- End Bookmark Context ---\n';
    const inputEl = findPlatformInput(platformName);
    if (!inputEl) {
      await copyToClipboard(contextBlock);
      return { success: false, fallbackUsed: true, clipboard: true, error: 'No input element found' };
    }

    let success = false;
    let fallbackUsed = false;
    const fullBlock = SEPARATOR + contextBlock + END_SEPARATOR;

    if (isContentEditable(inputEl)) {
      const currentText = inputEl.innerText || inputEl.textContent || '';
      if (currentText.includes('--- Bookmark Context ---')) {
        return { success: true, alreadyInjected: true, fallbackUsed: false };
      }
      inputEl.focus();
      inputEl.innerHTML = (fullBlock + currentText).replace(/\n/g, '<br>');
      inputEl.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertFromPaste',
      }));
      try {
        const sel = window.getSelection();
        const lastEl = inputEl.lastElementChild || inputEl.lastChild;
        if (sel && lastEl) {
          const range = document.createRange();
          range.setStartAfter(lastEl);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
        }
      } catch (e) {
      }
      success = true;
    } else if (isTextarea(inputEl)) {
      const currentVal = inputEl.value || '';
      if (currentVal.includes('--- Bookmark Context ---')) {
        return { success: true, alreadyInjected: true, fallbackUsed: false };
      }
      const newVal = fullBlock + currentVal;
      try {
        const proto = inputEl instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
        const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
        if (descriptor && descriptor.set) {
          descriptor.set.call(inputEl, newVal);
        } else {
          inputEl.value = newVal;
        }
      } catch (e) {
        inputEl.value = newVal;
      }
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      inputEl.focus();
      inputEl.setSelectionRange(newVal.length, newVal.length);
      success = true;
    } else {
      const currentText = inputEl.innerText || inputEl.textContent || '';
      if (currentText.includes('--- Bookmark Context ---')) {
        return { success: true, alreadyInjected: true, fallbackUsed: false };
      }
      injectDirectInput(inputEl, fullBlock + currentText);
      success = true;
      fallbackUsed = true;
    }

    return { success, fallbackUsed, clipboard: false };
  }

  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    }
  }

  globalThis.findPlatformInput = findPlatformInput;
  globalThis.injectContext = injectContext;
  globalThis.injectContextPrepend = injectContextPrepend;
})();
