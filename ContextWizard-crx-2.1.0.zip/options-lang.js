// Sets the <html> lang attribute before the page renders localized strings.
(function setUILang() {
  const uiLocaleMessage = (typeof chrome !== 'undefined' && chrome.i18n && typeof chrome.i18n.getMessage === 'function'
    ? chrome.i18n.getMessage('@@ui_locale')
    : '') || '';
  const browserLocale = (typeof navigator !== 'undefined' && navigator.language) || '';
  const rawLocale = uiLocaleMessage || browserLocale || 'en';
  document.documentElement.lang = rawLocale.replace('_', '-');
})();
