// RelevanceScorer — 纯 JS 关键词 + TF-IDF 语义评分
// 加载方式: content script (CONTENT_SCRIPT_FILES), 通过 globalThis 共享

(function () {
  'use strict';

  function tokenize(text) {
    if (!text) return [];
    const lower = text.toLowerCase();
    const tokens = [];
    for (const word of lower.split(/[^\p{L}\p{N}]+/u)) {
      if (word.length === 0) continue;
      if (/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/.test(word)) {
        for (const char of word) {
          tokens.push(char);
        }
      } else {
        tokens.push(word);
      }
    }
    return tokens;
  }

  function jaccardSimilarity(a, b) {
    if (a.length === 0 && b.length === 0) return 1;
    const setA = new Set(a);
    const setB = new Set(b);
    let intersection = 0;
    let union = new Set(setA);
    for (const item of setB) union.add(item);
    for (const item of setB) {
      if (setA.has(item)) intersection++;
    }
    return union.size === 0 ? 0 : intersection / union.size;
  }

  class RelevanceScorer {
    constructor() {
      this.corpusBuilt = false;
      this.docFreq = new Map();
      this.numDocs = 0;
      this.bookmarkVectors = null;
    }

    buildCorpus(bookmarks) {
      this.docFreq = new Map();
      this.numDocs = bookmarks.length;
      this.bookmarkVectors = new Map();

      for (const bm of bookmarks) {
        const text = [bm.annotation || '', bm.content || '', bm.selectedText || ''].join(' ').trim();
        const tokens = tokenize(text);
        const seen = new Set();
        for (const t of tokens) {
          if (!seen.has(t)) {
            seen.add(t);
            this.docFreq.set(t, (this.docFreq.get(t) || 0) + 1);
          }
        }
        this.bookmarkVectors.set(bm.id, tokens);
      }

      this.corpusBuilt = true;
    }

    score_keyword(query, bookmark) {
      const queryTokens = tokenize(query);
      const bmTokens = tokenize([bookmark.annotation || '', bookmark.content || '', bookmark.selectedText || ''].join(' '));
      const base = jaccardSimilarity(queryTokens, bmTokens);

      let tfWeight = 0;
      if (bmTokens.length > 0) {
        for (const qt of queryTokens) {
          const count = bmTokens.filter(t => t === qt).length;
          tfWeight += count / bmTokens.length;
        }
      }

      return Math.min(1, base * 0.6 + tfWeight * 0.4);
    }

    score_semantic(query, bookmark) {
      if (!this.corpusBuilt || this.numDocs === 0) return 0;

      const queryTokens = tokenize(query);
      const queryTF = new Map();
      for (const t of queryTokens) {
        queryTF.set(t, (queryTF.get(t) || 0) + 1);
      }

      const bmTokens = this.bookmarkVectors.get(bookmark.id) || [];
      const bmTF = new Map();
      for (const t of bmTokens) {
        bmTF.set(t, (bmTF.get(t) || 0) + 1);
      }

      const allTerms = new Set([...queryTF.keys(), ...bmTF.keys()]);
      const idf = (term) => {
        const df = this.docFreq.get(term) || 0;
        return df === 0 ? 0 : Math.log((this.numDocs + 1) / (df + 1)) + 1;
      };

      let dotProduct = 0;
      let qMagnitude = 0;
      let bmMagnitude = 0;

      for (const term of allTerms) {
        const w = idf(term);
        const qVal = (queryTF.get(term) || 0) > 0 ? (1 + Math.log((queryTF.get(term) || 0))) * w : 0;
        const bVal = (bmTF.get(term) || 0) > 0 ? (1 + Math.log((bmTF.get(term) || 0))) * w : 0;
        dotProduct += qVal * bVal;
        qMagnitude += qVal * qVal;
        bmMagnitude += bVal * bVal;
      }

      const magnitude = Math.sqrt(qMagnitude) * Math.sqrt(bmMagnitude);
      return magnitude === 0 ? 0 : dotProduct / magnitude;
    }

    finalScore(query, bookmark) {
      return 0.4 * this.score_keyword(query, bookmark) + 0.6 * this.score_semantic(query, bookmark);
    }

    scoreAll(query, bookmarks) {
      if (!this.corpusBuilt && bookmarks && bookmarks.length > 0) {
        this.buildCorpus(bookmarks);
      }

      const results = [];
      for (const bm of bookmarks) {
        const score = this.finalScore(query, bm);
        let level = 'low';
        if (score > 0.6) level = 'high';
        else if (score >= 0.3) level = 'medium';
        const bookmarkName = bm.annotation
          ? bm.annotation.replace(/\n/g, ' ').slice(0, 60)
          : (bm.content ? bm.content.replace(/\n/g, ' ').slice(0, 60) : bm.selectedText?.slice(0, 60) || '');
        results.push({ bookmarkId: bm.id, bookmarkName, score, level });
      }

      results.sort((a, b) => b.score - a.score);
      return results;
    }
  }

  globalThis.RelevanceScorer = RelevanceScorer;
})();
